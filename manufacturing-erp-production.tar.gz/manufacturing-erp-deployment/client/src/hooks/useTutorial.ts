import { useState, useEffect } from "react";

interface TutorialState {
  isActive: boolean;
  hasCompletedOnboarding: boolean;
  currentTutorialStep: string | null;
  skipCount: number;
}

const TUTORIAL_STORAGE_KEY = "manufacturing-erp-tutorial";

export function useTutorial() {
  const [tutorialState, setTutorialState] = useState<TutorialState>(() => {
    const stored = localStorage.getItem(TUTORIAL_STORAGE_KEY);
    if (stored) {
      try {
        return JSON.parse(stored);
      } catch {
        // Fallback to default state
      }
    }
    return {
      isActive: false,
      hasCompletedOnboarding: false,
      currentTutorialStep: null,
      skipCount: 0,
    };
  });

  const saveTutorialState = (newState: TutorialState) => {
    setTutorialState(newState);
    localStorage.setItem(TUTORIAL_STORAGE_KEY, JSON.stringify(newState));
  };

  const startOnboarding = () => {
    saveTutorialState({
      ...tutorialState,
      isActive: true,
      currentTutorialStep: "welcome",
    });
  };

  const completeOnboarding = () => {
    saveTutorialState({
      ...tutorialState,
      isActive: false,
      hasCompletedOnboarding: true,
      currentTutorialStep: null,
    });
  };

  const skipOnboarding = () => {
    saveTutorialState({
      ...tutorialState,
      isActive: false,
      hasCompletedOnboarding: true,
      currentTutorialStep: null,
      skipCount: tutorialState.skipCount + 1,
    });
  };

  const resetTutorial = () => {
    saveTutorialState({
      isActive: false,
      hasCompletedOnboarding: false,
      currentTutorialStep: null,
      skipCount: 0,
    });
  };

  const startContextualTutorial = (step: string) => {
    saveTutorialState({
      ...tutorialState,
      isActive: true,
      currentTutorialStep: step,
    });
  };

  const endContextualTutorial = () => {
    saveTutorialState({
      ...tutorialState,
      isActive: false,
      currentTutorialStep: null,
    });
  };

  // Auto-start onboarding for new users
  useEffect(() => {
    const checkAutoStart = () => {
      // Start onboarding if user hasn't completed it and hasn't skipped too many times
      if (!tutorialState.hasCompletedOnboarding && tutorialState.skipCount < 3) {
        const lastSkipTime = localStorage.getItem("tutorial-last-skip");
        const now = Date.now();
        
        if (!lastSkipTime || now - parseInt(lastSkipTime) > 24 * 60 * 60 * 1000) {
          // Auto-start after 24 hours or for new users
          setTimeout(() => {
            if (!tutorialState.isActive) {
              startOnboarding();
            }
          }, 2000); // Wait 2 seconds for app to load
        }
      }
    };

    checkAutoStart();
  }, [tutorialState.hasCompletedOnboarding, tutorialState.skipCount, tutorialState.isActive]);

  return {
    ...tutorialState,
    startOnboarding,
    completeOnboarding,
    skipOnboarding,
    resetTutorial,
    startContextualTutorial,
    endContextualTutorial,
  };
}