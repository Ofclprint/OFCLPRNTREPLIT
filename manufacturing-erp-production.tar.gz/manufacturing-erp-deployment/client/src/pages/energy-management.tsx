import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import Sidebar from "@/components/layout/sidebar";
import { 
  Zap, 
  TrendingUp, 
  TrendingDown, 
  Battery,
  Gauge,
  Lightbulb,
  Wind,
  Sun,
  AlertTriangle,
  CheckCircle,
  Settings,
  Target,
  Calendar,
  DollarSign,
  Leaf,
  Activity,
  BarChart3,
  RefreshCw,
  Power,
  ThermometerSun
} from "lucide-react";
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  RadialBarChart,
  RadialBar
} from "recharts";

interface EnergyDevice {
  id: string;
  name: string;
  type: "machine" | "lighting" | "hvac" | "compressor" | "other";
  zone: string;
  status: "online" | "offline" | "maintenance";
  powerConsumption: number; // kW
  efficiency: number; // percentage
  operatingHours: number;
  energyCost: number; // daily cost
  carbonFootprint: number; // kg CO2
  lastMaintenance: string;
  predictedFailure?: string;
  isControllable: boolean;
}

interface EnergyAlert {
  id: string;
  type: "high_consumption" | "efficiency_drop" | "peak_demand" | "carbon_limit";
  severity: "low" | "medium" | "high" | "critical";
  deviceId?: string;
  deviceName?: string;
  message: string;
  timestamp: string;
  resolved: boolean;
  suggestedAction?: string;
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#FF6B6B'];

export default function EnergyManagement() {
  const [selectedTimeRange, setSelectedTimeRange] = useState("24h");
  const [selectedZone, setSelectedZone] = useState("all");
  const [autoOptimization, setAutoOptimization] = useState(true);
  const [peakDemandMode, setPeakDemandMode] = useState(false);

  // Fetch energy data
  const { data: energyData, isLoading, refetch } = useQuery({
    queryKey: ["/api/energy/overview", selectedTimeRange, selectedZone],
    refetchInterval: 30000, // Refresh every 30 seconds
    staleTime: 0,
  });

  // Sample energy devices data
  const energyDevices: EnergyDevice[] = [
    {
      id: "E001",
      name: "CNC Machine Line A",
      type: "machine",
      zone: "Production Floor 1",
      status: "online",
      powerConsumption: 25.4,
      efficiency: 87,
      operatingHours: 18.5,
      energyCost: 152.40,
      carbonFootprint: 45.2,
      lastMaintenance: "2024-11-15",
      isControllable: true
    },
    {
      id: "E002",
      name: "Assembly Line Conveyor",
      type: "machine",
      zone: "Production Floor 2",
      status: "online",
      powerConsumption: 12.8,
      efficiency: 92,
      operatingHours: 22.0,
      energyCost: 76.80,
      carbonFootprint: 22.8,
      lastMaintenance: "2024-12-01",
      isControllable: true
    },
    {
      id: "E003",
      name: "Industrial HVAC System",
      type: "hvac",
      zone: "Facility Wide",
      status: "online",
      powerConsumption: 45.2,
      efficiency: 78,
      operatingHours: 24.0,
      energyCost: 271.20,
      carbonFootprint: 80.6,
      lastMaintenance: "2024-10-20",
      predictedFailure: "2025-02-15",
      isControllable: true
    },
    {
      id: "E004",
      name: "LED Lighting System",
      type: "lighting",
      zone: "Production Floor 1",
      status: "online",
      powerConsumption: 8.6,
      efficiency: 95,
      operatingHours: 16.0,
      energyCost: 41.28,
      carbonFootprint: 15.3,
      lastMaintenance: "2024-09-10",
      isControllable: true
    },
    {
      id: "E005",
      name: "Air Compressor Unit",
      type: "compressor",
      zone: "Utility Room",
      status: "maintenance",
      powerConsumption: 0,
      efficiency: 0,
      operatingHours: 0,
      energyCost: 0,
      carbonFootprint: 0,
      lastMaintenance: "2024-12-16",
      isControllable: false
    }
  ];

  // Sample energy consumption data over time
  const consumptionTrends = [
    { time: '00:00', total: 85.4, production: 45.2, hvac: 28.5, lighting: 11.7 },
    { time: '04:00', total: 78.2, production: 38.1, hvac: 26.8, lighting: 13.3 },
    { time: '08:00', total: 125.6, production: 78.4, hvac: 32.1, lighting: 15.1 },
    { time: '12:00', total: 142.8, production: 89.7, hvac: 35.6, lighting: 17.5 },
    { time: '16:00', total: 135.2, production: 82.3, hvac: 34.2, lighting: 18.7 },
    { time: '20:00', total: 95.4, production: 52.1, hvac: 29.8, lighting: 13.5 }
  ];

  // Energy efficiency by zone
  const zoneEfficiency = [
    { zone: 'Production Floor 1', efficiency: 89, target: 92, consumption: 34.0 },
    { zone: 'Production Floor 2', efficiency: 91, target: 94, consumption: 28.5 },
    { zone: 'Quality Control', efficiency: 85, target: 88, consumption: 15.2 },
    { zone: 'Utility Room', efficiency: 76, target: 82, consumption: 22.8 },
    { zone: 'Administrative', efficiency: 93, target: 95, consumption: 8.4 }
  ];

  // Carbon footprint breakdown
  const carbonData = [
    { name: 'Production Machines', value: 45, emissions: 68.0 },
    { name: 'HVAC Systems', value: 35, emissions: 52.5 },
    { name: 'Lighting', value: 10, emissions: 15.0 },
    { name: 'Support Equipment', value: 10, emissions: 15.0 }
  ];

  // Peak demand data
  const peakDemandData = [
    { hour: 1, demand: 85, cost: 8.5 },
    { hour: 2, demand: 78, cost: 7.8 },
    { hour: 3, demand: 142, cost: 17.8 },
    { hour: 4, demand: 156, cost: 23.4 },
    { hour: 5, demand: 148, cost: 19.2 },
    { hour: 6, demand: 92, cost: 9.2 }
  ];

  // Sample alerts
  const energyAlerts: EnergyAlert[] = [
    {
      id: "A001",
      type: "high_consumption",
      severity: "high",
      deviceId: "E003",
      deviceName: "Industrial HVAC System",
      message: "HVAC system consuming 15% above normal levels",
      timestamp: "2024-12-16 14:30",
      resolved: false,
      suggestedAction: "Check air filters and optimize temperature settings"
    },
    {
      id: "A002",
      type: "efficiency_drop",
      severity: "medium",
      deviceId: "E001",
      deviceName: "CNC Machine Line A",
      message: "Machine efficiency dropped to 87% from 92% baseline",
      timestamp: "2024-12-16 13:15",
      resolved: false,
      suggestedAction: "Schedule maintenance check for cutting tools"
    },
    {
      id: "A003",
      type: "peak_demand",
      severity: "critical",
      message: "Approaching peak demand threshold (95% of limit)",
      timestamp: "2024-12-16 14:45",
      resolved: false,
      suggestedAction: "Defer non-critical equipment startup by 2 hours"
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "online":
        return "bg-green-100 text-green-800";
      case "offline":
        return "bg-red-100 text-red-800";
      case "maintenance":
        return "bg-yellow-100 text-yellow-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "online":
        return <CheckCircle className="w-4 h-4" />;
      case "offline":
        return <AlertTriangle className="w-4 h-4" />;
      case "maintenance":
        return <Settings className="w-4 h-4" />;
      default:
        return <Power className="w-4 h-4" />;
    }
  };

  const getDeviceIcon = (type: string) => {
    switch (type) {
      case "machine":
        return <Settings className="w-5 h-5" />;
      case "lighting":
        return <Lightbulb className="w-5 h-5" />;
      case "hvac":
        return <Wind className="w-5 h-5" />;
      case "compressor":
        return <Activity className="w-5 h-5" />;
      default:
        return <Zap className="w-5 h-5" />;
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "low":
        return "bg-blue-100 text-blue-800";
      case "medium":
        return "bg-yellow-100 text-yellow-800";
      case "high":
        return "bg-orange-100 text-orange-800";
      case "critical":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const totalConsumption = energyDevices.reduce((sum, device) => sum + device.powerConsumption, 0);
  const totalCost = energyDevices.reduce((sum, device) => sum + device.energyCost, 0);
  const totalCarbon = energyDevices.reduce((sum, device) => sum + device.carbonFootprint, 0);
  const avgEfficiency = Math.round(energyDevices.reduce((sum, device) => sum + device.efficiency, 0) / energyDevices.filter(d => d.status === "online").length);
  const activeDevices = energyDevices.filter(device => device.status === "online").length;

  const filteredDevices = selectedZone === "all" 
    ? energyDevices 
    : energyDevices.filter(device => device.zone === selectedZone);

  return (
    <div className="flex h-screen bg-carbon-gray-10">
      <Sidebar />
      <div className="flex-1 overflow-auto">
        <div className="p-6 space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-carbon-gray-80">Energy Management</h1>
              <p className="text-carbon-gray-60">Monitor, optimize, and control facility energy consumption</p>
            </div>
            <div className="flex items-center space-x-3">
              <div className="flex items-center space-x-2">
                <div className={`w-2 h-2 rounded-full ${isLoading ? 'bg-blue-500 animate-pulse' : 'bg-green-500'}`} />
                <span className="text-sm text-carbon-gray-60">
                  {isLoading ? 'Updating...' : 'Live Data'}
                </span>
              </div>
              <Select value={selectedTimeRange} onValueChange={setSelectedTimeRange}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1h">Last Hour</SelectItem>
                  <SelectItem value="24h">Last 24h</SelectItem>
                  <SelectItem value="7d">Last 7 days</SelectItem>
                  <SelectItem value="30d">Last 30 days</SelectItem>
                </SelectContent>
              </Select>
              <Select value={selectedZone} onValueChange={setSelectedZone}>
                <SelectTrigger className="w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Zones</SelectItem>
                  <SelectItem value="Production Floor 1">Production Floor 1</SelectItem>
                  <SelectItem value="Production Floor 2">Production Floor 2</SelectItem>
                  <SelectItem value="Utility Room">Utility Room</SelectItem>
                  <SelectItem value="Facility Wide">Facility Wide</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" onClick={() => refetch()}>
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh
              </Button>
            </div>
          </div>

          {/* Real-time Overview Cards */}
          <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Zap className="w-5 h-5 text-blue-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Total Consumption</p>
                    <p className="text-xl font-bold">{totalConsumption.toFixed(1)} kW</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Power className="w-5 h-5 text-green-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Active Devices</p>
                    <p className="text-xl font-bold">{activeDevices}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Target className="w-5 h-5 text-purple-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Avg Efficiency</p>
                    <p className="text-xl font-bold">{avgEfficiency}%</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <DollarSign className="w-5 h-5 text-orange-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Daily Cost</p>
                    <p className="text-xl font-bold">${totalCost.toFixed(0)}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Leaf className="w-5 h-5 text-green-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">CO2 Emissions</p>
                    <p className="text-xl font-bold">{totalCarbon.toFixed(1)} kg</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <AlertTriangle className="w-5 h-5 text-red-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Active Alerts</p>
                    <p className="text-xl font-bold">{energyAlerts.filter(a => !a.resolved).length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Smart Controls */}
          <Card className="border-carbon-gray-20">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Settings className="w-5 h-5 text-carbon-blue" />
                <span>Smart Energy Controls</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <h4 className="font-medium">Auto Optimization</h4>
                    <p className="text-sm text-gray-600">Automatically optimize energy usage based on demand patterns</p>
                  </div>
                  <Switch 
                    checked={autoOptimization} 
                    onCheckedChange={setAutoOptimization}
                  />
                </div>
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <h4 className="font-medium">Peak Demand Mode</h4>
                    <p className="text-sm text-gray-600">Reduce consumption during peak pricing periods</p>
                  </div>
                  <Switch 
                    checked={peakDemandMode} 
                    onCheckedChange={setPeakDemandMode}
                  />
                </div>
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <h4 className="font-medium">Emergency Load Shed</h4>
                    <p className="text-sm text-gray-600">Enable automatic load shedding during emergencies</p>
                  </div>
                  <Button variant="outline" size="sm">
                    Configure
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Main Content Tabs */}
          <Tabs defaultValue="overview" className="space-y-4">
            <TabsList>
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="devices">Devices</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
              <TabsTrigger value="alerts">Alerts</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="border-carbon-gray-20">
                  <CardHeader>
                    <CardTitle>Real-time Consumption</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <AreaChart data={consumptionTrends}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="time" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Area type="monotone" dataKey="production" stackId="1" stroke="#0088FE" fill="#0088FE" name="Production" />
                        <Area type="monotone" dataKey="hvac" stackId="1" stroke="#00C49F" fill="#00C49F" name="HVAC" />
                        <Area type="monotone" dataKey="lighting" stackId="1" stroke="#FFBB28" fill="#FFBB28" name="Lighting" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card className="border-carbon-gray-20">
                  <CardHeader>
                    <CardTitle>Zone Efficiency</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {zoneEfficiency.map((zone, index) => (
                        <div key={index} className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span className="font-medium">{zone.zone}</span>
                            <span>{zone.efficiency}% / {zone.target}%</span>
                          </div>
                          <div className="flex space-x-2">
                            <Progress value={zone.efficiency} className="flex-1 h-2" />
                            <span className="text-xs text-gray-600 w-16">{zone.consumption} kW</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-carbon-gray-20">
                  <CardHeader>
                    <CardTitle>Carbon Footprint</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <PieChart>
                        <Pie
                          data={carbonData}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={({ name, value }) => `${name} ${value}%`}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                        >
                          {carbonData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card className="border-carbon-gray-20">
                  <CardHeader>
                    <CardTitle>Peak Demand Management</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={peakDemandData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="hour" />
                        <YAxis />
                        <Tooltip />
                        <Bar dataKey="demand" fill="#8884d8" name="Demand (kW)" />
                        <Bar dataKey="cost" fill="#82ca9d" name="Cost ($)" />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="devices" className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                {filteredDevices.map((device) => (
                  <Card key={device.id} className="border-carbon-gray-20">
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          {getDeviceIcon(device.type)}
                          <CardTitle className="text-lg">{device.name}</CardTitle>
                        </div>
                        <Badge className={getStatusColor(device.status)}>
                          {getStatusIcon(device.status)}
                          <span className="ml-1 capitalize">{device.status}</span>
                        </Badge>
                      </div>
                      <p className="text-sm text-carbon-gray-60">{device.zone}</p>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {/* Power Consumption */}
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Power Consumption</span>
                        <span className="font-bold text-lg">{device.powerConsumption} kW</span>
                      </div>

                      {/* Efficiency */}
                      {device.status === "online" && (
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span>Efficiency</span>
                            <span className="font-medium">{device.efficiency}%</span>
                          </div>
                          <Progress value={device.efficiency} className="h-2" />
                        </div>
                      )}

                      {/* Metrics Grid */}
                      <div className="grid grid-cols-2 gap-3">
                        <div className="text-center p-2 bg-gray-50 rounded">
                          <p className="text-xs text-gray-600">Operating Hours</p>
                          <p className="font-medium">{device.operatingHours}h</p>
                        </div>
                        <div className="text-center p-2 bg-gray-50 rounded">
                          <p className="text-xs text-gray-600">Daily Cost</p>
                          <p className="font-medium">${device.energyCost.toFixed(0)}</p>
                        </div>
                        <div className="text-center p-2 bg-gray-50 rounded">
                          <p className="text-xs text-gray-600">CO2 Emissions</p>
                          <p className="font-medium">{device.carbonFootprint} kg</p>
                        </div>
                        <div className="text-center p-2 bg-gray-50 rounded">
                          <p className="text-xs text-gray-600">Last Maintenance</p>
                          <p className="font-medium text-xs">{device.lastMaintenance}</p>
                        </div>
                      </div>

                      {/* Predicted Failure Warning */}
                      {device.predictedFailure && (
                        <div className="flex items-start space-x-2 p-2 bg-orange-50 border border-orange-200 rounded">
                          <AlertTriangle className="w-4 h-4 text-orange-600 mt-0.5" />
                          <div>
                            <p className="text-sm font-medium text-orange-800">Maintenance Due</p>
                            <p className="text-xs text-orange-700">Predicted failure: {device.predictedFailure}</p>
                          </div>
                        </div>
                      )}

                      {/* Controls */}
                      <div className="flex space-x-2 pt-2">
                        <Button variant="outline" size="sm" className="flex-1">
                          <BarChart3 className="w-4 h-4 mr-1" />
                          Analytics
                        </Button>
                        {device.isControllable && (
                          <Button variant="outline" size="sm" className="flex-1">
                            <Settings className="w-4 h-4 mr-1" />
                            Control
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="analytics" className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="border-carbon-gray-20">
                  <CardHeader>
                    <CardTitle>Energy Consumption Trends</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <LineChart data={consumptionTrends}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="time" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Line type="monotone" dataKey="total" stroke="#0088FE" strokeWidth={2} name="Total Consumption" />
                      </LineChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card className="border-carbon-gray-20">
                  <CardHeader>
                    <CardTitle>Cost Analysis</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center p-3 bg-gray-50 rounded">
                        <span>Today's Energy Cost</span>
                        <span className="font-bold text-lg">${totalCost.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between items-center p-3 bg-gray-50 rounded">
                        <span>Projected Monthly</span>
                        <span className="font-bold text-lg">${(totalCost * 30).toFixed(0)}</span>
                      </div>
                      <div className="flex justify-between items-center p-3 bg-green-50 rounded border border-green-200">
                        <span>Potential Savings</span>
                        <span className="font-bold text-lg text-green-600">${(totalCost * 0.15).toFixed(2)}/day</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-carbon-gray-20">
                  <CardHeader>
                    <CardTitle>Efficiency Comparison</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={zoneEfficiency}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="zone" angle={-45} textAnchor="end" height={80} />
                        <YAxis />
                        <Tooltip />
                        <Bar dataKey="efficiency" fill="#8884d8" name="Current Efficiency %" />
                        <Bar dataKey="target" fill="#82ca9d" name="Target Efficiency %" />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card className="border-carbon-gray-20">
                  <CardHeader>
                    <CardTitle>Sustainability Metrics</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between text-sm mb-2">
                          <span>Carbon Reduction Goal</span>
                          <span>75% of target</span>
                        </div>
                        <Progress value={75} className="h-3" />
                      </div>
                      <div>
                        <div className="flex justify-between text-sm mb-2">
                          <span>Renewable Energy Usage</span>
                          <span>42% of total</span>
                        </div>
                        <Progress value={42} className="h-3" />
                      </div>
                      <div>
                        <div className="flex justify-between text-sm mb-2">
                          <span>Energy Efficiency Rating</span>
                          <span>B+ Grade</span>
                        </div>
                        <Progress value={85} className="h-3" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="alerts" className="space-y-4">
              <div className="space-y-4">
                {energyAlerts.map((alert) => (
                  <Card key={alert.id} className="border-carbon-gray-20">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <Badge className={getSeverityColor(alert.severity)}>
                              <AlertTriangle className="w-3 h-3 mr-1" />
                              {alert.severity.toUpperCase()}
                            </Badge>
                            <span className="text-sm text-gray-600">{alert.timestamp}</span>
                          </div>
                          <h4 className="font-medium mb-1">{alert.message}</h4>
                          {alert.deviceName && (
                            <p className="text-sm text-gray-600 mb-2">Device: {alert.deviceName}</p>
                          )}
                          {alert.suggestedAction && (
                            <div className="bg-blue-50 border border-blue-200 rounded p-2 mt-2">
                              <p className="text-sm text-blue-800">
                                <strong>Suggested Action:</strong> {alert.suggestedAction}
                              </p>
                            </div>
                          )}
                        </div>
                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm">
                            View Details
                          </Button>
                          {!alert.resolved && (
                            <Button size="sm">
                              Resolve
                            </Button>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}