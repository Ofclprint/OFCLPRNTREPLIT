import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import Sidebar from "@/components/layout/sidebar";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  Brain, 
  Cpu,
  TrendingUp,
  TrendingDown,
  Activity,
  Zap,
  Eye,
  Camera,
  AlertTriangle,
  CheckCircle,
  Clock,
  Target,
  BarChart3,
  LineChart,
  PieChart,
  Layers,
  Database,
  Settings,
  Play,
  Pause,
  RefreshCw,
  Plus,
  Edit,
  Trash2,
  Download,
  Upload,
  Filter,
  Search,
  Info,
  AlertCircle,
  Star,
  Award,
  Wrench,
  Package,
  Shield,
  Gauge,
  Calendar,
  Timer,
  Users,
  Factory,
  Thermometer,
  Vibrate,
  Radio,
  Workflow,
  Network,
  GitBranch,
  Code,
  FileText,
  Image,
  Video,
  Microscope,
  Scan,
  MoreHorizontal
} from "lucide-react";

const mlModelSchema = z.object({
  name: z.string().min(1, "Model name is required"),
  description: z.string().min(1, "Description is required"),
  type: z.enum(["predictive_maintenance", "quality_prediction", "demand_forecasting", "anomaly_detection", "optimization"]),
  algorithm: z.enum(["random_forest", "neural_network", "svm", "linear_regression", "lstm", "cnn", "xgboost"]),
  dataSource: z.string().min(1, "Data source is required"),
  targetVariable: z.string().min(1, "Target variable is required"),
  features: z.array(z.string()).min(1, "At least one feature is required"),
  trainingFrequency: z.enum(["daily", "weekly", "monthly", "quarterly"]),
  predictionHorizon: z.number().min(1, "Prediction horizon must be at least 1"),
  accuracy: z.number().min(0).max(100).optional(),
  isActive: z.boolean().default(true),
});

const aiInsightSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().min(1, "Description is required"),
  category: z.enum(["maintenance", "quality", "production", "inventory", "energy", "safety"]),
  priority: z.enum(["low", "medium", "high", "critical"]),
  confidence: z.number().min(0).max(100),
  actionRequired: z.boolean().default(false),
  recommendations: z.array(z.string()).optional(),
  affectedAssets: z.array(z.string()).optional(),
  estimatedImpact: z.string().optional(),
});

interface MLModel {
  id: string;
  name: string;
  description: string;
  type: "predictive_maintenance" | "quality_prediction" | "demand_forecasting" | "anomaly_detection" | "optimization";
  algorithm: "random_forest" | "neural_network" | "svm" | "linear_regression" | "lstm" | "cnn" | "xgboost";
  status: "training" | "deployed" | "testing" | "failed" | "inactive";
  version: string;
  accuracy: number;
  precision: number;
  recall: number;
  f1Score: number;
  dataSource: string;
  targetVariable: string;
  features: string[];
  trainingFrequency: "daily" | "weekly" | "monthly" | "quarterly";
  predictionHorizon: number;
  lastTrained: string;
  nextTraining: string;
  totalPredictions: number;
  correctPredictions: number;
  isActive: boolean;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

interface AIPrediction {
  id: string;
  modelId: string;
  modelName: string;
  type: string;
  prediction: any;
  confidence: number;
  actualValue?: any;
  isCorrect?: boolean;
  timestamp: string;
  features: Record<string, any>;
  explanation: string;
  recommendations: string[];
  affectedAssets: string[];
  estimatedImpact: string;
  status: "pending" | "confirmed" | "false_positive" | "investigating";
}

interface AIInsight {
  id: string;
  title: string;
  description: string;
  category: "maintenance" | "quality" | "production" | "inventory" | "energy" | "safety";
  priority: "low" | "medium" | "high" | "critical";
  confidence: number;
  status: "new" | "acknowledged" | "investigating" | "resolved" | "dismissed";
  actionRequired: boolean;
  recommendations: string[];
  affectedAssets: string[];
  estimatedImpact: string;
  relatedPredictions: string[];
  createdAt: string;
  updatedAt: string;
  resolvedAt?: string;
  resolvedBy?: string;
}

interface ComputerVisionModel {
  id: string;
  name: string;
  description: string;
  type: "defect_detection" | "object_recognition" | "measurement" | "classification";
  status: "training" | "deployed" | "testing" | "inactive";
  accuracy: number;
  processingSpeed: number; // images per second
  supportedFormats: string[];
  classes: string[];
  lastTrained: string;
  totalInferences: number;
  isActive: boolean;
}

export default function AIMachineLearning() {
  const [activeTab, setActiveTab] = useState("models");
  const [isModelDialogOpen, setIsModelDialogOpen] = useState(false);
  const [isInsightDialogOpen, setIsInsightDialogOpen] = useState(false);
  const [selectedModel, setSelectedModel] = useState<MLModel | null>(null);
  const [filterType, setFilterType] = useState<string>("all");
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState("");

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const modelForm = useForm<z.infer<typeof mlModelSchema>>({
    resolver: zodResolver(mlModelSchema),
    defaultValues: {
      type: "predictive_maintenance",
      algorithm: "random_forest",
      trainingFrequency: "weekly",
      predictionHorizon: 7,
      isActive: true,
      features: [],
    },
  });

  const insightForm = useForm<z.infer<typeof aiInsightSchema>>({
    resolver: zodResolver(aiInsightSchema),
    defaultValues: {
      category: "maintenance",
      priority: "medium",
      confidence: 85,
      actionRequired: false,
      recommendations: [],
      affectedAssets: [],
    },
  });

  // Sample ML models data
  const sampleModels: MLModel[] = [
    {
      id: "model_001",
      name: "CNC Machine Failure Prediction",
      description: "Predicts potential failures in CNC machines based on sensor data and maintenance history",
      type: "predictive_maintenance",
      algorithm: "random_forest",
      status: "deployed",
      version: "2.1.3",
      accuracy: 92.5,
      precision: 89.3,
      recall: 94.7,
      f1Score: 91.9,
      dataSource: "machine_sensors",
      targetVariable: "failure_probability",
      features: ["vibration", "temperature", "pressure", "speed", "age", "maintenance_history"],
      trainingFrequency: "weekly",
      predictionHorizon: 7,
      lastTrained: "2024-12-15 02:00:00",
      nextTraining: "2024-12-22 02:00:00",
      totalPredictions: 1547,
      correctPredictions: 1431,
      isActive: true,
      createdBy: "Dr. Sarah ML Engineer",
      createdAt: "2024-10-01 10:00:00",
      updatedAt: "2024-12-15 02:30:00"
    },
    {
      id: "model_002",
      name: "Quality Defect Prediction",
      description: "Predicts quality defects based on production parameters and environmental conditions",
      type: "quality_prediction",
      algorithm: "neural_network",
      status: "deployed",
      version: "1.8.2",
      accuracy: 87.2,
      precision: 85.6,
      recall: 89.1,
      f1Score: 87.3,
      dataSource: "production_data",
      targetVariable: "defect_probability",
      features: ["temperature", "humidity", "pressure", "material_quality", "operator_skill", "machine_speed"],
      trainingFrequency: "daily",
      predictionHorizon: 1,
      lastTrained: "2024-12-17 01:00:00",
      nextTraining: "2024-12-18 01:00:00",
      totalPredictions: 3245,
      correctPredictions: 2830,
      isActive: true,
      createdBy: "Mike Quality AI",
      createdAt: "2024-11-01 14:00:00",
      updatedAt: "2024-12-17 01:30:00"
    },
    {
      id: "model_003",
      name: "Demand Forecasting Model",
      description: "Forecasts product demand based on historical sales, market trends, and external factors",
      type: "demand_forecasting",
      algorithm: "lstm",
      status: "deployed",
      version: "3.0.1",
      accuracy: 84.7,
      precision: 82.3,
      recall: 86.9,
      f1Score: 84.5,
      dataSource: "sales_data",
      targetVariable: "demand_forecast",
      features: ["historical_sales", "seasonality", "promotions", "market_trends", "economic_indicators"],
      trainingFrequency: "monthly",
      predictionHorizon: 30,
      lastTrained: "2024-12-01 03:00:00",
      nextTraining: "2025-01-01 03:00:00",
      totalPredictions: 892,
      correctPredictions: 756,
      isActive: true,
      createdBy: "Lisa Forecast Analyst",
      createdAt: "2024-09-15 11:00:00",
      updatedAt: "2024-12-01 03:30:00"
    },
    {
      id: "model_004",
      name: "Energy Consumption Optimizer",
      description: "Optimizes energy consumption patterns to reduce costs and improve efficiency",
      type: "optimization",
      algorithm: "xgboost",
      status: "testing",
      version: "1.2.0",
      accuracy: 78.4,
      precision: 76.8,
      recall: 80.1,
      f1Score: 78.4,
      dataSource: "energy_data",
      targetVariable: "optimal_consumption",
      features: ["production_schedule", "weather", "electricity_prices", "equipment_efficiency"],
      trainingFrequency: "weekly",
      predictionHorizon: 7,
      lastTrained: "2024-12-14 04:00:00",
      nextTraining: "2024-12-21 04:00:00",
      totalPredictions: 234,
      correctPredictions: 184,
      isActive: false,
      createdBy: "Tom Energy Analyst",
      createdAt: "2024-12-01 09:00:00",
      updatedAt: "2024-12-14 04:30:00"
    },
    {
      id: "model_005",
      name: "Production Anomaly Detector",
      description: "Detects anomalies in production processes using real-time sensor data",
      type: "anomaly_detection",
      algorithm: "neural_network",
      status: "training",
      version: "0.9.5",
      accuracy: 0,
      precision: 0,
      recall: 0,
      f1Score: 0,
      dataSource: "production_sensors",
      targetVariable: "anomaly_score",
      features: ["line_speed", "temperature", "pressure", "vibration", "current_draw", "output_quality"],
      trainingFrequency: "daily",
      predictionHorizon: 1,
      lastTrained: "2024-12-16 23:00:00",
      nextTraining: "2024-12-17 23:00:00",
      totalPredictions: 0,
      correctPredictions: 0,
      isActive: false,
      createdBy: "Alex Production Engineer",
      createdAt: "2024-12-16 15:00:00",
      updatedAt: "2024-12-16 23:30:00"
    }
  ];

  const samplePredictions: AIPrediction[] = [
    {
      id: "pred_001",
      modelId: "model_001",
      modelName: "CNC Machine Failure Prediction",
      type: "predictive_maintenance",
      prediction: {
        failureRisk: "high",
        daysUntilFailure: 3,
        failureType: "bearing_wear",
        severity: "critical"
      },
      confidence: 89.7,
      timestamp: "2024-12-17 10:30:00",
      features: {
        vibration: 8.7,
        temperature: 78.3,
        pressure: 145.2,
        speed: 1850,
        age: 1245,
        maintenance_history: "overdue"
      },
      explanation: "Elevated vibration levels and overdue maintenance indicate high probability of bearing failure",
      recommendations: [
        "Schedule immediate maintenance inspection",
        "Replace bearing assembly within 24 hours",
        "Monitor vibration levels every 2 hours",
        "Prepare backup machine for production continuity"
      ],
      affectedAssets: ["CNC-Machine-003", "Production-Line-A"],
      estimatedImpact: "$45,000 production loss if failure occurs",
      status: "pending"
    },
    {
      id: "pred_002",
      modelId: "model_002",
      modelName: "Quality Defect Prediction",
      type: "quality_prediction",
      prediction: {
        defectProbability: 0.78,
        defectType: "surface_finish",
        severity: "medium",
        affectedUnits: 45
      },
      confidence: 82.3,
      actualValue: {
        defectProbability: 0.74,
        actualDefects: 38
      },
      isCorrect: true,
      timestamp: "2024-12-17 09:15:00",
      features: {
        temperature: 24.8,
        humidity: 67.2,
        pressure: 1013.2,
        material_quality: "grade_b",
        operator_skill: "intermediate",
        machine_speed: 850
      },
      explanation: "High humidity and Grade B material quality increase surface finish defect probability",
      recommendations: [
        "Adjust climate control to reduce humidity to <60%",
        "Switch to Grade A material for next batch",
        "Reduce machine speed to 750 RPM",
        "Increase quality inspection frequency"
      ],
      affectedAssets: ["Production-Line-B", "Quality-Station-2"],
      estimatedImpact: "$8,200 material waste potential",
      status: "confirmed"
    },
    {
      id: "pred_003",
      modelId: "model_003",
      modelName: "Demand Forecasting Model",
      type: "demand_forecasting",
      prediction: {
        forecastedDemand: 1250,
        trend: "increasing",
        seasonalFactor: 1.15,
        confidence_interval: [1100, 1400]
      },
      confidence: 91.4,
      timestamp: "2024-12-17 08:00:00",
      features: {
        historical_sales: 1087,
        seasonality: "holiday_season",
        promotions: "black_friday",
        market_trends: "positive",
        economic_indicators: "stable"
      },
      explanation: "Holiday season and promotional activities driving increased demand",
      recommendations: [
        "Increase production capacity by 25%",
        "Secure additional raw material inventory",
        "Schedule overtime shifts for next 2 weeks",
        "Coordinate with logistics for increased shipping"
      ],
      affectedAssets: ["Production-Planning", "Inventory-Management", "Logistics"],
      estimatedImpact: "$340,000 additional revenue opportunity",
      status: "confirmed"
    }
  ];

  const sampleInsights: AIInsight[] = [
    {
      id: "insight_001",
      title: "Predictive Maintenance Opportunity",
      description: "Multiple machines showing early warning signs that could be addressed proactively",
      category: "maintenance",
      priority: "high",
      confidence: 87.5,
      status: "new",
      actionRequired: true,
      recommendations: [
        "Schedule maintenance for CNC-003, CNC-007, and Press-002",
        "Order replacement parts for bearing assemblies",
        "Implement vibration monitoring on all critical machines"
      ],
      affectedAssets: ["CNC-Machine-003", "CNC-Machine-007", "Hydraulic-Press-002"],
      estimatedImpact: "Prevent $150,000 in potential downtime costs",
      relatedPredictions: ["pred_001"],
      createdAt: "2024-12-17 10:30:00",
      updatedAt: "2024-12-17 10:30:00"
    },
    {
      id: "insight_002",
      title: "Quality Improvement Opportunity",
      description: "Process optimization could reduce defect rates by implementing environmental controls",
      category: "quality",
      priority: "medium",
      confidence: 79.2,
      status: "acknowledged",
      actionRequired: true,
      recommendations: [
        "Install humidity control system in production area",
        "Implement material quality verification process",
        "Train operators on environmental impact awareness"
      ],
      affectedAssets: ["Production-Line-B", "Quality-Control-Lab"],
      estimatedImpact: "Reduce defect rate by 12%, saving $25,000/month",
      relatedPredictions: ["pred_002"],
      createdAt: "2024-12-17 09:15:00",
      updatedAt: "2024-12-17 11:20:00"
    },
    {
      id: "insight_003",
      title: "Energy Optimization Pattern Detected",
      description: "Significant energy savings possible through optimized production scheduling",
      category: "energy",
      priority: "medium",
      confidence: 82.8,
      status: "investigating",
      actionRequired: false,
      recommendations: [
        "Shift high-energy processes to off-peak hours",
        "Implement dynamic load balancing across production lines",
        "Consider energy storage system for peak shaving"
      ],
      affectedAssets: ["Production-Line-A", "Production-Line-B", "HVAC-System"],
      estimatedImpact: "Potential 18% reduction in energy costs ($8,400/month)",
      relatedPredictions: [],
      createdAt: "2024-12-16 14:30:00",
      updatedAt: "2024-12-17 09:45:00"
    }
  ];

  const sampleComputerVisionModels: ComputerVisionModel[] = [
    {
      id: "cv_001",
      name: "Surface Defect Detection",
      description: "Automated detection of surface defects in manufactured parts",
      type: "defect_detection",
      status: "deployed",
      accuracy: 96.3,
      processingSpeed: 45,
      supportedFormats: ["jpg", "png", "bmp", "tiff"],
      classes: ["scratch", "dent", "discoloration", "crack", "acceptable"],
      lastTrained: "2024-12-10 15:00:00",
      totalInferences: 15847,
      isActive: true
    },
    {
      id: "cv_002",
      name: "Component Classification",
      description: "Classifies components by type, size, and specification",
      type: "classification",
      status: "deployed",
      accuracy: 98.7,
      processingSpeed: 62,
      supportedFormats: ["jpg", "png"],
      classes: ["type_a", "type_b", "type_c", "oversized", "undersized", "reject"],
      lastTrained: "2024-12-08 12:00:00",
      totalInferences: 23456,
      isActive: true
    },
    {
      id: "cv_003",
      name: "Dimensional Measurement",
      description: "Automated dimensional measurement and tolerance verification",
      type: "measurement",
      status: "testing",
      accuracy: 94.1,
      processingSpeed: 28,
      supportedFormats: ["tiff", "raw"],
      classes: ["within_tolerance", "over_tolerance", "under_tolerance"],
      lastTrained: "2024-12-15 09:00:00",
      totalInferences: 892,
      isActive: false
    }
  ];

  // Create ML model mutation
  const createModelMutation = useMutation({
    mutationFn: async (data: z.infer<typeof mlModelSchema>) => {
      return apiRequest("/api/ml-models", "POST", data);
    },
    onSuccess: () => {
      toast({
        title: "Model Created",
        description: "ML model has been created and training will begin shortly",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/ml-models"] });
      setIsModelDialogOpen(false);
      modelForm.reset();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create ML model",
        variant: "destructive",
      });
    },
  });

  // Train model mutation
  const trainModelMutation = useMutation({
    mutationFn: async (modelId: string) => {
      return apiRequest(`/api/ml-models/${modelId}/train`, "POST");
    },
    onSuccess: () => {
      toast({
        title: "Training Started",
        description: "Model training has been initiated",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/ml-models"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to start model training",
        variant: "destructive",
      });
    },
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "deployed":
        return "bg-green-100 text-green-800";
      case "training":
        return "bg-blue-100 text-blue-800";
      case "testing":
        return "bg-yellow-100 text-yellow-800";
      case "failed":
        return "bg-red-100 text-red-800";
      case "inactive":
        return "bg-gray-100 text-gray-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "low":
        return "bg-green-100 text-green-800";
      case "medium":
        return "bg-yellow-100 text-yellow-800";
      case "high":
        return "bg-orange-100 text-orange-800";
      case "critical":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "predictive_maintenance":
        return <Wrench className="w-5 h-5 text-orange-600" />;
      case "quality_prediction":
        return <Shield className="w-5 h-5 text-blue-600" />;
      case "demand_forecasting":
        return <TrendingUp className="w-5 h-5 text-green-600" />;
      case "anomaly_detection":
        return <AlertTriangle className="w-5 h-5 text-red-600" />;
      case "optimization":
        return <Target className="w-5 h-5 text-purple-600" />;
      default:
        return <Brain className="w-5 h-5 text-gray-600" />;
    }
  };

  const getAlgorithmBadge = (algorithm: string) => {
    const colors = {
      "random_forest": "bg-green-100 text-green-800",
      "neural_network": "bg-blue-100 text-blue-800",
      "svm": "bg-purple-100 text-purple-800",
      "linear_regression": "bg-gray-100 text-gray-800",
      "lstm": "bg-indigo-100 text-indigo-800",
      "cnn": "bg-pink-100 text-pink-800",
      "xgboost": "bg-yellow-100 text-yellow-800",
    };
    return colors[algorithm as keyof typeof colors] || "bg-gray-100 text-gray-800";
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "maintenance":
        return <Wrench className="w-4 h-4" />;
      case "quality":
        return <Shield className="w-4 h-4" />;
      case "production":
        return <Factory className="w-4 h-4" />;
      case "inventory":
        return <Package className="w-4 h-4" />;
      case "energy":
        return <Zap className="w-4 h-4" />;
      case "safety":
        return <AlertTriangle className="w-4 h-4" />;
      default:
        return <Info className="w-4 h-4" />;
    }
  };

  const filteredModels = sampleModels.filter(model => {
    const matchesType = filterType === "all" || model.type === filterType;
    const matchesStatus = filterStatus === "all" || model.status === filterStatus;
    const matchesSearch = searchTerm === "" || 
      model.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      model.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesType && matchesStatus && matchesSearch;
  });

  const modelStats = {
    total: sampleModels.length,
    deployed: sampleModels.filter(m => m.status === "deployed").length,
    training: sampleModels.filter(m => m.status === "training").length,
    avgAccuracy: Math.round(sampleModels.reduce((sum, m) => sum + m.accuracy, 0) / sampleModels.length * 10) / 10,
    totalPredictions: sampleModels.reduce((sum, m) => sum + m.totalPredictions, 0)
  };

  const onModelSubmit = (data: z.infer<typeof mlModelSchema>) => {
    createModelMutation.mutate(data);
  };

  const handleTrainModel = (modelId: string) => {
    trainModelMutation.mutate(modelId);
  };

  const handleDeployModel = (modelId: string) => {
    toast({
      title: "Model Deployed",
      description: "Model has been deployed to production environment",
    });
    // Implement deploy logic
  };

  return (
    <div className="flex h-screen bg-carbon-gray-10">
      <Sidebar />
      <div className="flex-1 overflow-auto">
        <div className="p-6 space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-carbon-gray-80">AI & Machine Learning</h1>
              <p className="text-carbon-gray-60">Intelligent automation and predictive analytics for manufacturing</p>
            </div>
            <div className="flex items-center space-x-3">
              <Button variant="outline" onClick={() => queryClient.invalidateQueries({ queryKey: ["/api/ml-models"] })}>
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh
              </Button>
            </div>
          </div>

          {/* Overview Stats */}
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Brain className="w-5 h-5 text-blue-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Total Models</p>
                    <p className="text-xl font-bold">{modelStats.total}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Deployed</p>
                    <p className="text-xl font-bold">{modelStats.deployed}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Cpu className="w-5 h-5 text-orange-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Training</p>
                    <p className="text-xl font-bold">{modelStats.training}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Target className="w-5 h-5 text-purple-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Avg Accuracy</p>
                    <p className="text-xl font-bold">{modelStats.avgAccuracy}%</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Activity className="w-5 h-5 text-indigo-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Predictions</p>
                    <p className="text-xl font-bold">{modelStats.totalPredictions.toLocaleString()}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
            <div className="flex items-center justify-between">
              <TabsList>
                <TabsTrigger value="models">ML Models</TabsTrigger>
                <TabsTrigger value="predictions">Predictions</TabsTrigger>
                <TabsTrigger value="insights">AI Insights</TabsTrigger>
                <TabsTrigger value="computer-vision">Computer Vision</TabsTrigger>
                <TabsTrigger value="training">Model Training</TabsTrigger>
              </TabsList>
              <div className="flex space-x-2">
                {activeTab === "models" && (
                  <Dialog open={isModelDialogOpen} onOpenChange={setIsModelDialogOpen}>
                    <DialogTrigger asChild>
                      <Button>
                        <Plus className="w-4 h-4 mr-2" />
                        New Model
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl">
                      <DialogHeader>
                        <DialogTitle>Create ML Model</DialogTitle>
                      </DialogHeader>
                      <Form {...modelForm}>
                        <form onSubmit={modelForm.handleSubmit(onModelSubmit)} className="space-y-4">
                          <div className="grid grid-cols-2 gap-4">
                            <FormField
                              control={modelForm.control}
                              name="name"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Model Name</FormLabel>
                                  <FormControl>
                                    <Input {...field} />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={modelForm.control}
                              name="type"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Model Type</FormLabel>
                                  <FormControl>
                                    <Select onValueChange={field.onChange} value={field.value}>
                                      <SelectTrigger>
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="predictive_maintenance">Predictive Maintenance</SelectItem>
                                        <SelectItem value="quality_prediction">Quality Prediction</SelectItem>
                                        <SelectItem value="demand_forecasting">Demand Forecasting</SelectItem>
                                        <SelectItem value="anomaly_detection">Anomaly Detection</SelectItem>
                                        <SelectItem value="optimization">Optimization</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                          </div>
                          <FormField
                            control={modelForm.control}
                            name="description"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Description</FormLabel>
                                <FormControl>
                                  <Textarea {...field} />
                                </FormControl>
                              </FormItem>
                            )}
                          />
                          <div className="grid grid-cols-2 gap-4">
                            <FormField
                              control={modelForm.control}
                              name="algorithm"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Algorithm</FormLabel>
                                  <FormControl>
                                    <Select onValueChange={field.onChange} value={field.value}>
                                      <SelectTrigger>
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="random_forest">Random Forest</SelectItem>
                                        <SelectItem value="neural_network">Neural Network</SelectItem>
                                        <SelectItem value="svm">Support Vector Machine</SelectItem>
                                        <SelectItem value="linear_regression">Linear Regression</SelectItem>
                                        <SelectItem value="lstm">LSTM</SelectItem>
                                        <SelectItem value="cnn">CNN</SelectItem>
                                        <SelectItem value="xgboost">XGBoost</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={modelForm.control}
                              name="dataSource"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Data Source</FormLabel>
                                  <FormControl>
                                    <Select onValueChange={field.onChange} value={field.value}>
                                      <SelectTrigger>
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="machine_sensors">Machine Sensors</SelectItem>
                                        <SelectItem value="production_data">Production Data</SelectItem>
                                        <SelectItem value="sales_data">Sales Data</SelectItem>
                                        <SelectItem value="energy_data">Energy Data</SelectItem>
                                        <SelectItem value="quality_data">Quality Data</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                            <FormField
                              control={modelForm.control}
                              name="targetVariable"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Target Variable</FormLabel>
                                  <FormControl>
                                    <Input {...field} />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={modelForm.control}
                              name="trainingFrequency"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Training Frequency</FormLabel>
                                  <FormControl>
                                    <Select onValueChange={field.onChange} value={field.value}>
                                      <SelectTrigger>
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="daily">Daily</SelectItem>
                                        <SelectItem value="weekly">Weekly</SelectItem>
                                        <SelectItem value="monthly">Monthly</SelectItem>
                                        <SelectItem value="quarterly">Quarterly</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                          </div>
                          <FormField
                            control={modelForm.control}
                            name="predictionHorizon"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Prediction Horizon (days)</FormLabel>
                                <FormControl>
                                  <Input 
                                    type="number" 
                                    min="1" 
                                    {...field}
                                    onChange={e => field.onChange(parseInt(e.target.value))}
                                  />
                                </FormControl>
                              </FormItem>
                            )}
                          />
                          <div className="flex justify-end space-x-2">
                            <Button type="button" variant="outline" onClick={() => setIsModelDialogOpen(false)}>
                              Cancel
                            </Button>
                            <Button type="submit" disabled={createModelMutation.isPending}>
                              {createModelMutation.isPending ? "Creating..." : "Create Model"}
                            </Button>
                          </div>
                        </form>
                      </Form>
                    </DialogContent>
                  </Dialog>
                )}
              </div>
            </div>

            <TabsContent value="models" className="space-y-4">
              {/* Filters and Search */}
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      placeholder="Search models..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10 w-64"
                    />
                  </div>
                  <Select value={filterType} onValueChange={setFilterType}>
                    <SelectTrigger className="w-48">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="predictive_maintenance">Predictive Maintenance</SelectItem>
                      <SelectItem value="quality_prediction">Quality Prediction</SelectItem>
                      <SelectItem value="demand_forecasting">Demand Forecasting</SelectItem>
                      <SelectItem value="anomaly_detection">Anomaly Detection</SelectItem>
                      <SelectItem value="optimization">Optimization</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={filterStatus} onValueChange={setFilterStatus}>
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="deployed">Deployed</SelectItem>
                      <SelectItem value="training">Training</SelectItem>
                      <SelectItem value="testing">Testing</SelectItem>
                      <SelectItem value="inactive">Inactive</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Models Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {filteredModels.map((model) => (
                  <Card key={model.id} className="border-carbon-gray-20">
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          {getTypeIcon(model.type)}
                          <div>
                            <CardTitle className="text-lg">{model.name}</CardTitle>
                            <p className="text-sm text-carbon-gray-60">v{model.version}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge className={getStatusColor(model.status)}>
                            {model.status}
                          </Badge>
                          <Badge className={getAlgorithmBadge(model.algorithm)}>
                            {model.algorithm.replace('_', ' ')}
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <p className="text-sm text-gray-600">{model.description}</p>
                      
                      {model.status === "deployed" && (
                        <div className="grid grid-cols-4 gap-4 text-sm">
                          <div>
                            <span className="text-gray-600">Accuracy:</span>
                            <p className="font-medium">{model.accuracy}%</p>
                          </div>
                          <div>
                            <span className="text-gray-600">Precision:</span>
                            <p className="font-medium">{model.precision}%</p>
                          </div>
                          <div>
                            <span className="text-gray-600">Recall:</span>
                            <p className="font-medium">{model.recall}%</p>
                          </div>
                          <div>
                            <span className="text-gray-600">F1 Score:</span>
                            <p className="font-medium">{model.f1Score}%</p>
                          </div>
                        </div>
                      )}

                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="text-gray-600">Predictions:</span>
                          <p className="font-medium">{model.totalPredictions.toLocaleString()}</p>
                        </div>
                        <div>
                          <span className="text-gray-600">Accuracy Rate:</span>
                          <p className="font-medium">
                            {model.totalPredictions > 0 ? 
                              Math.round((model.correctPredictions / model.totalPredictions) * 100) : 0}%
                          </p>
                        </div>
                        <div>
                          <span className="text-gray-600">Last Trained:</span>
                          <p className="font-medium">{model.lastTrained}</p>
                        </div>
                        <div>
                          <span className="text-gray-600">Next Training:</span>
                          <p className="font-medium">{model.nextTraining}</p>
                        </div>
                      </div>

                      <div>
                        <span className="text-sm text-gray-600">Features:</span>
                        <div className="flex flex-wrap gap-1 mt-2">
                          {model.features.slice(0, 4).map((feature, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {feature.replace('_', ' ')}
                            </Badge>
                          ))}
                          {model.features.length > 4 && (
                            <Badge variant="outline" className="text-xs">
                              +{model.features.length - 4}
                            </Badge>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-2 border-t">
                        <Switch 
                          checked={model.isActive}
                          onCheckedChange={() => {/* Handle toggle */}}
                        />
                        <div className="flex space-x-2">
                          {model.status === "testing" && (
                            <Button size="sm" onClick={() => handleDeployModel(model.id)}>
                              <Play className="w-3 h-3 mr-2" />
                              Deploy
                            </Button>
                          )}
                          <Button size="sm" variant="outline" onClick={() => handleTrainModel(model.id)}>
                            <RefreshCw className="w-3 h-3 mr-2" />
                            Retrain
                          </Button>
                          <Button size="sm" variant="outline">
                            <Eye className="w-3 h-3 mr-2" />
                            View
                          </Button>
                          <Button size="sm" variant="outline">
                            <Edit className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="predictions" className="space-y-4">
              <div className="space-y-4">
                {samplePredictions.map((prediction) => (
                  <Card key={prediction.id} className="border-carbon-gray-20">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-3">
                            {getTypeIcon(prediction.type)}
                            <h3 className="text-lg font-semibold">{prediction.modelName}</h3>
                            <Badge className={`${prediction.confidence >= 90 ? 'bg-green-100 text-green-800' : 
                              prediction.confidence >= 70 ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800'}`}>
                              {prediction.confidence}% confidence
                            </Badge>
                            {prediction.isCorrect !== undefined && (
                              <Badge className={prediction.isCorrect ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}>
                                {prediction.isCorrect ? 'Correct' : 'Incorrect'}
                              </Badge>
                            )}
                          </div>
                          
                          <p className="text-gray-600 mb-4">{prediction.explanation}</p>
                          
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-4">
                            <div>
                              <h4 className="font-medium text-gray-700 mb-2">Prediction Details:</h4>
                              <div className="bg-gray-50 p-3 rounded text-sm">
                                <pre className="whitespace-pre-wrap">
                                  {JSON.stringify(prediction.prediction, null, 2)}
                                </pre>
                              </div>
                            </div>
                            <div>
                              <h4 className="font-medium text-gray-700 mb-2">Input Features:</h4>
                              <div className="bg-gray-50 p-3 rounded text-sm">
                                {Object.entries(prediction.features).map(([key, value]) => (
                                  <div key={key} className="flex justify-between">
                                    <span>{key.replace('_', ' ')}:</span>
                                    <span className="font-medium">{value}</span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          </div>

                          <div className="mb-4">
                            <h4 className="font-medium text-gray-700 mb-2">Recommendations:</h4>
                            <ul className="list-disc list-inside space-y-1 text-sm text-gray-600">
                              {prediction.recommendations.map((rec, index) => (
                                <li key={index}>{rec}</li>
                              ))}
                            </ul>
                          </div>

                          <div className="grid grid-cols-3 gap-4 text-sm">
                            <div>
                              <span className="font-medium text-gray-700">Affected Assets:</span>
                              <p className="text-gray-600">{prediction.affectedAssets.join(', ')}</p>
                            </div>
                            <div>
                              <span className="font-medium text-gray-700">Estimated Impact:</span>
                              <p className="text-gray-600">{prediction.estimatedImpact}</p>
                            </div>
                            <div>
                              <span className="font-medium text-gray-700">Timestamp:</span>
                              <p className="text-gray-600">{prediction.timestamp}</p>
                            </div>
                          </div>
                        </div>

                        <div className="flex flex-col space-y-2 ml-6">
                          <Button size="sm" variant="outline">
                            <CheckCircle className="w-3 h-3 mr-2" />
                            Confirm
                          </Button>
                          <Button size="sm" variant="outline">
                            <AlertCircle className="w-3 h-3 mr-2" />
                            Flag
                          </Button>
                          <Button size="sm" variant="outline">
                            <Download className="w-3 h-3 mr-2" />
                            Export
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="insights" className="space-y-4">
              <div className="space-y-4">
                {sampleInsights.map((insight) => (
                  <Card key={insight.id} className="border-carbon-gray-20">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-3">
                            {getCategoryIcon(insight.category)}
                            <h3 className="text-lg font-semibold">{insight.title}</h3>
                            <Badge className={getPriorityColor(insight.priority)}>
                              {insight.priority}
                            </Badge>
                            <Badge className={`${insight.confidence >= 80 ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>
                              {insight.confidence}% confidence
                            </Badge>
                            {insight.actionRequired && (
                              <Badge className="bg-orange-100 text-orange-800">
                                Action Required
                              </Badge>
                            )}
                          </div>
                          
                          <p className="text-gray-600 mb-4">{insight.description}</p>
                          
                          <div className="mb-4">
                            <h4 className="font-medium text-gray-700 mb-2">Recommendations:</h4>
                            <ul className="list-disc list-inside space-y-1 text-sm text-gray-600">
                              {insight.recommendations.map((rec, index) => (
                                <li key={index}>{rec}</li>
                              ))}
                            </ul>
                          </div>

                          <div className="grid grid-cols-3 gap-4 text-sm">
                            <div>
                              <span className="font-medium text-gray-700">Affected Assets:</span>
                              <p className="text-gray-600">{insight.affectedAssets.join(', ')}</p>
                            </div>
                            <div>
                              <span className="font-medium text-gray-700">Estimated Impact:</span>
                              <p className="text-gray-600">{insight.estimatedImpact}</p>
                            </div>
                            <div>
                              <span className="font-medium text-gray-700">Created:</span>
                              <p className="text-gray-600">{insight.createdAt}</p>
                            </div>
                          </div>
                        </div>

                        <div className="flex flex-col space-y-2 ml-6">
                          <Button size="sm">
                            <CheckCircle className="w-3 h-3 mr-2" />
                            Acknowledge
                          </Button>
                          <Button size="sm" variant="outline">
                            <Eye className="w-3 h-3 mr-2" />
                            Investigate
                          </Button>
                          <Button size="sm" variant="outline">
                            <Trash2 className="w-3 h-3 mr-2" />
                            Dismiss
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="computer-vision" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {sampleComputerVisionModels.map((model) => (
                  <Card key={model.id} className="border-carbon-gray-20">
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <Camera className="w-6 h-6 text-blue-600" />
                          <div>
                            <CardTitle className="text-lg">{model.name}</CardTitle>
                            <p className="text-sm text-carbon-gray-60 capitalize">{model.type.replace('_', ' ')}</p>
                          </div>
                        </div>
                        <Badge className={getStatusColor(model.status)}>
                          {model.status}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <p className="text-sm text-gray-600">{model.description}</p>
                      
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="text-gray-600">Accuracy:</span>
                          <p className="font-medium">{model.accuracy}%</p>
                        </div>
                        <div>
                          <span className="text-gray-600">Speed:</span>
                          <p className="font-medium">{model.processingSpeed} fps</p>
                        </div>
                        <div>
                          <span className="text-gray-600">Inferences:</span>
                          <p className="font-medium">{model.totalInferences.toLocaleString()}</p>
                        </div>
                        <div>
                          <span className="text-gray-600">Classes:</span>
                          <p className="font-medium">{model.classes.length}</p>
                        </div>
                      </div>

                      <div>
                        <span className="text-sm text-gray-600">Supported Formats:</span>
                        <div className="flex flex-wrap gap-1 mt-2">
                          {model.supportedFormats.map((format, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {format.toUpperCase()}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      <div>
                        <span className="text-sm text-gray-600">Detection Classes:</span>
                        <div className="flex flex-wrap gap-1 mt-2">
                          {model.classes.slice(0, 3).map((cls, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {cls.replace('_', ' ')}
                            </Badge>
                          ))}
                          {model.classes.length > 3 && (
                            <Badge variant="outline" className="text-xs">
                              +{model.classes.length - 3}
                            </Badge>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-2 border-t">
                        <Switch 
                          checked={model.isActive}
                          onCheckedChange={() => {/* Handle toggle */}}
                        />
                        <div className="flex space-x-2">
                          <Button size="sm" variant="outline">
                            <Eye className="w-3 h-3 mr-2" />
                            Test
                          </Button>
                          <Button size="sm" variant="outline">
                            <Settings className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="training" className="space-y-4">
              <div className="text-center py-12">
                <Cpu className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">Model Training Center</h3>
                <p className="text-gray-600 mb-4">Monitor training progress and manage training pipelines</p>
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Start Training Job
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}