import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import Sidebar from "@/components/layout/sidebar";
import { 
  Activity, 
  AlertCircle, 
  CheckCircle, 
  Clock,
  Gauge,
  Power,
  Settings,
  Thermometer,
  Zap,
  Wrench,
  TrendingUp,
  TrendingDown,
  BarChart3,
  RefreshCw,
  PlayCircle,
  PauseCircle,
  StopCircle
} from "lucide-react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area
} from "recharts";

interface Machine {
  id: string;
  name: string;
  type: string;
  status: "running" | "idle" | "maintenance" | "error";
  efficiency: number;
  temperature: number;
  vibration: number;
  powerConsumption: number;
  lastMaintenance: string;
  nextMaintenance: string;
  operatingHours: number;
  totalProduction: number;
  errorCount: number;
  uptime: number;
}

export default function MachineMonitoring() {
  const [selectedMachine, setSelectedMachine] = useState<string>("all");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [autoRefresh, setAutoRefresh] = useState(true);

  // Fetch machine data with real-time updates
  const { data: machines, isLoading, refetch } = useQuery({
    queryKey: ["/api/machines/status"],
    refetchInterval: autoRefresh ? 5000 : false, // Refresh every 5 seconds
    staleTime: 0,
  });

  // Sample machine data for demonstration
  const machineData: Machine[] = [
    {
      id: "M001",
      name: "CNC Machine #1",
      type: "CNC Lathe",
      status: "running",
      efficiency: 87,
      temperature: 65,
      vibration: 2.1,
      powerConsumption: 15.4,
      lastMaintenance: "2024-12-01",
      nextMaintenance: "2025-01-15",
      operatingHours: 2840,
      totalProduction: 1250,
      errorCount: 3,
      uptime: 94.2
    },
    {
      id: "M002", 
      name: "Assembly Line A",
      type: "Conveyor System",
      status: "running",
      efficiency: 92,
      temperature: 42,
      vibration: 1.8,
      powerConsumption: 8.7,
      lastMaintenance: "2024-11-28",
      nextMaintenance: "2025-01-28",
      operatingHours: 3120,
      totalProduction: 2850,
      errorCount: 1,
      uptime: 98.1
    },
    {
      id: "M003",
      name: "Injection Molder #2",
      type: "Injection Molding",
      status: "maintenance",
      efficiency: 0,
      temperature: 25,
      vibration: 0,
      powerConsumption: 0,
      lastMaintenance: "2024-12-16",
      nextMaintenance: "2025-03-16",
      operatingHours: 1950,
      totalProduction: 890,
      errorCount: 8,
      uptime: 89.3
    },
    {
      id: "M004",
      name: "Quality Scanner",
      type: "Vision System",
      status: "error",
      efficiency: 0,
      temperature: 38,
      vibration: 0.5,
      powerConsumption: 2.1,
      lastMaintenance: "2024-12-10",
      nextMaintenance: "2025-02-10",
      operatingHours: 1840,
      totalProduction: 0,
      errorCount: 12,
      uptime: 76.8
    }
  ];

  // Sample performance data for charts
  const performanceData = [
    { time: '00:00', efficiency: 85, temperature: 62, power: 14.2 },
    { time: '04:00', efficiency: 88, temperature: 65, power: 15.1 },
    { time: '08:00', efficiency: 92, temperature: 68, power: 15.8 },
    { time: '12:00', efficiency: 87, temperature: 70, power: 15.4 },
    { time: '16:00', efficiency: 90, temperature: 67, power: 15.6 },
    { time: '20:00', efficiency: 86, temperature: 64, power: 14.9 }
  ];

  const getStatusColor = (status: Machine["status"]) => {
    switch (status) {
      case "running": return "bg-green-100 text-green-800";
      case "idle": return "bg-yellow-100 text-yellow-800";
      case "maintenance": return "bg-blue-100 text-blue-800";
      case "error": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusIcon = (status: Machine["status"]) => {
    switch (status) {
      case "running": return <PlayCircle className="w-4 h-4" />;
      case "idle": return <PauseCircle className="w-4 h-4" />;
      case "maintenance": return <Wrench className="w-4 h-4" />;
      case "error": return <AlertCircle className="w-4 h-4" />;
      default: return <StopCircle className="w-4 h-4" />;
    }
  };

  const filteredMachines = selectedMachine === "all" 
    ? machineData 
    : machineData.filter(m => m.id === selectedMachine);

  const overallStats = {
    totalMachines: machineData.length,
    runningMachines: machineData.filter(m => m.status === "running").length,
    avgEfficiency: Math.round(machineData.reduce((acc, m) => acc + m.efficiency, 0) / machineData.length),
    avgUptime: Math.round(machineData.reduce((acc, m) => acc + m.uptime, 0) / machineData.length),
    totalPowerConsumption: machineData.reduce((acc, m) => acc + m.powerConsumption, 0).toFixed(1)
  };

  return (
    <div className="flex h-screen bg-carbon-gray-10">
      <Sidebar />
      <div className="flex-1 overflow-auto">
        <div className="p-6 space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-carbon-gray-80">Machine Monitoring</h1>
              <p className="text-carbon-gray-60">Real-time equipment status and performance</p>
            </div>
            <div className="flex items-center space-x-3">
              <div className="flex items-center space-x-2">
                <div className={`w-2 h-2 rounded-full ${autoRefresh ? 'bg-green-500 animate-pulse' : 'bg-gray-400'}`} />
                <span className="text-sm text-carbon-gray-60">
                  {autoRefresh ? 'Live' : 'Paused'}
                </span>
              </div>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setAutoRefresh(!autoRefresh)}
              >
                {autoRefresh ? <PauseCircle className="w-4 h-4" /> : <PlayCircle className="w-4 h-4" />}
              </Button>
              <Select value={selectedMachine} onValueChange={setSelectedMachine}>
                <SelectTrigger className="w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Machines</SelectItem>
                  {machineData.map(machine => (
                    <SelectItem key={machine.id} value={machine.id}>
                      {machine.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button variant="outline" onClick={() => refetch()}>
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh
              </Button>
            </div>
          </div>

          {/* Overview Stats */}
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Settings className="w-5 h-5 text-blue-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Total Machines</p>
                    <p className="text-xl font-bold">{overallStats.totalMachines}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <PlayCircle className="w-5 h-5 text-green-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Running</p>
                    <p className="text-xl font-bold">{overallStats.runningMachines}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <TrendingUp className="w-5 h-5 text-purple-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Avg Efficiency</p>
                    <p className="text-xl font-bold">{overallStats.avgEfficiency}%</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Activity className="w-5 h-5 text-orange-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Avg Uptime</p>
                    <p className="text-xl font-bold">{overallStats.avgUptime}%</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Zap className="w-5 h-5 text-yellow-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Total Power</p>
                    <p className="text-xl font-bold">{overallStats.totalPowerConsumption} kW</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Machine Cards */}
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
            {filteredMachines.map((machine) => (
              <Card key={machine.id} className="border-carbon-gray-20">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{machine.name}</CardTitle>
                    <Badge className={getStatusColor(machine.status)}>
                      {getStatusIcon(machine.status)}
                      <span className="ml-1 capitalize">{machine.status}</span>
                    </Badge>
                  </div>
                  <p className="text-sm text-carbon-gray-60">{machine.type}</p>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Efficiency */}
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Efficiency</span>
                      <span className="font-medium">{machine.efficiency}%</span>
                    </div>
                    <Progress value={machine.efficiency} className="h-2" />
                  </div>

                  {/* Metrics Grid */}
                  <div className="grid grid-cols-2 gap-3">
                    <div className="flex items-center space-x-2 p-2 bg-gray-50 rounded">
                      <Thermometer className="w-4 h-4 text-red-500" />
                      <div>
                        <p className="text-xs text-gray-600">Temperature</p>
                        <p className="font-medium">{machine.temperature}°C</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2 p-2 bg-gray-50 rounded">
                      <Activity className="w-4 h-4 text-blue-500" />
                      <div>
                        <p className="text-xs text-gray-600">Vibration</p>
                        <p className="font-medium">{machine.vibration} mm/s</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2 p-2 bg-gray-50 rounded">
                      <Zap className="w-4 h-4 text-yellow-500" />
                      <div>
                        <p className="text-xs text-gray-600">Power</p>
                        <p className="font-medium">{machine.powerConsumption} kW</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2 p-2 bg-gray-50 rounded">
                      <Clock className="w-4 h-4 text-green-500" />
                      <div>
                        <p className="text-xs text-gray-600">Uptime</p>
                        <p className="font-medium">{machine.uptime}%</p>
                      </div>
                    </div>
                  </div>

                  {/* Production Stats */}
                  <div className="pt-2 border-t">
                    <div className="flex justify-between text-sm">
                      <span>Production Today</span>
                      <span className="font-medium">{machine.totalProduction} units</span>
                    </div>
                    <div className="flex justify-between text-sm mt-1">
                      <span>Operating Hours</span>
                      <span className="font-medium">{machine.operatingHours}h</span>
                    </div>
                    <div className="flex justify-between text-sm mt-1">
                      <span>Error Count</span>
                      <span className={`font-medium ${machine.errorCount > 5 ? 'text-red-600' : 'text-green-600'}`}>
                        {machine.errorCount}
                      </span>
                    </div>
                  </div>

                  {/* Next Maintenance */}
                  <div className="pt-2 border-t">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">Next Maintenance</span>
                      <span className="font-medium">{machine.nextMaintenance}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Performance Charts */}
          {selectedMachine !== "all" && (
            <Card className="border-carbon-gray-20">
              <CardHeader>
                <CardTitle>Performance Trends - {machineData.find(m => m.id === selectedMachine)?.name}</CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="efficiency" className="space-y-4">
                  <TabsList>
                    <TabsTrigger value="efficiency">Efficiency</TabsTrigger>
                    <TabsTrigger value="temperature">Temperature</TabsTrigger>
                    <TabsTrigger value="power">Power Consumption</TabsTrigger>
                  </TabsList>

                  <TabsContent value="efficiency">
                    <ResponsiveContainer width="100%" height={300}>
                      <LineChart data={performanceData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="time" />
                        <YAxis />
                        <Tooltip />
                        <Line type="monotone" dataKey="efficiency" stroke="#0088FE" strokeWidth={2} />
                      </LineChart>
                    </ResponsiveContainer>
                  </TabsContent>

                  <TabsContent value="temperature">
                    <ResponsiveContainer width="100%" height={300}>
                      <AreaChart data={performanceData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="time" />
                        <YAxis />
                        <Tooltip />
                        <Area type="monotone" dataKey="temperature" stroke="#FF8042" fill="#FF8042" fillOpacity={0.3} />
                      </AreaChart>
                    </ResponsiveContainer>
                  </TabsContent>

                  <TabsContent value="power">
                    <ResponsiveContainer width="100%" height={300}>
                      <LineChart data={performanceData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="time" />
                        <YAxis />
                        <Tooltip />
                        <Line type="monotone" dataKey="power" stroke="#00C49F" strokeWidth={2} />
                      </LineChart>
                    </ResponsiveContainer>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          )}

          {/* Alerts */}
          <Card className="border-carbon-gray-20">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <AlertCircle className="w-5 h-5 text-red-500" />
                <span>Active Alerts</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-start space-x-3 p-3 bg-red-50 border border-red-200 rounded-lg">
                  <AlertCircle className="w-5 h-5 text-red-600 mt-0.5" />
                  <div className="flex-1">
                    <h4 className="font-medium text-red-800">Quality Scanner - System Error</h4>
                    <p className="text-sm text-red-700">Machine M004 has stopped responding. Immediate attention required.</p>
                    <p className="text-xs text-red-600 mt-1">2 minutes ago</p>
                  </div>
                  <Button size="sm" variant="outline">
                    Acknowledge
                  </Button>
                </div>
                <div className="flex items-start space-x-3 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <AlertCircle className="w-5 h-5 text-yellow-600 mt-0.5" />
                  <div className="flex-1">
                    <h4 className="font-medium text-yellow-800">CNC Machine #1 - High Temperature</h4>
                    <p className="text-sm text-yellow-700">Operating temperature is above normal range (65°C). Monitor closely.</p>
                    <p className="text-xs text-yellow-600 mt-1">5 minutes ago</p>
                  </div>
                  <Button size="sm" variant="outline">
                    Acknowledge
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}