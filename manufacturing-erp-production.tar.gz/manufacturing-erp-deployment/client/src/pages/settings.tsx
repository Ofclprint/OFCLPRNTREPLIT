import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useTutorial } from "@/hooks/useTutorial";
import { useToast } from "@/hooks/use-toast";
import Sidebar from "@/components/layout/sidebar";
import MobileNav from "@/components/layout/mobile-nav";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Settings as SettingsIcon, User, LogOut, Shield, Bell, Palette, Globe, HelpCircle, BookOpen, Play } from "lucide-react";

export default function Settings() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading, user } = useAuth();
  const tutorial = useTutorial();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  if (isLoading || !isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-carbon-gray-10">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-carbon-blue border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-carbon-gray-50">Loading...</p>
        </div>
      </div>
    );
  }

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case "admin":
        return "bg-red-100 text-red-800";
      case "manager":
        return "bg-blue-100 text-blue-800";
      case "employee":
        return "bg-green-100 text-green-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getUserInitials = () => {
    if (user?.firstName && user?.lastName) {
      return `${user.firstName[0]}${user.lastName[0]}`.toUpperCase();
    }
    if (user?.email) {
      return user.email[0].toUpperCase();
    }
    return "U";
  };

  const settingsItems = [
    {
      category: "Profile",
      icon: User,
      items: [
        { label: "Personal Information", description: "Update your profile details", action: () => toast({ title: "Coming Soon", description: "Profile editing will be available soon" }) },
        { label: "Change Password", description: "Update your account password", action: () => toast({ title: "Coming Soon", description: "Password change will be available soon" }) },
      ]
    },
    {
      category: "Security",
      icon: Shield,
      items: [
        { label: "Two-Factor Authentication", description: "Enable 2FA for added security", action: () => toast({ title: "Coming Soon", description: "2FA setup will be available soon" }) },
        { label: "Login Sessions", description: "Manage your active sessions", action: () => toast({ title: "Coming Soon", description: "Session management will be available soon" }) },
      ]
    },
    {
      category: "Preferences",
      icon: Palette,
      items: [
        { label: "Theme", description: "Choose your preferred theme", action: () => toast({ title: "Coming Soon", description: "Theme selection will be available soon" }) },
        { label: "Language", description: "Set your language preference", action: () => toast({ title: "Coming Soon", description: "Language selection will be available soon" }) },
      ]
    },
    {
      category: "Notifications",
      icon: Bell,
      items: [
        { label: "Email Notifications", description: "Configure email alerts", action: () => toast({ title: "Coming Soon", description: "Notification settings will be available soon" }) },
        { label: "Push Notifications", description: "Manage push notification preferences", action: () => toast({ title: "Coming Soon", description: "Push notification settings will be available soon" }) },
      ]
    },
    {
      category: "Support",
      icon: HelpCircle,
      items: [
        { label: "Help Center", description: "Access documentation and guides", action: () => toast({ title: "Coming Soon", description: "Help center will be available soon" }) },
        { label: "Contact Support", description: "Get help from our support team", action: () => toast({ title: "Coming Soon", description: "Support contact will be available soon" }) },
      ]
    },
  ];

  return (
    <div className="min-h-screen flex bg-carbon-gray-10">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-white border-b border-carbon-gray-20 px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-semibold text-carbon-gray-80">Settings</h1>
              <p className="text-carbon-gray-50 text-sm mt-1">Manage your account and preferences</p>
            </div>
          </div>
        </header>

        {/* Settings Content */}
        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-4xl mx-auto space-y-6">
            {/* Profile Card */}
            <Card className="border-carbon-gray-20">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <User className="w-5 h-5 text-carbon-blue" />
                  <span>Profile Information</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-4">
                  <Avatar className="w-16 h-16">
                    <AvatarImage src={user?.profileImageUrl} alt="Profile" />
                    <AvatarFallback className="bg-carbon-blue text-white text-lg">
                      {getUserInitials()}
                    </AvatarFallback>
                  </Avatar>
                  
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <h3 className="text-lg font-semibold text-carbon-gray-80">
                        {user?.firstName && user?.lastName 
                          ? `${user.firstName} ${user.lastName}`
                          : user?.email || "User"
                        }
                      </h3>
                      <Badge className={getRoleColor(user?.role || "employee")}>
                        {user?.role || "employee"}
                      </Badge>
                    </div>
                    
                    <p className="text-carbon-gray-50 mb-1">{user?.email}</p>
                    <p className="text-sm text-carbon-gray-50">
                      Member since {user?.createdAt ? new Date(user.createdAt).toLocaleDateString() : "N/A"}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Settings Categories */}
            {settingsItems.map((category) => (
              <Card key={category.category} className="border-carbon-gray-20">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <category.icon className="w-5 h-5 text-carbon-blue" />
                    <span>{category.category}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-1">
                  {category.items.map((item, index) => (
                    <div key={index}>
                      <button
                        onClick={item.action}
                        className="w-full text-left p-3 rounded-lg hover:bg-carbon-gray-10 transition-colors"
                      >
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-medium text-carbon-gray-80">{item.label}</p>
                            <p className="text-sm text-carbon-gray-50">{item.description}</p>
                          </div>
                          <div className="text-carbon-gray-50">
                            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                            </svg>
                          </div>
                        </div>
                      </button>
                      {index < category.items.length - 1 && <Separator className="my-1" />}
                    </div>
                  ))}
                </CardContent>
              </Card>
            ))}

            {/* System Information */}
            <Card className="border-carbon-gray-20">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Settings className="w-5 h-5 text-carbon-blue" />
                  <span>System Information</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <label className="text-carbon-gray-50">Application Version</label>
                    <p className="font-medium text-carbon-gray-80">v1.0.0</p>
                  </div>
                  <div>
                    <label className="text-carbon-gray-50">Last Login</label>
                    <p className="font-medium text-carbon-gray-80">
                      {new Date().toLocaleDateString()} at {new Date().toLocaleTimeString()}
                    </p>
                  </div>
                  <div>
                    <label className="text-carbon-gray-50">Browser</label>
                    <p className="font-medium text-carbon-gray-80">{navigator.userAgent.split(' ')[0]}</p>
                  </div>
                  <div>
                    <label className="text-carbon-gray-50">Platform</label>
                    <p className="font-medium text-carbon-gray-80">{navigator.platform}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Tutorial Section */}
            <Card className="border-blue-200 bg-blue-50">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <BookOpen className="w-5 h-5 text-blue-600" />
                  <span>Tutorial & Help</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h3 className="font-medium text-blue-800">Onboarding Tutorial</h3>
                    <p className="text-sm text-blue-600 mb-3">
                      Need a refresher? Replay the guided tour to learn about key features
                    </p>
                    <Button 
                      onClick={() => {
                        tutorial.resetTutorial();
                        tutorial.startOnboarding();
                        toast({
                          title: "Tutorial Started",
                          description: "Starting the interactive onboarding guide",
                        });
                      }}
                      variant="outline"
                      className="flex items-center space-x-2 border-blue-300 text-blue-700 hover:bg-blue-100"
                    >
                      <Play className="w-4 h-4" />
                      <span>Start Tutorial</span>
                    </Button>
                  </div>
                  
                  <Separator />
                  
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <label className="text-blue-600">Tutorial Status</label>
                      <p className="font-medium text-blue-800">
                        {tutorial.hasCompletedOnboarding ? "Completed" : "Not completed"}
                      </p>
                    </div>
                    <div>
                      <label className="text-blue-600">Skip Count</label>
                      <p className="font-medium text-blue-800">{tutorial.skipCount} times</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Logout Section */}
            <Card className="border-red-200 bg-red-50">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium text-red-800">Sign Out</h3>
                    <p className="text-sm text-red-600">Sign out of your ManufacturePro account</p>
                  </div>
                  <Button 
                    onClick={handleLogout}
                    variant="destructive"
                    className="flex items-center space-x-2"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Sign Out</span>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
      
      <MobileNav />
    </div>
  );
}
