import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  Area,
  AreaChart,
  PieChart,
  Pie,
  Cell
} from "recharts";
import {
  Users,
  Building,
  Phone,
  Mail,
  MapPin,
  Calendar,
  DollarSign,
  TrendingUp,
  TrendingDown,
  Clock,
  Package,
  Truck,
  AlertTriangle,
  CheckCircle,
  Star,
  Plus,
  Edit,
  Eye,
  Search,
  Filter,
  Download,
  MessageSquare,
  FileText,
  Target,
  Award,
  BarChart3,
  Activity
} from "lucide-react";
import { format, subDays, startOfMonth, endOfMonth } from "date-fns";

interface Customer {
  id: string;
  name: string;
  type: "enterprise" | "mid_market" | "small_business";
  industry: string;
  status: "active" | "prospect" | "inactive" | "churned";
  tier: "platinum" | "gold" | "silver" | "bronze";
  contactPerson: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  country: string;
  website?: string;
  employeeCount: number;
  annualRevenue: number;
  totalOrders: number;
  totalValue: number;
  averageOrderValue: number;
  lastOrderDate: Date;
  acquisitionDate: Date;
  paymentTerms: string;
  creditLimit: number;
  outstandingBalance: number;
  satisfactionScore: number;
  relationshipManager: string;
  notes: string;
}

interface Opportunity {
  id: string;
  customerId: string;
  customerName: string;
  title: string;
  description: string;
  value: number;
  probability: number;
  stage: "prospecting" | "qualification" | "proposal" | "negotiation" | "closed_won" | "closed_lost";
  expectedCloseDate: Date;
  source: string;
  assignedTo: string;
  products: string[];
  competitors: string[];
  nextAction: string;
  lastActivity: Date;
  createdDate: Date;
}

interface CustomerInteraction {
  id: string;
  customerId: string;
  type: "call" | "email" | "meeting" | "visit" | "support" | "order";
  subject: string;
  description: string;
  outcome: "positive" | "neutral" | "negative";
  followUpRequired: boolean;
  followUpDate?: Date;
  assignedTo: string;
  createdDate: Date;
  duration?: number;
}

interface CRMMetrics {
  totalCustomers: number;
  activeCustomers: number;
  prospects: number;
  totalRevenue: number;
  averageOrderValue: number;
  customerSatisfaction: number;
  churnRate: number;
  acquisitionRate: number;
  pipelineValue: number;
  conversionRate: number;
}

export default function ManufacturingCRM() {
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterTier, setFilterTier] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [showCustomerDialog, setShowCustomerDialog] = useState(false);
  const [showOpportunityDialog, setShowOpportunityDialog] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const sampleCustomers: Customer[] = [
    {
      id: "C001",
      name: "TechCorp Industries",
      type: "enterprise",
      industry: "Technology",
      status: "active",
      tier: "platinum",
      contactPerson: "John Wilson",
      email: "j.wilson@techcorp.com",
      phone: "+1-555-0123",
      address: "123 Innovation Dr",
      city: "San Francisco",
      country: "USA",
      website: "www.techcorp.com",
      employeeCount: 5000,
      annualRevenue: 2500000,
      totalOrders: 45,
      totalValue: 1250000,
      averageOrderValue: 27778,
      lastOrderDate: new Date(2025, 4, 15),
      acquisitionDate: new Date(2022, 2, 10),
      paymentTerms: "Net 30",
      creditLimit: 500000,
      outstandingBalance: 75000,
      satisfactionScore: 9.2,
      relationshipManager: "Sarah Johnson",
      notes: "Key strategic partner, expanding operations globally"
    },
    {
      id: "C002",
      name: "Manufacturing Plus LLC",
      type: "mid_market",
      industry: "Manufacturing",
      status: "active",
      tier: "gold",
      contactPerson: "Mike Davis",
      email: "m.davis@mfgplus.com",
      phone: "+1-555-0456",
      address: "456 Industrial Blvd",
      city: "Detroit",
      country: "USA",
      employeeCount: 250,
      annualRevenue: 850000,
      totalOrders: 28,
      totalValue: 420000,
      averageOrderValue: 15000,
      lastOrderDate: new Date(2025, 5, 8),
      acquisitionDate: new Date(2023, 6, 22),
      paymentTerms: "Net 45",
      creditLimit: 200000,
      outstandingBalance: 35000,
      satisfactionScore: 8.7,
      relationshipManager: "Tom Brown",
      notes: "Reliable customer, interested in automation solutions"
    },
    {
      id: "C003",
      name: "Precision Parts Co",
      type: "small_business",
      industry: "Automotive",
      status: "prospect",
      tier: "silver",
      contactPerson: "Lisa Chen",
      email: "l.chen@precisionparts.com",
      phone: "+1-555-0789",
      address: "789 Auto Lane",
      city: "Chicago",
      country: "USA",
      employeeCount: 50,
      annualRevenue: 180000,
      totalOrders: 8,
      totalValue: 95000,
      averageOrderValue: 11875,
      lastOrderDate: new Date(2025, 3, 28),
      acquisitionDate: new Date(2024, 8, 15),
      paymentTerms: "Net 15",
      creditLimit: 50000,
      outstandingBalance: 12000,
      satisfactionScore: 7.8,
      relationshipManager: "Emma Wilson",
      notes: "Growing business, potential for larger orders"
    }
  ];

  const sampleOpportunities: Opportunity[] = [
    {
      id: "O001",
      customerId: "C001",
      customerName: "TechCorp Industries",
      title: "Automation System Upgrade",
      description: "Complete factory automation system with IoT integration",
      value: 850000,
      probability: 75,
      stage: "proposal",
      expectedCloseDate: new Date(2025, 6, 30),
      source: "Referral",
      assignedTo: "Sarah Johnson",
      products: ["CNC Machines", "Robotics", "Control Systems"],
      competitors: ["Siemens", "ABB"],
      nextAction: "Technical presentation scheduled",
      lastActivity: new Date(2025, 5, 15),
      createdDate: new Date(2025, 3, 10)
    },
    {
      id: "O002",
      customerId: "C002",
      customerName: "Manufacturing Plus LLC",
      title: "Quality Control Equipment",
      description: "Advanced inspection and testing equipment",
      value: 125000,
      probability: 60,
      stage: "negotiation",
      expectedCloseDate: new Date(2025, 7, 15),
      source: "Trade Show",
      assignedTo: "Tom Brown",
      products: ["Inspection Systems", "Testing Equipment"],
      competitors: ["Keyence", "Cognex"],
      nextAction: "Price negotiation meeting",
      lastActivity: new Date(2025, 5, 12),
      createdDate: new Date(2025, 4, 5)
    },
    {
      id: "O003",
      customerId: "C003",
      customerName: "Precision Parts Co",
      title: "Production Line Expansion",
      description: "Additional manufacturing equipment for capacity increase",
      value: 65000,
      probability: 45,
      stage: "qualification",
      expectedCloseDate: new Date(2025, 8, 20),
      source: "Cold Outreach",
      assignedTo: "Emma Wilson",
      products: ["Assembly Equipment", "Conveyors"],
      competitors: ["Local Suppliers"],
      nextAction: "Site visit and needs assessment",
      lastActivity: new Date(2025, 5, 10),
      createdDate: new Date(2025, 5, 1)
    }
  ];

  const sampleInteractions: CustomerInteraction[] = [
    {
      id: "I001",
      customerId: "C001",
      type: "meeting",
      subject: "Q2 Business Review",
      description: "Quarterly review meeting to discuss performance and future plans",
      outcome: "positive",
      followUpRequired: true,
      followUpDate: new Date(2025, 6, 1),
      assignedTo: "Sarah Johnson",
      createdDate: new Date(2025, 5, 16),
      duration: 120
    },
    {
      id: "I002",
      customerId: "C002",
      type: "call",
      subject: "Order Status Inquiry",
      description: "Customer called to check on delivery status of recent order",
      outcome: "neutral",
      followUpRequired: false,
      assignedTo: "Tom Brown",
      createdDate: new Date(2025, 5, 14),
      duration: 15
    },
    {
      id: "I003",
      customerId: "C003",
      type: "email",
      subject: "Quote Request Follow-up",
      description: "Followed up on submitted quote for production equipment",
      outcome: "positive",
      followUpRequired: true,
      followUpDate: new Date(2025, 5, 25),
      assignedTo: "Emma Wilson",
      createdDate: new Date(2025, 5, 11)
    }
  ];

  const crmMetrics: CRMMetrics = {
    totalCustomers: 245,
    activeCustomers: 198,
    prospects: 47,
    totalRevenue: 5250000,
    averageOrderValue: 18750,
    customerSatisfaction: 8.6,
    churnRate: 4.2,
    acquisitionRate: 12.8,
    pipelineValue: 2850000,
    conversionRate: 24.5
  };

  const revenueData = [
    { month: "Jan", revenue: 420000, customers: 38 },
    { month: "Feb", revenue: 385000, customers: 35 },
    { month: "Mar", revenue: 465000, customers: 42 },
    { month: "Apr", revenue: 520000, customers: 45 },
    { month: "May", revenue: 485000, customers: 41 },
    { month: "Jun", revenue: 575000, customers: 48 }
  ];

  const customerDistribution = [
    { name: "Enterprise", value: 15, revenue: 3200000 },
    { name: "Mid-Market", value: 45, revenue: 1650000 },
    { name: "Small Business", value: 185, revenue: 400000 }
  ];

  const pipelineData = [
    { stage: "Prospecting", count: 12, value: 485000 },
    { stage: "Qualification", count: 8, value: 725000 },
    { stage: "Proposal", count: 6, value: 950000 },
    { stage: "Negotiation", count: 4, value: 690000 }
  ];

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

  const filteredCustomers = sampleCustomers.filter(customer => {
    const matchesStatus = filterStatus === "all" || customer.status === filterStatus;
    const matchesTier = filterTier === "all" || customer.tier === filterTier;
    const matchesSearch = searchQuery === "" || 
      customer.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      customer.contactPerson.toLowerCase().includes(searchQuery.toLowerCase()) ||
      customer.industry.toLowerCase().includes(searchQuery.toLowerCase());
    
    return matchesStatus && matchesTier && matchesSearch;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active": return "bg-green-100 text-green-800";
      case "prospect": return "bg-blue-100 text-blue-800";
      case "inactive": return "bg-gray-100 text-gray-800";
      case "churned": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getTierColor = (tier: string) => {
    switch (tier) {
      case "platinum": return "bg-purple-100 text-purple-800";
      case "gold": return "bg-yellow-100 text-yellow-800";
      case "silver": return "bg-gray-100 text-gray-800";
      case "bronze": return "bg-orange-100 text-orange-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getStageColor = (stage: string) => {
    switch (stage) {
      case "prospecting": return "bg-blue-100 text-blue-800";
      case "qualification": return "bg-yellow-100 text-yellow-800";
      case "proposal": return "bg-orange-100 text-orange-800";
      case "negotiation": return "bg-purple-100 text-purple-800";
      case "closed_won": return "bg-green-100 text-green-800";
      case "closed_lost": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getOutcomeColor = (outcome: string) => {
    switch (outcome) {
      case "positive": return "text-green-600";
      case "neutral": return "text-yellow-600";
      case "negative": return "text-red-600";
      default: return "text-gray-600";
    }
  };

  const createCustomer = (customerData: Partial<Customer>) => {
    toast({
      title: "Customer Added",
      description: "New customer has been added to the CRM",
    });
    setShowCustomerDialog(false);
  };

  const createOpportunity = (opportunityData: Partial<Opportunity>) => {
    toast({
      title: "Opportunity Created",
      description: "New sales opportunity has been added",
    });
    setShowOpportunityDialog(false);
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-3xl font-bold mb-2">Manufacturing CRM</h1>
          <p className="text-gray-600">
            Comprehensive customer relationship management for manufacturing businesses
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Export Data
          </Button>
          <Button onClick={() => setShowCustomerDialog(true)}>
            <Plus className="w-4 h-4 mr-2" />
            Add Customer
          </Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Revenue</p>
                <p className="text-2xl font-bold text-green-600">${crmMetrics.totalRevenue.toLocaleString()}</p>
                <p className="text-xs text-green-600">+15.2% vs last quarter</p>
              </div>
              <DollarSign className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Active Customers</p>
                <p className="text-2xl font-bold text-blue-600">{crmMetrics.activeCustomers}</p>
                <p className="text-xs text-gray-500">{crmMetrics.totalCustomers} total</p>
              </div>
              <Users className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Pipeline Value</p>
                <p className="text-2xl font-bold text-purple-600">${crmMetrics.pipelineValue.toLocaleString()}</p>
                <p className="text-xs text-gray-500">{crmMetrics.conversionRate}% conversion rate</p>
              </div>
              <Target className="w-8 h-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Satisfaction Score</p>
                <p className="text-2xl font-bold text-orange-600">{crmMetrics.customerSatisfaction}/10</p>
                <p className="text-xs text-green-600">+0.3 vs last month</p>
              </div>
              <Star className="w-8 h-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="customers" className="space-y-4">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="customers">Customers</TabsTrigger>
          <TabsTrigger value="opportunities">Opportunities</TabsTrigger>
          <TabsTrigger value="interactions">Interactions</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>

        <TabsContent value="customers" className="space-y-4">
          {/* Filters */}
          <div className="flex flex-wrap gap-4 items-center">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search customers..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 w-64"
              />
            </div>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="prospect">Prospect</SelectItem>
                <SelectItem value="inactive">Inactive</SelectItem>
                <SelectItem value="churned">Churned</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filterTier} onValueChange={setFilterTier}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Tier" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Tiers</SelectItem>
                <SelectItem value="platinum">Platinum</SelectItem>
                <SelectItem value="gold">Gold</SelectItem>
                <SelectItem value="silver">Silver</SelectItem>
                <SelectItem value="bronze">Bronze</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Customers List */}
          <div className="space-y-4">
            {filteredCustomers.map((customer) => (
              <Card key={customer.id} className="hover:shadow-md transition-shadow cursor-pointer"
                    onClick={() => setSelectedCustomer(customer)}>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <Building className="w-5 h-5" />
                        <h3 className="font-semibold text-lg">{customer.name}</h3>
                        <Badge className={getStatusColor(customer.status)}>
                          {customer.status}
                        </Badge>
                        <Badge className={getTierColor(customer.tier)}>
                          {customer.tier}
                        </Badge>
                        <div className="flex items-center gap-1">
                          <Star className="w-4 h-4 text-yellow-500 fill-current" />
                          <span className="text-sm font-medium">{customer.satisfactionScore}</span>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm mb-3">
                        <div>
                          <p className="text-gray-500">Contact</p>
                          <p className="font-medium">{customer.contactPerson}</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Industry</p>
                          <p className="font-medium">{customer.industry}</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Annual Revenue</p>
                          <p className="font-medium">${customer.annualRevenue.toLocaleString()}</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Total Orders</p>
                          <p className="font-medium">{customer.totalOrders}</p>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm mb-3">
                        <div>
                          <p className="text-gray-500">Total Value</p>
                          <p className="font-medium">${customer.totalValue.toLocaleString()}</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Avg Order Value</p>
                          <p className="font-medium">${customer.averageOrderValue.toLocaleString()}</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Outstanding</p>
                          <p className="font-medium">${customer.outstandingBalance.toLocaleString()}</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Last Order</p>
                          <p className="font-medium">{format(customer.lastOrderDate, "MMM dd, yyyy")}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-4 text-sm text-gray-600">
                        <div className="flex items-center gap-1">
                          <Mail className="w-4 h-4" />
                          <span>{customer.email}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Phone className="w-4 h-4" />
                          <span>{customer.phone}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <MapPin className="w-4 h-4" />
                          <span>{customer.city}, {customer.country}</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex gap-2 ml-4">
                      <Button size="sm" variant="outline">
                        <Eye className="w-4 h-4" />
                      </Button>
                      <Button size="sm" variant="outline">
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button size="sm" variant="outline">
                        <MessageSquare className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="opportunities" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Sales Pipeline</h3>
            <Button onClick={() => setShowOpportunityDialog(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Add Opportunity
            </Button>
          </div>

          <div className="space-y-4">
            {sampleOpportunities.map((opportunity) => (
              <Card key={opportunity.id}>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <Target className="w-5 h-5" />
                        <h3 className="font-semibold text-lg">{opportunity.title}</h3>
                        <Badge className={getStageColor(opportunity.stage)}>
                          {opportunity.stage.replace('_', ' ')}
                        </Badge>
                        <Badge variant="outline">
                          {opportunity.probability}% probability
                        </Badge>
                      </div>
                      
                      <p className="text-gray-600 mb-3">{opportunity.description}</p>
                      
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm mb-3">
                        <div>
                          <p className="text-gray-500">Customer</p>
                          <p className="font-medium">{opportunity.customerName}</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Value</p>
                          <p className="font-medium">${opportunity.value.toLocaleString()}</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Expected Close</p>
                          <p className="font-medium">{format(opportunity.expectedCloseDate, "MMM dd, yyyy")}</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Assigned To</p>
                          <p className="font-medium">{opportunity.assignedTo}</p>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm mb-3">
                        <div>
                          <p className="text-gray-500">Source</p>
                          <p className="font-medium">{opportunity.source}</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Next Action</p>
                          <p className="font-medium">{opportunity.nextAction}</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Last Activity</p>
                          <p className="font-medium">{format(opportunity.lastActivity, "MMM dd, yyyy")}</p>
                        </div>
                      </div>

                      {opportunity.products.length > 0 && (
                        <div className="mb-3">
                          <p className="text-gray-500 text-sm mb-1">Products:</p>
                          <div className="flex flex-wrap gap-1">
                            {opportunity.products.map((product, index) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {product}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}

                      <div className="mb-2">
                        <div className="flex justify-between text-sm mb-1">
                          <span>Probability</span>
                          <span>{opportunity.probability}%</span>
                        </div>
                        <Progress value={opportunity.probability} className="h-2" />
                      </div>
                    </div>
                    
                    <div className="flex gap-2 ml-4">
                      <Button size="sm" variant="outline">
                        <Eye className="w-4 h-4" />
                      </Button>
                      <Button size="sm" variant="outline">
                        <Edit className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="interactions" className="space-y-4">
          <div className="space-y-4">
            {sampleInteractions.map((interaction) => (
              <Card key={interaction.id}>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <MessageSquare className="w-5 h-5" />
                        <h3 className="font-semibold">{interaction.subject}</h3>
                        <Badge variant="outline">{interaction.type}</Badge>
                        <Badge className={`${getOutcomeColor(interaction.outcome)} bg-transparent`}>
                          {interaction.outcome}
                        </Badge>
                      </div>
                      
                      <p className="text-gray-600 mb-3">{interaction.description}</p>
                      
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <p className="text-gray-500">Customer</p>
                          <p className="font-medium">
                            {sampleCustomers.find(c => c.id === interaction.customerId)?.name}
                          </p>
                        </div>
                        <div>
                          <p className="text-gray-500">Assigned To</p>
                          <p className="font-medium">{interaction.assignedTo}</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Date</p>
                          <p className="font-medium">{format(interaction.createdDate, "MMM dd, yyyy")}</p>
                        </div>
                        {interaction.duration && (
                          <div>
                            <p className="text-gray-500">Duration</p>
                            <p className="font-medium">{interaction.duration} minutes</p>
                          </div>
                        )}
                      </div>

                      {interaction.followUpRequired && (
                        <div className="mt-3 p-3 bg-yellow-50 border border-yellow-200 rounded">
                          <div className="flex items-center gap-2">
                            <Clock className="w-4 h-4 text-yellow-600" />
                            <span className="text-sm text-yellow-800">
                              Follow-up required by {interaction.followUpDate && format(interaction.followUpDate, "MMM dd, yyyy")}
                            </span>
                          </div>
                        </div>
                      )}
                    </div>
                    
                    <div className="flex gap-2 ml-4">
                      <Button size="sm" variant="outline">
                        <Edit className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Revenue Trends */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <TrendingUp className="w-5 h-5 mr-2" />
                  Revenue Trends
                </CardTitle>
                <CardDescription>Monthly revenue and customer acquisition</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <AreaChart data={revenueData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip formatter={(value: number, name: string) => [
                      name === 'revenue' ? `$${value.toLocaleString()}` : value,
                      name === 'revenue' ? 'Revenue' : 'Customers'
                    ]} />
                    <Area type="monotone" dataKey="revenue" stroke="#8884d8" fill="#8884d8" fillOpacity={0.3} />
                    <Line type="monotone" dataKey="customers" stroke="#82ca9d" strokeWidth={2} />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Customer Distribution */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Users className="w-5 h-5 mr-2" />
                  Customer Distribution
                </CardTitle>
                <CardDescription>Customer segments by type and revenue</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <PieChart>
                    <Pie
                      data={customerDistribution}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, value }) => `${name}: ${value}`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {customerDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value: number, name: string) => [value, 'Customers']} />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Pipeline Analysis */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BarChart3 className="w-5 h-5 mr-2" />
                  Sales Pipeline
                </CardTitle>
                <CardDescription>Opportunities by stage and value</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <BarChart data={pipelineData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="stage" />
                    <YAxis />
                    <Tooltip formatter={(value: number, name: string) => [
                      name === 'value' ? `$${value.toLocaleString()}` : value,
                      name === 'value' ? 'Value' : 'Count'
                    ]} />
                    <Bar dataKey="count" fill="#8884d8" name="Count" />
                    <Bar dataKey="value" fill="#82ca9d" name="Value" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Key Metrics */}
            <Card>
              <CardHeader>
                <CardTitle>Performance Metrics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm">Conversion Rate</span>
                      <span className="text-sm font-semibold">{crmMetrics.conversionRate}%</span>
                    </div>
                    <Progress value={crmMetrics.conversionRate} />
                  </div>
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm">Customer Satisfaction</span>
                      <span className="text-sm font-semibold">{crmMetrics.customerSatisfaction}/10</span>
                    </div>
                    <Progress value={crmMetrics.customerSatisfaction * 10} />
                  </div>
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm">Acquisition Rate</span>
                      <span className="text-sm font-semibold">{crmMetrics.acquisitionRate}%</span>
                    </div>
                    <Progress value={crmMetrics.acquisitionRate} />
                  </div>
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm">Churn Rate</span>
                      <span className="text-sm font-semibold">{crmMetrics.churnRate}%</span>
                    </div>
                    <Progress value={100 - crmMetrics.churnRate} className="bg-red-100" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="reports" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <Card className="hover:shadow-md transition-shadow cursor-pointer">
              <CardContent className="p-4">
                <div className="flex items-center gap-3 mb-2">
                  <Users className="w-6 h-6 text-blue-600" />
                  <h3 className="font-semibold">Customer Analysis</h3>
                </div>
                <p className="text-sm text-gray-600 mb-3">
                  Comprehensive customer segmentation and behavior analysis
                </p>
                <Button size="sm" variant="outline" className="w-full">
                  <Download className="w-4 h-4 mr-2" />
                  Generate
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-md transition-shadow cursor-pointer">
              <CardContent className="p-4">
                <div className="flex items-center gap-3 mb-2">
                  <DollarSign className="w-6 h-6 text-green-600" />
                  <h3 className="font-semibold">Revenue Report</h3>
                </div>
                <p className="text-sm text-gray-600 mb-3">
                  Revenue breakdown by customer, product, and time period
                </p>
                <Button size="sm" variant="outline" className="w-full">
                  <Download className="w-4 h-4 mr-2" />
                  Generate
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-md transition-shadow cursor-pointer">
              <CardContent className="p-4">
                <div className="flex items-center gap-3 mb-2">
                  <Target className="w-6 h-6 text-purple-600" />
                  <h3 className="font-semibold">Sales Pipeline</h3>
                </div>
                <p className="text-sm text-gray-600 mb-3">
                  Detailed pipeline analysis and forecasting
                </p>
                <Button size="sm" variant="outline" className="w-full">
                  <Download className="w-4 h-4 mr-2" />
                  Generate
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-md transition-shadow cursor-pointer">
              <CardContent className="p-4">
                <div className="flex items-center gap-3 mb-2">
                  <Activity className="w-6 h-6 text-orange-600" />
                  <h3 className="font-semibold">Activity Report</h3>
                </div>
                <p className="text-sm text-gray-600 mb-3">
                  Customer interactions and engagement tracking
                </p>
                <Button size="sm" variant="outline" className="w-full">
                  <Download className="w-4 h-4 mr-2" />
                  Generate
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-md transition-shadow cursor-pointer">
              <CardContent className="p-4">
                <div className="flex items-center gap-3 mb-2">
                  <Star className="w-6 h-6 text-yellow-600" />
                  <h3 className="font-semibold">Satisfaction Survey</h3>
                </div>
                <p className="text-sm text-gray-600 mb-3">
                  Customer satisfaction scores and feedback analysis
                </p>
                <Button size="sm" variant="outline" className="w-full">
                  <Download className="w-4 h-4 mr-2" />
                  Generate
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-md transition-shadow cursor-pointer">
              <CardContent className="p-4">
                <div className="flex items-center gap-3 mb-2">
                  <Award className="w-6 h-6 text-indigo-600" />
                  <h3 className="font-semibold">Executive Summary</h3>
                </div>
                <p className="text-sm text-gray-600 mb-3">
                  High-level CRM performance and key insights
                </p>
                <Button size="sm" variant="outline" className="w-full">
                  <Download className="w-4 h-4 mr-2" />
                  Generate
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Add Customer Dialog */}
      <Dialog open={showCustomerDialog} onOpenChange={setShowCustomerDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Add New Customer</DialogTitle>
            <DialogDescription>
              Enter customer information to add them to the CRM
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="customerName">Company Name</Label>
                <Input placeholder="TechCorp Industries" />
              </div>
              <div>
                <Label htmlFor="contactPerson">Contact Person</Label>
                <Input placeholder="John Wilson" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="email">Email</Label>
                <Input type="email" placeholder="contact@company.com" />
              </div>
              <div>
                <Label htmlFor="phone">Phone</Label>
                <Input placeholder="+1-555-0123" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="industry">Industry</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select industry" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="technology">Technology</SelectItem>
                    <SelectItem value="manufacturing">Manufacturing</SelectItem>
                    <SelectItem value="automotive">Automotive</SelectItem>
                    <SelectItem value="aerospace">Aerospace</SelectItem>
                    <SelectItem value="healthcare">Healthcare</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="type">Customer Type</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="enterprise">Enterprise</SelectItem>
                    <SelectItem value="mid_market">Mid-Market</SelectItem>
                    <SelectItem value="small_business">Small Business</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label htmlFor="address">Address</Label>
              <Textarea placeholder="Full company address" />
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setShowCustomerDialog(false)}>
              Cancel
            </Button>
            <Button onClick={() => createCustomer({})}>
              Add Customer
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Add Opportunity Dialog */}
      <Dialog open={showOpportunityDialog} onOpenChange={setShowOpportunityDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Create New Opportunity</DialogTitle>
            <DialogDescription>
              Add a new sales opportunity to the pipeline
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="oppTitle">Opportunity Title</Label>
                <Input placeholder="Automation System Upgrade" />
              </div>
              <div>
                <Label htmlFor="customer">Customer</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select customer" />
                  </SelectTrigger>
                  <SelectContent>
                    {sampleCustomers.map((customer) => (
                      <SelectItem key={customer.id} value={customer.id}>
                        {customer.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label htmlFor="description">Description</Label>
              <Textarea placeholder="Detailed description of the opportunity" />
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label htmlFor="value">Value ($)</Label>
                <Input type="number" placeholder="850000" />
              </div>
              <div>
                <Label htmlFor="probability">Probability (%)</Label>
                <Input type="number" placeholder="75" min="0" max="100" />
              </div>
              <div>
                <Label htmlFor="stage">Stage</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select stage" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="prospecting">Prospecting</SelectItem>
                    <SelectItem value="qualification">Qualification</SelectItem>
                    <SelectItem value="proposal">Proposal</SelectItem>
                    <SelectItem value="negotiation">Negotiation</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setShowOpportunityDialog(false)}>
              Cancel
            </Button>
            <Button onClick={() => createOpportunity({})}>
              Create Opportunity
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}