import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import {
  CalendarIcon,
  Wrench,
  Clock,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Plus,
  Filter,
  Search,
  BarChart3,
  Settings,
  Wrench as Tool,
  Battery,
  Thermometer,
  Gauge,
  Timer,
  FileText,
  Download,
  Eye,
  Edit,
  Trash2,
  RotateCcw
} from "lucide-react";
import { format, addDays, isAfter, isBefore } from "date-fns";

interface MaintenanceTask {
  id: number;
  equipmentId: string;
  equipmentName: string;
  taskType: "routine" | "inspection" | "repair" | "calibration" | "replacement";
  priority: "low" | "medium" | "high" | "critical";
  status: "scheduled" | "in_progress" | "completed" | "overdue" | "cancelled";
  scheduledDate: Date;
  completedDate?: Date;
  assignedTo: string;
  estimatedDuration: number;
  actualDuration?: number;
  description: string;
  instructions: string;
  requiredParts: string[];
  cost: number;
  notes?: string;
  nextDueDate?: Date;
}

interface Equipment {
  id: string;
  name: string;
  type: string;
  location: string;
  status: "operational" | "maintenance" | "down" | "retired";
  lastMaintenance: Date;
  nextMaintenance: Date;
  maintenanceInterval: number; // days
  criticality: "low" | "medium" | "high" | "critical";
  warranty: boolean;
  manufacturer: string;
  model: string;
  serialNumber: string;
  installDate: Date;
  totalDowntime: number; // hours
  maintenanceCost: number;
}

interface MaintenanceMetrics {
  totalTasks: number;
  completedTasks: number;
  overdueTasks: number;
  upcomingTasks: number;
  averageRepairTime: number;
  equipmentUptime: number;
  maintenanceCost: number;
  preventiveRatio: number;
}

export default function PreventiveMaintenance() {
  const [selectedDate, setSelectedDate] = useState<Date>();
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [filterPriority, setFilterPriority] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [showTaskDialog, setShowTaskDialog] = useState(false);
  const [selectedTask, setSelectedTask] = useState<MaintenanceTask | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Sample data - in production, this would come from API
  const sampleTasks: MaintenanceTask[] = [
    {
      id: 1,
      equipmentId: "EQ001",
      equipmentName: "CNC Machine #1",
      taskType: "routine",
      priority: "high",
      status: "scheduled",
      scheduledDate: new Date(2025, 5, 20),
      assignedTo: "John Smith",
      estimatedDuration: 4,
      description: "Monthly preventive maintenance",
      instructions: "Replace filters, check fluid levels, calibrate sensors",
      requiredParts: ["Filter Kit", "Hydraulic Oil", "Sensor Calibration Kit"],
      cost: 350,
      nextDueDate: new Date(2025, 6, 20)
    },
    {
      id: 2,
      equipmentId: "EQ002",
      equipmentName: "Conveyor Belt A",
      taskType: "inspection",
      priority: "medium",
      status: "overdue",
      scheduledDate: new Date(2025, 5, 15),
      assignedTo: "Mike Johnson",
      estimatedDuration: 2,
      description: "Belt tension and alignment check",
      instructions: "Inspect belt condition, adjust tension, check alignment",
      requiredParts: ["Tension Gauge"],
      cost: 150
    },
    {
      id: 3,
      equipmentId: "EQ003",
      equipmentName: "Hydraulic Press #2",
      taskType: "repair",
      priority: "critical",
      status: "in_progress",
      scheduledDate: new Date(2025, 5, 18),
      assignedTo: "Sarah Davis",
      estimatedDuration: 8,
      actualDuration: 6,
      description: "Hydraulic system leak repair",
      instructions: "Replace damaged seals, test pressure, check for additional leaks",
      requiredParts: ["Seal Kit", "Hydraulic Fluid"],
      cost: 800
    }
  ];

  const sampleEquipment: Equipment[] = [
    {
      id: "EQ001",
      name: "CNC Machine #1",
      type: "Machining",
      location: "Production Floor A",
      status: "operational",
      lastMaintenance: new Date(2025, 4, 20),
      nextMaintenance: new Date(2025, 5, 20),
      maintenanceInterval: 30,
      criticality: "high",
      warranty: true,
      manufacturer: "HAAS",
      model: "VF-2SS",
      serialNumber: "1234567",
      installDate: new Date(2023, 0, 15),
      totalDowntime: 24,
      maintenanceCost: 5200
    },
    {
      id: "EQ002",
      name: "Conveyor Belt A",
      type: "Material Handling",
      location: "Assembly Line",
      status: "maintenance",
      lastMaintenance: new Date(2025, 4, 10),
      nextMaintenance: new Date(2025, 5, 25),
      maintenanceInterval: 45,
      criticality: "medium",
      warranty: false,
      manufacturer: "FlexLink",
      model: "X65",
      serialNumber: "CV001",
      installDate: new Date(2022, 5, 10),
      totalDowntime: 48,
      maintenanceCost: 1800
    }
  ];

  const metrics: MaintenanceMetrics = {
    totalTasks: 125,
    completedTasks: 108,
    overdueTasks: 7,
    upcomingTasks: 15,
    averageRepairTime: 4.2,
    equipmentUptime: 94.7,
    maintenanceCost: 42500,
    preventiveRatio: 78.5
  };

  const filteredTasks = sampleTasks.filter(task => {
    const matchesStatus = filterStatus === "all" || task.status === filterStatus;
    const matchesPriority = filterPriority === "all" || task.priority === filterPriority;
    const matchesSearch = searchQuery === "" || 
      task.equipmentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      task.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    return matchesStatus && matchesPriority && matchesSearch;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "scheduled": return "bg-blue-100 text-blue-800";
      case "in_progress": return "bg-yellow-100 text-yellow-800";
      case "completed": return "bg-green-100 text-green-800";
      case "overdue": return "bg-red-100 text-red-800";
      case "cancelled": return "bg-gray-100 text-gray-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "low": return "bg-gray-100 text-gray-800";
      case "medium": return "bg-blue-100 text-blue-800";
      case "high": return "bg-orange-100 text-orange-800";
      case "critical": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "scheduled": return <Clock className="w-4 h-4" />;
      case "in_progress": return <RotateCcw className="w-4 h-4 animate-spin" />;
      case "completed": return <CheckCircle className="w-4 h-4" />;
      case "overdue": return <AlertTriangle className="w-4 h-4" />;
      case "cancelled": return <XCircle className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  const createTask = (taskData: Partial<MaintenanceTask>) => {
    // In production, this would make an API call
    toast({
      title: "Task Created",
      description: "Maintenance task has been scheduled successfully",
    });
    setShowTaskDialog(false);
  };

  const updateTaskStatus = (taskId: number, newStatus: string) => {
    // In production, this would make an API call
    toast({
      title: "Task Updated",
      description: `Task status changed to ${newStatus}`,
    });
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-3xl font-bold mb-2">Preventive Maintenance</h1>
          <p className="text-gray-600">
            Equipment maintenance scheduling, tracking, and performance analytics
          </p>
        </div>
        <Button onClick={() => setShowTaskDialog(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Schedule Maintenance
        </Button>
      </div>

      {/* Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Equipment Uptime</p>
                <p className="text-2xl font-bold text-green-600">{metrics.equipmentUptime}%</p>
              </div>
              <Gauge className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Overdue Tasks</p>
                <p className="text-2xl font-bold text-red-600">{metrics.overdueTasks}</p>
              </div>
              <AlertTriangle className="w-8 h-8 text-red-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Preventive Ratio</p>
                <p className="text-2xl font-bold text-blue-600">{metrics.preventiveRatio}%</p>
              </div>
              <BarChart3 className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Monthly Cost</p>
                <p className="text-2xl font-bold text-purple-600">${metrics.maintenanceCost.toLocaleString()}</p>
              </div>
              <Tool className="w-8 h-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="tasks" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="tasks">Maintenance Tasks</TabsTrigger>
          <TabsTrigger value="equipment">Equipment</TabsTrigger>
          <TabsTrigger value="schedule">Schedule</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="tasks" className="space-y-4">
          {/* Filters */}
          <div className="flex flex-wrap gap-4 items-center justify-between">
            <div className="flex gap-4 items-center">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search tasks..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 w-64"
                />
              </div>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="scheduled">Scheduled</SelectItem>
                  <SelectItem value="in_progress">In Progress</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="overdue">Overdue</SelectItem>
                </SelectContent>
              </Select>
              <Select value={filterPriority} onValueChange={setFilterPriority}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Priority" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Priority</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Tasks List */}
          <div className="space-y-4">
            {filteredTasks.map((task) => (
              <Card key={task.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        {getStatusIcon(task.status)}
                        <h3 className="font-semibold text-lg">{task.equipmentName}</h3>
                        <Badge className={getStatusColor(task.status)}>
                          {task.status.replace('_', ' ')}
                        </Badge>
                        <Badge className={getPriorityColor(task.priority)}>
                          {task.priority}
                        </Badge>
                      </div>
                      
                      <p className="text-gray-600 mb-3">{task.description}</p>
                      
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <p className="text-gray-500">Scheduled Date</p>
                          <p className="font-medium">{format(task.scheduledDate, "MMM dd, yyyy")}</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Assigned To</p>
                          <p className="font-medium">{task.assignedTo}</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Duration</p>
                          <p className="font-medium">
                            {task.actualDuration || task.estimatedDuration}h
                            {task.actualDuration && task.actualDuration !== task.estimatedDuration && 
                              <span className="text-gray-400"> (est. {task.estimatedDuration}h)</span>
                            }
                          </p>
                        </div>
                        <div>
                          <p className="text-gray-500">Cost</p>
                          <p className="font-medium">${task.cost}</p>
                        </div>
                      </div>

                      {task.requiredParts.length > 0 && (
                        <div className="mt-3">
                          <p className="text-gray-500 text-sm mb-1">Required Parts:</p>
                          <div className="flex flex-wrap gap-1">
                            {task.requiredParts.map((part, index) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {part}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                    
                    <div className="flex gap-2 ml-4">
                      <Button size="sm" variant="outline">
                        <Eye className="w-4 h-4" />
                      </Button>
                      <Button size="sm" variant="outline">
                        <Edit className="w-4 h-4" />
                      </Button>
                      {task.status === "scheduled" && (
                        <Button 
                          size="sm" 
                          onClick={() => updateTaskStatus(task.id, "in_progress")}
                        >
                          Start
                        </Button>
                      )}
                      {task.status === "in_progress" && (
                        <Button 
                          size="sm" 
                          onClick={() => updateTaskStatus(task.id, "completed")}
                          className="bg-green-600 hover:bg-green-700"
                        >
                          Complete
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="equipment" className="space-y-4">
          <div className="grid gap-4">
            {sampleEquipment.map((equipment) => (
              <Card key={equipment.id}>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <Settings className="w-5 h-5" />
                        <h3 className="font-semibold text-lg">{equipment.name}</h3>
                        <Badge className={
                          equipment.status === "operational" ? "bg-green-100 text-green-800" :
                          equipment.status === "maintenance" ? "bg-yellow-100 text-yellow-800" :
                          equipment.status === "down" ? "bg-red-100 text-red-800" :
                          "bg-gray-100 text-gray-800"
                        }>
                          {equipment.status}
                        </Badge>
                        <Badge className={getPriorityColor(equipment.criticality)}>
                          {equipment.criticality} criticality
                        </Badge>
                      </div>
                      
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm mb-4">
                        <div>
                          <p className="text-gray-500">Type</p>
                          <p className="font-medium">{equipment.type}</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Location</p>
                          <p className="font-medium">{equipment.location}</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Last Maintenance</p>
                          <p className="font-medium">{format(equipment.lastMaintenance, "MMM dd, yyyy")}</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Next Maintenance</p>
                          <p className="font-medium">{format(equipment.nextMaintenance, "MMM dd, yyyy")}</p>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <p className="text-gray-500">Manufacturer</p>
                          <p className="font-medium">{equipment.manufacturer}</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Model</p>
                          <p className="font-medium">{equipment.model}</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Total Downtime</p>
                          <p className="font-medium">{equipment.totalDowntime}h</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Maintenance Cost</p>
                          <p className="font-medium">${equipment.maintenanceCost.toLocaleString()}</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex gap-2 ml-4">
                      <Button size="sm" variant="outline">
                        <FileText className="w-4 h-4" />
                      </Button>
                      <Button size="sm" variant="outline">
                        <Wrench className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="schedule" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Maintenance Schedule Calendar</CardTitle>
              <CardDescription>View and manage upcoming maintenance tasks</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <Calendar
                    mode="single"
                    selected={selectedDate}
                    onSelect={setSelectedDate}
                    className="rounded-md border"
                  />
                </div>
                <div className="space-y-4">
                  <h3 className="font-semibold">Upcoming Tasks</h3>
                  {sampleTasks
                    .filter(task => task.status === "scheduled")
                    .slice(0, 5)
                    .map((task) => (
                      <div key={task.id} className="border rounded-lg p-3">
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-medium">{task.equipmentName}</span>
                          <Badge className={getPriorityColor(task.priority)}>
                            {task.priority}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-600 mb-1">{task.description}</p>
                        <p className="text-xs text-gray-500">
                          {format(task.scheduledDate, "MMM dd, yyyy")} • {task.estimatedDuration}h
                        </p>
                      </div>
                    ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Maintenance Performance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Completed Tasks</span>
                      <span>{metrics.completedTasks}/{metrics.totalTasks}</span>
                    </div>
                    <Progress value={(metrics.completedTasks / metrics.totalTasks) * 100} />
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Equipment Uptime</span>
                      <span>{metrics.equipmentUptime}%</span>
                    </div>
                    <Progress value={metrics.equipmentUptime} />
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Preventive vs Reactive</span>
                      <span>{metrics.preventiveRatio}%</span>
                    </div>
                    <Progress value={metrics.preventiveRatio} />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Cost Analysis</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-blue-600">${metrics.maintenanceCost.toLocaleString()}</p>
                    <p className="text-sm text-gray-600">Monthly maintenance cost</p>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Preventive Maintenance</span>
                      <span className="font-medium">${Math.round(metrics.maintenanceCost * 0.7).toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Emergency Repairs</span>
                      <span className="font-medium">${Math.round(metrics.maintenanceCost * 0.3).toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Average Repair Time</span>
                      <span className="font-medium">{metrics.averageRepairTime}h</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Create Task Dialog */}
      <Dialog open={showTaskDialog} onOpenChange={setShowTaskDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Schedule Maintenance Task</DialogTitle>
            <DialogDescription>
              Create a new maintenance task for equipment
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="equipment">Equipment</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select equipment" />
                  </SelectTrigger>
                  <SelectContent>
                    {sampleEquipment.map((eq) => (
                      <SelectItem key={eq.id} value={eq.id}>
                        {eq.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="taskType">Task Type</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="routine">Routine</SelectItem>
                    <SelectItem value="inspection">Inspection</SelectItem>
                    <SelectItem value="repair">Repair</SelectItem>
                    <SelectItem value="calibration">Calibration</SelectItem>
                    <SelectItem value="replacement">Replacement</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="priority">Priority</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select priority" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="critical">Critical</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="assignedTo">Assigned To</Label>
                <Input placeholder="Technician name" />
              </div>
            </div>
            <div>
              <Label htmlFor="description">Description</Label>
              <Input placeholder="Brief description of the task" />
            </div>
            <div>
              <Label htmlFor="instructions">Instructions</Label>
              <Textarea placeholder="Detailed maintenance instructions" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="estimatedDuration">Estimated Duration (hours)</Label>
                <Input type="number" placeholder="4" />
              </div>
              <div>
                <Label htmlFor="cost">Estimated Cost</Label>
                <Input type="number" placeholder="500" />
              </div>
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setShowTaskDialog(false)}>
              Cancel
            </Button>
            <Button onClick={() => createTask({})}>
              Schedule Task
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}