import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Sidebar from "@/components/layout/sidebar";
import MobileNav from "@/components/layout/mobile-nav";
import KPICards from "@/components/dashboard/kpi-cards";
import ProductionOrdersWidget from "@/components/dashboard/production-orders-widget";
import AIInsightsWidget from "@/components/dashboard/ai-insights-widget";
import LowStockWidget from "@/components/dashboard/low-stock-widget";
import ActivityFeedWidget from "@/components/dashboard/activity-feed-widget";
import QuickActionsPanel from "@/components/dashboard/quick-actions-panel";
import ProductionAnalyticsWidget from "@/components/dashboard/production-analytics-widget";
import SmartReorderWidget from "@/components/inventory/smart-reorder-widget";
import NotificationCenter from "@/components/notifications/notification-center";
import StripePaymentWidget from "@/components/payments/stripe-payment-widget";
import MachineStatusWidget from "@/components/monitoring/machine-status-widget";
import { Search, FolderSync } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function Dashboard() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  if (isLoading || !isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-carbon-gray-10">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-carbon-blue border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-carbon-gray-50">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  const handleSync = () => {
    toast({
      title: "Syncing data",
      description: "Synchronizing with server...",
    });
  };

  const handleNotifications = () => {
    toast({
      title: "Notifications",
      description: "No new notifications",
    });
  };

  return (
    <div className="min-h-screen flex bg-carbon-gray-10">
      {/* Desktop Sidebar */}
      <div className="hidden lg:block">
        <Sidebar />
      </div>
      
      {/* Mobile Navigation */}
      <div className="lg:hidden">
        <MobileNav />
      </div>
      
      <div className="flex-1 flex flex-col overflow-hidden lg:ml-0">
        {/* Responsive Header */}
        <header className="bg-white border-b border-carbon-gray-20 px-4 sm:px-6 py-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div className="flex items-center">
              <div>
                <h1 className="text-xl sm:text-2xl font-semibold text-carbon-gray-80">Dashboard</h1>
                <p className="text-carbon-gray-50 text-sm mt-1">Overview of manufacturing operations</p>
              </div>
            </div>
            
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 sm:gap-4">
              {/* Online Status */}
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-carbon-green rounded-full"></div>
                <span className="text-sm text-carbon-gray-50">Online</span>
              </div>
              
              {/* FolderSync Button */}
              <Button
                variant="ghost"
                size="sm"
                onClick={handleSync}
                className="p-2 text-carbon-gray-50 hover:text-carbon-gray-80"
              >
                <FolderSync className="w-4 h-4" />
              </Button>
              
              {/* Notifications */}
              <NotificationCenter />
              
              {/* Search */}
              <div className="relative">
                <Input
                  type="text"
                  placeholder="Search..."
                  className="pl-10 pr-4 py-2 w-64"
                />
                <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-carbon-gray-50" />
              </div>
            </div>
          </div>
        </header>

        {/* Dashboard Content */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6">
          {/* KPI Cards */}
          <KPICards />

          {/* Main Content Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
            {/* Left Column - Main Content */}
            <div className="lg:col-span-2 space-y-4 sm:space-y-6">
              <ProductionAnalyticsWidget />
              <ProductionOrdersWidget />
              <ActivityFeedWidget />
            </div>

            {/* Right Column - Sidebar Widgets */}
            <div className="space-y-4 sm:space-y-6">
              <LowStockWidget />
              <SmartReorderWidget />
              <MachineStatusWidget />
              <StripePaymentWidget />
              <AIInsightsWidget />
            </div>
          </div>

          {/* Quick Actions Panel */}
          <QuickActionsPanel />
        </main>
      </div>
    </div>
  );
}
