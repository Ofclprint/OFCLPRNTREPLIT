import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  Area,
  AreaChart,
  ScatterChart,
  Scatter
} from "recharts";
import {
  Package,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  CheckCircle,
  RotateCcw,
  Target,
  Zap,
  Brain,
  BarChart3,
  Settings,
  Search,
  Filter,
  Download,
  Play,
  Pause,
  RefreshCw,
  Clock,
  DollarSign,
  Truck,
  Warehouse,
  Activity
} from "lucide-react";

interface InventoryItem {
  id: string;
  sku: string;
  name: string;
  currentStock: number;
  optimalStock: number;
  reorderPoint: number;
  maxStock: number;
  averageDemand: number;
  leadTime: number;
  unitCost: number;
  carryingCost: number;
  stockoutCost: number;
  velocity: "fast" | "medium" | "slow";
  category: string;
  supplier: string;
  location: string;
  lastOrdered: Date;
  nextReorderDate: Date;
  optimizationScore: number;
  recommendations: string[];
}

interface OptimizationMetrics {
  totalItems: number;
  optimizedItems: number;
  stockoutRisk: number;
  overstockItems: number;
  totalValue: number;
  carryingCost: number;
  turnoverRate: number;
  fillRate: number;
  serviceLevel: number;
  potentialSavings: number;
}

interface ReorderSuggestion {
  id: string;
  itemName: string;
  sku: string;
  currentStock: number;
  suggestedQuantity: number;
  urgency: "critical" | "high" | "medium" | "low";
  reason: string;
  costImpact: number;
  leadTime: number;
  supplier: string;
  confidence: number;
}

interface DemandForecast {
  period: string;
  predicted: number;
  actual?: number;
  confidence: number;
  trend: "increasing" | "decreasing" | "stable";
}

export default function InventoryOptimization() {
  const [isOptimizationRunning, setIsOptimizationRunning] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedVelocity, setSelectedVelocity] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [autoOptimization, setAutoOptimization] = useState(true);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const sampleInventoryItems: InventoryItem[] = [
    {
      id: "INV001",
      sku: "WDG-001",
      name: "Widget Pro Base",
      currentStock: 850,
      optimalStock: 1200,
      reorderPoint: 400,
      maxStock: 2000,
      averageDemand: 45,
      leadTime: 7,
      unitCost: 12.50,
      carryingCost: 2.80,
      stockoutCost: 45.00,
      velocity: "fast",
      category: "Components",
      supplier: "Acme Parts Co",
      location: "Warehouse A",
      lastOrdered: new Date(2025, 4, 15),
      nextReorderDate: new Date(2025, 5, 22),
      optimizationScore: 78,
      recommendations: ["Increase reorder point by 15%", "Consider bulk discount opportunity"]
    },
    {
      id: "INV002",
      sku: "STL-042",
      name: "Steel Rod 6mm",
      currentStock: 2400,
      optimalStock: 1800,
      reorderPoint: 600,
      maxStock: 3000,
      averageDemand: 28,
      leadTime: 14,
      unitCost: 8.75,
      carryingCost: 1.95,
      stockoutCost: 32.00,
      velocity: "medium",
      category: "Raw Materials",
      supplier: "Steel Supply Inc",
      location: "Warehouse B",
      lastOrdered: new Date(2025, 3, 28),
      nextReorderDate: new Date(2025, 6, 5),
      optimizationScore: 65,
      recommendations: ["Reduce overstock", "Negotiate better lead time"]
    },
    {
      id: "INV003",
      sku: "FLT-220",
      name: "Filter Assembly",
      currentStock: 45,
      optimalStock: 120,
      reorderPoint: 80,
      maxStock: 250,
      averageDemand: 8,
      leadTime: 21,
      unitCost: 24.00,
      carryingCost: 5.40,
      stockoutCost: 180.00,
      velocity: "slow",
      category: "Finished Goods",
      supplier: "Filter Tech Ltd",
      location: "Warehouse A",
      lastOrdered: new Date(2025, 2, 10),
      nextReorderDate: new Date(2025, 5, 18),
      optimizationScore: 42,
      recommendations: ["Critical reorder needed", "Review demand forecast", "Consider alternative supplier"]
    }
  ];

  const optimizationMetrics: OptimizationMetrics = {
    totalItems: 1250,
    optimizedItems: 975,
    stockoutRisk: 12.3,
    overstockItems: 45,
    totalValue: 2850000,
    carryingCost: 342000,
    turnoverRate: 8.4,
    fillRate: 96.7,
    serviceLevel: 98.2,
    potentialSavings: 125000
  };

  const reorderSuggestions: ReorderSuggestion[] = [
    {
      id: "RS001",
      itemName: "Widget Pro Base",
      sku: "WDG-001",
      currentStock: 850,
      suggestedQuantity: 600,
      urgency: "high",
      reason: "Approaching reorder point with high demand",
      costImpact: 7500,
      leadTime: 7,
      supplier: "Acme Parts Co",
      confidence: 92
    },
    {
      id: "RS002",
      itemName: "Filter Assembly",
      sku: "FLT-220",
      currentStock: 45,
      suggestedQuantity: 150,
      urgency: "critical",
      reason: "Below safety stock with long lead time",
      costImpact: 3600,
      leadTime: 21,
      supplier: "Filter Tech Ltd",
      confidence: 96
    },
    {
      id: "RS003",
      itemName: "Bearing Set",
      sku: "BRG-105",
      currentStock: 180,
      suggestedQuantity: 200,
      urgency: "medium",
      reason: "Seasonal demand increase expected",
      costImpact: 1200,
      leadTime: 10,
      supplier: "Precision Bearings",
      confidence: 78
    }
  ];

  const demandForecast: DemandForecast[] = [
    { period: "Week 1", predicted: 450, actual: 442, confidence: 94, trend: "stable" },
    { period: "Week 2", predicted: 465, actual: 471, confidence: 91, trend: "increasing" },
    { period: "Week 3", predicted: 485, actual: 479, confidence: 89, trend: "increasing" },
    { period: "Week 4", predicted: 502, confidence: 87, trend: "increasing" },
    { period: "Week 5", predicted: 518, confidence: 85, trend: "increasing" },
    { period: "Week 6", predicted: 525, confidence: 82, trend: "stable" },
    { period: "Week 7", predicted: 520, confidence: 80, trend: "stable" },
    { period: "Week 8", predicted: 515, confidence: 78, trend: "decreasing" }
  ];

  const abcAnalysis = [
    { category: "A", items: 125, value: 1995000, percentage: 70.0 },
    { category: "B", items: 375, value: 570000, percentage: 20.0 },
    { category: "C", items: 750, value: 285000, percentage: 10.0 }
  ];

  const filteredItems = sampleInventoryItems.filter(item => {
    const matchesCategory = selectedCategory === "all" || item.category === selectedCategory;
    const matchesVelocity = selectedVelocity === "all" || item.velocity === selectedVelocity;
    const matchesSearch = searchQuery === "" || 
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.sku.toLowerCase().includes(searchQuery.toLowerCase());
    
    return matchesCategory && matchesVelocity && matchesSearch;
  });

  const runOptimization = async () => {
    setIsOptimizationRunning(true);
    // Simulate optimization process
    await new Promise(resolve => setTimeout(resolve, 3000));
    setIsOptimizationRunning(false);
    toast({
      title: "Optimization Complete",
      description: "Inventory parameters have been optimized using AI algorithms",
    });
  };

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case "critical": return "bg-red-100 text-red-800";
      case "high": return "bg-orange-100 text-orange-800";
      case "medium": return "bg-yellow-100 text-yellow-800";
      case "low": return "bg-green-100 text-green-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getVelocityColor = (velocity: string) => {
    switch (velocity) {
      case "fast": return "bg-green-100 text-green-800";
      case "medium": return "bg-yellow-100 text-yellow-800";
      case "slow": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getStockStatus = (item: InventoryItem) => {
    if (item.currentStock <= item.reorderPoint) return { status: "reorder", color: "text-red-600" };
    if (item.currentStock >= item.maxStock * 0.9) return { status: "overstock", color: "text-orange-600" };
    if (item.currentStock >= item.optimalStock * 0.8) return { status: "optimal", color: "text-green-600" };
    return { status: "low", color: "text-yellow-600" };
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-3xl font-bold mb-2">Inventory Optimization</h1>
          <p className="text-gray-600">
            AI-powered inventory management with demand forecasting and automatic optimization
          </p>
        </div>
        <div className="flex gap-2">
          <div className="flex items-center space-x-2">
            <Switch
              checked={autoOptimization}
              onCheckedChange={setAutoOptimization}
            />
            <Label htmlFor="auto-opt">Auto Optimization</Label>
          </div>
          <Button 
            onClick={runOptimization} 
            disabled={isOptimizationRunning}
            className="bg-blue-600 hover:bg-blue-700"
          >
            {isOptimizationRunning ? (
              <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Brain className="w-4 h-4 mr-2" />
            )}
            {isOptimizationRunning ? "Optimizing..." : "Run AI Optimization"}
          </Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Service Level</p>
                <p className="text-2xl font-bold text-green-600">{optimizationMetrics.serviceLevel}%</p>
                <p className="text-xs text-gray-500">Target: 95%</p>
              </div>
              <Target className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Stockout Risk</p>
                <p className="text-2xl font-bold text-orange-600">{optimizationMetrics.stockoutRisk}%</p>
                <p className="text-xs text-gray-500">Items at risk: {optimizationMetrics.overstockItems}</p>
              </div>
              <AlertTriangle className="w-8 h-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Turnover Rate</p>
                <p className="text-2xl font-bold text-blue-600">{optimizationMetrics.turnoverRate}x</p>
                <p className="text-xs text-green-600">+12% vs last year</p>
              </div>
              <RotateCcw className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Potential Savings</p>
                <p className="text-2xl font-bold text-purple-600">${optimizationMetrics.potentialSavings.toLocaleString()}</p>
                <p className="text-xs text-gray-500">Through optimization</p>
              </div>
              <DollarSign className="w-8 h-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="items">Items</TabsTrigger>
          <TabsTrigger value="reorders">Reorders</TabsTrigger>
          <TabsTrigger value="forecasting">Forecasting</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* ABC Analysis */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BarChart3 className="w-5 h-5 mr-2" />
                  ABC Analysis
                </CardTitle>
                <CardDescription>Inventory value distribution by category</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {abcAnalysis.map((category) => (
                    <div key={category.category} className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="font-medium">Category {category.category}</span>
                        <div className="text-right">
                          <span className="text-sm font-medium">${category.value.toLocaleString()}</span>
                          <p className="text-xs text-gray-600">{category.items} items</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Progress value={category.percentage} className="flex-1" />
                        <span className="text-sm text-gray-600">{category.percentage}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Demand Forecast */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <TrendingUp className="w-5 h-5 mr-2" />
                  Demand Forecast
                </CardTitle>
                <CardDescription>8-week demand prediction with confidence intervals</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <AreaChart data={demandForecast}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="period" />
                    <YAxis />
                    <Tooltip />
                    <Area type="monotone" dataKey="predicted" stroke="#8884d8" fill="#8884d8" fillOpacity={0.3} />
                    <Line type="monotone" dataKey="actual" stroke="#82ca9d" strokeWidth={2} dot={{ fill: '#82ca9d' }} />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Optimization Summary */}
          <Card>
            <CardHeader>
              <CardTitle>Optimization Summary</CardTitle>
              <CardDescription>Current optimization status and recommendations</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <h4 className="font-semibold text-green-600">Optimized Items</h4>
                  <p className="text-2xl font-bold">{optimizationMetrics.optimizedItems}</p>
                  <p className="text-sm text-gray-600">
                    {((optimizationMetrics.optimizedItems / optimizationMetrics.totalItems) * 100).toFixed(1)}% of total inventory
                  </p>
                  <Progress value={(optimizationMetrics.optimizedItems / optimizationMetrics.totalItems) * 100} className="h-2" />
                </div>
                
                <div className="space-y-2">
                  <h4 className="font-semibold text-blue-600">Fill Rate</h4>
                  <p className="text-2xl font-bold">{optimizationMetrics.fillRate}%</p>
                  <p className="text-sm text-gray-600">Customer demand satisfaction</p>
                  <Progress value={optimizationMetrics.fillRate} className="h-2" />
                </div>
                
                <div className="space-y-2">
                  <h4 className="font-semibold text-purple-600">Carrying Cost</h4>
                  <p className="text-2xl font-bold">${optimizationMetrics.carryingCost.toLocaleString()}</p>
                  <p className="text-sm text-gray-600">
                    {((optimizationMetrics.carryingCost / optimizationMetrics.totalValue) * 100).toFixed(1)}% of inventory value
                  </p>
                  <Progress value={(optimizationMetrics.carryingCost / optimizationMetrics.totalValue) * 100} className="h-2" />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="items" className="space-y-4">
          {/* Filters */}
          <div className="flex flex-wrap gap-4 items-center">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search items..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 w-64"
              />
            </div>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="Components">Components</SelectItem>
                <SelectItem value="Raw Materials">Raw Materials</SelectItem>
                <SelectItem value="Finished Goods">Finished Goods</SelectItem>
              </SelectContent>
            </Select>
            <Select value={selectedVelocity} onValueChange={setSelectedVelocity}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Velocity" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Velocities</SelectItem>
                <SelectItem value="fast">Fast Moving</SelectItem>
                <SelectItem value="medium">Medium Moving</SelectItem>
                <SelectItem value="slow">Slow Moving</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Items List */}
          <div className="space-y-4">
            {filteredItems.map((item) => {
              const stockStatus = getStockStatus(item);
              return (
                <Card key={item.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <Package className="w-5 h-5" />
                          <h3 className="font-semibold text-lg">{item.name}</h3>
                          <Badge variant="outline">{item.sku}</Badge>
                          <Badge className={getVelocityColor(item.velocity)}>
                            {item.velocity} moving
                          </Badge>
                          <Badge className={stockStatus.color}>
                            {stockStatus.status}
                          </Badge>
                        </div>
                        
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm mb-4">
                          <div>
                            <p className="text-gray-500">Current Stock</p>
                            <p className="font-medium">{item.currentStock}</p>
                          </div>
                          <div>
                            <p className="text-gray-500">Optimal Stock</p>
                            <p className="font-medium">{item.optimalStock}</p>
                          </div>
                          <div>
                            <p className="text-gray-500">Reorder Point</p>
                            <p className="font-medium">{item.reorderPoint}</p>
                          </div>
                          <div>
                            <p className="text-gray-500">Lead Time</p>
                            <p className="font-medium">{item.leadTime} days</p>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm mb-4">
                          <div>
                            <p className="text-gray-500">Unit Cost</p>
                            <p className="font-medium">${item.unitCost}</p>
                          </div>
                          <div>
                            <p className="text-gray-500">Avg Demand</p>
                            <p className="font-medium">{item.averageDemand}/day</p>
                          </div>
                          <div>
                            <p className="text-gray-500">Supplier</p>
                            <p className="font-medium">{item.supplier}</p>
                          </div>
                          <div>
                            <p className="text-gray-500">Optimization Score</p>
                            <p className="font-medium">{item.optimizationScore}%</p>
                          </div>
                        </div>

                        <div className="mb-3">
                          <div className="flex justify-between text-sm mb-1">
                            <span>Stock Level</span>
                            <span>{((item.currentStock / item.maxStock) * 100).toFixed(1)}%</span>
                          </div>
                          <Progress value={(item.currentStock / item.maxStock) * 100} className="h-2" />
                        </div>

                        {item.recommendations.length > 0 && (
                          <div>
                            <p className="text-gray-500 text-sm mb-1">AI Recommendations:</p>
                            <div className="flex flex-wrap gap-1">
                              {item.recommendations.map((rec, index) => (
                                <Badge key={index} variant="outline" className="text-xs">
                                  {rec}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                      
                      <div className="flex gap-2 ml-4">
                        <Button size="sm" variant="outline">
                          <Settings className="w-4 h-4" />
                        </Button>
                        {item.currentStock <= item.reorderPoint && (
                          <Button size="sm" className="bg-orange-600 hover:bg-orange-700">
                            Reorder
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="reorders" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Reorder Suggestions</CardTitle>
              <CardDescription>AI-generated purchase recommendations based on demand forecasting</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {reorderSuggestions.map((suggestion) => (
                  <div key={suggestion.id} className="border rounded-lg p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h4 className="font-semibold">{suggestion.itemName}</h4>
                          <Badge variant="outline">{suggestion.sku}</Badge>
                          <Badge className={getUrgencyColor(suggestion.urgency)}>
                            {suggestion.urgency}
                          </Badge>
                          <Badge variant="outline">
                            {suggestion.confidence}% confidence
                          </Badge>
                        </div>
                        
                        <p className="text-gray-600 mb-3">{suggestion.reason}</p>
                        
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                          <div>
                            <p className="text-gray-500">Current Stock</p>
                            <p className="font-medium">{suggestion.currentStock}</p>
                          </div>
                          <div>
                            <p className="text-gray-500">Suggested Quantity</p>
                            <p className="font-medium">{suggestion.suggestedQuantity}</p>
                          </div>
                          <div>
                            <p className="text-gray-500">Cost Impact</p>
                            <p className="font-medium">${suggestion.costImpact.toLocaleString()}</p>
                          </div>
                          <div>
                            <p className="text-gray-500">Lead Time</p>
                            <p className="font-medium">{suggestion.leadTime} days</p>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex gap-2 ml-4">
                        <Button size="sm" variant="outline">
                          Review
                        </Button>
                        <Button size="sm" className="bg-green-600 hover:bg-green-700">
                          Create PO
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="forecasting" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Demand Accuracy</CardTitle>
                <CardDescription>Forecast vs actual demand comparison</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={demandForecast.filter(d => d.actual)}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="period" />
                    <YAxis />
                    <Tooltip />
                    <Line type="monotone" dataKey="predicted" stroke="#8884d8" strokeWidth={2} name="Predicted" />
                    <Line type="monotone" dataKey="actual" stroke="#82ca9d" strokeWidth={2} name="Actual" />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Forecast Confidence</CardTitle>
                <CardDescription>Confidence levels for future periods</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={demandForecast}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="period" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="confidence" fill="#8884d8" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Inventory Performance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm">Fill Rate</span>
                      <span className="text-sm font-semibold">{optimizationMetrics.fillRate}%</span>
                    </div>
                    <Progress value={optimizationMetrics.fillRate} />
                  </div>
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm">Service Level</span>
                      <span className="text-sm font-semibold">{optimizationMetrics.serviceLevel}%</span>
                    </div>
                    <Progress value={optimizationMetrics.serviceLevel} />
                  </div>
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm">Optimization Coverage</span>
                      <span className="text-sm font-semibold">
                        {((optimizationMetrics.optimizedItems / optimizationMetrics.totalItems) * 100).toFixed(1)}%
                      </span>
                    </div>
                    <Progress value={(optimizationMetrics.optimizedItems / optimizationMetrics.totalItems) * 100} />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Cost Analysis</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-green-600">${optimizationMetrics.potentialSavings.toLocaleString()}</p>
                    <p className="text-sm text-gray-600">Potential annual savings</p>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Current Carrying Cost</span>
                      <span>${optimizationMetrics.carryingCost.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Optimized Carrying Cost</span>
                      <span>${(optimizationMetrics.carryingCost - optimizationMetrics.potentialSavings).toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Inventory Turnover</span>
                      <span>{optimizationMetrics.turnoverRate}x annually</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="settings" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Optimization Settings</CardTitle>
              <CardDescription>Configure AI optimization parameters</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="auto-optimize">Automatic Optimization</Label>
                    <p className="text-sm text-gray-600">Run optimization daily at 2 AM</p>
                  </div>
                  <Switch checked={autoOptimization} onCheckedChange={setAutoOptimization} />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="service-level">Target Service Level (%)</Label>
                    <Input type="number" defaultValue="95" className="mt-1" />
                  </div>
                  <div>
                    <Label htmlFor="stockout-cost">Stockout Cost Weight</Label>
                    <Input type="number" defaultValue="1.5" step="0.1" className="mt-1" />
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="carrying-cost">Carrying Cost Rate (%)</Label>
                    <Input type="number" defaultValue="12" className="mt-1" />
                  </div>
                  <div>
                    <Label htmlFor="forecast-horizon">Forecast Horizon (weeks)</Label>
                    <Input type="number" defaultValue="8" className="mt-1" />
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="optimization-frequency">Optimization Frequency</Label>
                  <Select defaultValue="daily">
                    <SelectTrigger className="mt-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="hourly">Hourly</SelectItem>
                      <SelectItem value="daily">Daily</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="manual">Manual Only</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}