import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import Sidebar from "@/components/layout/sidebar";
import MobileNav from "@/components/layout/mobile-nav";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Search, Plus, CheckCircle, XCircle, Clock, User, FileText } from "lucide-react";
import { format } from "date-fns";

const qualityControlSchema = z.object({
  orderId: z.number().min(1, "Order is required"),
  itemId: z.number().optional(),
  status: z.enum(["pass", "fail", "pending"]),
  notes: z.string().optional(),
  defects: z.array(z.string()).optional(),
  testResults: z.record(z.any()).optional(),
});

type QualityControlLog = {
  id: number;
  orderId: number;
  itemId?: number;
  inspectorId: string;
  status: "pass" | "fail" | "pending";
  notes?: string;
  defects?: string[];
  images?: string[];
  testResults?: Record<string, any>;
  createdAt: string;
};

type ProductionOrder = {
  id: number;
  orderNumber: string;
  productName: string;
  status: string;
};

const statusColors = {
  pass: "bg-green-100 text-green-800",
  fail: "bg-red-100 text-red-800",
  pending: "bg-yellow-100 text-yellow-800",
};

const statusIcons = {
  pass: CheckCircle,
  fail: XCircle,
  pending: Clock,
};

export default function QualityControl() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  
  const { toast } = useToast();
  const { isAuthenticated, isLoading, user } = useAuth();
  const queryClient = useQueryClient();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const form = useForm<z.infer<typeof qualityControlSchema>>({
    resolver: zodResolver(qualityControlSchema),
    defaultValues: {
      orderId: 0,
      itemId: undefined,
      status: "pending",
      notes: "",
      defects: [],
      testResults: {},
    },
  });

  const { data: qualityLogs = [], isLoading: isLoadingLogs } = useQuery({
    queryKey: ["/api/quality-control"],
    enabled: isAuthenticated,
  });

  const { data: orders = [] } = useQuery({
    queryKey: ["/api/orders"],
    enabled: isAuthenticated,
  });

  const { data: inventory = [] } = useQuery({
    queryKey: ["/api/inventory"],
    enabled: isAuthenticated,
  });

  const createMutation = useMutation({
    mutationFn: async (data: z.infer<typeof qualityControlSchema>) => {
      await apiRequest("POST", "/api/quality-control", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/quality-control"] });
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
      setIsCreateDialogOpen(false);
      form.reset();
      toast({
        title: "Success",
        description: "Quality control log created successfully",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create quality control log",
        variant: "destructive",
      });
    },
  });

  if (isLoading || !isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-carbon-gray-10">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-carbon-blue border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-carbon-gray-50">Loading...</p>
        </div>
      </div>
    );
  }

  const filteredLogs = qualityLogs.filter((log: QualityControlLog) => {
    const order = orders.find((o: ProductionOrder) => o.id === log.orderId);
    const matchesSearch = order ? 
      order.orderNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.productName.toLowerCase().includes(searchTerm.toLowerCase()) : false;
    
    const matchesStatus = statusFilter === "all" || log.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const onSubmit = (data: z.infer<typeof qualityControlSchema>) => {
    createMutation.mutate(data);
  };

  const getOrderDetails = (orderId: number) => {
    return orders.find((order: ProductionOrder) => order.id === orderId);
  };

  const getItemDetails = (itemId?: number) => {
    if (!itemId) return null;
    return inventory.find((item: any) => item.id === itemId);
  };

  return (
    <div className="min-h-screen flex bg-carbon-gray-10">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-white border-b border-carbon-gray-20 px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-semibold text-carbon-gray-80">Quality Control</h1>
              <p className="text-carbon-gray-50 text-sm mt-1">Monitor and log quality control checks</p>
            </div>
            
            <div className="flex items-center space-x-4">
              {/* Status Filter */}
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="pass">Pass</SelectItem>
                  <SelectItem value="fail">Fail</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                </SelectContent>
              </Select>
              
              {/* Search */}
              <div className="relative">
                <Input
                  type="text"
                  placeholder="Search orders..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 w-64"
                />
                <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-carbon-gray-50" />
              </div>
              
              {/* Add QC Log Button */}
              <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="carbon-blue">
                    <Plus className="w-4 h-4 mr-2" />
                    New QC Log
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Create Quality Control Log</DialogTitle>
                  </DialogHeader>
                  
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="orderId"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Production Order</FormLabel>
                              <Select onValueChange={(value) => field.onChange(parseInt(value))}>
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select order" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {orders.map((order: ProductionOrder) => (
                                    <SelectItem key={order.id} value={order.id.toString()}>
                                      {order.orderNumber} - {order.productName}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="itemId"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Inventory Item (Optional)</FormLabel>
                              <Select onValueChange={(value) => field.onChange(value ? parseInt(value) : undefined)}>
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select item" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {inventory.map((item: any) => (
                                    <SelectItem key={item.id} value={item.id.toString()}>
                                      {item.name} ({item.sku})
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <FormField
                        control={form.control}
                        name="status"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>QC Status</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select status" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="pending">Pending</SelectItem>
                                <SelectItem value="pass">Pass</SelectItem>
                                <SelectItem value="fail">Fail</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="notes"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Notes</FormLabel>
                            <FormControl>
                              <Textarea {...field} placeholder="Enter quality control notes..." />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="flex justify-end space-x-2">
                        <Button 
                          type="button" 
                          variant="outline"
                          onClick={() => {
                            setIsCreateDialogOpen(false);
                            form.reset();
                          }}
                        >
                          Cancel
                        </Button>
                        <Button 
                          type="submit" 
                          className="carbon-blue"
                          disabled={createMutation.isPending}
                        >
                          Create Log
                        </Button>
                      </div>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </header>

        {/* QC Logs Grid */}
        <main className="flex-1 overflow-y-auto p-6">
          {isLoadingLogs ? (
            <div className="flex items-center justify-center h-64">
              <div className="text-center">
                <div className="w-8 h-8 border-4 border-carbon-blue border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                <p className="text-carbon-gray-50">Loading quality control logs...</p>
              </div>
            </div>
          ) : filteredLogs.length === 0 ? (
            <div className="text-center py-12">
              <CheckCircle className="w-16 h-16 text-carbon-gray-50 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-carbon-gray-80 mb-2">
                {searchTerm || statusFilter !== "all" ? "No logs found" : "No quality control logs"}
              </h3>
              <p className="text-carbon-gray-50 mb-4">
                {searchTerm || statusFilter !== "all"
                  ? "Try adjusting your search or filter criteria" 
                  : "Start by creating your first quality control log"
                }
              </p>
              {!searchTerm && statusFilter === "all" && (
                <Button onClick={() => setIsCreateDialogOpen(true)} className="carbon-blue">
                  <Plus className="w-4 h-4 mr-2" />
                  Create First Log
                </Button>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
              {filteredLogs.map((log: QualityControlLog) => {
                const order = getOrderDetails(log.orderId);
                const item = getItemDetails(log.itemId);
                const StatusIcon = statusIcons[log.status];
                
                return (
                  <Card key={log.id} className="border-carbon-gray-20 hover:shadow-lg transition-shadow">
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <CardTitle className="text-lg font-semibold text-carbon-gray-80 mb-1">
                            QC Log #{log.id}
                          </CardTitle>
                          {order && (
                            <p className="text-sm text-carbon-gray-50">
                              {order.orderNumber} - {order.productName}
                            </p>
                          )}
                        </div>
                        <Badge className={statusColors[log.status]}>
                          <StatusIcon className="w-3 h-3 mr-1" />
                          {log.status}
                        </Badge>
                      </div>
                    </CardHeader>
                    
                    <CardContent className="space-y-3">
                      {/* Inspector */}
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-carbon-gray-50">Inspector:</span>
                        <div className="flex items-center space-x-1">
                          <User className="w-4 h-4 text-carbon-gray-50" />
                          <span className="text-sm text-carbon-gray-80">{log.inspectorId}</span>
                        </div>
                      </div>
                      
                      {/* Item */}
                      {item && (
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-carbon-gray-50">Item:</span>
                          <span className="text-sm text-carbon-gray-80">{item.name}</span>
                        </div>
                      )}
                      
                      {/* Notes */}
                      {log.notes && (
                        <div className="space-y-1">
                          <div className="flex items-center space-x-1">
                            <FileText className="w-4 h-4 text-carbon-gray-50" />
                            <span className="text-sm text-carbon-gray-50">Notes:</span>
                          </div>
                          <p className="text-xs text-carbon-gray-80 bg-carbon-gray-10 p-2 rounded">
                            {log.notes}
                          </p>
                        </div>
                      )}
                      
                      {/* Defects */}
                      {log.defects && log.defects.length > 0 && (
                        <div className="space-y-1">
                          <span className="text-sm text-carbon-gray-50">Defects:</span>
                          <div className="flex flex-wrap gap-1">
                            {log.defects.map((defect, index) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {defect}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                      
                      {/* Test Results */}
                      {log.testResults && Object.keys(log.testResults).length > 0 && (
                        <div className="space-y-1">
                          <span className="text-sm text-carbon-gray-50">Test Results:</span>
                          <div className="bg-carbon-gray-10 p-2 rounded text-xs">
                            {Object.entries(log.testResults).map(([key, value]) => (
                              <div key={key} className="flex justify-between">
                                <span>{key}:</span>
                                <span className="font-medium">{String(value)}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                      
                      {/* Timestamp */}
                      <div className="pt-2 border-t border-carbon-gray-20">
                        <div className="flex items-center space-x-1 text-xs text-carbon-gray-50">
                          <Clock className="w-3 h-3" />
                          <span>Logged {format(new Date(log.createdAt), "MMM dd, HH:mm")}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </main>
      </div>
      
      <MobileNav />
    </div>
  );
}
