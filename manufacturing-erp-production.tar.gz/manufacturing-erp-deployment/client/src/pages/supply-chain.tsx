import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import Sidebar from "@/components/layout/sidebar";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  Truck, 
  Package, 
  Clock, 
  AlertTriangle,
  CheckCircle,
  MapPin,
  DollarSign,
  Calendar,
  Plus,
  Edit,
  Eye,
  RefreshCw,
  Search,
  Filter,
  TrendingUp,
  TrendingDown,
  Building,
  Phone,
  Mail,
  Star
} from "lucide-react";

const supplierSchema = z.object({
  name: z.string().min(1, "Name is required"),
  contactPerson: z.string().min(1, "Contact person is required"),
  email: z.string().email("Valid email is required"),
  phone: z.string().min(1, "Phone is required"),
  address: z.string().min(1, "Address is required"),
  category: z.string().min(1, "Category is required"),
  rating: z.number().min(1).max(5),
  paymentTerms: z.string().min(1, "Payment terms are required"),
  deliveryTime: z.number().min(1, "Delivery time is required"),
});

const purchaseOrderSchema = z.object({
  supplierId: z.string().min(1, "Supplier is required"),
  items: z.array(z.object({
    name: z.string().min(1, "Item name is required"),
    quantity: z.number().min(1, "Quantity must be at least 1"),
    unitPrice: z.number().min(0, "Unit price must be positive"),
  })).min(1, "At least one item is required"),
  expectedDelivery: z.string().min(1, "Expected delivery date is required"),
  notes: z.string().optional(),
});

interface Supplier {
  id: string;
  name: string;
  contactPerson: string;
  email: string;
  phone: string;
  address: string;
  category: string;
  rating: number;
  paymentTerms: string;
  deliveryTime: number;
  totalOrders: number;
  onTimeDelivery: number;
  qualityScore: number;
  status: "active" | "inactive" | "pending";
}

interface PurchaseOrder {
  id: string;
  orderNumber: string;
  supplierId: string;
  supplierName: string;
  status: "pending" | "confirmed" | "shipped" | "delivered" | "cancelled";
  orderDate: string;
  expectedDelivery: string;
  actualDelivery?: string;
  totalAmount: number;
  items: Array<{
    name: string;
    quantity: number;
    unitPrice: number;
    total: number;
  }>;
  notes?: string;
}

interface Shipment {
  id: string;
  trackingNumber: string;
  orderId: string;
  status: "in_transit" | "delivered" | "delayed" | "lost";
  origin: string;
  destination: string;
  estimatedDelivery: string;
  actualDelivery?: string;
  carrier: string;
  lastUpdate: string;
}

export default function SupplyChain() {
  const [activeTab, setActiveTab] = useState("suppliers");
  const [isSupplierDialogOpen, setIsSupplierDialogOpen] = useState(false);
  const [isPODialogOpen, setIsPODialogOpen] = useState(false);
  const [selectedSupplier, setSelectedSupplier] = useState<Supplier | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const supplierForm = useForm<z.infer<typeof supplierSchema>>({
    resolver: zodResolver(supplierSchema),
    defaultValues: {
      rating: 3,
      deliveryTime: 7,
    },
  });

  const poForm = useForm<z.infer<typeof purchaseOrderSchema>>({
    resolver: zodResolver(purchaseOrderSchema),
  });

  // Fetch suppliers
  const { data: suppliers, isLoading: loadingSuppliers } = useQuery({
    queryKey: ["/api/suppliers"],
    staleTime: 5 * 60 * 1000,
  });

  // Fetch purchase orders
  const { data: purchaseOrders, isLoading: loadingPOs } = useQuery({
    queryKey: ["/api/purchase-orders"],
    staleTime: 5 * 60 * 1000,
  });

  // Fetch shipments
  const { data: shipments, isLoading: loadingShipments } = useQuery({
    queryKey: ["/api/shipments"],
    staleTime: 2 * 60 * 1000,
  });

  // Sample data for demonstration
  const sampleSuppliers: Supplier[] = [
    {
      id: "S001",
      name: "TechParts Global",
      contactPerson: "John Smith",
      email: "john@techparts.com",
      phone: "+1-555-0123",
      address: "123 Industrial Ave, Tech City, TC 12345",
      category: "Electronics",
      rating: 4.5,
      paymentTerms: "Net 30",
      deliveryTime: 5,
      totalOrders: 45,
      onTimeDelivery: 92,
      qualityScore: 4.3,
      status: "active"
    },
    {
      id: "S002",
      name: "MetalWorks Inc",
      contactPerson: "Sarah Johnson",
      email: "sarah@metalworks.com",
      phone: "+1-555-0456",
      address: "456 Steel St, Metal City, MC 67890",
      category: "Raw Materials",
      rating: 4.2,
      paymentTerms: "Net 15",
      deliveryTime: 3,
      totalOrders: 78,
      onTimeDelivery: 89,
      qualityScore: 4.1,
      status: "active"
    },
    {
      id: "S003",
      name: "PackCorp Solutions",
      contactPerson: "Mike Wilson",
      email: "mike@packcorp.com",
      phone: "+1-555-0789",
      address: "789 Package Blvd, Pack City, PC 11111",
      category: "Packaging",
      rating: 3.8,
      paymentTerms: "Net 45",
      deliveryTime: 7,
      totalOrders: 23,
      onTimeDelivery: 85,
      qualityScore: 3.9,
      status: "active"
    }
  ];

  const samplePurchaseOrders: PurchaseOrder[] = [
    {
      id: "PO001",
      orderNumber: "PO-2024-001",
      supplierId: "S001",
      supplierName: "TechParts Global",
      status: "confirmed",
      orderDate: "2024-12-10",
      expectedDelivery: "2024-12-20",
      totalAmount: 15750.00,
      items: [
        { name: "Circuit Boards", quantity: 50, unitPrice: 125.00, total: 6250.00 },
        { name: "Resistors Pack", quantity: 100, unitPrice: 25.00, total: 2500.00 },
        { name: "Capacitors", quantity: 200, unitPrice: 35.00, total: 7000.00 }
      ],
      notes: "Urgent order for production line restart"
    },
    {
      id: "PO002",
      orderNumber: "PO-2024-002",
      supplierId: "S002",
      supplierName: "MetalWorks Inc",
      status: "shipped",
      orderDate: "2024-12-08",
      expectedDelivery: "2024-12-18",
      totalAmount: 8900.00,
      items: [
        { name: "Steel Plates", quantity: 25, unitPrice: 180.00, total: 4500.00 },
        { name: "Aluminum Rods", quantity: 50, unitPrice: 88.00, total: 4400.00 }
      ]
    },
    {
      id: "PO003",
      orderNumber: "PO-2024-003",
      supplierId: "S003",
      supplierName: "PackCorp Solutions",
      status: "pending",
      orderDate: "2024-12-15",
      expectedDelivery: "2024-12-25",
      totalAmount: 3200.00,
      items: [
        { name: "Cardboard Boxes", quantity: 500, unitPrice: 4.50, total: 2250.00 },
        { name: "Bubble Wrap", quantity: 10, unitPrice: 95.00, total: 950.00 }
      ]
    }
  ];

  const sampleShipments: Shipment[] = [
    {
      id: "SH001",
      trackingNumber: "TG123456789",
      orderId: "PO002",
      status: "in_transit",
      origin: "Metal City, MC",
      destination: "Manufacturing Plant",
      estimatedDelivery: "2024-12-18",
      carrier: "FastShip Logistics",
      lastUpdate: "2024-12-16 14:30"
    },
    {
      id: "SH002",
      trackingNumber: "TP987654321",
      orderId: "PO001",
      status: "delivered",
      origin: "Tech City, TC",
      destination: "Manufacturing Plant",
      estimatedDelivery: "2024-12-20",
      actualDelivery: "2024-12-19",
      carrier: "TechTransport",
      lastUpdate: "2024-12-19 09:15"
    }
  ];

  // Create supplier mutation
  const createSupplierMutation = useMutation({
    mutationFn: async (data: z.infer<typeof supplierSchema>) => {
      return apiRequest("/api/suppliers", "POST", data);
    },
    onSuccess: () => {
      toast({
        title: "Supplier Created",
        description: "New supplier has been added successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/suppliers"] });
      setIsSupplierDialogOpen(false);
      supplierForm.reset();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create supplier",
        variant: "destructive",
      });
    },
  });

  // Create purchase order mutation
  const createPOMutation = useMutation({
    mutationFn: async (data: z.infer<typeof purchaseOrderSchema>) => {
      return apiRequest("/api/purchase-orders", "POST", data);
    },
    onSuccess: () => {
      toast({
        title: "Purchase Order Created",
        description: "New purchase order has been created successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/purchase-orders"] });
      setIsPODialogOpen(false);
      poForm.reset();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create purchase order",
        variant: "destructive",
      });
    },
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
      case "confirmed":
      case "delivered":
        return "bg-green-100 text-green-800";
      case "pending":
      case "in_transit":
        return "bg-yellow-100 text-yellow-800";
      case "shipped":
        return "bg-blue-100 text-blue-800";
      case "inactive":
      case "cancelled":
      case "lost":
        return "bg-red-100 text-red-800";
      case "delayed":
        return "bg-orange-100 text-orange-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "delivered":
        return <CheckCircle className="w-4 h-4" />;
      case "in_transit":
      case "shipped":
        return <Truck className="w-4 h-4" />;
      case "pending":
        return <Clock className="w-4 h-4" />;
      case "delayed":
      case "lost":
        return <AlertTriangle className="w-4 h-4" />;
      default:
        return <Package className="w-4 h-4" />;
    }
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`w-4 h-4 ${i < Math.floor(rating) ? 'text-yellow-400 fill-current' : 'text-gray-300'}`}
      />
    ));
  };

  const filteredSuppliers = sampleSuppliers.filter(supplier => {
    const matchesSearch = supplier.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         supplier.category.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === "all" || supplier.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const onSupplierSubmit = (data: z.infer<typeof supplierSchema>) => {
    createSupplierMutation.mutate(data);
  };

  const onPOSubmit = (data: z.infer<typeof purchaseOrderSchema>) => {
    createPOMutation.mutate(data);
  };

  return (
    <div className="flex h-screen bg-carbon-gray-10">
      <Sidebar />
      <div className="flex-1 overflow-auto">
        <div className="p-6 space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-carbon-gray-80">Supply Chain Management</h1>
              <p className="text-carbon-gray-60">Manage suppliers, orders, and shipments</p>
            </div>
            <div className="flex items-center space-x-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Search..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 w-64"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Overview Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Building className="w-5 h-5 text-blue-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Active Suppliers</p>
                    <p className="text-xl font-bold">{sampleSuppliers.filter(s => s.status === "active").length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Package className="w-5 h-5 text-green-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Active Orders</p>
                    <p className="text-xl font-bold">{samplePurchaseOrders.filter(po => po.status !== "delivered" && po.status !== "cancelled").length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Truck className="w-5 h-5 text-orange-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">In Transit</p>
                    <p className="text-xl font-bold">{sampleShipments.filter(s => s.status === "in_transit").length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <DollarSign className="w-5 h-5 text-purple-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Monthly Spend</p>
                    <p className="text-xl font-bold">${samplePurchaseOrders.reduce((sum, po) => sum + po.totalAmount, 0).toLocaleString()}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
            <div className="flex items-center justify-between">
              <TabsList>
                <TabsTrigger value="suppliers">Suppliers</TabsTrigger>
                <TabsTrigger value="orders">Purchase Orders</TabsTrigger>
                <TabsTrigger value="shipments">Shipments</TabsTrigger>
              </TabsList>
              <div className="flex space-x-2">
                {activeTab === "suppliers" && (
                  <Dialog open={isSupplierDialogOpen} onOpenChange={setIsSupplierDialogOpen}>
                    <DialogTrigger asChild>
                      <Button>
                        <Plus className="w-4 h-4 mr-2" />
                        Add Supplier
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl">
                      <DialogHeader>
                        <DialogTitle>Add New Supplier</DialogTitle>
                      </DialogHeader>
                      <Form {...supplierForm}>
                        <form onSubmit={supplierForm.handleSubmit(onSupplierSubmit)} className="space-y-4">
                          <div className="grid grid-cols-2 gap-4">
                            <FormField
                              control={supplierForm.control}
                              name="name"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Company Name</FormLabel>
                                  <FormControl>
                                    <Input {...field} />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={supplierForm.control}
                              name="contactPerson"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Contact Person</FormLabel>
                                  <FormControl>
                                    <Input {...field} />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={supplierForm.control}
                              name="email"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Email</FormLabel>
                                  <FormControl>
                                    <Input type="email" {...field} />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={supplierForm.control}
                              name="phone"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Phone</FormLabel>
                                  <FormControl>
                                    <Input {...field} />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                          </div>
                          <FormField
                            control={supplierForm.control}
                            name="address"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Address</FormLabel>
                                <FormControl>
                                  <Input {...field} />
                                </FormControl>
                              </FormItem>
                            )}
                          />
                          <div className="grid grid-cols-3 gap-4">
                            <FormField
                              control={supplierForm.control}
                              name="category"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Category</FormLabel>
                                  <FormControl>
                                    <Select onValueChange={field.onChange} value={field.value}>
                                      <SelectTrigger>
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="Electronics">Electronics</SelectItem>
                                        <SelectItem value="Raw Materials">Raw Materials</SelectItem>
                                        <SelectItem value="Packaging">Packaging</SelectItem>
                                        <SelectItem value="Services">Services</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={supplierForm.control}
                              name="rating"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Rating (1-5)</FormLabel>
                                  <FormControl>
                                    <Input 
                                      type="number" 
                                      min="1" 
                                      max="5" 
                                      {...field}
                                      onChange={e => field.onChange(parseInt(e.target.value))}
                                    />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={supplierForm.control}
                              name="deliveryTime"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Delivery Time (days)</FormLabel>
                                  <FormControl>
                                    <Input 
                                      type="number" 
                                      min="1" 
                                      {...field}
                                      onChange={e => field.onChange(parseInt(e.target.value))}
                                    />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                          </div>
                          <FormField
                            control={supplierForm.control}
                            name="paymentTerms"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Payment Terms</FormLabel>
                                <FormControl>
                                  <Input placeholder="e.g., Net 30" {...field} />
                                </FormControl>
                              </FormItem>
                            )}
                          />
                          <div className="flex justify-end space-x-2">
                            <Button type="button" variant="outline" onClick={() => setIsSupplierDialogOpen(false)}>
                              Cancel
                            </Button>
                            <Button type="submit" disabled={createSupplierMutation.isPending}>
                              {createSupplierMutation.isPending ? "Creating..." : "Create Supplier"}
                            </Button>
                          </div>
                        </form>
                      </Form>
                    </DialogContent>
                  </Dialog>
                )}
                {activeTab === "orders" && (
                  <Button onClick={() => setIsPODialogOpen(true)}>
                    <Plus className="w-4 h-4 mr-2" />
                    New Order
                  </Button>
                )}
              </div>
            </div>

            <TabsContent value="suppliers" className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                {filteredSuppliers.map((supplier) => (
                  <Card key={supplier.id} className="border-carbon-gray-20">
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-lg">{supplier.name}</CardTitle>
                        <Badge className={getStatusColor(supplier.status)}>
                          {supplier.status}
                        </Badge>
                      </div>
                      <div className="flex items-center space-x-1">
                        {renderStars(supplier.rating)}
                        <span className="text-sm text-gray-600 ml-2">{supplier.rating}</span>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="space-y-2">
                        <div className="flex items-center space-x-2 text-sm">
                          <Building className="w-4 h-4 text-gray-500" />
                          <span>{supplier.category}</span>
                        </div>
                        <div className="flex items-center space-x-2 text-sm">
                          <Phone className="w-4 h-4 text-gray-500" />
                          <span>{supplier.phone}</span>
                        </div>
                        <div className="flex items-center space-x-2 text-sm">
                          <Mail className="w-4 h-4 text-gray-500" />
                          <span>{supplier.email}</span>
                        </div>
                        <div className="flex items-center space-x-2 text-sm">
                          <MapPin className="w-4 h-4 text-gray-500" />
                          <span className="truncate">{supplier.address}</span>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-3 gap-2 pt-2 border-t text-center">
                        <div>
                          <p className="text-xs text-gray-600">Orders</p>
                          <p className="font-semibold">{supplier.totalOrders}</p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-600">On Time</p>
                          <p className="font-semibold">{supplier.onTimeDelivery}%</p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-600">Quality</p>
                          <p className="font-semibold">{supplier.qualityScore}</p>
                        </div>
                      </div>
                      
                      <div className="flex space-x-2 pt-2">
                        <Button variant="outline" size="sm" className="flex-1">
                          <Eye className="w-4 h-4 mr-1" />
                          View
                        </Button>
                        <Button variant="outline" size="sm" className="flex-1">
                          <Edit className="w-4 h-4 mr-1" />
                          Edit
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="orders" className="space-y-4">
              <div className="space-y-4">
                {samplePurchaseOrders.map((order) => (
                  <Card key={order.id} className="border-carbon-gray-20">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div>
                          <CardTitle className="text-lg">{order.orderNumber}</CardTitle>
                          <p className="text-sm text-carbon-gray-60">{order.supplierName}</p>
                        </div>
                        <div className="text-right">
                          <Badge className={getStatusColor(order.status)}>
                            {getStatusIcon(order.status)}
                            <span className="ml-1 capitalize">{order.status}</span>
                          </Badge>
                          <p className="text-lg font-bold mt-1">${order.totalAmount.toLocaleString()}</p>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-3 gap-4 text-sm">
                        <div>
                          <p className="text-gray-600">Order Date</p>
                          <p className="font-medium">{order.orderDate}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Expected Delivery</p>
                          <p className="font-medium">{order.expectedDelivery}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Items Count</p>
                          <p className="font-medium">{order.items.length} items</p>
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <h4 className="font-medium">Order Items:</h4>
                        {order.items.map((item, index) => (
                          <div key={index} className="flex justify-between text-sm bg-gray-50 p-2 rounded">
                            <span>{item.name} (x{item.quantity})</span>
                            <span className="font-medium">${item.total.toLocaleString()}</span>
                          </div>
                        ))}
                      </div>
                      
                      {order.notes && (
                        <div className="text-sm">
                          <p className="text-gray-600 mb-1">Notes:</p>
                          <p className="italic">{order.notes}</p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="shipments" className="space-y-4">
              <div className="space-y-4">
                {sampleShipments.map((shipment) => (
                  <Card key={shipment.id} className="border-carbon-gray-20">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div>
                          <CardTitle className="text-lg">Tracking: {shipment.trackingNumber}</CardTitle>
                          <p className="text-sm text-carbon-gray-60">Order: {shipment.orderId}</p>
                        </div>
                        <Badge className={getStatusColor(shipment.status)}>
                          {getStatusIcon(shipment.status)}
                          <span className="ml-1 capitalize">{shipment.status.replace('_', ' ')}</span>
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-sm text-gray-600">Origin</p>
                          <p className="font-medium">{shipment.origin}</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Destination</p>
                          <p className="font-medium">{shipment.destination}</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Carrier</p>
                          <p className="font-medium">{shipment.carrier}</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Est. Delivery</p>
                          <p className="font-medium">{shipment.estimatedDelivery}</p>
                        </div>
                      </div>
                      
                      <div className="flex justify-between items-center text-sm bg-gray-50 p-3 rounded">
                        <span>Last Update: {shipment.lastUpdate}</span>
                        <Button variant="outline" size="sm">
                          <RefreshCw className="w-4 h-4 mr-1" />
                          Track
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}