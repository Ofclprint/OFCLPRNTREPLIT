import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import Sidebar from "@/components/layout/sidebar";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  Shield, 
  Key,
  Lock,
  Unlock,
  Eye,
  EyeOff,
  User,
  Users,
  Settings,
  AlertTriangle,
  CheckCircle,
  Clock,
  FileText,
  Download,
  Upload,
  Search,
  Filter,
  Plus,
  Edit,
  Trash2,
  MoreHorizontal,
  Activity,
  Database,
  Server,
  Wifi,
  Smartphone,
  Monitor,
  Globe,
  Network,
  Fingerprint,
  Scan,
  QrCode,
  Camera,
  Bell,
  Mail,
  MessageSquare,
  Calendar,
  Target,
  Award,
  BookOpen,
  ClipboardList,
  BarChart3,
  TrendingUp,
  TrendingDown,
  Info,
  AlertTriangle as Warning,
  XCircle,
  RefreshCw,
  HardDrive,
  Cpu,
  Zap,
  Timer,
  History,
  GitBranch,
  Archive,
  Folder,
  Star,
  Flag
} from "lucide-react";

const securityPolicySchema = z.object({
  name: z.string().min(1, "Policy name is required"),
  description: z.string().min(1, "Description is required"),
  category: z.enum(["access", "data", "network", "application", "physical", "compliance"]),
  severity: z.enum(["low", "medium", "high", "critical"]),
  requirements: z.array(z.string()).min(1, "At least one requirement is required"),
  applicableRoles: z.array(z.string()).min(1, "At least one role is required"),
  enforcementLevel: z.enum(["advisory", "warning", "blocking"]),
  expiryDate: z.string().optional(),
  isActive: z.boolean().default(true),
});

const complianceFrameworkSchema = z.object({
  name: z.string().min(1, "Framework name is required"),
  description: z.string().min(1, "Description is required"),
  type: z.enum(["iso", "sox", "gdpr", "hipaa", "pci", "nist", "custom"]),
  version: z.string().min(1, "Version is required"),
  requirements: z.array(z.string()).min(1, "At least one requirement is required"),
  auditFrequency: z.enum(["monthly", "quarterly", "yearly"]),
  nextAuditDate: z.string().min(1, "Next audit date is required"),
  isActive: z.boolean().default(true),
});

interface SecurityPolicy {
  id: string;
  name: string;
  description: string;
  category: "access" | "data" | "network" | "application" | "physical" | "compliance";
  severity: "low" | "medium" | "high" | "critical";
  requirements: string[];
  applicableRoles: string[];
  enforcementLevel: "advisory" | "warning" | "blocking";
  status: "active" | "draft" | "deprecated" | "under_review";
  violations: number;
  lastUpdated: string;
  expiryDate?: string;
  createdBy: string;
  approvedBy?: string;
  isActive: boolean;
}

interface AccessControl {
  id: string;
  resourceName: string;
  resourceType: "system" | "data" | "function" | "report" | "api";
  permissions: Array<{
    role: string;
    access: "read" | "write" | "admin" | "denied";
    conditions?: string[];
  }>;
  isPublic: boolean;
  requiresMFA: boolean;
  allowedIPs?: string[];
  allowedDevices?: string[];
  timeRestrictions?: {
    allowedHours: string;
    allowedDays: string[];
  };
  lastAccessed: string;
  accessCount: number;
  createdAt: string;
  updatedAt: string;
}

interface ComplianceFramework {
  id: string;
  name: string;
  description: string;
  type: "iso" | "sox" | "gdpr" | "hipaa" | "pci" | "nist" | "custom";
  version: string;
  requirements: string[];
  controls: Array<{
    id: string;
    name: string;
    description: string;
    status: "compliant" | "non_compliant" | "partial" | "not_applicable";
    evidence: string[];
    lastAssessed: string;
    nextAssessment: string;
  }>;
  auditFrequency: "monthly" | "quarterly" | "yearly";
  nextAuditDate: string;
  complianceScore: number;
  isActive: boolean;
  assignedTo: string;
  createdAt: string;
  updatedAt: string;
}

interface SecurityIncident {
  id: string;
  title: string;
  description: string;
  severity: "low" | "medium" | "high" | "critical";
  category: "breach" | "unauthorized_access" | "malware" | "phishing" | "policy_violation" | "other";
  status: "open" | "investigating" | "resolved" | "closed";
  affectedSystems: string[];
  affectedUsers: string[];
  reportedBy: string;
  assignedTo: string;
  reportedAt: string;
  resolvedAt?: string;
  impact: string;
  rootCause?: string;
  remediation: string[];
  preventiveMeasures: string[];
}

interface AuditLog {
  id: string;
  timestamp: string;
  userId: string;
  username: string;
  action: string;
  resource: string;
  resourceType: string;
  method: string;
  ipAddress: string;
  userAgent: string;
  success: boolean;
  errorMessage?: string;
  sessionId: string;
  metadata: Record<string, any>;
}

export default function SecurityCompliance() {
  const [activeTab, setActiveTab] = useState("overview");
  const [isPolicyDialogOpen, setIsPolicyDialogOpen] = useState(false);
  const [isFrameworkDialogOpen, setIsFrameworkDialogOpen] = useState(false);
  const [selectedPolicy, setSelectedPolicy] = useState<SecurityPolicy | null>(null);
  const [filterCategory, setFilterCategory] = useState<string>("all");
  const [filterSeverity, setFilterSeverity] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState("");

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const policyForm = useForm<z.infer<typeof securityPolicySchema>>({
    resolver: zodResolver(securityPolicySchema),
    defaultValues: {
      category: "access",
      severity: "medium",
      enforcementLevel: "warning",
      isActive: true,
      requirements: [],
      applicableRoles: [],
    },
  });

  const frameworkForm = useForm<z.infer<typeof complianceFrameworkSchema>>({
    resolver: zodResolver(complianceFrameworkSchema),
    defaultValues: {
      type: "iso",
      auditFrequency: "quarterly",
      isActive: true,
      requirements: [],
    },
  });

  // Sample security policies data
  const samplePolicies: SecurityPolicy[] = [
    {
      id: "pol_001",
      name: "Multi-Factor Authentication Policy",
      description: "Mandatory MFA for all users accessing production systems",
      category: "access",
      severity: "critical",
      requirements: [
        "All users must enable MFA within 7 days of account creation",
        "MFA must use time-based or hardware tokens",
        "Backup authentication methods must be configured",
        "MFA bypass requires security team approval"
      ],
      applicableRoles: ["all_users"],
      enforcementLevel: "blocking",
      status: "active",
      violations: 3,
      lastUpdated: "2024-12-15 10:00:00",
      expiryDate: "2025-12-31",
      createdBy: "Security Team",
      approvedBy: "CISO",
      isActive: true
    },
    {
      id: "pol_002",
      name: "Data Classification and Handling",
      description: "Requirements for classifying and handling sensitive data",
      category: "data",
      severity: "high",
      requirements: [
        "All data must be classified as Public, Internal, Confidential, or Restricted",
        "Restricted data requires encryption at rest and in transit",
        "Data access must be logged and monitored",
        "Data retention policies must be followed"
      ],
      applicableRoles: ["data_handlers", "developers", "analysts"],
      enforcementLevel: "warning",
      status: "active",
      violations: 8,
      lastUpdated: "2024-12-10 14:30:00",
      createdBy: "Data Protection Officer",
      approvedBy: "CISO",
      isActive: true
    },
    {
      id: "pol_003",
      name: "Password Security Requirements",
      description: "Minimum password complexity and management requirements",
      category: "access",
      severity: "medium",
      requirements: [
        "Passwords must be at least 12 characters long",
        "Must contain uppercase, lowercase, numbers, and special characters",
        "Passwords must be unique across systems",
        "Password rotation every 90 days for privileged accounts"
      ],
      applicableRoles: ["all_users"],
      enforcementLevel: "blocking",
      status: "active",
      violations: 15,
      lastUpdated: "2024-12-05 09:15:00",
      createdBy: "Security Team",
      approvedBy: "IT Director",
      isActive: true
    },
    {
      id: "pol_004",
      name: "Network Access Control",
      description: "Controls for network access and segmentation",
      category: "network",
      severity: "high",
      requirements: [
        "Production networks must be segregated from development",
        "VPN access required for remote connections",
        "Network traffic must be monitored and logged",
        "Unauthorized devices must be blocked"
      ],
      applicableRoles: ["network_admins", "system_admins"],
      enforcementLevel: "blocking",
      status: "active",
      violations: 2,
      lastUpdated: "2024-12-12 16:45:00",
      createdBy: "Network Security Team",
      approvedBy: "CISO",
      isActive: true
    },
    {
      id: "pol_005",
      name: "Physical Security Controls",
      description: "Physical access controls for facilities and equipment",
      category: "physical",
      severity: "medium",
      requirements: [
        "Badge access required for all secure areas",
        "Visitor access must be escorted and logged",
        "Security cameras must cover all entry points",
        "Equipment must be secured when not in use"
      ],
      applicableRoles: ["facility_managers", "security_guards"],
      enforcementLevel: "advisory",
      status: "under_review",
      violations: 1,
      lastUpdated: "2024-12-08 11:20:00",
      createdBy: "Facility Manager",
      isActive: true
    }
  ];

  const sampleFrameworks: ComplianceFramework[] = [
    {
      id: "fw_001",
      name: "ISO 27001:2022",
      description: "Information Security Management System standard",
      type: "iso",
      version: "2022",
      requirements: [
        "Information security policy",
        "Risk management process",
        "Security awareness training",
        "Incident response procedures",
        "Business continuity planning"
      ],
      controls: [
        {
          id: "A.5.1",
          name: "Information Security Policy",
          description: "Policies for information security",
          status: "compliant",
          evidence: ["Policy document", "Management approval", "Communication records"],
          lastAssessed: "2024-12-01",
          nextAssessment: "2025-03-01"
        },
        {
          id: "A.6.1",
          name: "Information Security Roles",
          description: "Allocation of information security responsibilities",
          status: "compliant",
          evidence: ["Role definitions", "Assignment records"],
          lastAssessed: "2024-12-01",
          nextAssessment: "2025-03-01"
        },
        {
          id: "A.8.1",
          name: "Asset Management",
          description: "Responsibility for assets",
          status: "partial",
          evidence: ["Asset inventory", "Owner assignments"],
          lastAssessed: "2024-12-01",
          nextAssessment: "2025-01-15"
        }
      ],
      auditFrequency: "yearly",
      nextAuditDate: "2025-06-01",
      complianceScore: 87.5,
      isActive: true,
      assignedTo: "Compliance Manager",
      createdAt: "2024-01-15 10:00:00",
      updatedAt: "2024-12-01 14:30:00"
    },
    {
      id: "fw_002",
      name: "SOX IT Controls",
      description: "Sarbanes-Oxley IT General Controls",
      type: "sox",
      version: "2024",
      requirements: [
        "Change management controls",
        "Access controls",
        "Computer operations controls",
        "System development controls"
      ],
      controls: [
        {
          id: "ITGC-01",
          name: "Change Management",
          description: "Controls over system changes",
          status: "compliant",
          evidence: ["Change logs", "Approval records", "Testing documentation"],
          lastAssessed: "2024-11-15",
          nextAssessment: "2025-02-15"
        },
        {
          id: "ITGC-02",
          name: "Access Controls",
          description: "User access management",
          status: "non_compliant",
          evidence: ["Access reviews", "Termination procedures"],
          lastAssessed: "2024-11-15",
          nextAssessment: "2024-12-30"
        }
      ],
      auditFrequency: "quarterly",
      nextAuditDate: "2025-03-31",
      complianceScore: 72.3,
      isActive: true,
      assignedTo: "SOX Compliance Officer",
      createdAt: "2024-01-01 09:00:00",
      updatedAt: "2024-11-15 16:20:00"
    },
    {
      id: "fw_003",
      name: "GDPR Data Protection",
      description: "General Data Protection Regulation compliance",
      type: "gdpr",
      version: "2018",
      requirements: [
        "Data processing lawfulness",
        "Data subject rights",
        "Privacy by design",
        "Data breach notification",
        "Data protection impact assessments"
      ],
      controls: [
        {
          id: "Art.5",
          name: "Principles of Processing",
          description: "Lawfulness, fairness and transparency",
          status: "compliant",
          evidence: ["Privacy notices", "Consent records", "Processing logs"],
          lastAssessed: "2024-10-15",
          nextAssessment: "2025-01-15"
        },
        {
          id: "Art.32",
          name: "Security of Processing",
          description: "Technical and organizational measures",
          status: "partial",
          evidence: ["Security policies", "Encryption implementation"],
          lastAssessed: "2024-10-15",
          nextAssessment: "2024-12-30"
        }
      ],
      auditFrequency: "yearly",
      nextAuditDate: "2025-10-15",
      complianceScore: 91.2,
      isActive: true,
      assignedTo: "Data Protection Officer",
      createdAt: "2024-02-01 11:00:00",
      updatedAt: "2024-10-15 13:45:00"
    }
  ];

  const sampleIncidents: SecurityIncident[] = [
    {
      id: "inc_001",
      title: "Unauthorized Access Attempt",
      description: "Multiple failed login attempts detected from suspicious IP address",
      severity: "medium",
      category: "unauthorized_access",
      status: "investigating",
      affectedSystems: ["Production ERP", "User Authentication"],
      affectedUsers: ["john.doe@company.com", "admin@company.com"],
      reportedBy: "Security Monitoring System",
      assignedTo: "Security Team",
      reportedAt: "2024-12-17 09:30:00",
      impact: "No successful breach, but indicates potential targeted attack",
      remediation: [
        "IP address blocked",
        "Affected accounts locked",
        "Security team notified",
        "Enhanced monitoring enabled"
      ],
      preventiveMeasures: [
        "Implement rate limiting",
        "Enhanced threat intelligence",
        "User security awareness training"
      ]
    },
    {
      id: "inc_002",
      title: "Data Classification Violation",
      description: "Confidential data found in unprotected shared folder",
      severity: "high",
      category: "policy_violation",
      status: "resolved",
      affectedSystems: ["File Server", "Document Management"],
      affectedUsers: ["data.analyst@company.com"],
      reportedBy: "Data Loss Prevention System",
      assignedTo: "Data Protection Team",
      reportedAt: "2024-12-16 14:20:00",
      resolvedAt: "2024-12-16 18:45:00",
      impact: "Confidential customer data exposed to unauthorized users",
      rootCause: "Misconfigured folder permissions during system migration",
      remediation: [
        "Data moved to secure location",
        "Folder permissions corrected",
        "Access logs reviewed",
        "Affected users notified"
      ],
      preventiveMeasures: [
        "Automated permission scanning",
        "Data classification training",
        "Migration procedure review"
      ]
    },
    {
      id: "inc_003",
      title: "Phishing Email Campaign",
      description: "Employees received suspicious emails requesting credential verification",
      severity: "medium",
      category: "phishing",
      status: "closed",
      affectedSystems: ["Email System"],
      affectedUsers: ["multiple users"],
      reportedBy: "Employee",
      assignedTo: "Security Team",
      reportedAt: "2024-12-15 11:15:00",
      resolvedAt: "2024-12-15 15:30:00",
      impact: "3 employees clicked suspicious links, no credentials compromised",
      rootCause: "Sophisticated phishing campaign bypassed email filters",
      remediation: [
        "Emails blocked and quarantined",
        "Email filters updated",
        "Affected users counseled",
        "Company-wide alert sent"
      ],
      preventiveMeasures: [
        "Enhanced email filtering",
        "Regular phishing simulations",
        "Security awareness training update"
      ]
    }
  ];

  const sampleAuditLogs: AuditLog[] = [
    {
      id: "log_001",
      timestamp: "2024-12-17 10:45:23",
      userId: "user_123",
      username: "john.manager",
      action: "LOGIN",
      resource: "Manufacturing ERP",
      resourceType: "application",
      method: "POST",
      ipAddress: "192.168.1.45",
      userAgent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
      success: true,
      sessionId: "sess_789abc",
      metadata: { mfa_used: true, location: "Office Building A" }
    },
    {
      id: "log_002",
      timestamp: "2024-12-17 10:42:15",
      userId: "user_456",
      username: "sarah.analyst",
      action: "DATA_EXPORT",
      resource: "Production Reports",
      resourceType: "data",
      method: "GET",
      ipAddress: "192.168.1.67",
      userAgent: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)",
      success: true,
      sessionId: "sess_456def",
      metadata: { export_format: "CSV", record_count: 1247 }
    },
    {
      id: "log_003",
      timestamp: "2024-12-17 10:38:42",
      userId: "user_789",
      username: "mike.admin",
      action: "CONFIG_CHANGE",
      resource: "User Permissions",
      resourceType: "system",
      method: "PUT",
      ipAddress: "192.168.1.89",
      userAgent: "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36",
      success: true,
      sessionId: "sess_123ghi",
      metadata: { changed_user: "new.employee", role_added: "inventory_viewer" }
    }
  ];

  // Create security policy mutation
  const createPolicyMutation = useMutation({
    mutationFn: async (data: z.infer<typeof securityPolicySchema>) => {
      return apiRequest("/api/security/policies", "POST", data);
    },
    onSuccess: () => {
      toast({
        title: "Policy Created",
        description: "Security policy has been created successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/security/policies"] });
      setIsPolicyDialogOpen(false);
      policyForm.reset();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create security policy",
        variant: "destructive",
      });
    },
  });

  // Create compliance framework mutation
  const createFrameworkMutation = useMutation({
    mutationFn: async (data: z.infer<typeof complianceFrameworkSchema>) => {
      return apiRequest("/api/compliance/frameworks", "POST", data);
    },
    onSuccess: () => {
      toast({
        title: "Framework Added",
        description: "Compliance framework has been added successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/compliance/frameworks"] });
      setIsFrameworkDialogOpen(false);
      frameworkForm.reset();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to add compliance framework",
        variant: "destructive",
      });
    },
  });

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "critical":
        return "bg-red-100 text-red-800";
      case "high":
        return "bg-orange-100 text-orange-800";
      case "medium":
        return "bg-yellow-100 text-yellow-800";
      case "low":
        return "bg-green-100 text-green-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
      case "compliant":
      case "resolved":
      case "closed":
        return "bg-green-100 text-green-800";
      case "investigating":
      case "partial":
      case "under_review":
        return "bg-yellow-100 text-yellow-800";
      case "non_compliant":
      case "open":
        return "bg-red-100 text-red-800";
      case "draft":
      case "not_applicable":
        return "bg-gray-100 text-gray-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "access":
        return <Key className="w-5 h-5 text-blue-600" />;
      case "data":
        return <Database className="w-5 h-5 text-green-600" />;
      case "network":
        return <Network className="w-5 h-5 text-purple-600" />;
      case "application":
        return <Monitor className="w-5 h-5 text-orange-600" />;
      case "physical":
        return <Lock className="w-5 h-5 text-red-600" />;
      case "compliance":
        return <FileText className="w-5 h-5 text-indigo-600" />;
      default:
        return <Shield className="w-5 h-5 text-gray-600" />;
    }
  };

  const getFrameworkIcon = (type: string) => {
    switch (type) {
      case "iso":
        return <Award className="w-5 h-5 text-blue-600" />;
      case "sox":
        return <BarChart3 className="w-5 h-5 text-green-600" />;
      case "gdpr":
        return <Shield className="w-5 h-5 text-purple-600" />;
      case "hipaa":
        return <Shield className="w-5 h-5 text-red-600" />;
      case "pci":
        return <Key className="w-5 h-5 text-yellow-600" />;
      case "nist":
        return <Target className="w-5 h-5 text-indigo-600" />;
      default:
        return <BookOpen className="w-5 h-5 text-gray-600" />;
    }
  };

  const filteredPolicies = samplePolicies.filter(policy => {
    const matchesCategory = filterCategory === "all" || policy.category === filterCategory;
    const matchesSeverity = filterSeverity === "all" || policy.severity === filterSeverity;
    const matchesSearch = searchTerm === "" || 
      policy.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      policy.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSeverity && matchesSearch;
  });

  const securityStats = {
    totalPolicies: samplePolicies.length,
    activePolicies: samplePolicies.filter(p => p.status === "active").length,
    totalViolations: samplePolicies.reduce((sum, p) => sum + p.violations, 0),
    criticalPolicies: samplePolicies.filter(p => p.severity === "critical").length,
    avgComplianceScore: Math.round(sampleFrameworks.reduce((sum, f) => sum + f.complianceScore, 0) / sampleFrameworks.length * 10) / 10,
    openIncidents: sampleIncidents.filter(i => i.status === "open" || i.status === "investigating").length
  };

  const onPolicySubmit = (data: z.infer<typeof securityPolicySchema>) => {
    createPolicyMutation.mutate(data);
  };

  const onFrameworkSubmit = (data: z.infer<typeof complianceFrameworkSchema>) => {
    createFrameworkMutation.mutate(data);
  };

  return (
    <div className="flex h-screen bg-carbon-gray-10">
      <Sidebar />
      <div className="flex-1 overflow-auto">
        <div className="p-6 space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-carbon-gray-80">Security & Compliance</h1>
              <p className="text-carbon-gray-60">Enterprise security management and regulatory compliance</p>
            </div>
            <div className="flex items-center space-x-3">
              <Button variant="outline" onClick={() => queryClient.invalidateQueries({ queryKey: ["/api/security"] })}>
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh
              </Button>
            </div>
          </div>

          {/* Overview Stats */}
          <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Shield className="w-5 h-5 text-blue-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Active Policies</p>
                    <p className="text-xl font-bold">{securityStats.activePolicies}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <AlertTriangle className="w-5 h-5 text-red-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Violations</p>
                    <p className="text-xl font-bold">{securityStats.totalViolations}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <XCircle className="w-5 h-5 text-orange-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Open Incidents</p>
                    <p className="text-xl font-bold">{securityStats.openIncidents}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Target className="w-5 h-5 text-green-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Compliance</p>
                    <p className="text-xl font-bold">{securityStats.avgComplianceScore}%</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Warning className="w-5 h-5 text-yellow-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Critical Policies</p>
                    <p className="text-xl font-bold">{securityStats.criticalPolicies}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <BookOpen className="w-5 h-5 text-purple-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Frameworks</p>
                    <p className="text-xl font-bold">{sampleFrameworks.length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
            <div className="flex items-center justify-between">
              <TabsList>
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="policies">Security Policies</TabsTrigger>
                <TabsTrigger value="compliance">Compliance</TabsTrigger>
                <TabsTrigger value="access">Access Control</TabsTrigger>
                <TabsTrigger value="incidents">Incidents</TabsTrigger>
                <TabsTrigger value="audit">Audit Logs</TabsTrigger>
              </TabsList>
              <div className="flex space-x-2">
                {activeTab === "policies" && (
                  <Dialog open={isPolicyDialogOpen} onOpenChange={setIsPolicyDialogOpen}>
                    <DialogTrigger asChild>
                      <Button>
                        <Plus className="w-4 h-4 mr-2" />
                        New Policy
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl">
                      <DialogHeader>
                        <DialogTitle>Create Security Policy</DialogTitle>
                      </DialogHeader>
                      <Form {...policyForm}>
                        <form onSubmit={policyForm.handleSubmit(onPolicySubmit)} className="space-y-4">
                          <div className="grid grid-cols-2 gap-4">
                            <FormField
                              control={policyForm.control}
                              name="name"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Policy Name</FormLabel>
                                  <FormControl>
                                    <Input {...field} />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={policyForm.control}
                              name="category"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Category</FormLabel>
                                  <FormControl>
                                    <Select onValueChange={field.onChange} value={field.value}>
                                      <SelectTrigger>
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="access">Access Control</SelectItem>
                                        <SelectItem value="data">Data Protection</SelectItem>
                                        <SelectItem value="network">Network Security</SelectItem>
                                        <SelectItem value="application">Application Security</SelectItem>
                                        <SelectItem value="physical">Physical Security</SelectItem>
                                        <SelectItem value="compliance">Compliance</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                          </div>
                          <FormField
                            control={policyForm.control}
                            name="description"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Description</FormLabel>
                                <FormControl>
                                  <Textarea {...field} />
                                </FormControl>
                              </FormItem>
                            )}
                          />
                          <div className="grid grid-cols-2 gap-4">
                            <FormField
                              control={policyForm.control}
                              name="severity"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Severity</FormLabel>
                                  <FormControl>
                                    <Select onValueChange={field.onChange} value={field.value}>
                                      <SelectTrigger>
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="low">Low</SelectItem>
                                        <SelectItem value="medium">Medium</SelectItem>
                                        <SelectItem value="high">High</SelectItem>
                                        <SelectItem value="critical">Critical</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={policyForm.control}
                              name="enforcementLevel"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Enforcement</FormLabel>
                                  <FormControl>
                                    <Select onValueChange={field.onChange} value={field.value}>
                                      <SelectTrigger>
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="advisory">Advisory</SelectItem>
                                        <SelectItem value="warning">Warning</SelectItem>
                                        <SelectItem value="blocking">Blocking</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                          </div>
                          <FormField
                            control={policyForm.control}
                            name="expiryDate"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Expiry Date (Optional)</FormLabel>
                                <FormControl>
                                  <Input type="date" {...field} />
                                </FormControl>
                              </FormItem>
                            )}
                          />
                          <div className="flex justify-end space-x-2">
                            <Button type="button" variant="outline" onClick={() => setIsPolicyDialogOpen(false)}>
                              Cancel
                            </Button>
                            <Button type="submit" disabled={createPolicyMutation.isPending}>
                              {createPolicyMutation.isPending ? "Creating..." : "Create Policy"}
                            </Button>
                          </div>
                        </form>
                      </Form>
                    </DialogContent>
                  </Dialog>
                )}
                {activeTab === "compliance" && (
                  <Dialog open={isFrameworkDialogOpen} onOpenChange={setIsFrameworkDialogOpen}>
                    <DialogTrigger asChild>
                      <Button>
                        <Plus className="w-4 h-4 mr-2" />
                        Add Framework
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl">
                      <DialogHeader>
                        <DialogTitle>Add Compliance Framework</DialogTitle>
                      </DialogHeader>
                      <Form {...frameworkForm}>
                        <form onSubmit={frameworkForm.handleSubmit(onFrameworkSubmit)} className="space-y-4">
                          <div className="grid grid-cols-2 gap-4">
                            <FormField
                              control={frameworkForm.control}
                              name="name"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Framework Name</FormLabel>
                                  <FormControl>
                                    <Input {...field} />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={frameworkForm.control}
                              name="type"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Type</FormLabel>
                                  <FormControl>
                                    <Select onValueChange={field.onChange} value={field.value}>
                                      <SelectTrigger>
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="iso">ISO</SelectItem>
                                        <SelectItem value="sox">SOX</SelectItem>
                                        <SelectItem value="gdpr">GDPR</SelectItem>
                                        <SelectItem value="hipaa">HIPAA</SelectItem>
                                        <SelectItem value="pci">PCI DSS</SelectItem>
                                        <SelectItem value="nist">NIST</SelectItem>
                                        <SelectItem value="custom">Custom</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                          </div>
                          <FormField
                            control={frameworkForm.control}
                            name="description"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Description</FormLabel>
                                <FormControl>
                                  <Textarea {...field} />
                                </FormControl>
                              </FormItem>
                            )}
                          />
                          <div className="grid grid-cols-3 gap-4">
                            <FormField
                              control={frameworkForm.control}
                              name="version"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Version</FormLabel>
                                  <FormControl>
                                    <Input {...field} />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={frameworkForm.control}
                              name="auditFrequency"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Audit Frequency</FormLabel>
                                  <FormControl>
                                    <Select onValueChange={field.onChange} value={field.value}>
                                      <SelectTrigger>
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="monthly">Monthly</SelectItem>
                                        <SelectItem value="quarterly">Quarterly</SelectItem>
                                        <SelectItem value="yearly">Yearly</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={frameworkForm.control}
                              name="nextAuditDate"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Next Audit</FormLabel>
                                  <FormControl>
                                    <Input type="date" {...field} />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                          </div>
                          <div className="flex justify-end space-x-2">
                            <Button type="button" variant="outline" onClick={() => setIsFrameworkDialogOpen(false)}>
                              Cancel
                            </Button>
                            <Button type="submit" disabled={createFrameworkMutation.isPending}>
                              {createFrameworkMutation.isPending ? "Adding..." : "Add Framework"}
                            </Button>
                          </div>
                        </form>
                      </Form>
                    </DialogContent>
                  </Dialog>
                )}
              </div>
            </div>

            <TabsContent value="overview" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="border-carbon-gray-20">
                  <CardHeader>
                    <CardTitle>Security Posture</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <span>Policy Compliance</span>
                        <span className="font-medium">94%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div className="bg-green-600 h-2 rounded-full" style={{ width: "94%" }}></div>
                      </div>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="text-gray-600">Active Policies:</span>
                          <p className="font-medium">{securityStats.activePolicies}</p>
                        </div>
                        <div>
                          <span className="text-gray-600">Violations:</span>
                          <p className="font-medium text-red-600">{securityStats.totalViolations}</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-carbon-gray-20">
                  <CardHeader>
                    <CardTitle>Compliance Status</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {sampleFrameworks.map((framework) => (
                        <div key={framework.id} className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            {getFrameworkIcon(framework.type)}
                            <span className="text-sm">{framework.name}</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <span className="text-sm font-medium">{framework.complianceScore}%</span>
                            <div className="w-16 bg-gray-200 rounded-full h-2">
                              <div 
                                className={`h-2 rounded-full ${
                                  framework.complianceScore >= 90 ? 'bg-green-600' :
                                  framework.complianceScore >= 70 ? 'bg-yellow-600' : 'bg-red-600'
                                }`}
                                style={{ width: `${framework.complianceScore}%` }}
                              ></div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card className="border-carbon-gray-20">
                <CardHeader>
                  <CardTitle>Recent Security Events</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {sampleIncidents.slice(0, 5).map((incident) => (
                      <div key={incident.id} className="flex items-center justify-between p-3 border rounded">
                        <div className="flex items-center space-x-3">
                          <Badge className={getSeverityColor(incident.severity)}>
                            {incident.severity}
                          </Badge>
                          <div>
                            <p className="font-medium text-sm">{incident.title}</p>
                            <p className="text-xs text-gray-500">{incident.reportedAt}</p>
                          </div>
                        </div>
                        <Badge className={getStatusColor(incident.status)}>
                          {incident.status.replace('_', ' ')}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="policies" className="space-y-4">
              {/* Filters and Search */}
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      placeholder="Search policies..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10 w-64"
                    />
                  </div>
                  <Select value={filterCategory} onValueChange={setFilterCategory}>
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Categories</SelectItem>
                      <SelectItem value="access">Access Control</SelectItem>
                      <SelectItem value="data">Data Protection</SelectItem>
                      <SelectItem value="network">Network Security</SelectItem>
                      <SelectItem value="application">Application Security</SelectItem>
                      <SelectItem value="physical">Physical Security</SelectItem>
                      <SelectItem value="compliance">Compliance</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={filterSeverity} onValueChange={setFilterSeverity}>
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Severities</SelectItem>
                      <SelectItem value="critical">Critical</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="low">Low</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Policies List */}
              <div className="space-y-4">
                {filteredPolicies.map((policy) => (
                  <Card key={policy.id} className="border-carbon-gray-20">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-3">
                            {getCategoryIcon(policy.category)}
                            <h3 className="text-lg font-semibold">{policy.name}</h3>
                            <Badge className={getSeverityColor(policy.severity)}>
                              {policy.severity}
                            </Badge>
                            <Badge className={getStatusColor(policy.status)}>
                              {policy.status.replace('_', ' ')}
                            </Badge>
                            <Badge variant="outline">
                              {policy.enforcementLevel}
                            </Badge>
                          </div>
                          
                          <p className="text-gray-600 mb-4">{policy.description}</p>
                          
                          <div className="mb-4">
                            <h4 className="font-medium text-gray-700 mb-2">Requirements:</h4>
                            <ul className="list-disc list-inside space-y-1 text-sm text-gray-600">
                              {policy.requirements.slice(0, 3).map((req, index) => (
                                <li key={index}>{req}</li>
                              ))}
                              {policy.requirements.length > 3 && (
                                <li className="text-blue-600 cursor-pointer">
                                  +{policy.requirements.length - 3} more requirements...
                                </li>
                              )}
                            </ul>
                          </div>

                          <div className="grid grid-cols-4 gap-4 text-sm">
                            <div>
                              <span className="font-medium text-gray-700">Violations:</span>
                              <p className={`font-medium ${policy.violations > 0 ? 'text-red-600' : 'text-green-600'}`}>
                                {policy.violations}
                              </p>
                            </div>
                            <div>
                              <span className="font-medium text-gray-700">Last Updated:</span>
                              <p className="text-gray-600">{policy.lastUpdated}</p>
                            </div>
                            <div>
                              <span className="font-medium text-gray-700">Created By:</span>
                              <p className="text-gray-600">{policy.createdBy}</p>
                            </div>
                            <div>
                              <span className="font-medium text-gray-700">Approved By:</span>
                              <p className="text-gray-600">{policy.approvedBy || "Pending"}</p>
                            </div>
                          </div>
                        </div>

                        <div className="flex flex-col space-y-2 ml-6">
                          <Switch 
                            checked={policy.isActive}
                            onCheckedChange={() => {/* Handle toggle */}}
                          />
                          <Button size="sm" variant="outline">
                            <Eye className="w-3 h-3 mr-2" />
                            View
                          </Button>
                          <Button size="sm" variant="outline">
                            <Edit className="w-3 h-3 mr-2" />
                            Edit
                          </Button>
                          <Button size="sm" variant="outline">
                            <MoreHorizontal className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="compliance" className="space-y-4">
              <div className="space-y-6">
                {sampleFrameworks.map((framework) => (
                  <Card key={framework.id} className="border-carbon-gray-20">
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          {getFrameworkIcon(framework.type)}
                          <div>
                            <CardTitle className="text-lg">{framework.name}</CardTitle>
                            <p className="text-sm text-carbon-gray-60">Version {framework.version}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-3">
                          <div className="text-right">
                            <p className="text-2xl font-bold text-green-600">{framework.complianceScore}%</p>
                            <p className="text-xs text-gray-500">Compliance Score</p>
                          </div>
                          <Badge className={getStatusColor(framework.isActive ? "active" : "inactive")}>
                            {framework.isActive ? "Active" : "Inactive"}
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <p className="text-gray-600">{framework.description}</p>
                      
                      <div className="grid grid-cols-3 gap-4 text-sm">
                        <div>
                          <span className="font-medium text-gray-700">Audit Frequency:</span>
                          <p className="text-gray-600 capitalize">{framework.auditFrequency}</p>
                        </div>
                        <div>
                          <span className="font-medium text-gray-700">Next Audit:</span>
                          <p className="text-gray-600">{framework.nextAuditDate}</p>
                        </div>
                        <div>
                          <span className="font-medium text-gray-700">Assigned To:</span>
                          <p className="text-gray-600">{framework.assignedTo}</p>
                        </div>
                      </div>

                      <div>
                        <h4 className="font-medium text-gray-700 mb-3">Controls Status:</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {framework.controls.map((control) => (
                            <div key={control.id} className="border rounded p-3">
                              <div className="flex items-center justify-between mb-2">
                                <span className="font-medium text-sm">{control.id}</span>
                                <Badge className={getStatusColor(control.status)}>
                                  {control.status.replace('_', ' ')}
                                </Badge>
                              </div>
                              <p className="text-sm text-gray-600 mb-2">{control.name}</p>
                              <div className="text-xs text-gray-500">
                                <p>Last assessed: {control.lastAssessed}</p>
                                <p>Next assessment: {control.nextAssessment}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="flex justify-end space-x-2 pt-4 border-t">
                        <Button size="sm" variant="outline">
                          <Download className="w-3 h-3 mr-2" />
                          Export Report
                        </Button>
                        <Button size="sm" variant="outline">
                          <Calendar className="w-3 h-3 mr-2" />
                          Schedule Audit
                        </Button>
                        <Button size="sm" variant="outline">
                          <Edit className="w-3 h-3 mr-2" />
                          Update
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="access" className="space-y-4">
              <div className="text-center py-12">
                <Key className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">Access Control Management</h3>
                <p className="text-gray-600 mb-4">Role-based access control and permissions management</p>
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Configure Access
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="incidents" className="space-y-4">
              <div className="space-y-4">
                {sampleIncidents.map((incident) => (
                  <Card key={incident.id} className="border-carbon-gray-20">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-3">
                            <AlertTriangle className="w-5 h-5 text-red-600" />
                            <h3 className="text-lg font-semibold">{incident.title}</h3>
                            <Badge className={getSeverityColor(incident.severity)}>
                              {incident.severity}
                            </Badge>
                            <Badge className={getStatusColor(incident.status)}>
                              {incident.status.replace('_', ' ')}
                            </Badge>
                          </div>
                          
                          <p className="text-gray-600 mb-4">{incident.description}</p>
                          
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm mb-4">
                            <div>
                              <span className="font-medium text-gray-700">Category:</span>
                              <p className="text-gray-600 capitalize">{incident.category.replace('_', ' ')}</p>
                            </div>
                            <div>
                              <span className="font-medium text-gray-700">Reported By:</span>
                              <p className="text-gray-600">{incident.reportedBy}</p>
                            </div>
                            <div>
                              <span className="font-medium text-gray-700">Assigned To:</span>
                              <p className="text-gray-600">{incident.assignedTo}</p>
                            </div>
                            <div>
                              <span className="font-medium text-gray-700">Reported:</span>
                              <p className="text-gray-600">{incident.reportedAt}</p>
                            </div>
                          </div>

                          <div className="mb-4">
                            <span className="font-medium text-gray-700">Impact:</span>
                            <p className="text-gray-600">{incident.impact}</p>
                          </div>

                          {incident.remediation.length > 0 && (
                            <div className="mb-4">
                              <span className="font-medium text-gray-700">Remediation Actions:</span>
                              <ul className="list-disc list-inside space-y-1 text-sm text-gray-600 mt-2">
                                {incident.remediation.map((action, index) => (
                                  <li key={index}>{action}</li>
                                ))}
                              </ul>
                            </div>
                          )}

                          <div className="flex flex-wrap gap-2">
                            <span className="text-sm font-medium text-gray-700">Affected Systems:</span>
                            {incident.affectedSystems.map((system, index) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {system}
                              </Badge>
                            ))}
                          </div>
                        </div>

                        <div className="flex flex-col space-y-2 ml-6">
                          <Button size="sm">
                            <Edit className="w-3 h-3 mr-2" />
                            Update
                          </Button>
                          <Button size="sm" variant="outline">
                            <Eye className="w-3 h-3 mr-2" />
                            Details
                          </Button>
                          {incident.status === "resolved" && (
                            <Button size="sm" variant="outline">
                              <Archive className="w-3 h-3 mr-2" />
                              Close
                            </Button>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="audit" className="space-y-4">
              <Card className="border-carbon-gray-20">
                <CardHeader>
                  <CardTitle>Recent Audit Logs</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {sampleAuditLogs.map((log) => (
                      <div key={log.id} className="flex items-center justify-between p-3 border rounded text-sm">
                        <div className="flex items-center space-x-4">
                          <div className={`w-2 h-2 rounded-full ${log.success ? 'bg-green-500' : 'bg-red-500'}`} />
                          <div>
                            <p className="font-medium">{log.username}</p>
                            <p className="text-gray-500">{log.action} on {log.resource}</p>
                          </div>
                          <Badge variant="outline" className="text-xs">
                            {log.method}
                          </Badge>
                        </div>
                        <div className="text-right text-gray-500">
                          <p>{log.timestamp}</p>
                          <p className="text-xs">{log.ipAddress}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}