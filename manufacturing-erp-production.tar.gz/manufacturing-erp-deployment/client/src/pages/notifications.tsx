import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import Sidebar from "@/components/layout/sidebar";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  Bell, 
  Settings, 
  CheckCircle, 
  AlertCircle, 
  AlertTriangle,
  Info,
  Plus,
  Edit,
  Trash2,
  Play,
  Pause,
  Volume2,
  VolumeX,
  Smartphone,
  Mail,
  MessageSquare,
  Slack,
  Clock,
  Filter,
  Search,
  Archive,
  MoreHorizontal,
  Users,
  Zap,
  Package,
  Activity,
  Shield,
  TrendingDown,
  TrendingUp
} from "lucide-react";

const notificationRuleSchema = z.object({
  name: z.string().min(1, "Name is required"),
  description: z.string().min(1, "Description is required"),
  eventType: z.string().min(1, "Event type is required"),
  severity: z.enum(["info", "warning", "error", "critical"]),
  conditions: z.record(z.any()),
  channels: z.array(z.string()).min(1, "At least one channel is required"),
  recipients: z.array(z.string()).min(1, "At least one recipient is required"),
  isActive: z.boolean().default(true),
  cooldownMinutes: z.number().min(0, "Cooldown must be 0 or greater"),
  priority: z.enum(["low", "medium", "high", "urgent"]),
});

interface NotificationRule {
  id: string;
  name: string;
  description: string;
  eventType: string;
  severity: "info" | "warning" | "error" | "critical";
  conditions: Record<string, any>;
  channels: string[];
  recipients: string[];
  isActive: boolean;
  cooldownMinutes: number;
  priority: "low" | "medium" | "high" | "urgent";
  lastTriggered?: string;
  triggerCount: number;
  createdAt: string;
  updatedAt: string;
}

interface Notification {
  id: string;
  title: string;
  message: string;
  severity: "info" | "warning" | "error" | "critical";
  priority: "low" | "medium" | "high" | "urgent";
  category: string;
  source: string;
  timestamp: string;
  isRead: boolean;
  isArchived: boolean;
  actions?: Array<{
    label: string;
    url: string;
    type: "primary" | "secondary";
  }>;
  metadata?: Record<string, any>;
}

interface NotificationChannel {
  id: string;
  name: string;
  type: "email" | "sms" | "push" | "slack" | "webhook";
  description: string;
  isActive: boolean;
  configuration: Record<string, any>;
  lastUsed?: string;
  successRate: number;
}

export default function Notifications() {
  const [activeTab, setActiveTab] = useState("notifications");
  const [isRuleDialogOpen, setIsRuleDialogOpen] = useState(false);
  const [selectedRule, setSelectedRule] = useState<NotificationRule | null>(null);
  const [filterSeverity, setFilterSeverity] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState("");

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const ruleForm = useForm<z.infer<typeof notificationRuleSchema>>({
    resolver: zodResolver(notificationRuleSchema),
    defaultValues: {
      isActive: true,
      cooldownMinutes: 15,
      priority: "medium",
      severity: "warning",
      channels: [],
      recipients: [],
    },
  });

  // Sample notifications data
  const sampleNotifications: Notification[] = [
    {
      id: "notif_001",
      title: "Low Stock Alert",
      message: "Product SKU-001 has fallen below minimum stock level (5 units remaining)",
      severity: "warning",
      priority: "high",
      category: "inventory",
      source: "Inventory Management",
      timestamp: "2024-12-17 03:45:00",
      isRead: false,
      isArchived: false,
      actions: [
        { label: "Reorder", url: "/inventory/reorder/SKU-001", type: "primary" },
        { label: "View Details", url: "/inventory/item/SKU-001", type: "secondary" }
      ],
      metadata: { itemId: "SKU-001", currentStock: 5, minStock: 10 }
    },
    {
      id: "notif_002",
      title: "Quality Control Failure",
      message: "Production order PO-2024-156 failed quality inspection",
      severity: "error",
      priority: "urgent",
      category: "quality",
      source: "Quality Control",
      timestamp: "2024-12-17 03:30:00",
      isRead: false,
      isArchived: false,
      actions: [
        { label: "Review", url: "/quality/order/PO-2024-156", type: "primary" },
        { label: "Assign Inspector", url: "/quality/assign", type: "secondary" }
      ],
      metadata: { orderId: "PO-2024-156", defectType: "dimensional", inspector: "John Doe" }
    },
    {
      id: "notif_003",
      title: "Machine Maintenance Required",
      message: "CNC Machine #3 requires scheduled maintenance in 2 hours",
      severity: "warning",
      priority: "medium",
      category: "maintenance",
      source: "Machine Monitoring",
      timestamp: "2024-12-17 03:15:00",
      isRead: true,
      isArchived: false,
      actions: [
        { label: "Schedule", url: "/maintenance/schedule/machine-3", type: "primary" }
      ],
      metadata: { machineId: "machine-3", maintenanceType: "scheduled", hours: 2 }
    },
    {
      id: "notif_004",
      title: "Production Target Achieved",
      message: "Daily production target of 500 units reached ahead of schedule",
      severity: "info",
      priority: "low",
      category: "production",
      source: "Production Management",
      timestamp: "2024-12-17 02:45:00",
      isRead: true,
      isArchived: false,
      metadata: { target: 500, actual: 502, ahead: "2 hours" }
    },
    {
      id: "notif_005",
      title: "Energy Consumption Spike",
      message: "Factory energy usage exceeded normal levels by 25%",
      severity: "warning",
      priority: "medium",
      category: "energy",
      source: "Energy Management",
      timestamp: "2024-12-17 02:30:00",
      isRead: false,
      isArchived: false,
      actions: [
        { label: "View Analysis", url: "/energy/analysis", type: "primary" }
      ],
      metadata: { increase: "25%", department: "Assembly Line", cost: "$245" }
    },
    {
      id: "notif_006",
      title: "System Integration Error",
      message: "Failed to sync data with SAP ERP system",
      severity: "error",
      priority: "high",
      category: "integration",
      source: "API Integrations",
      timestamp: "2024-12-17 02:15:00",
      isRead: false,
      isArchived: false,
      actions: [
        { label: "Retry Sync", url: "/api-integrations/retry/sap", type: "primary" },
        { label: "Check Logs", url: "/api-integrations/logs", type: "secondary" }
      ],
      metadata: { integration: "SAP ERP", errorCode: "AUTH_EXPIRED", lastSync: "2024-12-17 01:30:00" }
    }
  ];

  const sampleRules: NotificationRule[] = [
    {
      id: "rule_001",
      name: "Low Stock Alert",
      description: "Alert when inventory falls below minimum stock level",
      eventType: "inventory.low_stock",
      severity: "warning",
      conditions: { threshold: 10, comparison: "less_than" },
      channels: ["email", "push"],
      recipients: ["inventory@company.com", "manager@company.com"],
      isActive: true,
      cooldownMinutes: 60,
      priority: "high",
      lastTriggered: "2024-12-17 03:45:00",
      triggerCount: 15,
      createdAt: "2024-12-01 10:00:00",
      updatedAt: "2024-12-17 03:45:00"
    },
    {
      id: "rule_002",
      name: "Quality Failure Alert",
      description: "Immediate notification for quality control failures",
      eventType: "quality.failure",
      severity: "error",
      conditions: { defectRate: 5, comparison: "greater_than" },
      channels: ["email", "sms", "slack"],
      recipients: ["quality@company.com", "+1234567890", "#quality-alerts"],
      isActive: true,
      cooldownMinutes: 0,
      priority: "urgent",
      lastTriggered: "2024-12-17 03:30:00",
      triggerCount: 3,
      createdAt: "2024-12-01 10:00:00",
      updatedAt: "2024-12-17 03:30:00"
    },
    {
      id: "rule_003",
      name: "Machine Maintenance Due",
      description: "Preventive maintenance scheduling alerts",
      eventType: "machine.maintenance_due",
      severity: "warning",
      conditions: { hours_remaining: 2, comparison: "less_than_equal" },
      channels: ["email", "push"],
      recipients: ["maintenance@company.com"],
      isActive: true,
      cooldownMinutes: 480,
      priority: "medium",
      lastTriggered: "2024-12-17 03:15:00",
      triggerCount: 8,
      createdAt: "2024-12-01 10:00:00",
      updatedAt: "2024-12-17 03:15:00"
    },
    {
      id: "rule_004",
      name: "Energy Usage Spike",
      description: "Alert for abnormal energy consumption patterns",
      eventType: "energy.spike",
      severity: "warning",
      conditions: { increase_percentage: 20, comparison: "greater_than" },
      channels: ["email"],
      recipients: ["facilities@company.com"],
      isActive: true,
      cooldownMinutes: 120,
      priority: "medium",
      triggerCount: 5,
      createdAt: "2024-12-01 10:00:00",
      updatedAt: "2024-12-17 02:30:00"
    }
  ];

  const sampleChannels: NotificationChannel[] = [
    {
      id: "ch_001",
      name: "Company Email",
      type: "email",
      description: "SMTP email notifications",
      isActive: true,
      configuration: { smtp_host: "smtp.company.com", port: 587 },
      lastUsed: "2024-12-17 03:45:00",
      successRate: 98.5
    },
    {
      id: "ch_002",
      name: "SMS Alerts",
      type: "sms",
      description: "Twilio SMS notifications",
      isActive: true,
      configuration: { provider: "twilio", from: "+1234567890" },
      lastUsed: "2024-12-17 03:30:00",
      successRate: 99.2
    },
    {
      id: "ch_003",
      name: "Slack Integration",
      type: "slack",
      description: "Slack workspace notifications",
      isActive: true,
      configuration: { workspace: "company.slack.com", default_channel: "#alerts" },
      lastUsed: "2024-12-17 03:30:00",
      successRate: 97.8
    },
    {
      id: "ch_004",
      name: "Push Notifications",
      type: "push",
      description: "Mobile app push notifications",
      isActive: true,
      configuration: { fcm_key: "***", apns_key: "***" },
      lastUsed: "2024-12-17 03:15:00",
      successRate: 95.4
    }
  ];

  // Create notification rule mutation
  const createRuleMutation = useMutation({
    mutationFn: async (data: z.infer<typeof notificationRuleSchema>) => {
      return apiRequest("/api/notifications/rules", "POST", data);
    },
    onSuccess: () => {
      toast({
        title: "Rule Created",
        description: "Notification rule has been created successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications/rules"] });
      setIsRuleDialogOpen(false);
      ruleForm.reset();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create notification rule",
        variant: "destructive",
      });
    },
  });

  // Mark notification as read mutation
  const markAsReadMutation = useMutation({
    mutationFn: async (notificationId: string) => {
      return apiRequest(`/api/notifications/${notificationId}/read`, "PATCH");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
    },
  });

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case "critical":
        return <AlertCircle className="w-5 h-5 text-red-600" />;
      case "error":
        return <AlertCircle className="w-5 h-5 text-red-500" />;
      case "warning":
        return <AlertTriangle className="w-5 h-5 text-yellow-500" />;
      case "info":
        return <Info className="w-5 h-5 text-blue-500" />;
      default:
        return <Bell className="w-5 h-5 text-gray-500" />;
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "critical":
        return "bg-red-100 text-red-800 border-red-200";
      case "error":
        return "bg-red-50 text-red-700 border-red-150";
      case "warning":
        return "bg-yellow-50 text-yellow-700 border-yellow-150";
      case "info":
        return "bg-blue-50 text-blue-700 border-blue-150";
      default:
        return "bg-gray-50 text-gray-700 border-gray-150";
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "urgent":
        return "bg-red-500 text-white";
      case "high":
        return "bg-orange-500 text-white";
      case "medium":
        return "bg-blue-500 text-white";
      case "low":
        return "bg-gray-500 text-white";
      default:
        return "bg-gray-400 text-white";
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "inventory":
        return <Package className="w-4 h-4" />;
      case "quality":
        return <Shield className="w-4 h-4" />;
      case "maintenance":
        return <Settings className="w-4 h-4" />;
      case "production":
        return <Activity className="w-4 h-4" />;
      case "energy":
        return <Zap className="w-4 h-4" />;
      case "integration":
        return <Bell className="w-4 h-4" />;
      default:
        return <Info className="w-4 h-4" />;
    }
  };

  const getChannelIcon = (type: string) => {
    switch (type) {
      case "email":
        return <Mail className="w-5 h-5" />;
      case "sms":
        return <Smartphone className="w-5 h-5" />;
      case "slack":
        return <Slack className="w-5 h-5" />;
      case "push":
        return <Bell className="w-5 h-5" />;
      case "webhook":
        return <Activity className="w-5 h-5" />;
      default:
        return <MessageSquare className="w-5 h-5" />;
    }
  };

  const filteredNotifications = sampleNotifications.filter(notification => {
    const matchesSeverity = filterSeverity === "all" || notification.severity === filterSeverity;
    const matchesSearch = searchTerm === "" || 
      notification.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      notification.message.toLowerCase().includes(searchTerm.toLowerCase()) ||
      notification.category.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesSeverity && matchesSearch;
  });

  const notificationStats = {
    total: sampleNotifications.length,
    unread: sampleNotifications.filter(n => !n.isRead).length,
    critical: sampleNotifications.filter(n => n.severity === "critical").length,
    warnings: sampleNotifications.filter(n => n.severity === "warning").length,
    activeRules: sampleRules.filter(r => r.isActive).length
  };

  const onRuleSubmit = (data: z.infer<typeof notificationRuleSchema>) => {
    createRuleMutation.mutate(data);
  };

  const handleMarkAsRead = (notificationId: string) => {
    markAsReadMutation.mutate(notificationId);
  };

  return (
    <div className="flex h-screen bg-carbon-gray-10">
      <Sidebar />
      <div className="flex-1 overflow-auto">
        <div className="p-6 space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-carbon-gray-80">Notifications & Alerts</h1>
              <p className="text-carbon-gray-60">Manage real-time notifications and alert rules</p>
            </div>
            <div className="flex items-center space-x-3">
              <Button variant="outline" onClick={() => queryClient.invalidateQueries({ queryKey: ["/api/notifications"] })}>
                <Bell className="w-4 h-4 mr-2" />
                Refresh
              </Button>
            </div>
          </div>

          {/* Overview Stats */}
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Bell className="w-5 h-5 text-blue-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Total Alerts</p>
                    <p className="text-xl font-bold">{notificationStats.total}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <TrendingUp className="w-5 h-5 text-orange-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Unread</p>
                    <p className="text-xl font-bold">{notificationStats.unread}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <AlertCircle className="w-5 h-5 text-red-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Critical</p>
                    <p className="text-xl font-bold">{notificationStats.critical}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <AlertTriangle className="w-5 h-5 text-yellow-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Warnings</p>
                    <p className="text-xl font-bold">{notificationStats.warnings}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Settings className="w-5 h-5 text-green-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Active Rules</p>
                    <p className="text-xl font-bold">{notificationStats.activeRules}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
            <div className="flex items-center justify-between">
              <TabsList>
                <TabsTrigger value="notifications">
                  Notifications
                  {notificationStats.unread > 0 && (
                    <Badge className="ml-2 bg-red-500 text-white text-xs">
                      {notificationStats.unread}
                    </Badge>
                  )}
                </TabsTrigger>
                <TabsTrigger value="rules">Alert Rules</TabsTrigger>
                <TabsTrigger value="channels">Channels</TabsTrigger>
                <TabsTrigger value="analytics">Analytics</TabsTrigger>
              </TabsList>
              <div className="flex space-x-2">
                {activeTab === "rules" && (
                  <Dialog open={isRuleDialogOpen} onOpenChange={setIsRuleDialogOpen}>
                    <DialogTrigger asChild>
                      <Button>
                        <Plus className="w-4 h-4 mr-2" />
                        New Rule
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl">
                      <DialogHeader>
                        <DialogTitle>Create Notification Rule</DialogTitle>
                      </DialogHeader>
                      <Form {...ruleForm}>
                        <form onSubmit={ruleForm.handleSubmit(onRuleSubmit)} className="space-y-4">
                          <div className="grid grid-cols-2 gap-4">
                            <FormField
                              control={ruleForm.control}
                              name="name"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Rule Name</FormLabel>
                                  <FormControl>
                                    <Input {...field} />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={ruleForm.control}
                              name="eventType"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Event Type</FormLabel>
                                  <FormControl>
                                    <Select onValueChange={field.onChange} value={field.value}>
                                      <SelectTrigger>
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="inventory.low_stock">Low Stock</SelectItem>
                                        <SelectItem value="quality.failure">Quality Failure</SelectItem>
                                        <SelectItem value="machine.maintenance_due">Maintenance Due</SelectItem>
                                        <SelectItem value="production.target_missed">Target Missed</SelectItem>
                                        <SelectItem value="energy.spike">Energy Spike</SelectItem>
                                        <SelectItem value="integration.error">Integration Error</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                          </div>
                          <FormField
                            control={ruleForm.control}
                            name="description"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Description</FormLabel>
                                <FormControl>
                                  <Textarea {...field} />
                                </FormControl>
                              </FormItem>
                            )}
                          />
                          <div className="grid grid-cols-3 gap-4">
                            <FormField
                              control={ruleForm.control}
                              name="severity"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Severity</FormLabel>
                                  <FormControl>
                                    <Select onValueChange={field.onChange} value={field.value}>
                                      <SelectTrigger>
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="info">Info</SelectItem>
                                        <SelectItem value="warning">Warning</SelectItem>
                                        <SelectItem value="error">Error</SelectItem>
                                        <SelectItem value="critical">Critical</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={ruleForm.control}
                              name="priority"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Priority</FormLabel>
                                  <FormControl>
                                    <Select onValueChange={field.onChange} value={field.value}>
                                      <SelectTrigger>
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="low">Low</SelectItem>
                                        <SelectItem value="medium">Medium</SelectItem>
                                        <SelectItem value="high">High</SelectItem>
                                        <SelectItem value="urgent">Urgent</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={ruleForm.control}
                              name="cooldownMinutes"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Cooldown (minutes)</FormLabel>
                                  <FormControl>
                                    <Input 
                                      type="number" 
                                      min="0" 
                                      {...field}
                                      onChange={e => field.onChange(parseInt(e.target.value))}
                                    />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                          </div>
                          <div className="flex justify-end space-x-2">
                            <Button type="button" variant="outline" onClick={() => setIsRuleDialogOpen(false)}>
                              Cancel
                            </Button>
                            <Button type="submit" disabled={createRuleMutation.isPending}>
                              {createRuleMutation.isPending ? "Creating..." : "Create Rule"}
                            </Button>
                          </div>
                        </form>
                      </Form>
                    </DialogContent>
                  </Dialog>
                )}
              </div>
            </div>

            <TabsContent value="notifications" className="space-y-4">
              {/* Filters */}
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      placeholder="Search notifications..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10 w-64"
                    />
                  </div>
                  <Select value={filterSeverity} onValueChange={setFilterSeverity}>
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Severities</SelectItem>
                      <SelectItem value="critical">Critical</SelectItem>
                      <SelectItem value="error">Error</SelectItem>
                      <SelectItem value="warning">Warning</SelectItem>
                      <SelectItem value="info">Info</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm">
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Mark All Read
                  </Button>
                  <Button variant="outline" size="sm">
                    <Archive className="w-4 h-4 mr-2" />
                    Archive Read
                  </Button>
                </div>
              </div>

              {/* Notifications List */}
              <div className="space-y-3">
                {filteredNotifications.map((notification) => (
                  <Card key={notification.id} className={`border-carbon-gray-20 ${!notification.isRead ? 'bg-blue-50/30' : ''}`}>
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            {getSeverityIcon(notification.severity)}
                            <h4 className={`font-medium ${!notification.isRead ? 'font-semibold' : ''}`}>
                              {notification.title}
                            </h4>
                            <Badge className={getSeverityColor(notification.severity)}>
                              {notification.severity}
                            </Badge>
                            <Badge className={getPriorityColor(notification.priority)} variant="secondary">
                              {notification.priority}
                            </Badge>
                            <div className="flex items-center space-x-1 text-xs text-gray-500">
                              {getCategoryIcon(notification.category)}
                              <span>{notification.category}</span>
                            </div>
                          </div>
                          <p className="text-sm text-gray-700 mb-3">{notification.message}</p>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-4 text-xs text-gray-500">
                              <span>{notification.source}</span>
                              <span>•</span>
                              <span>{notification.timestamp}</span>
                            </div>
                            {notification.actions && (
                              <div className="flex space-x-2">
                                {notification.actions.map((action, index) => (
                                  <Button
                                    key={index}
                                    size="sm"
                                    variant={action.type === "primary" ? "default" : "outline"}
                                  >
                                    {action.label}
                                  </Button>
                                ))}
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center space-x-2 ml-4">
                          {!notification.isRead && (
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => handleMarkAsRead(notification.id)}
                            >
                              <CheckCircle className="w-4 h-4" />
                            </Button>
                          )}
                          <Button size="sm" variant="ghost">
                            <MoreHorizontal className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="rules" className="space-y-4">
              <div className="space-y-4">
                {sampleRules.map((rule) => (
                  <Card key={rule.id} className="border-carbon-gray-20">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            {getSeverityIcon(rule.severity)}
                            <h4 className="font-medium">{rule.name}</h4>
                            <Badge className={getSeverityColor(rule.severity)}>
                              {rule.severity}
                            </Badge>
                            <Badge className={getPriorityColor(rule.priority)} variant="secondary">
                              {rule.priority}
                            </Badge>
                            <Badge variant={rule.isActive ? "default" : "secondary"}>
                              {rule.isActive ? "Active" : "Inactive"}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-600 mb-2">{rule.description}</p>
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs text-gray-500">
                            <div>
                              <span className="font-medium">Event:</span> {rule.eventType}
                            </div>
                            <div>
                              <span className="font-medium">Triggers:</span> {rule.triggerCount}
                            </div>
                            <div>
                              <span className="font-medium">Cooldown:</span> {rule.cooldownMinutes}m
                            </div>
                            <div>
                              <span className="font-medium">Channels:</span> {rule.channels.length}
                            </div>
                          </div>
                          {rule.lastTriggered && (
                            <p className="text-xs text-gray-500 mt-2">
                              Last triggered: {rule.lastTriggered}
                            </p>
                          )}
                        </div>
                        <div className="flex items-center space-x-2">
                          <Switch 
                            checked={rule.isActive}
                            onCheckedChange={() => {/* Handle toggle */}}
                          />
                          <Button variant="outline" size="sm">
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button variant="outline" size="sm">
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="channels" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {sampleChannels.map((channel) => (
                  <Card key={channel.id} className="border-carbon-gray-20">
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          {getChannelIcon(channel.type)}
                          <div>
                            <CardTitle className="text-lg">{channel.name}</CardTitle>
                            <p className="text-sm text-carbon-gray-60 capitalize">{channel.type}</p>
                          </div>
                        </div>
                        <Badge variant={channel.isActive ? "default" : "secondary"}>
                          {channel.isActive ? "Active" : "Inactive"}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <p className="text-sm text-gray-600">{channel.description}</p>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <p className="text-gray-600">Success Rate</p>
                          <p className="font-medium">{channel.successRate}%</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Last Used</p>
                          <p className="font-medium">{channel.lastUsed || "Never"}</p>
                        </div>
                      </div>
                      <div className="flex items-center justify-between pt-2 border-t">
                        <Switch 
                          checked={channel.isActive}
                          onCheckedChange={() => {/* Handle toggle */}}
                        />
                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm">
                            <Settings className="w-4 h-4" />
                          </Button>
                          <Button variant="outline" size="sm">
                            <Play className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="analytics" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="border-carbon-gray-20">
                  <CardHeader>
                    <CardTitle>Notification Volume (Last 7 Days)</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-32 flex items-center justify-center text-gray-500">
                      Chart visualization would appear here
                    </div>
                  </CardContent>
                </Card>
                <Card className="border-carbon-gray-20">
                  <CardHeader>
                    <CardTitle>Channel Performance</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {sampleChannels.map((channel) => (
                        <div key={channel.id} className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            {getChannelIcon(channel.type)}
                            <span className="text-sm">{channel.name}</span>
                          </div>
                          <div className="text-sm font-medium">{channel.successRate}%</div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}