import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  Area,
  AreaChart
} from "recharts";
import {
  Settings,
  Layout,
  Eye,
  EyeOff,
  Grid3X3,
  RotateCcw,
  Save,
  Package,
  ClipboardList,
  CheckCircle,
  AlertTriangle,
  TrendingUp,
  TrendingDown,
  DollarSign,
  Activity,
  Users,
  Zap,
  Calendar,
  Target,
  Plus,
  Minus,
  GripVertical
} from "lucide-react";

interface DashboardWidget {
  id: string;
  type: string;
  title: string;
  visible: boolean;
  position: { x: number; y: number };
  size: { width: number; height: number };
  config?: any;
}

interface DashboardLayout {
  widgets: DashboardWidget[];
  layout: string; // 'grid', 'masonry', 'custom'
  columns: number;
  theme: string;
  refreshInterval: number;
}

const defaultWidgets: DashboardWidget[] = [
  {
    id: "efficiency-kpi",
    type: "kpi",
    title: "Overall Efficiency",
    visible: true,
    position: { x: 0, y: 0 },
    size: { width: 1, height: 1 },
    config: { metric: "efficiency", icon: "TrendingUp", color: "blue" }
  },
  {
    id: "inventory-value-kpi",
    type: "kpi",
    title: "Inventory Value",
    visible: true,
    position: { x: 1, y: 0 },
    size: { width: 1, height: 1 },
    config: { metric: "inventoryValue", icon: "DollarSign", color: "green" }
  },
  {
    id: "active-orders-kpi",
    type: "kpi",
    title: "Active Orders",
    visible: true,
    position: { x: 2, y: 0 },
    size: { width: 1, height: 1 },
    config: { metric: "activeOrders", icon: "ClipboardList", color: "orange" }
  },
  {
    id: "quality-score-kpi",
    type: "kpi",
    title: "Quality Score",
    visible: true,
    position: { x: 3, y: 0 },
    size: { width: 1, height: 1 },
    config: { metric: "qualityScore", icon: "CheckCircle", color: "purple" }
  },
  {
    id: "order-status-chart",
    type: "chart",
    title: "Order Status Distribution",
    visible: true,
    position: { x: 0, y: 1 },
    size: { width: 2, height: 2 },
    config: { chartType: "pie", dataSource: "orderStatus" }
  },
  {
    id: "efficiency-trend-chart",
    type: "chart",
    title: "Efficiency Trend",
    visible: true,
    position: { x: 2, y: 1 },
    size: { width: 2, height: 2 },
    config: { chartType: "area", dataSource: "efficiencyTrend" }
  },
  {
    id: "low-stock-alerts",
    type: "alerts",
    title: "Stock Alerts",
    visible: true,
    position: { x: 0, y: 3 },
    size: { width: 2, height: 2 },
    config: { alertType: "lowStock", maxItems: 5 }
  },
  {
    id: "recent-activity",
    type: "activity",
    title: "Recent Activity",
    visible: true,
    position: { x: 2, y: 3 },
    size: { width: 2, height: 2 },
    config: { maxItems: 5, showTimestamp: true }
  }
];

export default function CustomizableDashboard() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isCustomizing, setIsCustomizing] = useState(false);
  const [dashboardLayout, setDashboardLayout] = useState<DashboardLayout>({
    widgets: defaultWidgets,
    layout: 'grid',
    columns: 4,
    theme: 'default',
    refreshInterval: 30000
  });

  // Fetch data
  const { data: kpis } = useQuery({
    queryKey: ["/api/dashboard/kpis"],
    refetchInterval: dashboardLayout.refreshInterval,
  });

  const { data: inventory = [] } = useQuery({
    queryKey: ["/api/inventory"],
    refetchInterval: dashboardLayout.refreshInterval,
  });

  const { data: productionOrders = [] } = useQuery({
    queryKey: ["/api/production-orders"],
    refetchInterval: dashboardLayout.refreshInterval,
  });

  const { data: lowStockItems = [] } = useQuery({
    queryKey: ["/api/inventory/low-stock"],
    refetchInterval: dashboardLayout.refreshInterval,
  });

  const { data: recentActivity = [] } = useQuery({
    queryKey: ["/api/activity-logs/recent"],
    refetchInterval: dashboardLayout.refreshInterval,
  });

  // Load saved layout
  const { data: savedLayout } = useQuery({
    queryKey: ["/api/dashboard/layout"],
    enabled: !isCustomizing,
    retry: false,
  });

  // Save layout mutation
  const saveLayoutMutation = useMutation({
    mutationFn: async (layout: DashboardLayout) => {
      const response = await apiRequest("POST", "/api/dashboard/layout", layout);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Dashboard Saved",
        description: "Your dashboard layout has been saved successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/layout"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to save dashboard layout.",
        variant: "destructive",
      });
    },
  });

  // Load saved layout on mount
  useEffect(() => {
    if (savedLayout && typeof savedLayout === 'object') {
      setDashboardLayout(savedLayout as DashboardLayout);
    }
  }, [savedLayout]);

  // Calculate metrics
  const metrics = {
    efficiency: (kpis as any)?.efficiency || 87,
    inventoryValue: Array.isArray(inventory) 
      ? inventory.reduce((sum: number, item: any) => sum + (item.currentStock || 0) * (item.unitPrice || 0), 0)
      : 0,
    activeOrders: Array.isArray(productionOrders) 
      ? productionOrders.filter((order: any) => order.status === "in_progress" || order.status === "pending").length
      : 0,
    qualityScore: 95,
    totalItems: Array.isArray(inventory) ? inventory.length : 0,
  };

  // Chart data
  const orderStatusData = [
    { name: "Completed", value: Array.isArray(productionOrders) ? productionOrders.filter((order: any) => order.status === "completed").length : 0, color: "#22c55e" },
    { name: "In Progress", value: metrics.activeOrders, color: "#3b82f6" },
    { name: "Pending", value: Array.isArray(productionOrders) ? productionOrders.filter((order: any) => order.status === "pending").length : 0, color: "#f59e0b" },
  ];

  const efficiencyTrendData = [
    { name: "Mon", efficiency: 89 },
    { name: "Tue", efficiency: 92 },
    { name: "Wed", efficiency: 87 },
    { name: "Thu", efficiency: 94 },
    { name: "Fri", efficiency: 91 },
    { name: "Sat", efficiency: 88 },
    { name: "Sun", efficiency: 85 },
  ];

  const toggleWidgetVisibility = (widgetId: string) => {
    setDashboardLayout(prev => ({
      ...prev,
      widgets: prev.widgets.map(widget =>
        widget.id === widgetId ? { ...widget, visible: !widget.visible } : widget
      )
    }));
  };

  const updateWidgetConfig = (widgetId: string, config: any) => {
    setDashboardLayout(prev => ({
      ...prev,
      widgets: prev.widgets.map(widget =>
        widget.id === widgetId ? { ...widget, config: { ...widget.config, ...config } } : widget
      )
    }));
  };

  const saveDashboard = () => {
    saveLayoutMutation.mutate(dashboardLayout);
    setIsCustomizing(false);
  };

  const resetToDefault = () => {
    setDashboardLayout({
      widgets: defaultWidgets,
      layout: 'grid',
      columns: 4,
      theme: 'default',
      refreshInterval: 30000
    });
  };

  const renderWidget = (widget: DashboardWidget) => {
    if (!widget.visible) return null;

    const getIcon = (iconName: string) => {
      const icons: any = {
        TrendingUp, DollarSign, ClipboardList, CheckCircle, Package, AlertTriangle
      };
      return icons[iconName] || TrendingUp;
    };

    const getMetricValue = (metric: string) => {
      switch (metric) {
        case 'efficiency': return `${metrics.efficiency}%`;
        case 'inventoryValue': return `$${metrics.inventoryValue.toLocaleString()}`;
        case 'activeOrders': return metrics.activeOrders.toString();
        case 'qualityScore': return `${metrics.qualityScore}%`;
        default: return '0';
      }
    };

    switch (widget.type) {
      case 'kpi':
        const Icon = getIcon(widget.config?.icon || 'TrendingUp');
        const value = getMetricValue(widget.config?.metric || 'efficiency');
        return (
          <Card key={widget.id} className="relative">
            {isCustomizing && (
              <div className="absolute top-2 right-2 flex gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => toggleWidgetVisibility(widget.id)}
                >
                  {widget.visible ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
                </Button>
              </div>
            )}
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{widget.title}</CardTitle>
              <Icon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{value}</div>
              {widget.config?.metric === 'efficiency' || widget.config?.metric === 'qualityScore' ? (
                <Progress value={parseInt(value)} className="mt-2" />
              ) : null}
            </CardContent>
          </Card>
        );

      case 'chart':
        return (
          <Card key={widget.id} className="relative">
            {isCustomizing && (
              <div className="absolute top-2 right-2 flex gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => toggleWidgetVisibility(widget.id)}
                >
                  {widget.visible ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
                </Button>
              </div>
            )}
            <CardHeader>
              <CardTitle>{widget.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  {widget.config?.chartType === 'pie' ? (
                    <PieChart>
                      <Pie
                        data={orderStatusData}
                        cx="50%"
                        cy="50%"
                        innerRadius={40}
                        outerRadius={80}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {orderStatusData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  ) : (
                    <AreaChart data={efficiencyTrendData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Area 
                        type="monotone" 
                        dataKey="efficiency" 
                        stroke="#3b82f6" 
                        fill="#3b82f6" 
                        fillOpacity={0.3}
                      />
                    </AreaChart>
                  )}
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        );

      case 'alerts':
        return (
          <Card key={widget.id} className="relative">
            {isCustomizing && (
              <div className="absolute top-2 right-2 flex gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => toggleWidgetVisibility(widget.id)}
                >
                  {widget.visible ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
                </Button>
              </div>
            )}
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-red-500" />
                {widget.title}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {Array.isArray(lowStockItems) && lowStockItems.length > 0 ? (
                <div className="space-y-3">
                  {(lowStockItems as any[]).slice(0, widget.config?.maxItems || 5).map((item: any) => (
                    <div key={item.id} className="flex items-center justify-between p-3 bg-red-50 dark:bg-red-900/20 rounded-lg">
                      <div>
                        <p className="font-medium text-gray-900 dark:text-white">
                          {item.name}
                        </p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          Stock: {item.currentStock} / Min: {item.minStock}
                        </p>
                      </div>
                      <Badge variant="destructive">Low Stock</Badge>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                  <CheckCircle className="h-12 w-12 mx-auto mb-4 text-green-500" />
                  <p>All inventory levels normal</p>
                </div>
              )}
            </CardContent>
          </Card>
        );

      case 'activity':
        return (
          <Card key={widget.id} className="relative">
            {isCustomizing && (
              <div className="absolute top-2 right-2 flex gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => toggleWidgetVisibility(widget.id)}
                >
                  {widget.visible ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
                </Button>
              </div>
            )}
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5 text-blue-500" />
                {widget.title}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {Array.isArray(recentActivity) && recentActivity.length > 0 ? (
                <div className="space-y-3">
                  {(recentActivity as any[]).slice(0, widget.config?.maxItems || 5).map((activity: any) => (
                    <div key={activity.id} className="flex items-start gap-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                      <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                      <div className="flex-1">
                        <p className="text-sm font-medium text-gray-900 dark:text-white">
                          {activity.action}
                        </p>
                        {widget.config?.showTimestamp && (
                          <p className="text-xs text-gray-600 dark:text-gray-400">
                            {new Date(activity.createdAt).toLocaleString()}
                          </p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                  <Activity className="h-12 w-12 mx-auto mb-4" />
                  <p>No recent activity</p>
                </div>
              )}
            </CardContent>
          </Card>
        );

      default:
        return null;
    }
  };

  const getGridClass = () => {
    switch (dashboardLayout.columns) {
      case 2: return "grid-cols-1 md:grid-cols-2";
      case 3: return "grid-cols-1 md:grid-cols-2 lg:grid-cols-3";
      case 4: return "grid-cols-1 md:grid-cols-2 lg:grid-cols-4";
      case 6: return "grid-cols-1 md:grid-cols-3 lg:grid-cols-6";
      default: return "grid-cols-1 md:grid-cols-2 lg:grid-cols-4";
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
              Dashboard
            </h1>
            <p className="text-gray-600 dark:text-gray-400 mt-2">
              {isCustomizing ? "Customize your dashboard layout" : "Your personalized manufacturing overview"}
            </p>
          </div>
          <div className="flex items-center gap-4">
            {isCustomizing ? (
              <>
                <Button variant="outline" onClick={resetToDefault}>
                  <RotateCcw className="h-4 w-4 mr-2" />
                  Reset
                </Button>
                <Button variant="outline" onClick={() => setIsCustomizing(false)}>
                  Cancel
                </Button>
                <Button onClick={saveDashboard} disabled={saveLayoutMutation.isPending}>
                  <Save className="h-4 w-4 mr-2" />
                  {saveLayoutMutation.isPending ? "Saving..." : "Save"}
                </Button>
              </>
            ) : (
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="outline" onClick={() => setIsCustomizing(true)}>
                    <Settings className="h-4 w-4 mr-2" />
                    Customize
                  </Button>
                </DialogTrigger>
              </Dialog>
            )}
          </div>
        </div>

        {/* Customization Panel */}
        {isCustomizing && (
          <Card className="mb-6 bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Layout className="h-5 w-5" />
                Dashboard Settings
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <label className="text-sm font-medium mb-2 block">Layout</label>
                  <Select 
                    value={dashboardLayout.layout} 
                    onValueChange={(value) => setDashboardLayout(prev => ({ ...prev, layout: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="grid">Grid Layout</SelectItem>
                      <SelectItem value="masonry">Masonry Layout</SelectItem>
                      <SelectItem value="custom">Custom Layout</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="text-sm font-medium mb-2 block">Columns</label>
                  <Select 
                    value={dashboardLayout.columns.toString()} 
                    onValueChange={(value) => setDashboardLayout(prev => ({ ...prev, columns: parseInt(value) }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="2">2 Columns</SelectItem>
                      <SelectItem value="3">3 Columns</SelectItem>
                      <SelectItem value="4">4 Columns</SelectItem>
                      <SelectItem value="6">6 Columns</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-sm font-medium mb-2 block">Refresh Interval</label>
                  <Select 
                    value={dashboardLayout.refreshInterval.toString()} 
                    onValueChange={(value) => setDashboardLayout(prev => ({ ...prev, refreshInterval: parseInt(value) }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="10000">10 seconds</SelectItem>
                      <SelectItem value="30000">30 seconds</SelectItem>
                      <SelectItem value="60000">1 minute</SelectItem>
                      <SelectItem value="300000">5 minutes</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Dashboard Grid */}
        <div className={`grid gap-6 ${getGridClass()}`}>
          {dashboardLayout.widgets
            .filter(widget => widget.visible || isCustomizing)
            .map(widget => renderWidget(widget))}
        </div>

        {/* Widget Visibility Panel */}
        {isCustomizing && (
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Widget Visibility</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {dashboardLayout.widgets.map(widget => (
                  <div key={widget.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <span className="text-sm font-medium">{widget.title}</span>
                    <Switch
                      checked={widget.visible}
                      onCheckedChange={() => toggleWidgetVisibility(widget.id)}
                    />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}