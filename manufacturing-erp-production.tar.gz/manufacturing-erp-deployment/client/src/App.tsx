import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import { Toaster } from "@/components/ui/toaster";
import CustomizableDashboard from "@/pages/customizable-dashboard";
import MVPLayout from "@/pages/mvp-layout";
import PerformanceSnapshot from "@/pages/performance-snapshot";
import Inventory from "@/pages/inventory";
import ProductionOrders from "@/pages/production-orders";
import QualityControl from "@/pages/quality-control";
import BarcodeScanner from "@/pages/barcode-scanner";
import MVPSettings from "@/pages/mvp-settings";
import Landing from "@/pages/landing";
import NotFound from "@/pages/not-found";
// Removed analytics and notifications for MVP focus

function Router() {
  const { isAuthenticated, isLoading } = useAuth();

  return (
    <Switch>
      {isLoading || !isAuthenticated ? (
        <Route path="/" component={Landing} />
      ) : (
        <>
          <Route path="/" component={() => (
            <MVPLayout>
              <CustomizableDashboard />
            </MVPLayout>
          )} />
          <Route path="/performance-snapshot" component={() => (
            <MVPLayout>
              <PerformanceSnapshot />
            </MVPLayout>
          )} />
          <Route path="/inventory" component={() => (
            <MVPLayout>
              <Inventory />
            </MVPLayout>
          )} />
          <Route path="/production-orders" component={() => (
            <MVPLayout>
              <ProductionOrders />
            </MVPLayout>
          )} />
          <Route path="/quality-control" component={() => (
            <MVPLayout>
              <QualityControl />
            </MVPLayout>
          )} />
          <Route path="/barcode-scanner" component={() => (
            <MVPLayout>
              <BarcodeScanner />
            </MVPLayout>
          )} />

          <Route path="/settings" component={() => (
            <MVPLayout>
              <MVPSettings />
            </MVPLayout>
          )} />
        </>
      )}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <div className="min-h-screen bg-background">
        <Router />
        <Toaster />
      </div>
    </QueryClientProvider>
  );
}

export default App;