import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { FileBarChart, Download, Filter, Calendar, TrendingUp, DollarSign } from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

type ReportData = {
  productionMetrics: {
    totalOrders: number;
    completedOrders: number;
    avgEfficiency: number;
    totalRevenue: number;
  };
  costAnalysis: {
    materialCosts: number;
    laborCosts: number;
    overheadCosts: number;
    totalCosts: number;
  };
  qualityMetrics: {
    passRate: number;
    defectRate: number;
    reworkRate: number;
  };
  timeMetrics: {
    avgLeadTime: number;
    avgCycleTime: number;
    onTimeDelivery: number;
  };
};

export default function AdvancedReportsWidget() {
  const { toast } = useToast();
  const [dateRange, setDateRange] = useState("last30days");
  const [reportType, setReportType] = useState("overview");

  const { data: reportData, isLoading } = useQuery({
    queryKey: ['/api/reports/advanced', dateRange, reportType],
    refetchInterval: 300000,
  });

  const exportReportMutation = useMutation({
    mutationFn: async (format: "pdf" | "excel" | "csv") => {
      return await apiRequest('/api/reports/export', 'POST', { 
        dateRange, 
        reportType, 
        format 
      });
    },
    onSuccess: () => {
      toast({
        title: "Report Exported",
        description: "Your report has been exported successfully",
      });
    },
  });

  const reports: ReportData = reportData || {
    productionMetrics: {
      totalOrders: 0,
      completedOrders: 0,
      avgEfficiency: 0,
      totalRevenue: 0,
    },
    costAnalysis: {
      materialCosts: 0,
      laborCosts: 0,
      overheadCosts: 0,
      totalCosts: 0,
    },
    qualityMetrics: {
      passRate: 0,
      defectRate: 0,
      reworkRate: 0,
    },
    timeMetrics: {
      avgLeadTime: 0,
      avgCycleTime: 0,
      onTimeDelivery: 0,
    },
  };

  const productionData = [
    { name: "Week 1", orders: 45, completed: 42, efficiency: 93 },
    { name: "Week 2", orders: 52, completed: 48, efficiency: 92 },
    { name: "Week 3", orders: 38, completed: 36, efficiency: 95 },
    { name: "Week 4", orders: 61, completed: 58, efficiency: 94 },
  ];

  const costBreakdown = [
    { name: "Materials", value: reports.costAnalysis.materialCosts || 45000, color: "#0088FE" },
    { name: "Labor", value: reports.costAnalysis.laborCosts || 32000, color: "#00C49F" },
    { name: "Overhead", value: reports.costAnalysis.overheadCosts || 18000, color: "#FFBB28" },
  ];

  const qualityTrends = [
    { month: "Jan", passRate: 94, defectRate: 6 },
    { month: "Feb", passRate: 96, defectRate: 4 },
    { month: "Mar", passRate: 93, defectRate: 7 },
    { month: "Apr", passRate: 97, defectRate: 3 },
    { month: "May", passRate: 95, defectRate: 5 },
    { month: "Jun", passRate: 98, defectRate: 2 },
  ];

  const handleExport = (format: "pdf" | "excel" | "csv") => {
    exportReportMutation.mutate(format);
  };

  return (
    <Card className="border-carbon-gray-20">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <FileBarChart className="w-5 h-5 text-carbon-blue" />
            <span>Advanced Reports</span>
          </div>
          <div className="flex items-center space-x-2">
            <select
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value)}
              className="text-sm border border-carbon-gray-20 rounded px-2 py-1"
            >
              <option value="last7days">Last 7 Days</option>
              <option value="last30days">Last 30 Days</option>
              <option value="last90days">Last 90 Days</option>
              <option value="lastyear">Last Year</option>
            </select>
            <Button
              size="sm"
              variant="outline"
              onClick={() => handleExport("pdf")}
              disabled={exportReportMutation.isPending}
            >
              <Download className="w-4 h-4 mr-1" />
              Export
            </Button>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {/* Key Metrics Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-3 bg-blue-50 rounded-lg">
              <p className="text-2xl font-bold text-blue-600">{reports.productionMetrics.totalOrders}</p>
              <p className="text-sm text-blue-700">Total Orders</p>
            </div>
            <div className="text-center p-3 bg-green-50 rounded-lg">
              <p className="text-2xl font-bold text-green-600">{reports.productionMetrics.avgEfficiency}%</p>
              <p className="text-sm text-green-700">Avg Efficiency</p>
            </div>
            <div className="text-center p-3 bg-purple-50 rounded-lg">
              <p className="text-2xl font-bold text-purple-600">{reports.qualityMetrics.passRate}%</p>
              <p className="text-sm text-purple-700">Quality Pass Rate</p>
            </div>
            <div className="text-center p-3 bg-orange-50 rounded-lg">
              <p className="text-2xl font-bold text-orange-600">${reports.productionMetrics.totalRevenue.toLocaleString()}</p>
              <p className="text-sm text-orange-700">Total Revenue</p>
            </div>
          </div>

          {/* Charts Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Production Trends */}
            <div>
              <h4 className="font-medium text-carbon-gray-80 mb-3">Production Trends</h4>
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={productionData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" fontSize={12} />
                  <YAxis fontSize={12} />
                  <Tooltip />
                  <Bar dataKey="orders" fill="#0088FE" name="Total Orders" />
                  <Bar dataKey="completed" fill="#00C49F" name="Completed" />
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Cost Breakdown */}
            <div>
              <h4 className="font-medium text-carbon-gray-80 mb-3">Cost Breakdown</h4>
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie
                    data={costBreakdown}
                    cx="50%"
                    cy="50%"
                    innerRadius={40}
                    outerRadius={80}
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {costBreakdown.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => `$${Number(value).toLocaleString()}`} />
                </PieChart>
              </ResponsiveContainer>
            </div>

            {/* Quality Trends */}
            <div>
              <h4 className="font-medium text-carbon-gray-80 mb-3">Quality Trends</h4>
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={qualityTrends}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" fontSize={12} />
                  <YAxis fontSize={12} />
                  <Tooltip />
                  <Line type="monotone" dataKey="passRate" stroke="#00C49F" name="Pass Rate %" />
                  <Line type="monotone" dataKey="defectRate" stroke="#FF8042" name="Defect Rate %" />
                </LineChart>
              </ResponsiveContainer>
            </div>

            {/* Performance Metrics */}
            <div>
              <h4 className="font-medium text-carbon-gray-80 mb-3">Performance Summary</h4>
              <div className="space-y-3">
                <div className="flex items-center justify-between p-2 bg-carbon-gray-10 rounded">
                  <span className="text-sm text-carbon-gray-70">Average Lead Time</span>
                  <span className="font-medium text-carbon-gray-80">{reports.timeMetrics.avgLeadTime} days</span>
                </div>
                <div className="flex items-center justify-between p-2 bg-carbon-gray-10 rounded">
                  <span className="text-sm text-carbon-gray-70">Average Cycle Time</span>
                  <span className="font-medium text-carbon-gray-80">{reports.timeMetrics.avgCycleTime} hours</span>
                </div>
                <div className="flex items-center justify-between p-2 bg-carbon-gray-10 rounded">
                  <span className="text-sm text-carbon-gray-70">On-Time Delivery</span>
                  <span className="font-medium text-green-600">{reports.timeMetrics.onTimeDelivery}%</span>
                </div>
                <div className="flex items-center justify-between p-2 bg-carbon-gray-10 rounded">
                  <span className="text-sm text-carbon-gray-70">Total Cost</span>
                  <span className="font-medium text-carbon-gray-80">${reports.costAnalysis.totalCosts.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Export Options */}
          <div className="border-t pt-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-carbon-gray-50">Export formats:</span>
              <div className="flex space-x-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleExport("pdf")}
                  disabled={exportReportMutation.isPending}
                >
                  PDF
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleExport("excel")}
                  disabled={exportReportMutation.isPending}
                >
                  Excel
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleExport("csv")}
                  disabled={exportReportMutation.isPending}
                >
                  CSV
                </Button>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}