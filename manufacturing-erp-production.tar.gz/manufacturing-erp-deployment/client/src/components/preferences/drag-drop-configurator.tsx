import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { 
  GripVertical, 
  Eye, 
  EyeOff, 
  RotateCcw, 
  Save, 
  Settings, 
  Layout,
  Palette,
  Bell,
  Zap
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface DraggableItem {
  id: string;
  title: string;
  description: string;
  category: string;
  enabled: boolean;
  order: number;
  icon: React.ReactNode;
  configurable?: boolean;
}

interface PreferenceSection {
  id: string;
  title: string;
  description: string;
  items: DraggableItem[];
}

interface DragDropConfiguratorProps {
  onSave?: (preferences: any) => void;
  onReset?: () => void;
}

export default function DragDropConfigurator({ onSave, onReset }: DragDropConfiguratorProps) {
  const { toast } = useToast();
  const draggedItem = useRef<DraggableItem | null>(null);
  const draggedIndex = useRef<number>(-1);
  const draggedSection = useRef<string>("");

  const [preferences, setPreferences] = useState<PreferenceSection[]>([
    {
      id: "dashboard",
      title: "Dashboard Widgets",
      description: "Customize your dashboard layout and widget visibility",
      items: [
        {
          id: "kpi-cards",
          title: "KPI Cards",
          description: "Key performance indicators overview",
          category: "dashboard",
          enabled: true,
          order: 1,
          icon: <Zap className="w-4 h-4" />,
          configurable: true
        },
        {
          id: "recent-activity",
          title: "Recent Activity",
          description: "Latest system activities and updates",
          category: "dashboard",
          enabled: true,
          order: 2,
          icon: <Bell className="w-4 h-4" />,
          configurable: true
        },
        {
          id: "production-chart",
          title: "Production Analytics",
          description: "Real-time production metrics and trends",
          category: "dashboard",
          enabled: true,
          order: 3,
          icon: <Layout className="w-4 h-4" />,
          configurable: true
        },
        {
          id: "inventory-alerts",
          title: "Inventory Alerts",
          description: "Low stock and reorder notifications",
          category: "dashboard",
          enabled: false,
          order: 4,
          icon: <Bell className="w-4 h-4" />,
          configurable: true
        }
      ]
    },
    {
      id: "navigation",
      title: "Navigation & Shortcuts",
      description: "Organize menu items and quick access features",
      items: [
        {
          id: "inventory-menu",
          title: "Inventory Management",
          description: "Access to inventory tools and reports",
          category: "navigation",
          enabled: true,
          order: 1,
          icon: <Layout className="w-4 h-4" />
        },
        {
          id: "production-menu",
          title: "Production Orders",
          description: "Manufacturing workflow management",
          category: "navigation",
          enabled: true,
          order: 2,
          icon: <Settings className="w-4 h-4" />
        },
        {
          id: "quality-menu",
          title: "Quality Control",
          description: "Quality assurance and compliance",
          category: "navigation",
          enabled: true,
          order: 3,
          icon: <Eye className="w-4 h-4" />
        },
        {
          id: "scanner-menu",
          title: "Barcode Scanner",
          description: "Mobile scanning capabilities",
          category: "navigation",
          enabled: true,
          order: 4,
          icon: <Zap className="w-4 h-4" />
        }
      ]
    },
    {
      id: "notifications",
      title: "Notification Preferences",
      description: "Control what notifications you receive and how",
      items: [
        {
          id: "low-stock-alerts",
          title: "Low Stock Alerts",
          description: "Notify when inventory falls below minimum levels",
          category: "notifications",
          enabled: true,
          order: 1,
          icon: <Bell className="w-4 h-4" />
        },
        {
          id: "order-updates",
          title: "Order Status Updates",
          description: "Production order progress notifications",
          category: "notifications",
          enabled: true,
          order: 2,
          icon: <Bell className="w-4 h-4" />
        },
        {
          id: "quality-issues",
          title: "Quality Issues",
          description: "Quality control failure notifications",
          category: "notifications",
          enabled: true,
          order: 3,
          icon: <Bell className="w-4 h-4" />
        },
        {
          id: "system-maintenance",
          title: "System Maintenance",
          description: "Scheduled maintenance and updates",
          category: "notifications",
          enabled: false,
          order: 4,
          icon: <Settings className="w-4 h-4" />
        }
      ]
    }
  ]);

  const [hasChanges, setHasChanges] = useState(false);

  const handleDragStart = (item: DraggableItem, index: number, sectionId: string) => {
    draggedItem.current = item;
    draggedIndex.current = index;
    draggedSection.current = sectionId;
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (targetIndex: number, targetSectionId: string) => {
    if (!draggedItem.current) return;

    const newPreferences = [...preferences];
    const sourceSection = newPreferences.find(section => section.id === draggedSection.current);
    const targetSection = newPreferences.find(section => section.id === targetSectionId);

    if (!sourceSection || !targetSection) return;

    // Remove from source
    const [movedItem] = sourceSection.items.splice(draggedIndex.current, 1);
    
    // Update category if moving between sections
    if (draggedSection.current !== targetSectionId) {
      movedItem.category = targetSectionId;
    }

    // Insert at target position
    targetSection.items.splice(targetIndex, 0, movedItem);

    // Reorder items in both sections
    sourceSection.items.forEach((item, index) => {
      item.order = index + 1;
    });
    targetSection.items.forEach((item, index) => {
      item.order = index + 1;
    });

    setPreferences(newPreferences);
    setHasChanges(true);

    // Reset drag state
    draggedItem.current = null;
    draggedIndex.current = -1;
    draggedSection.current = "";

    toast({
      title: "Item Moved",
      description: `${movedItem.title} has been repositioned`,
    });
  };

  const toggleItemEnabled = (sectionId: string, itemId: string) => {
    const newPreferences = preferences.map(section => {
      if (section.id === sectionId) {
        return {
          ...section,
          items: section.items.map(item => 
            item.id === itemId ? { ...item, enabled: !item.enabled } : item
          )
        };
      }
      return section;
    });
    
    setPreferences(newPreferences);
    setHasChanges(true);
  };

  const handleSave = () => {
    onSave?.(preferences);
    setHasChanges(false);
    
    toast({
      title: "Preferences Saved",
      description: "Your layout and settings have been updated",
    });
  };

  const handleReset = () => {
    onReset?.();
    setHasChanges(false);
    
    toast({
      title: "Preferences Reset",
      description: "All settings have been restored to defaults",
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center space-x-2">
            <Palette className="w-6 h-6 text-blue-600" />
            <span>Customize Your Experience</span>
          </h2>
          <p className="text-gray-600 mt-1">
            Drag and drop items to reorganize your interface and toggle features on or off
          </p>
        </div>
        
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            onClick={handleReset}
            disabled={!hasChanges}
          >
            <RotateCcw className="w-4 h-4 mr-2" />
            Reset
          </Button>
          <Button 
            onClick={handleSave}
            disabled={!hasChanges}
          >
            <Save className="w-4 h-4 mr-2" />
            Save Changes
          </Button>
        </div>
      </div>

      {hasChanges && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <p className="text-blue-800 text-sm">
            You have unsaved changes. Don't forget to save your preferences.
          </p>
        </div>
      )}

      {/* Preference Sections */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {preferences.map(section => (
          <Card key={section.id} className="h-fit">
            <CardHeader>
              <CardTitle className="text-lg">{section.title}</CardTitle>
              <p className="text-sm text-gray-600">{section.description}</p>
            </CardHeader>
            <CardContent className="space-y-3">
              {section.items
                .sort((a, b) => a.order - b.order)
                .map((item, index) => (
                  <div
                    key={item.id}
                    draggable
                    onDragStart={() => handleDragStart(item, index, section.id)}
                    onDragOver={handleDragOver}
                    onDrop={() => handleDrop(index, section.id)}
                    className={`
                      group border rounded-lg p-3 cursor-move transition-all duration-200
                      ${item.enabled 
                        ? 'bg-white border-gray-200 hover:border-blue-300 hover:shadow-md' 
                        : 'bg-gray-50 border-gray-100 opacity-60'
                      }
                    `}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-start space-x-3 flex-1">
                        <div className="flex items-center space-x-2">
                          <GripVertical className="w-4 h-4 text-gray-400 group-hover:text-gray-600" />
                          <div className="text-blue-600">
                            {item.icon}
                          </div>
                        </div>
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center space-x-2">
                            <h4 className="font-medium text-sm truncate">
                              {item.title}
                            </h4>
                            {item.configurable && (
                              <Badge variant="outline" className="text-xs">
                                Customizable
                              </Badge>
                            )}
                          </div>
                          <p className="text-xs text-gray-500 mt-1 line-clamp-2">
                            {item.description}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2 ml-2">
                        <button
                          onClick={() => toggleItemEnabled(section.id, item.id)}
                          className="text-gray-400 hover:text-gray-600 transition-colors"
                        >
                          {item.enabled ? (
                            <Eye className="w-4 h-4" />
                          ) : (
                            <EyeOff className="w-4 h-4" />
                          )}
                        </button>
                        <Switch
                          checked={item.enabled}
                          onCheckedChange={() => toggleItemEnabled(section.id, item.id)}
                        />
                      </div>
                    </div>
                  </div>
                ))}

              {section.items.length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  <Layout className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">No items in this section</p>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Drop Zones for Cross-Section Drops */}
      <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
        <div className="text-gray-500">
          <Layout className="w-12 h-12 mx-auto mb-4 opacity-50" />
          <h3 className="font-medium mb-2">Drop Zone</h3>
          <p className="text-sm">
            Drag items here to create a new section or reorganize across categories
          </p>
        </div>
      </div>

      {/* Preview Section */}
      <Card>
        <CardHeader>
          <CardTitle>Preview Your Changes</CardTitle>
          <p className="text-sm text-gray-600">
            See how your customizations will appear in the interface
          </p>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {preferences.map(section => (
              <div key={section.id} className="space-y-2">
                <h4 className="font-medium text-sm text-gray-700">{section.title}</h4>
                <div className="space-y-1">
                  {section.items
                    .filter(item => item.enabled)
                    .sort((a, b) => a.order - b.order)
                    .map((item, index) => (
                      <div key={item.id} className="flex items-center space-x-2 text-sm">
                        <span className="text-gray-400">{index + 1}.</span>
                        <div className="text-blue-600">{item.icon}</div>
                        <span>{item.title}</span>
                      </div>
                    ))}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}