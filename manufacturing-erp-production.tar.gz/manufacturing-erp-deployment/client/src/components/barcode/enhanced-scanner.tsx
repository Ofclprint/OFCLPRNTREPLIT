import { useState, useRef, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Camera, QrCode, Package, Plus, Minus, CheckCircle, AlertTriangle } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

type InventoryItem = {
  id: number;
  name: string;
  sku: string;
  currentStock: number;
  minStock: number;
  maxStock: number;
  unitPrice: string;
  unit: string;
  location?: string;
  barcode?: string;
};

export default function EnhancedBarcodeScanner() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [manualInput, setManualInput] = useState("");
  const [scannedItem, setScannedItem] = useState<InventoryItem | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [operation, setOperation] = useState<"in" | "out">("in");
  const [reason, setReason] = useState("");

  const scanItemMutation = useMutation({
    mutationFn: async (barcode: string) => {
      return await apiRequest(`/api/inventory/scan/${barcode}`, 'GET');
    },
    onSuccess: (data: InventoryItem) => {
      setScannedItem(data);
      toast({
        title: "Item Found",
        description: `Scanned: ${data.name}`,
      });
    },
    onError: () => {
      toast({
        title: "Item Not Found",
        description: "No item found with this barcode",
        variant: "destructive",
      });
    },
  });

  const handleManualScan = () => {
    if (manualInput.trim()) {
      scanItemMutation.mutate(manualInput.trim());
      setManualInput("");
    }
  };

  const getStockStatus = (item: InventoryItem) => {
    if (item.currentStock <= item.minStock) {
      return { status: "Low Stock", color: "bg-red-100 text-red-800", icon: AlertTriangle };
    }
    return { status: "Normal", color: "bg-green-100 text-green-800", icon: CheckCircle };
  };

  return (
    <div className="space-y-6">
      <Card className="border-carbon-gray-20">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <QrCode className="w-5 h-5 text-carbon-blue" />
            <span>Enhanced Barcode Scanner</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex space-x-2">
            <Input
              placeholder="Enter barcode or scan..."
              value={manualInput}
              onChange={(e) => setManualInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleManualScan()}
            />
            <Button 
              onClick={handleManualScan}
              disabled={!manualInput.trim() || scanItemMutation.isPending}
            >
              {scanItemMutation.isPending ? "Scanning..." : "Scan"}
            </Button>
          </div>

          {scannedItem && (
            <div className="border border-carbon-gray-20 rounded-lg p-4 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h3 className="font-semibold text-carbon-gray-80">{scannedItem.name}</h3>
                  <p className="text-sm text-carbon-gray-50">SKU: {scannedItem.sku}</p>
                  <p className="text-sm text-carbon-gray-50">Price: {scannedItem.unitPrice}</p>
                </div>
                
                <div className="space-y-2">
                  {(() => {
                    const stockInfo = getStockStatus(scannedItem);
                    const StatusIcon = stockInfo.icon;
                    return (
                      <div className="flex items-center space-x-2">
                        <StatusIcon className="w-4 h-4" />
                        <span className="text-sm">Stock: {scannedItem.currentStock} {scannedItem.unit}</span>
                        <Badge className={stockInfo.color}>
                          {stockInfo.status}
                        </Badge>
                      </div>
                    );
                  })()}
                </div>
              </div>

              <div className="flex space-x-2 pt-2">
                <Button
                  variant="outline"
                  onClick={() => setScannedItem(null)}
                >
                  Clear
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}