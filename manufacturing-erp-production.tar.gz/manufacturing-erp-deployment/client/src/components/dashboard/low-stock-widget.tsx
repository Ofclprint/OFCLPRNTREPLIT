import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Package } from "lucide-react";
import { Link } from "wouter";

type InventoryItem = {
  id: number;
  name: string;
  sku: string;
  currentStock: number;
  minStock: number;
  unit: string;
};

export default function LowStockWidget() {
  const { data: lowStockItems = [], isLoading } = useQuery({
    queryKey: ["/api/inventory/low-stock"],
  });

  if (isLoading) {
    return (
      <Card className="border-carbon-gray-20">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Low Stock Alerts</span>
            <div className="w-6 h-6 bg-carbon-gray-10 rounded-full animate-pulse"></div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-16 bg-carbon-gray-10 rounded-lg"></div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const getStockStatus = (item: InventoryItem) => {
    const ratio = item.currentStock / item.minStock;
    if (ratio <= 1) {
      return { status: "Critical", color: "text-red-600", bgColor: "bg-red-50" };
    } else if (ratio <= 1.5) {
      return { status: "Low", color: "text-yellow-600", bgColor: "bg-yellow-50" };
    }
    return { status: "Normal", color: "text-green-600", bgColor: "bg-green-50" };
  };

  return (
    <Card className="border-carbon-gray-20">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Low Stock Alerts</CardTitle>
          {lowStockItems.length > 0 && (
            <Badge className="bg-red-500 text-white text-xs px-2 py-1 rounded-full">
              {lowStockItems.length}
            </Badge>
          )}
        </div>
      </CardHeader>
      
      <CardContent>
        {lowStockItems.length === 0 ? (
          <div className="text-center py-6">
            <Package className="w-12 h-12 text-green-500 mx-auto mb-2" />
            <p className="text-carbon-gray-80 font-medium mb-1">All Stock Levels Good</p>
            <p className="text-carbon-gray-50 text-sm">No items are running low</p>
          </div>
        ) : (
          <div className="space-y-3">
            {lowStockItems.slice(0, 5).map((item: InventoryItem) => {
              const stockStatus = getStockStatus(item);
              
              return (
                <div 
                  key={item.id} 
                  className={`flex items-center justify-between p-3 rounded-lg cursor-pointer hover:shadow-sm transition-shadow ${stockStatus.bgColor}`}
                >
                  <div className="flex-1">
                    <div className="flex items-center space-x-2">
                      <AlertTriangle className={`w-4 h-4 ${stockStatus.color}`} />
                      <p className="font-medium text-carbon-gray-80">
                        {item.name}
                      </p>
                    </div>
                    <p className="text-sm text-carbon-gray-50 ml-6">
                      {item.currentStock} / {item.minStock} {item.unit}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className={`text-sm font-medium ${stockStatus.color}`}>
                      {stockStatus.status}
                    </p>
                    <Button 
                      variant="link" 
                      size="sm" 
                      className="text-carbon-blue text-xs p-0 h-auto hover:underline"
                    >
                      Reorder
                    </Button>
                  </div>
                </div>
              );
            })}
            
            {lowStockItems.length > 5 && (
              <div className="pt-2">
                <p className="text-xs text-carbon-gray-50 text-center">
                  +{lowStockItems.length - 5} more items
                </p>
              </div>
            )}
          </div>
        )}
        
        <Link href="/inventory">
          <Button className="w-full mt-4 bg-carbon-blue text-white hover:bg-carbon-blue/90 transition-colors text-sm font-medium">
            View All Inventory
          </Button>
        </Link>
      </CardContent>
    </Card>
  );
}
