import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle, Plus, AlertTriangle, FolderSync, Clock } from "lucide-react";
import { format } from "date-fns";

type ActivityLog = {
  id: number;
  userId: string;
  action: string;
  entityType?: string;
  entityId?: string;
  details?: Record<string, any>;
  createdAt: string;
};

const activityIcons = {
  created: Plus,
  updated: CheckCircle,
  completed: CheckCircle,
  alert: AlertTriangle,
  sync: FolderSync,
  default: Clock,
};

const activityColors = {
  created: "text-blue-500 bg-blue-100",
  updated: "text-green-500 bg-green-100",
  completed: "text-green-600 bg-green-100",
  alert: "text-yellow-500 bg-yellow-100",
  sync: "text-gray-500 bg-gray-100",
  default: "text-carbon-gray-50 bg-carbon-gray-10",
};

export default function ActivityFeedWidget() {
  const { data: activities = [], isLoading } = useQuery({
    queryKey: ["/api/dashboard/recent-activity"],
  });

  if (isLoading) {
    return (
      <Card className="border-carbon-gray-20">
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="flex items-start space-x-3">
                <div className="w-8 h-8 bg-carbon-gray-10 rounded-full"></div>
                <div className="flex-1 space-y-2">
                  <div className="h-4 bg-carbon-gray-10 rounded w-3/4"></div>
                  <div className="h-3 bg-carbon-gray-10 rounded w-1/2"></div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const getActivityIcon = (action: string) => {
    const actionLower = action.toLowerCase();
    if (actionLower.includes("created")) return "created";
    if (actionLower.includes("updated") || actionLower.includes("completed")) return "updated";
    if (actionLower.includes("alert") || actionLower.includes("low stock")) return "alert";
    if (actionLower.includes("sync")) return "sync";
    return "default";
  };

  return (
    <Card className="border-carbon-gray-20">
      <CardHeader>
        <CardTitle>Recent Activity</CardTitle>
      </CardHeader>
      
      <CardContent>
        {activities.length === 0 ? (
          <div className="text-center py-6">
            <Clock className="w-12 h-12 text-carbon-gray-50 mx-auto mb-2" />
            <p className="text-carbon-gray-50 text-sm">No recent activity</p>
          </div>
        ) : (
          <div className="space-y-4">
            {activities.slice(0, 6).map((activity: ActivityLog) => {
              const iconType = getActivityIcon(activity.action);
              const Icon = activityIcons[iconType] || activityIcons.default;
              const colorClass = activityColors[iconType] || activityColors.default;
              
              return (
                <div key={activity.id} className="flex items-start space-x-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${colorClass}`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-carbon-gray-80">
                      <span className="font-medium">{activity.userId}</span>{" "}
                      {activity.action.toLowerCase()}
                    </p>
                    <p className="text-xs text-carbon-gray-50 mt-1">
                      {format(new Date(activity.createdAt), "MMM dd, HH:mm")}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
