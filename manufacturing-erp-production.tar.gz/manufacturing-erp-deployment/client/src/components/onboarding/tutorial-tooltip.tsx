import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { X, ArrowRight, ArrowLeft, Lightbulb, Target } from "lucide-react";

interface TutorialTooltipProps {
  target: string;
  title: string;
  content: string;
  position?: "top" | "bottom" | "left" | "right";
  onNext?: () => void;
  onPrevious?: () => void;
  onSkip: () => void;
  showNext?: boolean;
  showPrevious?: boolean;
  step?: number;
  totalSteps?: number;
}

export default function TutorialTooltip({
  target,
  title,
  content,
  position = "bottom",
  onNext,
  onPrevious,
  onSkip,
  showNext = false,
  showPrevious = false,
  step,
  totalSteps
}: TutorialTooltipProps) {
  const [tooltipPosition, setTooltipPosition] = useState({ top: 0, left: 0 });
  const [isVisible, setIsVisible] = useState(false);
  const tooltipRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const targetElement = document.querySelector(target);
    if (!targetElement || !tooltipRef.current) return;

    const targetRect = targetElement.getBoundingClientRect();
    const tooltipRect = tooltipRef.current.getBoundingClientRect();
    const scrollY = window.scrollY;
    const scrollX = window.scrollX;

    let top = 0;
    let left = 0;

    switch (position) {
      case "top":
        top = targetRect.top + scrollY - tooltipRect.height - 10;
        left = targetRect.left + scrollX + (targetRect.width - tooltipRect.width) / 2;
        break;
      case "bottom":
        top = targetRect.bottom + scrollY + 10;
        left = targetRect.left + scrollX + (targetRect.width - tooltipRect.width) / 2;
        break;
      case "left":
        top = targetRect.top + scrollY + (targetRect.height - tooltipRect.height) / 2;
        left = targetRect.left + scrollX - tooltipRect.width - 10;
        break;
      case "right":
        top = targetRect.top + scrollY + (targetRect.height - tooltipRect.height) / 2;
        left = targetRect.right + scrollX + 10;
        break;
    }

    // Ensure tooltip stays within viewport
    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;

    if (left < 10) left = 10;
    if (left + tooltipRect.width > viewportWidth - 10) {
      left = viewportWidth - tooltipRect.width - 10;
    }
    if (top < 10) top = 10;
    if (top + tooltipRect.height > viewportHeight + scrollY - 10) {
      top = viewportHeight + scrollY - tooltipRect.height - 10;
    }

    setTooltipPosition({ top, left });
    setIsVisible(true);

    // Add highlight to target element
    targetElement.classList.add('tutorial-highlight');
    
    return () => {
      targetElement.classList.remove('tutorial-highlight');
    };
  }, [target, position]);

  useEffect(() => {
    // Add CSS for highlight effect
    const style = document.createElement('style');
    style.textContent = `
      .tutorial-highlight {
        position: relative;
        z-index: 1001 !important;
        box-shadow: 0 0 0 4px rgba(59, 130, 246, 0.5), 0 0 0 9999px rgba(0, 0, 0, 0.5) !important;
        border-radius: 8px;
        animation: tutorial-pulse 2s infinite;
      }
      
      @keyframes tutorial-pulse {
        0%, 100% { box-shadow: 0 0 0 4px rgba(59, 130, 246, 0.5), 0 0 0 9999px rgba(0, 0, 0, 0.5); }
        50% { box-shadow: 0 0 0 8px rgba(59, 130, 246, 0.3), 0 0 0 9999px rgba(0, 0, 0, 0.5); }
      }
    `;
    document.head.appendChild(style);

    return () => {
      document.head.removeChild(style);
    };
  }, []);

  if (!isVisible) return null;

  return (
    <div
      ref={tooltipRef}
      className="fixed z-[1002] max-w-sm"
      style={{
        top: tooltipPosition.top,
        left: tooltipPosition.left,
      }}
    >
      <Card className="border-blue-200 shadow-xl">
        <CardContent className="p-4 space-y-3">
          {/* Header */}
          <div className="flex items-start justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center">
                <Lightbulb className="w-3 h-3 text-blue-600" />
              </div>
              <h3 className="font-semibold text-sm">{title}</h3>
            </div>
            <Button variant="ghost" size="sm" onClick={onSkip} className="h-6 w-6 p-0">
              <X className="h-3 w-3" />
            </Button>
          </div>

          {/* Content */}
          <p className="text-sm text-gray-600 leading-relaxed">{content}</p>

          {/* Step indicator */}
          {step && totalSteps && (
            <div className="flex items-center justify-center space-x-1">
              {Array.from({ length: totalSteps }, (_, i) => (
                <div
                  key={i}
                  className={`w-2 h-2 rounded-full ${
                    i + 1 === step ? 'bg-blue-500' : 'bg-gray-300'
                  }`}
                />
              ))}
            </div>
          )}

          {/* Navigation */}
          <div className="flex justify-between items-center pt-2">
            <div>
              {showPrevious && (
                <Button variant="outline" size="sm" onClick={onPrevious}>
                  <ArrowLeft className="w-3 h-3 mr-1" />
                  Previous
                </Button>
              )}
            </div>
            
            <div className="flex space-x-2">
              <Button variant="ghost" size="sm" onClick={onSkip} className="text-xs">
                Skip
              </Button>
              {showNext && (
                <Button size="sm" onClick={onNext}>
                  Next
                  <ArrowRight className="w-3 h-3 ml-1" />
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Arrow pointing to target */}
      <div
        className={`absolute w-0 h-0 ${
          position === "bottom"
            ? "border-l-4 border-r-4 border-b-4 border-l-transparent border-r-transparent border-b-white -top-1 left-1/2 transform -translate-x-1/2"
            : position === "top"
            ? "border-l-4 border-r-4 border-t-4 border-l-transparent border-r-transparent border-t-white -bottom-1 left-1/2 transform -translate-x-1/2"
            : position === "right"
            ? "border-t-4 border-b-4 border-r-4 border-t-transparent border-b-transparent border-r-white -left-1 top-1/2 transform -translate-y-1/2"
            : "border-t-4 border-b-4 border-l-4 border-t-transparent border-b-transparent border-l-white -right-1 top-1/2 transform -translate-y-1/2"
        }`}
      />
    </div>
  );
}