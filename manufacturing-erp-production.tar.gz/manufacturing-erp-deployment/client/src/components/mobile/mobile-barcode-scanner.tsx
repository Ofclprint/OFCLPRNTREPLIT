import { useState, useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Camera, CameraResultType, CameraSource } from "@capacitor/camera";
import { Device } from "@capacitor/device";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";
import { Camera as CameraIcon, Package, AlertTriangle, CheckCircle, QrCode } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

type InventoryItem = {
  id: number;
  name: string;
  sku: string;
  currentStock: number;
  minStock: number;
  maxStock: number;
  unitPrice: string;
  unit: string;
  location?: string;
  barcode?: string;
};

export default function MobileBarcodeScanner() {
  const [isScanning, setIsScanning] = useState(false);
  const [scannedItem, setScannedItem] = useState<InventoryItem | null>(null);
  const [isNativeApp, setIsNativeApp] = useState(false);
  const [manualBarcode, setManualBarcode] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Check if running in native app
  useEffect(() => {
    Device.getInfo().then((info) => {
      setIsNativeApp(info.platform !== "web");
    });
  }, []);

  const scanBarcodeMutation = useMutation({
    mutationFn: async (barcode: string): Promise<InventoryItem> => {
      const response = await fetch(`/api/inventory/barcode/${barcode}`);
      if (!response.ok) {
        throw new Error('Item not found');
      }
      return response.json();
    },
    onSuccess: (data: InventoryItem) => {
      setScannedItem(data);
      setIsScanning(false);
      toast({
        title: "Item Found!",
        description: `Found ${data.name} (${data.sku})`,
      });
    },
    onError: (error: Error) => {
      setIsScanning(false);
      toast({
        title: "Item Not Found",
        description: "No item found with this barcode",
        variant: "destructive",
      });
    },
  });

  const handleNativeCameraScan = async () => {
    if (!isNativeApp) {
      toast({
        title: "Camera Not Available",
        description: "Native camera scanning only works in the mobile app",
        variant: "destructive",
      });
      return;
    }

    try {
      setIsScanning(true);
      
      const image = await Camera.getPhoto({
        quality: 90,
        allowEditing: false,
        resultType: CameraResultType.DataUrl,
        source: CameraSource.Camera,
      });

      // In a real implementation, you would use a barcode scanning library
      // like @capacitor-community/barcode-scanner or ML Kit
      // For now, we'll simulate scanning
      
      toast({
        title: "Barcode Scanning",
        description: "Processing image... (Would use ML Kit in production)",
      });

      // Simulate barcode detection delay
      setTimeout(() => {
        // Simulate finding a barcode (in production, extract from image)
        const simulatedBarcode = "1234567890123";
        scanBarcodeMutation.mutate(simulatedBarcode);
      }, 2000);

    } catch (error) {
      setIsScanning(false);
      toast({
        title: "Camera Error",
        description: "Failed to access camera",
        variant: "destructive",
      });
    }
  };

  const handleManualBarcode = () => {
    const barcode = prompt("Enter barcode manually:");
    if (barcode) {
      scanBarcodeMutation.mutate(barcode);
    }
  };

  const getStockStatus = (item: InventoryItem) => {
    if (item.currentStock <= item.minStock) {
      return { status: "low", color: "destructive", icon: AlertTriangle };
    } else if (item.currentStock >= item.maxStock) {
      return { status: "high", color: "secondary", icon: CheckCircle };
    } else {
      return { status: "normal", color: "default", icon: CheckCircle };
    }
  };

  return (
    <div className="space-y-6 p-4">
      <div className="text-center space-y-4">
        <h1 className="text-3xl font-bold">Mobile Barcode Scanner</h1>
        <p className="text-muted-foreground">
          Scan inventory items using your device camera
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CameraIcon className="h-5 w-5" />
            Scanner Controls
          </CardTitle>
          <CardDescription>
            {isNativeApp 
              ? "Use your device camera to scan barcodes" 
              : "Manual barcode entry available in web version"
            }
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {isNativeApp ? (
            <Button
              onClick={handleNativeCameraScan}
              disabled={isScanning || scanBarcodeMutation.isPending}
              className="w-full h-16 text-lg"
              size="lg"
            >
              <CameraIcon className="mr-2 h-6 w-6" />
              {isScanning ? "Scanning..." : "Scan Barcode"}
            </Button>
          ) : (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                Camera scanning available in mobile app
              </p>
              <div className="space-y-2">
                <Input
                  type="text"
                  placeholder="Enter barcode manually..."
                  value={manualBarcode}
                  onChange={(e) => setManualBarcode(e.target.value)}
                  className="w-full"
                />
                <Button
                  onClick={() => {
                    if (manualBarcode.trim()) {
                      scanBarcodeMutation.mutate(manualBarcode.trim());
                      setManualBarcode("");
                    }
                  }}
                  disabled={scanBarcodeMutation.isPending || !manualBarcode.trim()}
                  className="w-full h-12"
                  variant="outline"
                >
                  <QrCode className="mr-2 h-4 w-4" />
                  Search Barcode
                </Button>
              </div>
            </div>
          )}

          {scanBarcodeMutation.isPending && (
            <div className="text-center p-4">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
              <p className="mt-2 text-sm text-muted-foreground">Looking up item...</p>
            </div>
          )}
        </CardContent>
      </Card>

      {scannedItem && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Package className="h-5 w-5" />
              Scanned Item
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 gap-4">
              <div>
                <h3 className="font-semibold text-lg">{scannedItem.name}</h3>
                <p className="text-muted-foreground">SKU: {scannedItem.sku}</p>
              </div>

              <Separator />

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium">Current Stock</p>
                  <div className="flex items-center gap-2">
                    <span className="text-2xl font-bold">{scannedItem.currentStock}</span>
                    <Badge variant={
                      getStockStatus(scannedItem).color === "destructive" ? "destructive" :
                      getStockStatus(scannedItem).color === "secondary" ? "secondary" :
                      "default"
                    }>
                      {getStockStatus(scannedItem).status}
                    </Badge>
                  </div>
                </div>

                <div>
                  <p className="text-sm font-medium">Unit Price</p>
                  <p className="text-2xl font-bold">${scannedItem.unitPrice}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="font-medium">Min Stock</p>
                  <p>{scannedItem.minStock} {scannedItem.unit}</p>
                </div>
                <div>
                  <p className="font-medium">Max Stock</p>
                  <p>{scannedItem.maxStock} {scannedItem.unit}</p>
                </div>
              </div>

              {scannedItem.location && (
                <div>
                  <p className="text-sm font-medium">Location</p>
                  <p>{scannedItem.location}</p>
                </div>
              )}
            </div>

            <div className="flex gap-2 pt-4">
              <Button 
                onClick={() => setScannedItem(null)} 
                variant="outline"
                className="flex-1"
              >
                Clear
              </Button>
              <Button 
                onClick={isNativeApp ? handleNativeCameraScan : handleManualBarcode}
                className="flex-1"
              >
                Scan Another
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {!isNativeApp && (
        <Card className="border-blue-200 bg-blue-50/50">
          <CardContent className="pt-6">
            <div className="text-center space-y-2">
              <p className="font-medium text-blue-900">Enhanced Mobile Experience</p>
              <p className="text-sm text-blue-700">
                Install the mobile app for native camera barcode scanning and offline capabilities
              </p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}