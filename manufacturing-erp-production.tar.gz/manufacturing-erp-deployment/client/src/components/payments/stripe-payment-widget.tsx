import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { CreditCard, DollarSign, CheckCircle, AlertCircle, Clock } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

type SupplierInvoice = {
  id: number;
  supplierName: string;
  invoiceNumber: string;
  amount: number;
  dueDate: string;
  status: "pending" | "processing" | "paid" | "overdue";
  description: string;
  purchaseOrderId?: number;
};

export default function StripePaymentWidget() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedInvoice, setSelectedInvoice] = useState<SupplierInvoice | null>(null);
  const [paymentMethod, setPaymentMethod] = useState("card");

  const { data: pendingInvoices } = useQuery({
    queryKey: ['/api/payments/pending-invoices'],
    refetchInterval: 60000,
  });

  const processPaymentMutation = useMutation({
    mutationFn: async (data: { invoiceId: number; paymentMethodId: string; amount: number }) => {
      return await apiRequest('/api/payments/process', 'POST', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/payments'] });
      toast({
        title: "Payment Processed",
        description: "Payment has been successfully processed via Stripe",
      });
      setSelectedInvoice(null);
    },
    onError: () => {
      toast({
        title: "Payment Failed",
        description: "Payment processing failed. Please try again.",
        variant: "destructive",
      });
    },
  });

  const invoiceList: SupplierInvoice[] = pendingInvoices || [];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "paid": return "bg-green-100 text-green-800";
      case "processing": return "bg-blue-100 text-blue-800";
      case "overdue": return "bg-red-100 text-red-800";
      default: return "bg-yellow-100 text-yellow-800";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "paid": return <CheckCircle className="w-4 h-4 text-green-600" />;
      case "processing": return <Clock className="w-4 h-4 text-blue-600" />;
      case "overdue": return <AlertCircle className="w-4 h-4 text-red-600" />;
      default: return <Clock className="w-4 h-4 text-yellow-600" />;
    }
  };

  const handlePayment = () => {
    if (selectedInvoice) {
      processPaymentMutation.mutate({
        invoiceId: selectedInvoice.id,
        paymentMethodId: "pm_card_visa",
        amount: selectedInvoice.amount
      });
    }
  };

  const totalPending = invoiceList
    .filter(inv => inv.status === "pending" || inv.status === "overdue")
    .reduce((sum, inv) => sum + inv.amount, 0);

  const overdueCount = invoiceList.filter(inv => inv.status === "overdue").length;

  if (invoiceList.length === 0) {
    return (
      <Card className="border-carbon-gray-20">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <CreditCard className="w-5 h-5 text-carbon-blue" />
            <span>Supplier Payments</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <CreditCard className="w-12 h-12 text-carbon-gray-40 mx-auto mb-4" />
            <p className="text-carbon-gray-50">No pending payments</p>
            <p className="text-sm text-carbon-gray-40">All supplier invoices are up to date</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-carbon-gray-20">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <CreditCard className="w-5 h-5 text-carbon-blue" />
            <span>Supplier Payments</span>
          </div>
          {overdueCount > 0 && (
            <Badge className="bg-red-100 text-red-800">
              {overdueCount} overdue
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4 p-3 bg-carbon-gray-10 rounded-lg">
            <div>
              <p className="text-sm text-carbon-gray-50">Total Pending</p>
              <p className="text-lg font-semibold text-carbon-gray-80">${totalPending.toLocaleString()}</p>
            </div>
            <div>
              <p className="text-sm text-carbon-gray-50">Invoices</p>
              <p className="text-lg font-semibold text-carbon-gray-80">{invoiceList.length}</p>
            </div>
          </div>

          <div className="space-y-3 max-h-64 overflow-y-auto">
            {invoiceList.map((invoice) => (
              <div
                key={invoice.id}
                className={`border rounded-lg p-3 cursor-pointer transition-colors ${
                  selectedInvoice?.id === invoice.id 
                    ? 'border-carbon-blue bg-blue-50' 
                    : 'border-carbon-gray-20 hover:bg-carbon-gray-10'
                }`}
                onClick={() => setSelectedInvoice(invoice)}
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <h4 className="font-medium text-carbon-gray-80">{invoice.supplierName}</h4>
                    <p className="text-sm text-carbon-gray-50">{invoice.invoiceNumber}</p>
                    <p className="text-xs text-carbon-gray-50">{invoice.description}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-carbon-gray-80">${invoice.amount.toLocaleString()}</p>
                    <div className="flex items-center space-x-1 mt-1">
                      {getStatusIcon(invoice.status)}
                      <Badge className={getStatusColor(invoice.status)}>
                        {invoice.status}
                      </Badge>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center justify-between text-xs text-carbon-gray-50">
                  <span>Due: {new Date(invoice.dueDate).toLocaleDateString()}</span>
                  {invoice.purchaseOrderId && (
                    <span>PO: #{invoice.purchaseOrderId}</span>
                  )}
                </div>
              </div>
            ))}
          </div>

          {selectedInvoice && (
            <div className="border-t pt-4 space-y-4">
              <h4 className="font-medium text-carbon-gray-80">Process Payment</h4>
              
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm text-carbon-gray-50">Supplier</label>
                    <p className="font-medium text-carbon-gray-80">{selectedInvoice.supplierName}</p>
                  </div>
                  <div>
                    <label className="text-sm text-carbon-gray-50">Amount</label>
                    <p className="font-medium text-carbon-gray-80">${selectedInvoice.amount.toLocaleString()}</p>
                  </div>
                </div>

                <div>
                  <label className="text-sm text-carbon-gray-50">Payment Method</label>
                  <select
                    className="w-full mt-1 p-2 border border-carbon-gray-20 rounded-md"
                    value={paymentMethod}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                  >
                    <option value="card">Credit Card (Stripe)</option>
                    <option value="ach">ACH Transfer</option>
                    <option value="wire">Wire Transfer</option>
                  </select>
                </div>

                {paymentMethod === "card" && (
                  <div className="space-y-2">
                    <Input placeholder="Card Number" />
                    <div className="grid grid-cols-2 gap-2">
                      <Input placeholder="MM/YY" />
                      <Input placeholder="CVC" />
                    </div>
                  </div>
                )}

                <div className="flex space-x-2">
                  <Button
                    onClick={handlePayment}
                    disabled={processPaymentMutation.isPending}
                    className="flex-1 flex items-center space-x-2"
                  >
                    {processPaymentMutation.isPending ? (
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <DollarSign className="w-4 h-4" />
                    )}
                    <span>
                      {processPaymentMutation.isPending ? "Processing..." : "Pay with Stripe"}
                    </span>
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setSelectedInvoice(null)}
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            </div>
          )}

          <div className="text-center pt-2 border-t border-carbon-gray-20">
            <div className="flex items-center justify-center space-x-2 text-xs text-carbon-gray-50">
              <CreditCard className="w-3 h-3" />
              <span>Payments secured by Stripe</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}