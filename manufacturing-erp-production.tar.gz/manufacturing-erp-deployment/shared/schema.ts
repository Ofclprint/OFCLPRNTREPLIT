import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  integer,
  decimal,
  boolean,
  uuid,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Session storage table for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  role: varchar("role").default("employee"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Inventory items
export const inventoryItems = pgTable("inventory_items", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  sku: varchar("sku", { length: 100 }).unique().notNull(),
  currentStock: integer("current_stock").default(0),
  minStock: integer("min_stock").default(0),
  maxStock: integer("max_stock").default(1000),
  unitPrice: decimal("unit_price", { precision: 10, scale: 2 }),
  unit: varchar("unit", { length: 50 }).default("pieces"),
  location: varchar("location", { length: 255 }),
  barcode: varchar("barcode", { length: 255 }),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Production orders
export const productionOrders = pgTable("production_orders", {
  id: serial("id").primaryKey(),
  orderNumber: varchar("order_number", { length: 50 }).unique().notNull(),
  productName: varchar("product_name", { length: 255 }).notNull(),
  description: text("description"),
  quantity: integer("quantity").notNull(),
  status: varchar("status", { 
    enum: ["pending", "in_progress", "ready_for_qc", "completed", "cancelled", "urgent"] 
  }).default("pending"),
  priority: varchar("priority", { enum: ["low", "normal", "high", "urgent"] }).default("normal"),
  assignedTo: varchar("assigned_to").references(() => users.id),
  progress: integer("progress").default(0), // 0-100
  dueDate: timestamp("due_date"),
  startedAt: timestamp("started_at"),
  completedAt: timestamp("completed_at"),
  createdBy: varchar("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Quality control logs
export const qualityControlLogs = pgTable("quality_control_logs", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").references(() => productionOrders.id),
  itemId: integer("item_id").references(() => inventoryItems.id),
  inspectorId: varchar("inspector_id").references(() => users.id),
  status: varchar("status", { enum: ["pass", "fail", "pending"] }).notNull(),
  notes: text("notes"),
  defects: text("defects").array(),
  images: text("images").array(),
  testResults: jsonb("test_results"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Inventory movements/transactions
export const inventoryMovements = pgTable("inventory_movements", {
  id: serial("id").primaryKey(),
  itemId: integer("item_id").references(() => inventoryItems.id),
  type: varchar("type", { enum: ["in", "out", "adjustment", "transfer"] }).notNull(),
  quantity: integer("quantity").notNull(),
  previousStock: integer("previous_stock"),
  newStock: integer("new_stock"),
  reason: varchar("reason", { length: 255 }),
  orderId: integer("order_id").references(() => productionOrders.id),
  userId: varchar("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

// Activity logs
export const activityLogs = pgTable("activity_logs", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id),
  action: varchar("action", { length: 255 }).notNull(),
  entityType: varchar("entity_type", { length: 100 }),
  entityId: varchar("entity_id", { length: 100 }),
  details: jsonb("details"),
  createdAt: timestamp("created_at").defaultNow(),
});

// AI forecasts
export const aiForecasts = pgTable("ai_forecasts", {
  id: serial("id").primaryKey(),
  type: varchar("type", { enum: ["demand", "cost_optimization", "quality_prediction"] }).notNull(),
  itemId: integer("item_id").references(() => inventoryItems.id),
  prediction: jsonb("prediction").notNull(),
  confidence: decimal("confidence", { precision: 3, scale: 2 }),
  validUntil: timestamp("valid_until"),
  createdAt: timestamp("created_at").defaultNow(),
});

// User preferences
export const userPreferences = pgTable("user_preferences", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(),
  dashboardLayout: jsonb("dashboard_layout").notNull(),
  theme: varchar("theme", { length: 20 }).default("light"),
  language: varchar("language", { length: 10 }).default("en"),
  notifications: jsonb("notifications").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// API Integrations tables
export const integrations = pgTable("integrations", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  type: varchar("type", { length: 50 }).notNull(), // erp, crm, inventory, payment, shipping, email, sms, analytics
  description: text("description").notNull(),
  endpoint: varchar("endpoint", { length: 500 }).notNull(),
  apiKey: text("api_key").notNull(),
  status: varchar("status", { length: 20 }).notNull().default("disconnected"), // connected, disconnected, error, syncing
  isActive: boolean("is_active").notNull().default(true),
  syncInterval: integer("sync_interval").notNull().default(15), // minutes
  lastSync: timestamp("last_sync"),
  recordsSynced: integer("records_synced").notNull().default(0),
  healthStatus: varchar("health_status", { length: 20 }).notNull().default("unknown"), // healthy, warning, critical
  responseTime: integer("response_time").notNull().default(0), // milliseconds
  configuration: jsonb("configuration"),
  webhookUrl: varchar("webhook_url", { length: 500 }),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const webhooks = pgTable("webhooks", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  url: varchar("url", { length: 500 }).notNull(),
  events: text("events").array().notNull(),
  status: varchar("status", { length: 20 }).notNull().default("active"), // active, inactive, error
  isActive: boolean("is_active").notNull().default(true),
  secret: varchar("secret", { length: 255 }),
  headers: jsonb("headers"),
  lastTriggered: timestamp("last_triggered"),
  successRate: decimal("success_rate", { precision: 5, scale: 2 }).notNull().default("0"),
  triggerCount: integer("trigger_count").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const apiLogs = pgTable("api_logs", {
  id: serial("id").primaryKey(),
  integrationId: integer("integration_id").references(() => integrations.id),
  integrationName: varchar("integration_name", { length: 255 }).notNull(),
  method: varchar("method", { length: 10 }).notNull(), // GET, POST, PUT, DELETE
  endpoint: varchar("endpoint", { length: 500 }).notNull(),
  statusCode: integer("status_code").notNull(),
  responseTime: integer("response_time").notNull(),
  success: boolean("success").notNull(),
  errorMessage: text("error_message"),
  requestId: varchar("request_id", { length: 255 }).notNull(),
  requestBody: jsonb("request_body"),
  responseBody: jsonb("response_body"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Notifications tables
export const notificationRules = pgTable("notification_rules", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description").notNull(),
  eventType: varchar("event_type", { length: 100 }).notNull(), // inventory.low_stock, quality.failure, etc.
  severity: varchar("severity", { length: 20 }).notNull().default("warning"), // info, warning, error, critical
  priority: varchar("priority", { length: 20 }).notNull().default("medium"), // low, medium, high, urgent
  conditions: jsonb("conditions").notNull(),
  channels: text("channels").array().notNull(), // email, sms, push, slack, webhook
  recipients: text("recipients").array().notNull(),
  isActive: boolean("is_active").notNull().default(true),
  cooldownMinutes: integer("cooldown_minutes").notNull().default(0),
  lastTriggered: timestamp("last_triggered"),
  triggerCount: integer("trigger_count").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  ruleId: integer("rule_id").references(() => notificationRules.id),
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message").notNull(),
  severity: varchar("severity", { length: 20 }).notNull().default("warning"), // info, warning, error, critical
  priority: varchar("priority", { length: 20 }).notNull().default("medium"), // low, medium, high, urgent
  category: varchar("category", { length: 50 }).notNull(), // inventory, quality, maintenance, production, energy, integration
  source: varchar("source", { length: 100 }).notNull(),
  isRead: boolean("is_read").notNull().default(false),
  isArchived: boolean("is_archived").notNull().default(false),
  actions: jsonb("actions"), // array of action objects with label, url, type
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const notificationChannels = pgTable("notification_channels", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  type: varchar("type", { length: 20 }).notNull(), // email, sms, push, slack, webhook
  description: text("description").notNull(),
  isActive: boolean("is_active").notNull().default(true),
  configuration: jsonb("configuration").notNull(),
  lastUsed: timestamp("last_used"),
  successRate: decimal("success_rate", { precision: 5, scale: 2 }).notNull().default("0"),
  totalSent: integer("total_sent").notNull().default(0),
  totalSuccess: integer("total_success").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many, one }) => ({
  assignedOrders: many(productionOrders, { relationName: "assignedTo" }),
  createdOrders: many(productionOrders, { relationName: "createdBy" }),
  qualityControlLogs: many(qualityControlLogs),
  inventoryMovements: many(inventoryMovements),
  activityLogs: many(activityLogs),
  preferences: one(userPreferences, {
    fields: [users.id],
    references: [userPreferences.userId],
  }),
}));

export const userPreferencesRelations = relations(userPreferences, ({ one }) => ({
  user: one(users, {
    fields: [userPreferences.userId],
    references: [users.id],
  }),
}));

export const inventoryItemsRelations = relations(inventoryItems, ({ many }) => ({
  movements: many(inventoryMovements),
  qualityControlLogs: many(qualityControlLogs),
  forecasts: many(aiForecasts),
}));

export const productionOrdersRelations = relations(productionOrders, ({ one, many }) => ({
  assignedUser: one(users, {
    fields: [productionOrders.assignedTo],
    references: [users.id],
    relationName: "assignedTo",
  }),
  createdByUser: one(users, {
    fields: [productionOrders.createdBy],
    references: [users.id],
    relationName: "createdBy",
  }),
  qualityControlLogs: many(qualityControlLogs),
  inventoryMovements: many(inventoryMovements),
}));

export const qualityControlLogsRelations = relations(qualityControlLogs, ({ one }) => ({
  order: one(productionOrders, {
    fields: [qualityControlLogs.orderId],
    references: [productionOrders.id],
  }),
  item: one(inventoryItems, {
    fields: [qualityControlLogs.itemId],
    references: [inventoryItems.id],
  }),
  inspector: one(users, {
    fields: [qualityControlLogs.inspectorId],
    references: [users.id],
  }),
}));

export const inventoryMovementsRelations = relations(inventoryMovements, ({ one }) => ({
  item: one(inventoryItems, {
    fields: [inventoryMovements.itemId],
    references: [inventoryItems.id],
  }),
  order: one(productionOrders, {
    fields: [inventoryMovements.orderId],
    references: [productionOrders.id],
  }),
  user: one(users, {
    fields: [inventoryMovements.userId],
    references: [users.id],
  }),
}));

export const activityLogsRelations = relations(activityLogs, ({ one }) => ({
  user: one(users, {
    fields: [activityLogs.userId],
    references: [users.id],
  }),
}));

export const aiForecastsRelations = relations(aiForecasts, ({ one }) => ({
  item: one(inventoryItems, {
    fields: [aiForecasts.itemId],
    references: [inventoryItems.id],
  }),
}));

// API Integration Relations
export const integrationsRelations = relations(integrations, ({ many }) => ({
  apiLogs: many(apiLogs),
}));

export const apiLogsRelations = relations(apiLogs, ({ one }) => ({
  integration: one(integrations, {
    fields: [apiLogs.integrationId],
    references: [integrations.id],
  }),
}));

// Notification Relations
export const notificationRulesRelations = relations(notificationRules, ({ many }) => ({
  notifications: many(notifications),
}));

export const notificationsRelations = relations(notifications, ({ one }) => ({
  rule: one(notificationRules, {
    fields: [notifications.ruleId],
    references: [notificationRules.id],
  }),
}));

// Schemas
export const insertUserSchema = createInsertSchema(users).omit({ createdAt: true, updatedAt: true });
export const insertInventoryItemSchema = createInsertSchema(inventoryItems).omit({ id: true, createdAt: true, updatedAt: true });
export const insertProductionOrderSchema = createInsertSchema(productionOrders).omit({ id: true, createdAt: true, updatedAt: true });
export const insertQualityControlLogSchema = createInsertSchema(qualityControlLogs).omit({ id: true, createdAt: true });
export const insertInventoryMovementSchema = createInsertSchema(inventoryMovements).omit({ id: true, createdAt: true });
export const insertActivityLogSchema = createInsertSchema(activityLogs).omit({ id: true, createdAt: true });
export const insertAiForecastSchema = createInsertSchema(aiForecasts).omit({ id: true, createdAt: true });
export const insertUserPreferencesSchema = createInsertSchema(userPreferences).omit({ id: true, createdAt: true, updatedAt: true });

// API Integration Schemas
export const insertIntegrationSchema = createInsertSchema(integrations).omit({ id: true, createdAt: true, updatedAt: true });
export const insertWebhookSchema = createInsertSchema(webhooks).omit({ id: true, createdAt: true, updatedAt: true });
export const insertApiLogSchema = createInsertSchema(apiLogs).omit({ id: true, createdAt: true });

// Notification Schemas
export const insertNotificationRuleSchema = createInsertSchema(notificationRules).omit({ id: true, createdAt: true, updatedAt: true });
export const insertNotificationSchema = createInsertSchema(notifications).omit({ id: true, createdAt: true, updatedAt: true });
export const insertNotificationChannelSchema = createInsertSchema(notificationChannels).omit({ id: true, createdAt: true, updatedAt: true });

// Types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type InsertInventoryItem = z.infer<typeof insertInventoryItemSchema>;
export type InventoryItem = typeof inventoryItems.$inferSelect;
export type InsertProductionOrder = z.infer<typeof insertProductionOrderSchema>;
export type ProductionOrder = typeof productionOrders.$inferSelect;
export type InsertQualityControlLog = z.infer<typeof insertQualityControlLogSchema>;
export type QualityControlLog = typeof qualityControlLogs.$inferSelect;
export type InsertInventoryMovement = z.infer<typeof insertInventoryMovementSchema>;
export type InventoryMovement = typeof inventoryMovements.$inferSelect;
export type InsertActivityLog = z.infer<typeof insertActivityLogSchema>;
export type ActivityLog = typeof activityLogs.$inferSelect;
export type InsertAiForecast = z.infer<typeof insertAiForecastSchema>;
export type AiForecast = typeof aiForecasts.$inferSelect;
export type InsertUserPreferences = z.infer<typeof insertUserPreferencesSchema>;
export type UserPreferences = typeof userPreferences.$inferSelect;

// API Integration Types
export type InsertIntegration = z.infer<typeof insertIntegrationSchema>;
export type Integration = typeof integrations.$inferSelect;
export type InsertWebhook = z.infer<typeof insertWebhookSchema>;
export type Webhook = typeof webhooks.$inferSelect;
export type InsertApiLog = z.infer<typeof insertApiLogSchema>;
export type ApiLog = typeof apiLogs.$inferSelect;

// Notification Types
export type InsertNotificationRule = z.infer<typeof insertNotificationRuleSchema>;
export type NotificationRule = typeof notificationRules.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type Notification = typeof notifications.$inferSelect;
export type InsertNotificationChannel = z.infer<typeof insertNotificationChannelSchema>;
export type NotificationChannel = typeof notificationChannels.$inferSelect;
