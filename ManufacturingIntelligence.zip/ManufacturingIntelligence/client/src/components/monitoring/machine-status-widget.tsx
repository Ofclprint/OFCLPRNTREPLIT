import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Settings, AlertTriangle, CheckCircle, Clock, Zap, Thermometer, Gauge } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

type Machine = {
  id: number;
  name: string;
  type: string;
  status: "running" | "idle" | "maintenance" | "error" | "offline";
  efficiency: number;
  temperature: number;
  pressure: number;
  vibration: number;
  lastMaintenance: string;
  nextMaintenance: string;
  currentJob?: string;
  operatorId?: string;
};

export default function MachineStatusWidget() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: machines, isLoading } = useQuery({
    queryKey: ['/api/machines/status'],
    refetchInterval: 5000,
  });

  const updateMachineStatusMutation = useMutation({
    mutationFn: async (data: { machineId: number; status: string; reason?: string }) => {
      return await apiRequest('/api/machines/update-status', 'POST', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/machines'] });
      toast({
        title: "Machine Status Updated",
        description: "Machine status has been updated successfully",
      });
    },
  });

  const machineList: Machine[] = machines || [];

  const getStatusConfig = (status: string) => {
    switch (status) {
      case "running":
        return { 
          icon: CheckCircle, 
          color: "bg-green-100 text-green-800", 
          bgColor: "bg-green-50 border-green-200" 
        };
      case "idle":
        return { 
          icon: Clock, 
          color: "bg-yellow-100 text-yellow-800", 
          bgColor: "bg-yellow-50 border-yellow-200" 
        };
      case "maintenance":
        return { 
          icon: Settings, 
          color: "bg-blue-100 text-blue-800", 
          bgColor: "bg-blue-50 border-blue-200" 
        };
      case "error":
        return { 
          icon: AlertTriangle, 
          color: "bg-red-100 text-red-800", 
          bgColor: "bg-red-50 border-red-200" 
        };
      default:
        return { 
          icon: Clock, 
          color: "bg-gray-100 text-gray-800", 
          bgColor: "bg-gray-50 border-gray-200" 
        };
    }
  };

  const runningCount = machineList.filter(m => m.status === "running").length;
  const errorCount = machineList.filter(m => m.status === "error").length;
  const maintenanceCount = machineList.filter(m => m.status === "maintenance").length;
  const avgEfficiency = machineList
    .filter(m => m.status === "running")
    .reduce((sum, m) => sum + m.efficiency, 0) / (runningCount || 1);

  if (machineList.length === 0) {
    return (
      <Card className="border-carbon-gray-20">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Gauge className="w-5 h-5 text-carbon-blue" />
            <span>Machine Monitoring</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <Gauge className="w-12 h-12 text-carbon-gray-40 mx-auto mb-4" />
            <p className="text-carbon-gray-50">No machines connected</p>
            <p className="text-sm text-carbon-gray-40">Connect machines to monitor their status</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-carbon-gray-20">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Gauge className="w-5 h-5 text-carbon-blue" />
            <span>Machine Monitoring</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            <span className="text-xs text-carbon-gray-50">Live</span>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="grid grid-cols-4 gap-3">
            <div className="text-center">
              <p className="text-lg font-semibold text-green-600">{runningCount}</p>
              <p className="text-xs text-carbon-gray-50">Running</p>
            </div>
            <div className="text-center">
              <p className="text-lg font-semibold text-red-600">{errorCount}</p>
              <p className="text-xs text-carbon-gray-50">Errors</p>
            </div>
            <div className="text-center">
              <p className="text-lg font-semibold text-blue-600">{maintenanceCount}</p>
              <p className="text-xs text-carbon-gray-50">Maintenance</p>
            </div>
            <div className="text-center">
              <p className="text-lg font-semibold text-carbon-gray-80">{avgEfficiency.toFixed(1)}%</p>
              <p className="text-xs text-carbon-gray-50">Avg Efficiency</p>
            </div>
          </div>

          <div className="space-y-3 max-h-80 overflow-y-auto">
            {machineList.map((machine) => {
              const statusConfig = getStatusConfig(machine.status);
              const StatusIcon = statusConfig.icon;
              
              return (
                <div
                  key={machine.id}
                  className={`border rounded-lg p-4 ${statusConfig.bgColor}`}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-1">
                        <h4 className="font-medium text-carbon-gray-80">{machine.name}</h4>
                        <Badge className={statusConfig.color}>
                          <StatusIcon className="w-3 h-3 mr-1" />
                          {machine.status}
                        </Badge>
                      </div>
                      <p className="text-sm text-carbon-gray-50">{machine.type}</p>
                      {machine.currentJob && (
                        <p className="text-xs text-carbon-gray-50">Job: {machine.currentJob}</p>
                      )}
                    </div>
                    
                    {machine.status === "running" && (
                      <div className="text-right">
                        <p className="text-lg font-semibold text-green-600">
                          {machine.efficiency}%
                        </p>
                        <p className="text-xs text-carbon-gray-50">Efficiency</p>
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-3 gap-3 text-sm">
                    <div className="flex items-center space-x-1">
                      <Thermometer className="w-4 h-4 text-orange-500" />
                      <span className="text-carbon-gray-70">{machine.temperature}°C</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Gauge className="w-4 h-4 text-blue-500" />
                      <span className="text-carbon-gray-70">{machine.pressure} PSI</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Zap className="w-4 h-4 text-purple-500" />
                      <span className="text-carbon-gray-70">{machine.vibration} Hz</span>
                    </div>
                  </div>

                  <div className="mt-3 pt-3 border-t border-carbon-gray-20">
                    <div className="flex items-center justify-between text-xs text-carbon-gray-50">
                      <span>Last: {new Date(machine.lastMaintenance).toLocaleDateString()}</span>
                      <span>Next: {new Date(machine.nextMaintenance).toLocaleDateString()}</span>
                    </div>
                  </div>

                  {machine.status === "error" && (
                    <div className="mt-3 flex space-x-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => updateMachineStatusMutation.mutate({
                          machineId: machine.id,
                          status: "maintenance",
                          reason: "Error resolution"
                        })}
                        className="text-xs"
                      >
                        Start Maintenance
                      </Button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}