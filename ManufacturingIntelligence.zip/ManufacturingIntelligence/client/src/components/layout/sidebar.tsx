import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { 
  BarChart3, 
  Package, 
  ClipboardList, 
  CheckCircle, 
  QrCode, 
  MessageSquare, 
  Settings,
  Palette,
  LogOut,
  Factory,
  TrendingUp,
  Activity,
  Truck,
  Users,
  Zap,
  Plug,
  Bell,
  Camera,
  Wrench,
  Calculator,
  Target,
  Calendar,
  Building
} from "lucide-react";

export default function Sidebar() {
  const [location] = useLocation();
  const { user } = useAuth();

  const { data: lowStockCount = 0 } = useQuery({
    queryKey: ["/api/inventory/low-stock"],
    select: (data: any[]) => data.length,
  });

  const getUserInitials = () => {
    if (user?.firstName && user?.lastName) {
      return `${user.firstName[0]}${user.lastName[0]}`.toUpperCase();
    }
    if (user?.email) {
      return user.email[0].toUpperCase();
    }
    return "U";
  };

  const getUserDisplayName = () => {
    if (user?.firstName && user?.lastName) {
      return `${user.firstName} ${user.lastName}`;
    }
    if (user?.email) {
      return user.email.split('@')[0];
    }
    return "User";
  };

  const getRoleDisplayName = () => {
    switch (user?.role) {
      case "admin":
        return "Administrator";
      case "manager":
        return "Production Manager";
      case "employee":
        return "Employee";
      default:
        return "User";
    }
  };

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  const navItems = [
    {
      category: "Main",
      items: [
        {
          label: "Dashboard",
          href: "/",
          icon: BarChart3,
          active: location === "/",
        },
        {
          label: "Performance Snapshot",
          href: "/performance-snapshot",
          icon: Camera,
          active: location === "/performance-snapshot",
          badge: "NEW",
          badgeColor: "bg-blue-500 text-white",
        },
        {
          label: "Inventory",
          href: "/inventory",
          icon: Package,
          active: location === "/inventory",
          badge: lowStockCount > 0 ? lowStockCount : undefined,
          badgeColor: "bg-red-500 text-white",
        },
        {
          label: "Production Orders",
          href: "/production-orders",
          icon: ClipboardList,
          active: location === "/production-orders",
        },
        {
          label: "Quality Control",
          href: "/quality-control",
          icon: CheckCircle,
          active: location === "/quality-control",
        },
        {
          label: "Barcode Scanner",
          href: "/barcode-scanner",
          icon: QrCode,
          active: location === "/barcode-scanner",
        },
      ],
    },
    {
      category: "Advanced Systems",
      items: [
        {
          label: "Advanced Analytics",
          href: "/advanced-analytics",
          icon: TrendingUp,
          active: location === "/advanced-analytics",
        },
        {
          label: "Machine Monitoring",
          href: "/machine-monitoring",
          icon: Activity,
          active: location === "/machine-monitoring",
        },
        {
          label: "Supply Chain",
          href: "/supply-chain",
          icon: Truck,
          active: location === "/supply-chain",
        },
        {
          label: "Workforce",
          href: "/workforce-management",
          icon: Users,
          active: location === "/workforce-management",
        },
        {
          label: "Energy Management",
          href: "/energy-management",
          icon: Zap,
          active: location === "/energy-management",
        },
        {
          label: "API Integrations",
          href: "/api-integrations",
          icon: Plug,
          active: location === "/api-integrations",
        },
      ],
    },
    {
      category: "Enterprise Operations",
      items: [
        {
          label: "Preventive Maintenance",
          href: "/preventive-maintenance",
          icon: Wrench,
          active: location === "/preventive-maintenance",
        },
        {
          label: "Cost Accounting",
          href: "/cost-accounting",
          icon: Calculator,
          active: location === "/cost-accounting",
        },
        {
          label: "Inventory Optimization",
          href: "/inventory-optimization",
          icon: Target,
          active: location === "/inventory-optimization",
        },
        {
          label: "Smart Scheduling",
          href: "/smart-scheduling",
          icon: Calendar,
          active: location === "/smart-scheduling",
        },
        {
          label: "Manufacturing CRM",
          href: "/manufacturing-crm",
          icon: Building,
          active: location === "/manufacturing-crm",
        },
      ],
    },
    {
      category: "Notifications",
      items: [
        {
          label: "Alerts & Notifications",
          href: "/notifications",
          icon: Bell,
          active: location === "/notifications",
          badge: 3,
          badgeColor: "bg-red-500 text-white",
        },
      ],
    },
    {
      category: "Collaboration",
      items: [
        {
          label: "Team Chat",
          href: "/chat",
          icon: MessageSquare,
          active: location === "/chat",
          badge: 2,
          badgeColor: "bg-green-500 text-white",
          disabled: true, // Coming soon
        },
      ],
    },
    {
      category: "System",
      items: [
        {
          label: "Preferences",
          href: "/preferences",
          icon: Palette,
          active: location === "/preferences",
        },
        {
          label: "Settings",
          href: "/settings",
          icon: Settings,
          active: location === "/settings",
        },
      ],
    },
  ];

  return (
    <div className="w-64 bg-carbon-gray-80 text-white flex-shrink-0 hidden lg:flex flex-col">
      {/* Header */}
      <div className="p-6">
        <div className="flex items-center space-x-3">
          <Factory className="w-8 h-8 text-carbon-blue" />
          <div>
            <h1 className="text-xl font-semibold text-white">ManufacturePro</h1>
            <p className="text-carbon-gray-20 text-sm">ERP System</p>
          </div>
        </div>
      </div>
      
      {/* Navigation */}
      <nav className="flex-1 mt-8">
        {navItems.map((section) => (
          <div key={section.category}>
            <div className="px-6 mb-4">
              <p className="text-carbon-gray-20 text-xs uppercase tracking-wider font-medium">
                {section.category}
              </p>
            </div>
            
            {section.items.map((item) => (
              <div key={item.href}>
                {item.disabled ? (
                  <div className="flex items-center px-6 py-3 text-carbon-gray-50 opacity-50 cursor-not-allowed">
                    <item.icon className="w-5 h-5 mr-3" />
                    <span className="flex-1">{item.label}</span>
                    {item.badge && (
                      <Badge className={`text-xs px-2 py-1 rounded-full ${item.badgeColor}`}>
                        {item.badge}
                      </Badge>
                    )}
                  </div>
                ) : (
                  <Link href={item.href} className={`flex items-center px-6 py-3 transition-colors ${
                        item.active
                          ? "text-white bg-carbon-blue border-r-2 border-carbon-blue"
                          : "text-carbon-gray-20 hover:text-white hover:bg-carbon-gray-70"
                      }`}>
                    <item.icon className="w-5 h-5 mr-3" />
                    <span className="flex-1">{item.label}</span>
                    {item.badge && (
                      <Badge className={`text-xs px-2 py-1 rounded-full ${item.badgeColor}`}>
                        {item.badge}
                      </Badge>
                    )}
                  </Link>
                )}
              </div>
            ))}
          </div>
        ))}
      </nav>
      
      {/* User Profile */}
      <div className="p-6 bg-carbon-gray-70 border-t border-carbon-gray-50">
        <div className="flex items-center space-x-3">
          <Avatar className="w-10 h-10">
            <AvatarImage src={user?.profileImageUrl} alt="Profile" />
            <AvatarFallback className="bg-carbon-blue text-white font-semibold">
              {getUserInitials()}
            </AvatarFallback>
          </Avatar>
          
          <div className="flex-1 min-w-0">
            <p className="text-white text-sm font-medium truncate">
              {getUserDisplayName()}
            </p>
            <p className="text-carbon-gray-20 text-xs truncate">
              {getRoleDisplayName()}
            </p>
          </div>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={handleLogout}
            className="p-1 h-8 w-8 text-carbon-gray-20 hover:text-white hover:bg-carbon-gray-50"
          >
            <LogOut className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
