import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { 
  BarChart3, 
  Package, 
  ClipboardList, 
  CheckCircle, 
  QrCode, 
  Settings,
  LogOut,
  Camera
} from "lucide-react";

export default function MVPSidebar() {
  const [location] = useLocation();
  const { user } = useAuth();

  // Get low stock count for badge
  const { data: lowStockItems = [] } = useQuery({
    queryKey: ["/api/inventory/low-stock"],
    enabled: !!user,
  });
  const lowStockCount = Array.isArray(lowStockItems) ? lowStockItems.length : 0;

  const getUserRole = () => {
    const role = (user as any)?.role;
    switch (role) {
      case "admin":
        return "Administrator";
      case "manager":
        return "Manager";
      case "employee":
        return "Employee";
      default:
        return "User";
    }
  };

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  const navItems = [
    {
      category: "Core Operations",
      items: [
        {
          label: "Customizable Dashboard",
          href: "/",
          icon: BarChart3,
          active: location === "/",
          badge: "CUSTOM",
          badgeColor: "bg-green-500 text-white",
        },
        {
          label: "Performance Snapshot",
          href: "/performance-snapshot",
          icon: Camera,
          active: location === "/performance-snapshot",
          badge: "NEW",
          badgeColor: "bg-blue-500 text-white",
        },
        {
          label: "Inventory",
          href: "/inventory",
          icon: Package,
          active: location === "/inventory",
          badge: lowStockCount > 0 ? lowStockCount : undefined,
          badgeColor: "bg-red-500 text-white",
        },
        {
          label: "Production Orders",
          href: "/production-orders",
          icon: ClipboardList,
          active: location === "/production-orders",
        },
        {
          label: "Quality Control",
          href: "/quality-control",
          icon: CheckCircle,
          active: location === "/quality-control",
        },
        {
          label: "Barcode Scanner",
          href: "/barcode-scanner",
          icon: QrCode,
          active: location === "/barcode-scanner",
        },
      ],
    },

    {
      category: "System",
      items: [
        {
          label: "Settings",
          href: "/settings",
          icon: Settings,
          active: location === "/settings",
        },
      ],
    },
  ];

  return (
    <div className="flex h-screen w-64 flex-col bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-700">
      {/* Header */}
      <div className="flex h-16 items-center justify-between px-6 border-b border-gray-200 dark:border-gray-700">
        <h1 className="text-xl font-bold text-gray-900 dark:text-white">Manufacturing ERP</h1>
      </div>

      {/* User Profile with Profile Switching */}
      <div className="p-4 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center gap-3 mb-3">
          <Avatar className="h-10 w-10">
            <AvatarImage src={(user as any)?.profileImageUrl || ""} />
            <AvatarFallback className="bg-blue-500 text-white">
              {(user as any)?.firstName?.[0] || (user as any)?.lastName?.[0] || (user as any)?.email?.[0]?.toUpperCase() || "U"}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-gray-900 dark:text-white truncate">
              {(user as any)?.firstName && (user as any)?.lastName 
                ? `${(user as any).firstName} ${(user as any).lastName}`
                : (user as any)?.email || "Unknown User"
              }
            </p>
            <p className="text-xs text-gray-500 dark:text-gray-400 truncate">
              {getUserRole()}
            </p>
          </div>
        </div>
        <Button
          onClick={() => window.location.href = "/settings"}
          variant="outline"
          size="sm"
          className="w-full text-xs"
        >
          Switch Profile
        </Button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto p-4">
        <div className="space-y-6">
          {navItems.map((section) => (
            <div key={section.category}>
              <h3 className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-3">
                {section.category}
              </h3>
              <div className="space-y-1">
                {section.items.map((item) => (
                  <Link key={item.href} href={item.href}>
                    <span className={`flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors cursor-pointer ${
                      item.active
                        ? "bg-blue-50 dark:bg-blue-900/50 text-blue-700 dark:text-blue-300"
                        : "text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800"
                    }`}>
                      <item.icon className="h-5 w-5" />
                      <span className="flex-1">{item.label}</span>
                      {item.badge && (
                        <Badge className={`text-xs ${item.badgeColor}`}>
                          {item.badge}
                        </Badge>
                      )}
                    </span>
                  </Link>
                ))}
              </div>
            </div>
          ))}
        </div>
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-gray-200 dark:border-gray-700">
        <Button
          onClick={handleLogout}
          variant="ghost"
          className="w-full justify-start gap-3 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800"
        >
          <LogOut className="h-5 w-5" />
          Logout
        </Button>
      </div>
    </div>
  );
}