import { Link, useLocation } from "wouter";
import { 
  BarChart3, 
  Package, 
  QrCode, 
  ClipboardList, 
  MoreHorizontal 
} from "lucide-react";

export default function MobileNav() {
  const [location] = useLocation();

  const navItems = [
    {
      label: "Dashboard",
      href: "/",
      icon: BarChart3,
      active: location === "/",
    },
    {
      label: "Inventory", 
      href: "/inventory",
      icon: Package,
      active: location === "/inventory",
    },
    {
      label: "Scan",
      href: "/barcode-scanner", 
      icon: QrCode,
      active: location === "/barcode-scanner",
    },
    {
      label: "Orders",
      href: "/orders",
      icon: ClipboardList, 
      active: location === "/orders",
    },
    {
      label: "More",
      href: "/settings",
      icon: MoreHorizontal,
      active: ["/settings", "/quality-control"].includes(location),
    },
  ];

  return (
    <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-carbon-gray-20 z-40">
      <div className="grid grid-cols-5 h-16">
        {navItems.map((item) => (
          <Link key={item.href} href={item.href}>
            <a className={`flex flex-col items-center justify-center h-full ${
              item.active 
                ? "text-carbon-blue" 
                : "text-carbon-gray-50"
            }`}>
              <item.icon className="w-5 h-5 mb-1" />
              <span className="text-xs">{item.label}</span>
            </a>
          </Link>
        ))}
      </div>
    </div>
  );
}
