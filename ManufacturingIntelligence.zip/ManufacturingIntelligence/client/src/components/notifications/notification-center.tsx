import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bell, AlertTriangle, CheckCircle, Info, X, Clock } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { formatDistanceToNow } from "date-fns";

type Notification = {
  id: number;
  title: string;
  message: string;
  type: "info" | "warning" | "error" | "success";
  priority: "low" | "medium" | "high";
  read: boolean;
  createdAt: string;
  actionUrl?: string;
  actionLabel?: string;
};

export default function NotificationCenter() {
  const [isOpen, setIsOpen] = useState(false);
  const queryClient = useQueryClient();

  const { data: notifications } = useQuery({
    queryKey: ['/api/notifications'],
    refetchInterval: 10000,
  });

  const markAsReadMutation = useMutation({
    mutationFn: async (notificationIds: number[]) => {
      return await apiRequest('/api/notifications/mark-read', 'POST', { ids: notificationIds });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/notifications'] });
    },
  });

  const notificationList: Notification[] = notifications || [];
  const unreadCount = notificationList.filter(n => !n.read).length;
  const highPriorityCount = notificationList.filter(n => !n.read && n.priority === "high").length;

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "warning": return <AlertTriangle className="w-4 h-4 text-yellow-600" />;
      case "error": return <AlertTriangle className="w-4 h-4 text-red-600" />;
      case "success": return <CheckCircle className="w-4 h-4 text-green-600" />;
      default: return <Info className="w-4 h-4 text-blue-600" />;
    }
  };

  return (
    <div className="relative">
      <Button variant="ghost" size="sm" onClick={() => setIsOpen(!isOpen)} className="relative">
        <Bell className="w-5 h-5" />
        {unreadCount > 0 && (
          <Badge className={`absolute -top-1 -right-1 min-w-[20px] h-5 text-xs ${
            highPriorityCount > 0 ? 'bg-red-500' : 'bg-carbon-blue'
          }`}>
            {unreadCount > 99 ? '99+' : unreadCount}
          </Badge>
        )}
      </Button>

      {isOpen && (
        <div className="absolute right-0 top-full mt-2 w-96 z-50">
          <Card className="border-carbon-gray-20 shadow-lg">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Notifications</CardTitle>
                <Button variant="ghost" size="sm" onClick={() => setIsOpen(false)}>
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-center py-6">
                <Bell className="w-12 h-12 text-carbon-gray-40 mx-auto mb-4" />
                <p className="text-carbon-gray-50">No notifications</p>
                <p className="text-sm text-carbon-gray-40">You're all caught up!</p>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}