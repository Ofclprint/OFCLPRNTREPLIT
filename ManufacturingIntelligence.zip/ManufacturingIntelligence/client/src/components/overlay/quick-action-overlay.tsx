import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Search, 
  Package, 
  Plus, 
  Minus, 
  BarChart3, 
  ClipboardList, 
  Settings, 
  X, 
  ExternalLink,
  AlertCircle,
  CheckCircle,
  Loader2
} from "lucide-react";

interface InventoryItem {
  id: number;
  name: string;
  sku: string;
  currentStock: number;
  minStock: number;
  maxStock: number;
  unitPrice: string;
  unit: string;
  location?: string;
  barcode?: string;
  description?: string;
}

interface QuickActionOverlayProps {
  isOpen: boolean;
  onClose: () => void;
}

export function QuickActionOverlay({ isOpen, onClose }: QuickActionOverlayProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedItem, setSelectedItem] = useState<InventoryItem | null>(null);
  const [actionType, setActionType] = useState<"stock_in" | "stock_out" | "view" | null>(null);
  const [quantity, setQuantity] = useState("");
  const [reason, setReason] = useState("");
  const searchInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Search inventory items
  const { data: searchResults, isLoading: isSearching } = useQuery({
    queryKey: ["/api/inventory", searchQuery],
    enabled: searchQuery.length > 2,
    staleTime: 30000,
    select: (data: InventoryItem[]) => {
      if (!searchQuery) return data;
      return data.filter(item => 
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.sku.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (item.barcode && item.barcode.includes(searchQuery))
      );
    }
  });

  // Stock movement mutation
  const stockMovementMutation = useMutation({
    mutationFn: async (data: {
      itemId: number;
      type: "in" | "out" | "adjustment";
      quantity: number;
      reason: string;
    }) => {
      return apiRequest("/api/inventory/movements", "POST", data);
    },
    onSuccess: () => {
      toast({
        title: "Stock Updated",
        description: "Inventory movement recorded successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/inventory"] });
      resetForm();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update stock",
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setSelectedItem(null);
    setActionType(null);
    setQuantity("");
    setReason("");
    setSearchQuery("");
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  const handleItemSelect = (item: InventoryItem) => {
    setSelectedItem(item);
    setActionType("view");
  };

  const handleStockMovement = () => {
    if (!selectedItem || !actionType || !quantity || !reason) return;

    const numQuantity = parseInt(quantity);
    if (isNaN(numQuantity) || numQuantity <= 0) {
      toast({
        title: "Invalid Quantity",
        description: "Please enter a valid positive number",
        variant: "destructive",
      });
      return;
    }

    stockMovementMutation.mutate({
      itemId: selectedItem.id,
      type: actionType === "stock_in" ? "in" : "out",
      quantity: numQuantity,
      reason,
    });
  };

  const getStockStatus = (item: InventoryItem) => {
    if (item.currentStock <= item.minStock) {
      return { status: "Low Stock", color: "bg-red-100 text-red-800" };
    } else if (item.currentStock >= item.maxStock) {
      return { status: "High Stock", color: "bg-yellow-100 text-yellow-800" };
    }
    return { status: "Normal", color: "bg-green-100 text-green-800" };
  };

  // Focus search input when overlay opens
  useEffect(() => {
    if (isOpen && searchInputRef.current) {
      setTimeout(() => searchInputRef.current?.focus(), 100);
    }
  }, [isOpen]);

  // Handle keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (!isOpen) return;
      
      if (event.key === "Escape") {
        handleClose();
      }
      
      // Quick action shortcuts when item is selected
      if (selectedItem) {
        if (event.key === "1" && (event.ctrlKey || event.metaKey)) {
          event.preventDefault();
          setActionType("stock_in");
        }
        if (event.key === "2" && (event.ctrlKey || event.metaKey)) {
          event.preventDefault();
          setActionType("stock_out");
        }
      }
    };

    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, selectedItem]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-2 sm:p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[95vh] sm:max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200">
          <div className="flex items-center space-x-2">
            <Package className="w-6 h-6 text-carbon-blue" />
            <h2 className="text-lg font-semibold text-carbon-gray-80">Quick Inventory Actions</h2>
          </div>
          <Button variant="ghost" size="sm" onClick={handleClose}>
            <X className="w-5 h-5" />
          </Button>
        </div>

        <div className="p-4 space-y-4 max-h-[calc(90vh-120px)] overflow-y-auto">
          {/* Search Section */}
          <div className="space-y-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                ref={searchInputRef}
                type="text"
                placeholder="Search by name, SKU, or barcode..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 h-12 border-2 focus:border-carbon-blue"
              />
            </div>

            {/* Search Results */}
            {isSearching && (
              <div className="flex items-center justify-center py-4">
                <Loader2 className="w-5 h-5 animate-spin text-carbon-blue mr-2" />
                <span className="text-sm text-gray-600">Searching...</span>
              </div>
            )}

            {searchResults && searchResults.length > 0 && (
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {searchResults.map((item: InventoryItem) => (
                  <Card
                    key={item.id}
                    className="cursor-pointer hover:bg-gray-50 transition-colors"
                    onClick={() => handleItemSelect(item)}
                  >
                    <CardContent className="p-3">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2">
                            <span className="font-medium text-sm">{item.name}</span>
                            <Badge variant="outline" className="text-xs">
                              {item.sku}
                            </Badge>
                          </div>
                          <p className="text-xs text-gray-600 mt-1">{item.description}</p>
                        </div>
                        <div className="text-right">
                          <Badge className={getStockStatus(item).color}>
                            {item.currentStock} {item.unit}
                          </Badge>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}

            {searchQuery.length > 2 && searchResults && searchResults.length === 0 && !isSearching && (
              <div className="text-center py-4">
                <Package className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                <p className="text-sm text-gray-600">No items found</p>
              </div>
            )}
          </div>

          {/* Selected Item Actions */}
          {selectedItem && (
            <div className="space-y-4 pt-4 border-t border-gray-200">
              <div className="flex items-center justify-between">
                <h3 className="font-medium text-carbon-gray-80">Selected Item</h3>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSelectedItem(null)}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>

              <Card className="bg-gray-50">
                <CardContent className="p-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-sm">{selectedItem.name}</h4>
                      <p className="text-xs text-gray-600">SKU: {selectedItem.sku}</p>
                      <p className="text-xs text-gray-600">
                        Current Stock: {selectedItem.currentStock} {selectedItem.unit}
                      </p>
                    </div>
                    <Badge className={getStockStatus(selectedItem).color}>
                      {getStockStatus(selectedItem).status}
                    </Badge>
                  </div>
                </CardContent>
              </Card>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <Button
                  variant={actionType === "stock_in" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setActionType("stock_in")}
                  className="flex items-center justify-center"
                >
                  <Plus className="w-4 h-4 mr-1" />
                  Stock In
                </Button>
                <Button
                  variant={actionType === "stock_out" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setActionType("stock_out")}
                  className="flex items-center justify-center"
                >
                  <Minus className="w-4 h-4 mr-1" />
                  Stock Out
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    handleClose();
                    window.location.href = `/inventory?item=${selectedItem.id}`;
                  }}
                  className="flex items-center justify-center"
                >
                  <ExternalLink className="w-4 h-4 mr-1" />
                  View Details
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    handleClose();
                    window.location.href = `/inventory?edit=${selectedItem.id}`;
                  }}
                  className="flex items-center justify-center"
                >
                  <Settings className="w-4 h-4 mr-1" />
                  Edit
                </Button>
              </div>

              {/* Stock Movement Form */}
              {(actionType === "stock_in" || actionType === "stock_out") && (
                <div className="space-y-3 p-3 bg-blue-50 rounded-lg">
                  <h4 className="font-medium text-sm">
                    {actionType === "stock_in" ? "Add Stock" : "Remove Stock"}
                  </h4>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-medium text-gray-700 mb-1">
                        Quantity ({selectedItem.unit})
                      </label>
                      <Input
                        type="number"
                        value={quantity}
                        onChange={(e) => setQuantity(e.target.value)}
                        placeholder="0"
                        min="1"
                        className="h-10"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-gray-700 mb-1">
                        Reason
                      </label>
                      <Input
                        type="text"
                        value={reason}
                        onChange={(e) => setReason(e.target.value)}
                        placeholder="e.g., Purchase, Sale, Adjustment"
                        className="h-10"
                      />
                    </div>
                  </div>
                  <Button
                    onClick={handleStockMovement}
                    disabled={!quantity || !reason || stockMovementMutation.isPending}
                    className="w-full bg-carbon-blue hover:bg-carbon-blue-dark"
                  >
                    {stockMovementMutation.isPending ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <CheckCircle className="w-4 h-4 mr-2" />
                    )}
                    {stockMovementMutation.isPending ? "Processing..." : "Update Stock"}
                  </Button>
                </div>
              )}
            </div>
          )}

          {/* Quick Access Links */}
          {!selectedItem && (
            <div className="space-y-3 pt-4 border-t border-gray-200">
              <h3 className="font-medium text-carbon-gray-80">Quick Access</h3>
              <div className="grid grid-cols-2 gap-2">
                <Button
                  variant="outline"
                  onClick={() => {
                    handleClose();
                    window.location.href = "/inventory";
                  }}
                  className="flex items-center justify-center h-12"
                >
                  <Package className="w-5 h-5 mr-2" />
                  All Inventory
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    handleClose();
                    window.location.href = "/barcode-scanner";
                  }}
                  className="flex items-center justify-center h-12"
                >
                  <Search className="w-5 h-5 mr-2" />
                  Barcode Scanner
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    handleClose();
                    window.location.href = "/";
                  }}
                  className="flex items-center justify-center h-12"
                >
                  <BarChart3 className="w-5 h-5 mr-2" />
                  Dashboard
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    handleClose();
                    window.location.href = "/production-orders";
                  }}
                  className="flex items-center justify-center h-12"
                >
                  <ClipboardList className="w-5 h-5 mr-2" />
                  Production Orders
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}