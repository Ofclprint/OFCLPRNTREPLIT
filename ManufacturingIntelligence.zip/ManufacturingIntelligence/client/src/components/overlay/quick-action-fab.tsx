import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Package, Zap } from "lucide-react";
import { QuickActionOverlay } from "./quick-action-overlay";

export function QuickActionFAB() {
  const [isOverlayOpen, setIsOverlayOpen] = useState(false);

  // Global keyboard shortcut
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "k" && (event.ctrlKey || event.metaKey)) {
        event.preventDefault();
        setIsOverlayOpen(true);
      }
    };

    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, []);

  return (
    <>
      {/* Floating Action Button */}
      <div className="fixed bottom-6 right-6 z-40">
        <div className="relative">
          {/* Pulse ring animation */}
          <div className="absolute inset-0 rounded-full bg-carbon-blue opacity-30 animate-ping"></div>
          <Button
            onClick={() => setIsOverlayOpen(true)}
            size="lg"
            className="relative h-14 w-14 rounded-full bg-carbon-blue hover:bg-carbon-blue-dark shadow-lg hover:shadow-xl transition-all duration-200 group"
            title="Quick Inventory Actions (Ctrl/Cmd + K)"
          >
            <div className="relative">
              <Package className="w-6 h-6 text-white group-hover:scale-110 transition-transform" />
              <Zap className="absolute -top-1 -right-1 w-3 h-3 text-yellow-300 animate-pulse" />
            </div>
          </Button>
        </div>
      </div>

      {/* Quick Action Overlay */}
      <QuickActionOverlay 
        isOpen={isOverlayOpen} 
        onClose={() => setIsOverlayOpen(false)} 
      />
    </>
  );
}