import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { Wrench, AlertTriangle, Calendar, TrendingDown, Clock, CheckCircle } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

type MaintenanceAlert = {
  id: number;
  machineId: number;
  machineName: string;
  alertType: "vibration" | "temperature" | "pressure" | "wear" | "performance";
  severity: "low" | "medium" | "high" | "critical";
  description: string;
  predictedFailureDate: string;
  confidence: number;
  recommendedAction: string;
  estimatedCost: number;
  estimatedDowntime: number;
  createdAt: string;
};

type MaintenanceSchedule = {
  id: number;
  machineId: number;
  machineName: string;
  maintenanceType: "preventive" | "predictive" | "corrective";
  scheduledDate: string;
  estimatedDuration: number;
  priority: "low" | "medium" | "high" | "critical";
  status: "scheduled" | "in_progress" | "completed" | "overdue";
  technician?: string;
};

export default function PredictiveMaintenanceWidget() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedAlert, setSelectedAlert] = useState<MaintenanceAlert | null>(null);

  const { data: alerts } = useQuery({
    queryKey: ['/api/maintenance/alerts'],
    refetchInterval: 30000,
  });

  const { data: schedule } = useQuery({
    queryKey: ['/api/maintenance/schedule'],
    refetchInterval: 60000,
  });

  const scheduleMaintenanceMutation = useMutation({
    mutationFn: async (data: { alertId: number; scheduledDate: string; priority: string }) => {
      return await apiRequest('/api/maintenance/schedule', 'POST', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/maintenance'] });
      toast({
        title: "Maintenance Scheduled",
        description: "Predictive maintenance has been scheduled successfully",
      });
      setSelectedAlert(null);
    },
  });

  const alertList: MaintenanceAlert[] = alerts || [];
  const scheduleList: MaintenanceSchedule[] = schedule || [];

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "critical": return "bg-red-100 text-red-800";
      case "high": return "bg-orange-100 text-orange-800";
      case "medium": return "bg-yellow-100 text-yellow-800";
      default: return "bg-blue-100 text-blue-800";
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case "critical": return <AlertTriangle className="w-4 h-4 text-red-600" />;
      case "high": return <AlertTriangle className="w-4 h-4 text-orange-600" />;
      case "medium": return <Clock className="w-4 h-4 text-yellow-600" />;
      default: return <CheckCircle className="w-4 h-4 text-blue-600" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed": return "bg-green-100 text-green-800";
      case "in_progress": return "bg-blue-100 text-blue-800";
      case "overdue": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const handleScheduleMaintenance = (alert: MaintenanceAlert) => {
    const scheduledDate = new Date(alert.predictedFailureDate);
    scheduledDate.setDate(scheduledDate.getDate() - 7); // Schedule 1 week before predicted failure

    scheduleMaintenanceMutation.mutate({
      alertId: alert.id,
      scheduledDate: scheduledDate.toISOString().split('T')[0],
      priority: alert.severity
    });
  };

  const criticalAlerts = alertList.filter(a => a.severity === "critical").length;
  const highAlerts = alertList.filter(a => a.severity === "high").length;
  const overdueMaintenance = scheduleList.filter(s => s.status === "overdue").length;
  const avgConfidence = alertList.reduce((sum, a) => sum + a.confidence, 0) / (alertList.length || 1);

  // Sample trend data for vibration analysis
  const trendData = [
    { time: "00:00", vibration: 2.1, temperature: 68, pressure: 45 },
    { time: "04:00", vibration: 2.3, temperature: 72, pressure: 46 },
    { time: "08:00", vibration: 2.8, temperature: 75, pressure: 48 },
    { time: "12:00", vibration: 3.2, temperature: 78, pressure: 50 },
    { time: "16:00", vibration: 3.1, temperature: 76, pressure: 49 },
    { time: "20:00", vibration: 2.9, temperature: 73, pressure: 47 },
  ];

  return (
    <div className="space-y-6">
      <Card className="border-carbon-gray-20">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Wrench className="w-5 h-5 text-carbon-blue" />
              <span>Predictive Maintenance</span>
            </div>
            {criticalAlerts > 0 && (
              <Badge className="bg-red-100 text-red-800">
                {criticalAlerts} critical
              </Badge>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Status Overview */}
            <div className="grid grid-cols-4 gap-4 p-3 bg-carbon-gray-10 rounded-lg">
              <div className="text-center">
                <p className="text-lg font-semibold text-red-600">{criticalAlerts}</p>
                <p className="text-xs text-carbon-gray-50">Critical Alerts</p>
              </div>
              <div className="text-center">
                <p className="text-lg font-semibold text-orange-600">{highAlerts}</p>
                <p className="text-xs text-carbon-gray-50">High Priority</p>
              </div>
              <div className="text-center">
                <p className="text-lg font-semibold text-red-600">{overdueMaintenance}</p>
                <p className="text-xs text-carbon-gray-50">Overdue</p>
              </div>
              <div className="text-center">
                <p className="text-lg font-semibold text-blue-600">{avgConfidence.toFixed(0)}%</p>
                <p className="text-xs text-carbon-gray-50">Avg Confidence</p>
              </div>
            </div>

            {/* Predictive Alerts */}
            <div>
              <h4 className="font-medium text-carbon-gray-80 mb-3">Predictive Alerts</h4>
              <div className="space-y-3 max-h-64 overflow-y-auto">
                {alertList.length === 0 ? (
                  <div className="text-center py-8">
                    <Wrench className="w-12 h-12 text-carbon-gray-40 mx-auto mb-4" />
                    <p className="text-carbon-gray-50">No maintenance alerts</p>
                    <p className="text-sm text-carbon-gray-40">All machines are operating normally</p>
                  </div>
                ) : (
                  alertList.map((alert) => (
                    <div
                      key={alert.id}
                      className={`border rounded-lg p-3 cursor-pointer transition-colors ${
                        selectedAlert?.id === alert.id 
                          ? 'border-carbon-blue bg-blue-50' 
                          : 'border-carbon-gray-20 hover:bg-carbon-gray-10'
                      }`}
                      onClick={() => setSelectedAlert(alert)}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-1">
                            <h4 className="font-medium text-carbon-gray-80">{alert.machineName}</h4>
                            <Badge className={getSeverityColor(alert.severity)}>
                              {getSeverityIcon(alert.severity)}
                              {alert.severity}
                            </Badge>
                          </div>
                          <p className="text-sm text-carbon-gray-70 capitalize">{alert.alertType} anomaly detected</p>
                          <p className="text-xs text-carbon-gray-50">{alert.description}</p>
                        </div>
                        
                        <div className="text-right">
                          <p className="text-sm font-medium text-carbon-gray-80">{alert.confidence}%</p>
                          <p className="text-xs text-carbon-gray-50">Confidence</p>
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-3 text-xs text-carbon-gray-50">
                        <div>
                          <span>Failure Date:</span>
                          <p className="font-medium text-carbon-gray-80">
                            {new Date(alert.predictedFailureDate).toLocaleDateString()}
                          </p>
                        </div>
                        <div>
                          <span>Est. Cost:</span>
                          <p className="font-medium text-carbon-gray-80">${alert.estimatedCost.toLocaleString()}</p>
                        </div>
                        <div>
                          <span>Downtime:</span>
                          <p className="font-medium text-carbon-gray-80">{alert.estimatedDowntime}h</p>
                        </div>
                      </div>

                      {alert.severity === "critical" || alert.severity === "high" ? (
                        <div className="mt-3 pt-2 border-t border-carbon-gray-20">
                          <Button
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleScheduleMaintenance(alert);
                            }}
                            disabled={scheduleMaintenanceMutation.isPending}
                            className="w-full"
                          >
                            {scheduleMaintenanceMutation.isPending ? "Scheduling..." : "Schedule Maintenance"}
                          </Button>
                        </div>
                      ) : null}
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Machine Health Trends */}
      <Card className="border-carbon-gray-20">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <TrendingDown className="w-5 h-5 text-carbon-blue" />
            <span>Machine Health Trends</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <h4 className="font-medium text-carbon-gray-80 mb-3">24-Hour Vibration Analysis</h4>
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={trendData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="time" fontSize={12} />
                  <YAxis fontSize={12} />
                  <Tooltip />
                  <Line 
                    type="monotone" 
                    dataKey="vibration" 
                    stroke="#ff6b6b" 
                    strokeWidth={2}
                    name="Vibration (Hz)"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                <div className="flex items-center space-x-2 mb-1">
                  <AlertTriangle className="w-4 h-4 text-red-600" />
                  <span className="font-medium text-red-800">High Vibration</span>
                </div>
                <p className="text-red-700">Peak: 3.2 Hz at 12:00</p>
                <p className="text-xs text-red-600">Normal range: 0-2.5 Hz</p>
              </div>

              <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                <div className="flex items-center space-x-2 mb-1">
                  <Clock className="w-4 h-4 text-yellow-600" />
                  <span className="font-medium text-yellow-800">Temperature Rising</span>
                </div>
                <p className="text-yellow-700">Current: 78°C</p>
                <p className="text-xs text-yellow-600">Optimal range: 65-75°C</p>
              </div>

              <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                <div className="flex items-center space-x-2 mb-1">
                  <CheckCircle className="w-4 h-4 text-green-600" />
                  <span className="font-medium text-green-800">Pressure Normal</span>
                </div>
                <p className="text-green-700">Current: 50 PSI</p>
                <p className="text-xs text-green-600">Within normal range</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Maintenance Schedule */}
      <Card className="border-carbon-gray-20">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Calendar className="w-5 h-5 text-carbon-blue" />
            <span>Maintenance Schedule</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {scheduleList.length === 0 ? (
              <div className="text-center py-8">
                <Calendar className="w-12 h-12 text-carbon-gray-40 mx-auto mb-4" />
                <p className="text-carbon-gray-50">No scheduled maintenance</p>
              </div>
            ) : (
              scheduleList.slice(0, 5).map((item) => (
                <div key={item.id} className="flex items-center justify-between p-3 border border-carbon-gray-20 rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-1">
                      <h4 className="font-medium text-carbon-gray-80">{item.machineName}</h4>
                      <Badge className={getStatusColor(item.status)}>
                        {item.status}
                      </Badge>
                    </div>
                    <p className="text-sm text-carbon-gray-50 capitalize">{item.maintenanceType} maintenance</p>
                    {item.technician && (
                      <p className="text-xs text-carbon-gray-50">Technician: {item.technician}</p>
                    )}
                  </div>
                  
                  <div className="text-right">
                    <p className="text-sm font-medium text-carbon-gray-80">
                      {new Date(item.scheduledDate).toLocaleDateString()}
                    </p>
                    <p className="text-xs text-carbon-gray-50">{item.estimatedDuration}h estimated</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}