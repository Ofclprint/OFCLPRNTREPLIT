import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { X, CheckCircle, ArrowRight, ArrowLeft, Play, BookOpen, Target, Users } from "lucide-react";
import { useLocation } from "wouter";

interface OnboardingStep {
  id: string;
  title: string;
  description: string;
  content: React.ReactNode;
  route?: string;
  action?: () => void;
  completable: boolean;
}

interface OnboardingWizardProps {
  onComplete: () => void;
  onSkip: () => void;
}

export default function OnboardingWizard({ onComplete, onSkip }: OnboardingWizardProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [completedSteps, setCompletedSteps] = useState<string[]>([]);
  const [, setLocation] = useLocation();

  const steps: OnboardingStep[] = [
    {
      id: "welcome",
      title: "Welcome to Manufacturing ERP",
      description: "Your complete manufacturing management solution",
      content: (
        <div className="text-center space-y-4">
          <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
            <Target className="w-8 h-8 text-blue-600" />
          </div>
          <h3 className="text-xl font-semibold">Get started in 5 minutes</h3>
          <p className="text-gray-600">
            This guided tour will help you understand the key features and get you productive quickly.
          </p>
          <div className="grid grid-cols-2 gap-4 mt-6">
            <div className="p-4 bg-gray-50 rounded-lg">
              <h4 className="font-medium">Inventory Management</h4>
              <p className="text-sm text-gray-600">Track stock levels and locations</p>
            </div>
            <div className="p-4 bg-gray-50 rounded-lg">
              <h4 className="font-medium">Production Orders</h4>
              <p className="text-sm text-gray-600">Manage manufacturing workflows</p>
            </div>
            <div className="p-4 bg-gray-50 rounded-lg">
              <h4 className="font-medium">Quality Control</h4>
              <p className="text-sm text-gray-600">Ensure product quality standards</p>
            </div>
            <div className="p-4 bg-gray-50 rounded-lg">
              <h4 className="font-medium">Barcode Scanning</h4>
              <p className="text-sm text-gray-600">Quick mobile inventory updates</p>
            </div>
          </div>
        </div>
      ),
      completable: true
    },
    {
      id: "dashboard",
      title: "Dashboard Overview",
      description: "Your command center for manufacturing operations",
      route: "/",
      content: (
        <div className="space-y-4">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto">
            <BookOpen className="w-8 h-8 text-green-600" />
          </div>
          <h3 className="text-xl font-semibold text-center">Dashboard Walkthrough</h3>
          <div className="space-y-3">
            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-blue-500 text-white rounded-full flex items-center justify-center text-sm font-medium">1</div>
              <div>
                <h4 className="font-medium">Key Performance Indicators</h4>
                <p className="text-sm text-gray-600">Monitor efficiency, active orders, quality scores, and inventory value</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-blue-500 text-white rounded-full flex items-center justify-center text-sm font-medium">2</div>
              <div>
                <h4 className="font-medium">Recent Activity</h4>
                <p className="text-sm text-gray-600">Track latest production updates and system changes</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-blue-500 text-white rounded-full flex items-center justify-center text-sm font-medium">3</div>
              <div>
                <h4 className="font-medium">Quick Actions</h4>
                <p className="text-sm text-gray-600">Access frequently used features like scanning and order creation</p>
              </div>
            </div>
          </div>
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <p className="text-sm text-yellow-800">
              <strong>Tip:</strong> Use the navigation sidebar to quickly jump between different modules.
            </p>
          </div>
        </div>
      ),
      completable: true
    },
    {
      id: "inventory",
      title: "Inventory Management",
      description: "Learn how to track and manage your inventory",
      route: "/inventory",
      content: (
        <div className="space-y-4">
          <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto">
            <Users className="w-8 h-8 text-purple-600" />
          </div>
          <h3 className="text-xl font-semibold text-center">Inventory Features</h3>
          <div className="space-y-3">
            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-purple-500 text-white rounded-full flex items-center justify-center text-sm font-medium">1</div>
              <div>
                <h4 className="font-medium">View All Items</h4>
                <p className="text-sm text-gray-600">Browse your complete inventory with search and filtering</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-purple-500 text-white rounded-full flex items-center justify-center text-sm font-medium">2</div>
              <div>
                <h4 className="font-medium">Stock Level Monitoring</h4>
                <p className="text-sm text-gray-600">Track current stock, minimum levels, and reorder points</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-purple-500 text-white rounded-full flex items-center justify-center text-sm font-medium">3</div>
              <div>
                <h4 className="font-medium">Add New Items</h4>
                <p className="text-sm text-gray-600">Create new inventory items with SKU, location, and pricing</p>
              </div>
            </div>
          </div>
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-sm text-blue-800">
              <strong>Try it:</strong> Click "Add Item" to create your first inventory entry.
            </p>
          </div>
        </div>
      ),
      completable: true
    },
    {
      id: "barcode",
      title: "Barcode Scanner",
      description: "Quick inventory updates with mobile scanning",
      route: "/barcode-scanner",
      content: (
        <div className="space-y-4">
          <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto">
            <Play className="w-8 h-8 text-orange-600" />
          </div>
          <h3 className="text-xl font-semibold text-center">Barcode Scanning</h3>
          <div className="space-y-3">
            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-orange-500 text-white rounded-full flex items-center justify-center text-sm font-medium">1</div>
              <div>
                <h4 className="font-medium">Camera Access</h4>
                <p className="text-sm text-gray-600">Allow camera permission for barcode scanning</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-orange-500 text-white rounded-full flex items-center justify-center text-sm font-medium">2</div>
              <div>
                <h4 className="font-medium">Scan Products</h4>
                <p className="text-sm text-gray-600">Point camera at barcodes to quickly look up inventory items</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-orange-500 text-white rounded-full flex items-center justify-center text-sm font-medium">3</div>
              <div>
                <h4 className="font-medium">Manual Entry</h4>
                <p className="text-sm text-gray-600">Type barcodes manually if camera scanning isn't available</p>
              </div>
            </div>
          </div>
          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <p className="text-sm text-green-800">
              <strong>Mobile Ready:</strong> This feature works great on phones and tablets.
            </p>
          </div>
        </div>
      ),
      completable: true
    },
    {
      id: "production",
      title: "Production Orders",
      description: "Manage your manufacturing workflows",
      route: "/production-orders",
      content: (
        <div className="space-y-4">
          <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto">
            <Target className="w-8 h-8 text-red-600" />
          </div>
          <h3 className="text-xl font-semibold text-center">Production Management</h3>
          <div className="space-y-3">
            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center text-sm font-medium">1</div>
              <div>
                <h4 className="font-medium">Order Tracking</h4>
                <p className="text-sm text-gray-600">Monitor order status from pending to completed</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center text-sm font-medium">2</div>
              <div>
                <h4 className="font-medium">Priority Management</h4>
                <p className="text-sm text-gray-600">Set priority levels and due dates for orders</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center text-sm font-medium">3</div>
              <div>
                <h4 className="font-medium">Progress Tracking</h4>
                <p className="text-sm text-gray-600">Monitor completion progress and assign team members</p>
              </div>
            </div>
          </div>
        </div>
      ),
      completable: true
    },
    {
      id: "complete",
      title: "You're All Set!",
      description: "Start using your Manufacturing ERP system",
      content: (
        <div className="text-center space-y-4">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto">
            <CheckCircle className="w-8 h-8 text-green-600" />
          </div>
          <h3 className="text-xl font-semibold">Congratulations!</h3>
          <p className="text-gray-600">
            You've completed the onboarding tour. You're now ready to manage your manufacturing operations efficiently.
          </p>
          <div className="bg-gray-50 rounded-lg p-6 space-y-4">
            <h4 className="font-medium">Quick Reference:</h4>
            <div className="grid grid-cols-1 gap-2 text-sm">
              <div className="flex justify-between">
                <span>Dashboard</span>
                <Badge variant="outline">Overview & KPIs</Badge>
              </div>
              <div className="flex justify-between">
                <span>Inventory</span>
                <Badge variant="outline">Stock Management</Badge>
              </div>
              <div className="flex justify-between">
                <span>Scanner</span>
                <Badge variant="outline">Mobile Updates</Badge>
              </div>
              <div className="flex justify-between">
                <span>Production</span>
                <Badge variant="outline">Order Tracking</Badge>
              </div>
            </div>
          </div>
          <p className="text-sm text-gray-500">
            You can always replay this tutorial from the Settings page.
          </p>
        </div>
      ),
      completable: true
    }
  ];

  const currentStepData = steps[currentStep];
  const progress = ((currentStep + 1) / steps.length) * 100;

  const handleNext = () => {
    if (currentStepData.route && currentStep > 0) {
      setLocation(currentStepData.route);
    }
    
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
      if (currentStepData.completable) {
        setCompletedSteps([...completedSteps, currentStepData.id]);
      }
    } else {
      handleComplete();
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleComplete = () => {
    setCompletedSteps([...completedSteps, currentStepData.id]);
    onComplete();
  };

  const handleStepClick = (stepIndex: number) => {
    setCurrentStep(stepIndex);
    const step = steps[stepIndex];
    if (step.route) {
      setLocation(step.route);
    }
  };

  useEffect(() => {
    // Auto-navigate to route when step changes
    if (currentStepData.route && currentStep > 0) {
      const timer = setTimeout(() => {
        setLocation(currentStepData.route!);
      }, 300);
      return () => clearTimeout(timer);
    }
  }, [currentStep, currentStepData.route, setLocation]);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
          <div className="space-y-1">
            <CardTitle className="text-lg">
              {currentStepData.title}
            </CardTitle>
            <p className="text-sm text-gray-600">
              {currentStepData.description}
            </p>
          </div>
          <Button variant="ghost" size="sm" onClick={onSkip}>
            <X className="h-4 w-4" />
          </Button>
        </CardHeader>
        
        <CardContent className="space-y-6">
          {/* Progress Bar */}
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Step {currentStep + 1} of {steps.length}</span>
              <span>{Math.round(progress)}% Complete</span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>

          {/* Step Navigation */}
          <div className="flex space-x-2 overflow-x-auto pb-2">
            {steps.map((step, index) => (
              <button
                key={step.id}
                onClick={() => handleStepClick(index)}
                className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center text-xs font-medium transition-colors ${
                  index === currentStep
                    ? 'bg-blue-500 text-white'
                    : completedSteps.includes(step.id)
                    ? 'bg-green-500 text-white'
                    : index < currentStep
                    ? 'bg-gray-300 text-gray-600'
                    : 'bg-gray-100 text-gray-400'
                }`}
              >
                {completedSteps.includes(step.id) ? (
                  <CheckCircle className="w-4 h-4" />
                ) : (
                  index + 1
                )}
              </button>
            ))}
          </div>

          {/* Step Content */}
          <div className="min-h-[300px]">
            {currentStepData.content}
          </div>

          {/* Navigation Buttons */}
          <div className="flex justify-between pt-4 border-t">
            <Button
              variant="outline"
              onClick={handlePrevious}
              disabled={currentStep === 0}
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Previous
            </Button>
            
            <div className="flex space-x-2">
              <Button variant="ghost" onClick={onSkip}>
                Skip Tutorial
              </Button>
              <Button onClick={handleNext}>
                {currentStep === steps.length - 1 ? (
                  <>
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Complete
                  </>
                ) : (
                  <>
                    Next
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </>
                )}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}