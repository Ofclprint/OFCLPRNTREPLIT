import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, ShoppingCart, TrendingUp, Clock } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

type ReorderSuggestion = {
  id: number;
  name: string;
  sku: string;
  currentStock: number;
  suggestedQuantity: number;
  estimatedCost: number;
  urgency: "high" | "medium" | "low";
  daysUntilStockout: number;
  averageWeeklyUsage: number;
};

export default function SmartReorderWidget() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: suggestions, isLoading } = useQuery({
    queryKey: ['/api/inventory/reorder-suggestions'],
    refetchInterval: 300000, // Refresh every 5 minutes
  });

  const createPurchaseOrderMutation = useMutation({
    mutationFn: async (items: { id: number; quantity: number }[]) => {
      return await apiRequest('/api/purchase-orders', 'POST', { items });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/inventory'] });
      queryClient.invalidateQueries({ queryKey: ['/api/inventory/reorder-suggestions'] });
      toast({
        title: "Purchase Order Created",
        description: "Your purchase order has been submitted for approval.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to create purchase order. Please try again.",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <Card className="border-carbon-gray-20">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <ShoppingCart className="w-5 h-5 text-carbon-blue" />
            <span>Smart Reorder Suggestions</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-48 flex items-center justify-center">
            <div className="w-8 h-8 border-4 border-carbon-blue border-t-transparent rounded-full animate-spin"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const reorderSuggestions: ReorderSuggestion[] = suggestions || [];

  if (reorderSuggestions.length === 0) {
    return (
      <Card className="border-carbon-gray-20">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <ShoppingCart className="w-5 h-5 text-carbon-blue" />
            <span>Smart Reorder Suggestions</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <ShoppingCart className="w-12 h-12 text-carbon-gray-40 mx-auto mb-4" />
            <p className="text-carbon-gray-50">No reorder suggestions at this time</p>
            <p className="text-sm text-carbon-gray-40">Your inventory levels are optimal</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case "high":
        return "bg-red-100 text-red-800";
      case "medium":
        return "bg-yellow-100 text-yellow-800";
      case "low":
        return "bg-green-100 text-green-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const handleCreatePurchaseOrder = (suggestions: ReorderSuggestion[]) => {
    const items = suggestions.map(s => ({ id: s.id, quantity: s.suggestedQuantity }));
    createPurchaseOrderMutation.mutate(items);
  };

  const totalEstimatedCost = reorderSuggestions.reduce((sum, item) => sum + item.estimatedCost, 0);
  const highUrgencyItems = reorderSuggestions.filter(item => item.urgency === "high").length;

  return (
    <Card className="border-carbon-gray-20">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <ShoppingCart className="w-5 h-5 text-carbon-blue" />
            <span>Smart Reorder Suggestions</span>
          </div>
          {highUrgencyItems > 0 && (
            <Badge className="bg-red-100 text-red-800">
              {highUrgencyItems} urgent
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Summary */}
          <div className="grid grid-cols-2 gap-4 p-3 bg-carbon-gray-10 rounded-lg">
            <div>
              <p className="text-sm text-carbon-gray-50">Total Items</p>
              <p className="text-lg font-semibold text-carbon-gray-80">{reorderSuggestions.length}</p>
            </div>
            <div>
              <p className="text-sm text-carbon-gray-50">Est. Cost</p>
              <p className="text-lg font-semibold text-carbon-gray-80">${totalEstimatedCost.toLocaleString()}</p>
            </div>
          </div>

          {/* Suggestions List */}
          <div className="space-y-3 max-h-64 overflow-y-auto">
            {reorderSuggestions.map((item) => (
              <div key={item.id} className="border border-carbon-gray-20 rounded-lg p-3">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <h4 className="font-medium text-carbon-gray-80">{item.name}</h4>
                    <p className="text-sm text-carbon-gray-50">SKU: {item.sku}</p>
                  </div>
                  <Badge className={getUrgencyColor(item.urgency)}>
                    {item.urgency}
                  </Badge>
                </div>
                
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div className="flex items-center space-x-1">
                    <AlertTriangle className="w-4 h-4 text-orange-500" />
                    <span className="text-carbon-gray-50">Stock: {item.currentStock}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Clock className="w-4 h-4 text-blue-500" />
                    <span className="text-carbon-gray-50">{item.daysUntilStockout} days left</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <TrendingUp className="w-4 h-4 text-green-500" />
                    <span className="text-carbon-gray-50">Weekly: {item.averageWeeklyUsage}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <ShoppingCart className="w-4 h-4 text-purple-500" />
                    <span className="text-carbon-gray-50">Order: {item.suggestedQuantity}</span>
                  </div>
                </div>
                
                <div className="mt-2 pt-2 border-t border-carbon-gray-20">
                  <p className="text-sm font-medium text-carbon-gray-70">
                    Est. Cost: ${item.estimatedCost.toLocaleString()}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Actions */}
          <div className="flex space-x-2 pt-2 border-t border-carbon-gray-20">
            <Button
              onClick={() => handleCreatePurchaseOrder(reorderSuggestions)}
              disabled={createPurchaseOrderMutation.isPending}
              className="flex-1"
            >
              {createPurchaseOrderMutation.isPending ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
              ) : (
                <ShoppingCart className="w-4 h-4 mr-2" />
              )}
              Create Purchase Order
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}