import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { ArrowRight, Clock } from "lucide-react";
import { Link } from "wouter";
import { format } from "date-fns";

type ProductionOrder = {
  id: number;
  orderNumber: string;
  productName: string;
  quantity: number;
  status: "pending" | "in_progress" | "ready_for_qc" | "completed" | "cancelled" | "urgent";
  progress: number;
  dueDate?: string;
  createdAt: string;
};

const statusColors = {
  pending: "bg-gray-100 text-gray-800",
  in_progress: "bg-blue-100 text-blue-800",
  ready_for_qc: "bg-green-100 text-green-800",
  completed: "bg-green-200 text-green-900",
  cancelled: "bg-red-100 text-red-800",
  urgent: "bg-red-200 text-red-900",
};

const progressColors = {
  pending: "bg-gray-400",
  in_progress: "bg-blue-500",
  ready_for_qc: "bg-green-500",
  completed: "bg-green-600",
  cancelled: "bg-red-500",
  urgent: "bg-red-600",
};

export default function ProductionOrdersWidget() {
  const { data: orders = [], isLoading } = useQuery({
    queryKey: ["/api/orders"],
  });

  if (isLoading) {
    return (
      <Card className="border-carbon-gray-20">
        <CardHeader className="border-b border-carbon-gray-20">
          <CardTitle>Recent Production Orders</CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-16 bg-carbon-gray-10 rounded"></div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  // Get the 5 most recent orders
  const recentOrders = orders.slice(0, 5);

  return (
    <Card className="border-carbon-gray-20">
      <CardHeader className="p-6 border-b border-carbon-gray-20">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold text-carbon-gray-80">
            Recent Production Orders
          </CardTitle>
          <Link href="/orders">
            <Button variant="ghost" size="sm" className="text-carbon-blue hover:text-carbon-blue/80">
              View All <ArrowRight className="w-4 h-4 ml-1" />
            </Button>
          </Link>
        </div>
      </CardHeader>
      
      <CardContent className="p-0">
        {recentOrders.length === 0 ? (
          <div className="p-8 text-center">
            <p className="text-carbon-gray-50">No production orders found</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-carbon-gray-20">
                  <th className="text-left p-4 text-sm font-medium text-carbon-gray-50">Order ID</th>
                  <th className="text-left p-4 text-sm font-medium text-carbon-gray-50">Product</th>
                  <th className="text-left p-4 text-sm font-medium text-carbon-gray-50">Status</th>
                  <th className="text-left p-4 text-sm font-medium text-carbon-gray-50">Due Date</th>
                  <th className="text-left p-4 text-sm font-medium text-carbon-gray-50">Progress</th>
                </tr>
              </thead>
              <tbody>
                {recentOrders.map((order: ProductionOrder) => (
                  <tr 
                    key={order.id} 
                    className="border-b border-carbon-gray-20 hover:bg-carbon-gray-10 cursor-pointer transition-colors"
                  >
                    <td className="p-4">
                      <span className="font-medium text-carbon-gray-80">
                        {order.orderNumber}
                      </span>
                    </td>
                    <td className="p-4">
                      <div>
                        <p className="font-medium text-carbon-gray-80">
                          {order.productName}
                        </p>
                        <p className="text-sm text-carbon-gray-50">
                          Qty: {order.quantity}
                        </p>
                      </div>
                    </td>
                    <td className="p-4">
                      <Badge className={statusColors[order.status]}>
                        {order.status.replace('_', ' ')}
                      </Badge>
                    </td>
                    <td className="p-4">
                      {order.dueDate ? (
                        <div className="flex items-center space-x-1">
                          <Clock className="w-3 h-3 text-carbon-gray-50" />
                          <span className={`text-sm ${
                            new Date(order.dueDate) < new Date() 
                              ? "text-red-600 font-medium" 
                              : "text-carbon-gray-80"
                          }`}>
                            {format(new Date(order.dueDate), "MMM dd")}
                          </span>
                        </div>
                      ) : (
                        <span className="text-sm text-carbon-gray-50">-</span>
                      )}
                    </td>
                    <td className="p-4">
                      <div className="flex items-center space-x-2">
                        <div className="flex-1 bg-carbon-gray-10 rounded-full h-2 max-w-20">
                          <Progress 
                            value={order.progress} 
                            className="h-2"
                          />
                        </div>
                        <span className="text-sm text-carbon-gray-50 min-w-10">
                          {order.progress}%
                        </span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
