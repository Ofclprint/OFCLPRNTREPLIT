import { useState } from "react";
import { Button } from "@/components/ui/button";
import { QrCode, Plus, ClipboardCheck, Package } from "lucide-react";
import { Link } from "wouter";

export default function QuickActionsPanel() {
  const [isOpen, setIsOpen] = useState(false);

  const quickActions = [
    {
      label: "Scan Barcode",
      href: "/barcode-scanner",
      icon: QrCode,
      color: "text-carbon-gray-80 hover:bg-carbon-gray-10",
    },
    {
      label: "New Order",
      href: "/orders",
      icon: Plus,
      color: "text-carbon-gray-80 hover:bg-carbon-gray-10",
    },
    {
      label: "Log QC Check",
      href: "/quality-control",
      icon: ClipboardCheck,
      color: "text-carbon-gray-80 hover:bg-carbon-gray-10",
    },
    {
      label: "Update Stock",
      href: "/inventory",
      icon: Package,
      color: "text-carbon-gray-80 hover:bg-carbon-gray-10",
    },
  ];

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {/* Quick Actions Menu */}
      {isOpen && (
        <div className="absolute bottom-16 right-0 bg-white rounded-lg shadow-xl border border-carbon-gray-20 p-2 space-y-1 min-w-48">
          {quickActions.map((action) => (
            <Link key={action.href} href={action.href}>
              <Button
                variant="ghost"
                className={`flex items-center w-full px-4 py-2 text-sm justify-start ${action.color} rounded`}
                onClick={() => setIsOpen(false)}
              >
                <action.icon className="w-5 h-5 mr-3" />
                {action.label}
              </Button>
            </Link>
          ))}
        </div>
      )}

      {/* Floating Action Button */}
      <Button
        onClick={() => setIsOpen(!isOpen)}
        className="w-14 h-14 rounded-full bg-carbon-blue hover:bg-carbon-blue/90 shadow-lg transition-all duration-200 hover:scale-105"
        size="lg"
      >
        <Plus 
          className={`w-6 h-6 text-white transition-transform duration-200 ${
            isOpen ? 'rotate-45' : 'rotate-0'
          }`} 
        />
      </Button>
    </div>
  );
}
