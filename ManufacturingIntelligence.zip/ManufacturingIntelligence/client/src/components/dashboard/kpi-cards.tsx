import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { BarChart3, ClipboardList, CheckCircle, Package } from "lucide-react";

type KPIData = {
  efficiency: number;
  activeOrders: number;
  qualityScore: number;
  inventoryValue: number;
};

export default function KPICards() {
  const { data: kpis, isLoading } = useQuery({
    queryKey: ["/api/dashboard/kpis"],
  });

  const { data: lowStockItems = [] } = useQuery({
    queryKey: ["/api/inventory/low-stock"],
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {[1, 2, 3, 4].map((i) => (
          <Card key={i} className="border-carbon-gray-20">
            <CardContent className="p-6">
              <div className="animate-pulse">
                <div className="w-12 h-12 bg-carbon-gray-10 rounded-lg mb-4"></div>
                <div className="h-8 bg-carbon-gray-10 rounded mb-2"></div>
                <div className="h-4 bg-carbon-gray-10 rounded"></div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const kpiData: KPIData = kpis || {
    efficiency: 0,
    activeOrders: 0,
    qualityScore: 0,
    inventoryValue: 0,
  };

  const kpiCards = [
    {
      title: "Production Efficiency",
      value: `${kpiData.efficiency}%`,
      change: "+12%",
      changeType: "positive" as const,
      icon: BarChart3,
      iconColor: "text-carbon-blue",
      iconBg: "bg-carbon-blue bg-opacity-10",
      progress: kpiData.efficiency,
      progressColor: "bg-carbon-blue",
    },
    {
      title: "Active Orders",
      value: kpiData.activeOrders.toString(),
      change: "+3",
      changeType: "positive" as const,
      icon: ClipboardList,
      iconColor: "text-yellow-600",
      iconBg: "bg-yellow-100",
      subtitle: "8 urgent, 16 normal",
    },
    {
      title: "Quality Score",
      value: `${kpiData.qualityScore}%`,
      change: "+2.1%",
      changeType: "positive" as const,
      icon: CheckCircle,
      iconColor: "text-green-600",
      iconBg: "bg-green-100",
      progress: kpiData.qualityScore,
      progressColor: "bg-green-500",
    },
    {
      title: "Inventory Value",
      value: `$${(kpiData.inventoryValue / 1000000).toFixed(1)}M`,
      change: "-5.2%",
      changeType: "negative" as const,
      icon: Package,
      iconColor: "text-red-600",
      iconBg: "bg-red-100",
      subtitle: `${lowStockItems.length} items low stock`,
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {kpiCards.map((card, index) => (
        <Card key={index} className="border-carbon-gray-20 hover:shadow-lg transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className={`w-12 h-12 ${card.iconBg} rounded-lg flex items-center justify-center`}>
                <card.icon className={`${card.iconColor} text-xl w-6 h-6`} />
              </div>
              <span className={`text-sm font-medium ${
                card.changeType === "positive" ? "text-green-600" : "text-red-600"
              }`}>
                {card.change}
              </span>
            </div>
            
            <h3 className="text-2xl font-semibold text-carbon-gray-80 mb-1">
              {card.value}
            </h3>
            
            <p className="text-carbon-gray-50 text-sm mb-3">
              {card.title}
            </p>
            
            {card.progress !== undefined && (
              <div className="space-y-1">
                <Progress value={card.progress} className="h-2" />
              </div>
            )}
            
            {card.subtitle && (
              <p className={`text-xs mt-2 ${
                card.changeType === "negative" ? "text-red-600" : "text-carbon-gray-50"
              }`}>
                {card.subtitle}
              </p>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
