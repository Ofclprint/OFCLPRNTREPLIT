import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Brain, TrendingUp, DollarSign, Shield } from "lucide-react";

type AIForecast = {
  id: number;
  type: "demand" | "cost_optimization" | "quality_prediction";
  prediction: {
    prediction: string;
    confidence: number;
    type: string;
  };
  confidence: string;
  validUntil?: string;
  createdAt: string;
};

const insightIcons = {
  demand: TrendingUp,
  cost_optimization: DollarSign,
  quality_prediction: Shield,
};

const insightColors = {
  demand: "border-l-4 border-carbon-blue bg-blue-50",
  cost_optimization: "border-l-4 border-yellow-500 bg-yellow-50",
  quality_prediction: "border-l-4 border-green-500 bg-green-50",
};

const insightTitles = {
  demand: "Demand Forecast",
  cost_optimization: "Cost Optimization",
  quality_prediction: "Quality Prediction",
};

export default function AIInsightsWidget() {
  const { data: forecasts = [], isLoading } = useQuery({
    queryKey: ["/api/ai/insights"],
  });

  if (isLoading) {
    return (
      <Card className="border-carbon-gray-20">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
              <Brain className="text-white text-sm w-4 h-4" />
            </div>
            <span>AI Insights</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-20 bg-carbon-gray-10 rounded-lg"></div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-carbon-gray-20">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
            <Brain className="text-white text-sm w-4 h-4" />
          </div>
          <span>AI Insights</span>
        </CardTitle>
      </CardHeader>
      
      <CardContent>
        {forecasts.length === 0 ? (
          <div className="text-center py-6">
            <Brain className="w-12 h-12 text-carbon-gray-50 mx-auto mb-2" />
            <p className="text-carbon-gray-50 text-sm">No AI insights available</p>
          </div>
        ) : (
          <div className="space-y-4">
            {forecasts.slice(0, 3).map((forecast: AIForecast) => {
              const Icon = insightIcons[forecast.type];
              const colorClass = insightColors[forecast.type];
              const title = insightTitles[forecast.type];
              
              return (
                <div 
                  key={forecast.id} 
                  className={`p-4 rounded-lg ${colorClass}`}
                >
                  <div className="flex items-start space-x-3">
                    <Icon className="w-5 h-5 text-carbon-gray-70 mt-0.5" />
                    <div className="flex-1">
                      <h4 className="font-medium text-carbon-gray-80 mb-2">
                        {title}
                      </h4>
                      <p className="text-sm text-carbon-gray-70">
                        {forecast.prediction.prediction}
                      </p>
                      <div className="flex items-center justify-between mt-2">
                        <span className="text-xs text-carbon-gray-50">
                          Confidence: {Math.round(parseFloat(forecast.confidence) * 100)}%
                        </span>
                        {forecast.validUntil && (
                          <span className="text-xs text-carbon-gray-50">
                            Valid until {new Date(forecast.validUntil).toLocaleDateString()}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
