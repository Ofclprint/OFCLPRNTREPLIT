import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from "recharts";
import { TrendingUp, TrendingDown, Activity } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

type ProductionMetrics = {
  date: string;
  orders: number;
  completed: number;
  efficiency: number;
};

export default function ProductionAnalyticsWidget() {
  const { data: metrics, isLoading } = useQuery({
    queryKey: ['/api/analytics/production'],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  if (isLoading) {
    return (
      <Card className="border-carbon-gray-20">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Activity className="w-5 h-5 text-carbon-blue" />
            <span>Production Analytics</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64 flex items-center justify-center">
            <div className="w-8 h-8 border-4 border-carbon-blue border-t-transparent rounded-full animate-spin"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const productionData: ProductionMetrics[] = metrics || [
    { date: "Mon", orders: 12, completed: 10, efficiency: 83 },
    { date: "Tue", orders: 15, completed: 14, efficiency: 93 },
    { date: "Wed", orders: 8, completed: 8, efficiency: 100 },
    { date: "Thu", orders: 18, completed: 16, efficiency: 89 },
    { date: "Fri", orders: 22, completed: 20, efficiency: 91 },
    { date: "Sat", orders: 6, completed: 5, efficiency: 83 },
    { date: "Sun", orders: 4, completed: 4, efficiency: 100 },
  ];

  const avgEfficiency = productionData.reduce((sum, day) => sum + day.efficiency, 0) / productionData.length;
  const trend = productionData[productionData.length - 1].efficiency > productionData[0].efficiency;

  return (
    <Card className="border-carbon-gray-20">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Activity className="w-5 h-5 text-carbon-blue" />
            <span>Production Analytics</span>
          </div>
          <div className="flex items-center space-x-2 text-sm">
            {trend ? (
              <TrendingUp className="w-4 h-4 text-green-600" />
            ) : (
              <TrendingDown className="w-4 h-4 text-red-600" />
            )}
            <span className={trend ? "text-green-600" : "text-red-600"}>
              {avgEfficiency.toFixed(1)}% avg
            </span>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {/* Production Volume Chart */}
          <div>
            <h4 className="text-sm font-medium text-carbon-gray-70 mb-3">Daily Production Volume</h4>
            <ResponsiveContainer width="100%" height={120}>
              <BarChart data={productionData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="date" fontSize={12} />
                <YAxis fontSize={12} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'white', 
                    border: '1px solid #e5e7eb',
                    borderRadius: '6px'
                  }}
                />
                <Bar dataKey="orders" fill="#0f62fe" name="Orders" />
                <Bar dataKey="completed" fill="#24a148" name="Completed" />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Efficiency Trend */}
          <div>
            <h4 className="text-sm font-medium text-carbon-gray-70 mb-3">Efficiency Trend</h4>
            <ResponsiveContainer width="100%" height={100}>
              <LineChart data={productionData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="date" fontSize={12} />
                <YAxis domain={[70, 100]} fontSize={12} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'white', 
                    border: '1px solid #e5e7eb',
                    borderRadius: '6px'
                  }}
                  formatter={(value) => [`${value}%`, 'Efficiency']}
                />
                <Line 
                  type="monotone" 
                  dataKey="efficiency" 
                  stroke="#0f62fe" 
                  strokeWidth={2}
                  dot={{ fill: '#0f62fe', strokeWidth: 2 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}