import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import Sidebar from "@/components/layout/sidebar";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  FileText, 
  BarChart3, 
  PieChart, 
  TrendingUp,
  Calendar,
  Download,
  Share,
  Eye,
  Edit,
  Trash2,
  Plus,
  Filter,
  Search,
  Clock,
  User,
  Mail,
  Printer,
  FileSpreadsheet,
  FileImage,
  Database,
  Layers,
  Grid,
  LineChart,
  Activity,
  Target,
  Zap,
  Package,
  Settings,
  Play,
  Pause,
  MoreHorizontal,
  CheckCircle,
  AlertCircle,
  Info
} from "lucide-react";

const reportSchema = z.object({
  name: z.string().min(1, "Report name is required"),
  description: z.string().min(1, "Description is required"),
  category: z.string().min(1, "Category is required"),
  type: z.enum(["chart", "table", "dashboard", "kpi"]),
  dataSource: z.string().min(1, "Data source is required"),
  visualization: z.string().min(1, "Visualization type is required"),
  filters: z.record(z.any()).optional(),
  schedule: z.object({
    enabled: z.boolean().default(false),
    frequency: z.enum(["daily", "weekly", "monthly", "quarterly"]).optional(),
    time: z.string().optional(),
    recipients: z.array(z.string()).optional(),
  }).optional(),
  isPublic: z.boolean().default(false),
});

interface Report {
  id: string;
  name: string;
  description: string;
  category: string;
  type: "chart" | "table" | "dashboard" | "kpi";
  dataSource: string;
  visualization: string;
  filters: Record<string, any>;
  schedule?: {
    enabled: boolean;
    frequency?: "daily" | "weekly" | "monthly" | "quarterly";
    time?: string;
    recipients?: string[];
  };
  isPublic: boolean;
  createdBy: string;
  lastRun?: string;
  status: "active" | "inactive" | "error";
  viewCount: number;
  exportCount: number;
  createdAt: string;
  updatedAt: string;
}

interface ReportTemplate {
  id: string;
  name: string;
  description: string;
  category: string;
  type: "chart" | "table" | "dashboard" | "kpi";
  previewImage: string;
  complexity: "simple" | "intermediate" | "advanced";
  estimatedTime: string;
  tags: string[];
  isPopular: boolean;
}

interface Dashboard {
  id: string;
  name: string;
  description: string;
  widgets: Array<{
    id: string;
    type: string;
    title: string;
    reportId: string;
    position: { x: number; y: number; w: number; h: number };
    config: Record<string, any>;
  }>;
  isDefault: boolean;
  shareSettings: {
    isPublic: boolean;
    allowedUsers: string[];
    allowExport: boolean;
  };
  refreshInterval: number; // minutes
  createdAt: string;
  updatedAt: string;
}

export default function Reports() {
  const [activeTab, setActiveTab] = useState("reports");
  const [isReportDialogOpen, setIsReportDialogOpen] = useState(false);
  const [isDashboardDialogOpen, setIsDashboardDialogOpen] = useState(false);
  const [selectedReport, setSelectedReport] = useState<Report | null>(null);
  const [filterCategory, setFilterCategory] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const reportForm = useForm<z.infer<typeof reportSchema>>({
    resolver: zodResolver(reportSchema),
    defaultValues: {
      type: "chart",
      isPublic: false,
      schedule: {
        enabled: false,
      },
    },
  });

  // Sample reports data
  const sampleReports: Report[] = [
    {
      id: "rpt_001",
      name: "Production Efficiency Dashboard",
      description: "Daily production metrics and efficiency KPIs",
      category: "production",
      type: "dashboard",
      dataSource: "production_orders",
      visualization: "multi_chart",
      filters: { dateRange: "last_30_days", department: "all" },
      schedule: {
        enabled: true,
        frequency: "daily",
        time: "08:00",
        recipients: ["manager@company.com", "production@company.com"]
      },
      isPublic: false,
      createdBy: "John Manager",
      lastRun: "2024-12-17 05:00:00",
      status: "active",
      viewCount: 156,
      exportCount: 23,
      createdAt: "2024-12-01 10:00:00",
      updatedAt: "2024-12-17 05:00:00"
    },
    {
      id: "rpt_002",
      name: "Inventory Stock Levels",
      description: "Current stock levels and low stock alerts",
      category: "inventory",
      type: "table",
      dataSource: "inventory_items",
      visualization: "data_table",
      filters: { stockStatus: "all", location: "all" },
      isPublic: true,
      createdBy: "Sarah Inventory",
      lastRun: "2024-12-17 04:30:00",
      status: "active",
      viewCount: 89,
      exportCount: 34,
      createdAt: "2024-12-01 10:00:00",
      updatedAt: "2024-12-17 04:30:00"
    },
    {
      id: "rpt_003",
      name: "Quality Control Metrics",
      description: "Quality inspection results and defect analysis",
      category: "quality",
      type: "chart",
      dataSource: "quality_control_logs",
      visualization: "line_chart",
      filters: { timeframe: "last_7_days", inspector: "all" },
      schedule: {
        enabled: true,
        frequency: "weekly",
        time: "09:00",
        recipients: ["quality@company.com"]
      },
      isPublic: false,
      createdBy: "Mike Quality",
      lastRun: "2024-12-16 09:00:00",
      status: "active",
      viewCount: 67,
      exportCount: 12,
      createdAt: "2024-12-01 10:00:00",
      updatedAt: "2024-12-16 09:00:00"
    },
    {
      id: "rpt_004",
      name: "Energy Consumption Analysis",
      description: "Energy usage patterns and cost optimization opportunities",
      category: "energy",
      type: "chart",
      dataSource: "energy_data",
      visualization: "area_chart",
      filters: { period: "last_month", department: "all" },
      isPublic: false,
      createdBy: "Tom Facilities",
      lastRun: "2024-12-17 03:00:00",
      status: "active",
      viewCount: 45,
      exportCount: 8,
      createdAt: "2024-12-05 10:00:00",
      updatedAt: "2024-12-17 03:00:00"
    },
    {
      id: "rpt_005",
      name: "Financial Performance Summary",
      description: "Revenue, costs, and profitability analysis",
      category: "financial",
      type: "kpi",
      dataSource: "financial_data",
      visualization: "kpi_cards",
      filters: { quarter: "Q4_2024", comparison: "previous_quarter" },
      schedule: {
        enabled: true,
        frequency: "monthly",
        time: "07:00",
        recipients: ["finance@company.com", "ceo@company.com"]
      },
      isPublic: false,
      createdBy: "Lisa Finance",
      status: "error",
      viewCount: 134,
      exportCount: 45,
      createdAt: "2024-12-01 10:00:00",
      updatedAt: "2024-12-15 07:00:00"
    }
  ];

  const sampleTemplates: ReportTemplate[] = [
    {
      id: "tpl_001",
      name: "Production Efficiency Report",
      description: "Track production output, efficiency rates, and bottlenecks",
      category: "production",
      type: "dashboard",
      previewImage: "/templates/production-efficiency.png",
      complexity: "intermediate",
      estimatedTime: "15 minutes",
      tags: ["production", "efficiency", "kpi", "real-time"],
      isPopular: true
    },
    {
      id: "tpl_002",
      name: "Inventory Turnover Analysis",
      description: "Analyze inventory turnover rates and stock optimization",
      category: "inventory",
      type: "chart",
      previewImage: "/templates/inventory-turnover.png",
      complexity: "simple",
      estimatedTime: "10 minutes",
      tags: ["inventory", "turnover", "optimization"],
      isPopular: true
    },
    {
      id: "tpl_003",
      name: "Quality Control Dashboard",
      description: "Monitor quality metrics, defect rates, and inspector performance",
      category: "quality",
      type: "dashboard",
      previewImage: "/templates/quality-control.png",
      complexity: "advanced",
      estimatedTime: "25 minutes",
      tags: ["quality", "defects", "inspection", "compliance"],
      isPopular: false
    },
    {
      id: "tpl_004",
      name: "Financial KPI Summary",
      description: "Executive summary of key financial performance indicators",
      category: "financial",
      type: "kpi",
      previewImage: "/templates/financial-kpi.png",
      complexity: "simple",
      estimatedTime: "8 minutes",
      tags: ["financial", "kpi", "executive", "summary"],
      isPopular: true
    },
    {
      id: "tpl_005",
      name: "Machine Utilization Report",
      description: "Track machine uptime, utilization rates, and maintenance schedules",
      category: "maintenance",
      type: "table",
      previewImage: "/templates/machine-utilization.png",
      complexity: "intermediate",
      estimatedTime: "12 minutes",
      tags: ["machines", "utilization", "maintenance", "uptime"],
      isPopular: false
    },
    {
      id: "tpl_006",
      name: "Supply Chain Analytics",
      description: "Comprehensive supply chain performance and supplier analysis",
      category: "supply_chain",
      type: "dashboard",
      previewImage: "/templates/supply-chain.png",
      complexity: "advanced",
      estimatedTime: "30 minutes",
      tags: ["supply_chain", "suppliers", "logistics", "performance"],
      isPopular: true
    }
  ];

  // Create report mutation
  const createReportMutation = useMutation({
    mutationFn: async (data: z.infer<typeof reportSchema>) => {
      return apiRequest("/api/reports", "POST", data);
    },
    onSuccess: () => {
      toast({
        title: "Report Created",
        description: "New report has been created successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/reports"] });
      setIsReportDialogOpen(false);
      reportForm.reset();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create report",
        variant: "destructive",
      });
    },
  });

  // Run report mutation
  const runReportMutation = useMutation({
    mutationFn: async (reportId: string) => {
      return apiRequest(`/api/reports/${reportId}/run`, "POST");
    },
    onSuccess: () => {
      toast({
        title: "Report Generated",
        description: "Report has been generated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/reports"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to generate report",
        variant: "destructive",
      });
    },
  });

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "production":
        return <Activity className="w-5 h-5 text-blue-600" />;
      case "inventory":
        return <Package className="w-5 h-5 text-green-600" />;
      case "quality":
        return <CheckCircle className="w-5 h-5 text-purple-600" />;
      case "energy":
        return <Zap className="w-5 h-5 text-yellow-600" />;
      case "financial":
        return <TrendingUp className="w-5 h-5 text-emerald-600" />;
      case "maintenance":
        return <Settings className="w-5 h-5 text-orange-600" />;
      case "supply_chain":
        return <Database className="w-5 h-5 text-indigo-600" />;
      default:
        return <FileText className="w-5 h-5 text-gray-600" />;
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "chart":
        return <BarChart3 className="w-4 h-4" />;
      case "table":
        return <Grid className="w-4 h-4" />;
      case "dashboard":
        return <Layers className="w-4 h-4" />;
      case "kpi":
        return <Target className="w-4 h-4" />;
      default:
        return <FileText className="w-4 h-4" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800";
      case "inactive":
        return "bg-gray-100 text-gray-800";
      case "error":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getComplexityColor = (complexity: string) => {
    switch (complexity) {
      case "simple":
        return "bg-green-100 text-green-800";
      case "intermediate":
        return "bg-yellow-100 text-yellow-800";
      case "advanced":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const filteredReports = sampleReports.filter(report => {
    const matchesCategory = filterCategory === "all" || report.category === filterCategory;
    const matchesSearch = searchTerm === "" || 
      report.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      report.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      report.category.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const reportStats = {
    total: sampleReports.length,
    active: sampleReports.filter(r => r.status === "active").length,
    scheduled: sampleReports.filter(r => r.schedule?.enabled).length,
    public: sampleReports.filter(r => r.isPublic).length,
    totalViews: sampleReports.reduce((sum, r) => sum + r.viewCount, 0)
  };

  const onReportSubmit = (data: z.infer<typeof reportSchema>) => {
    createReportMutation.mutate(data);
  };

  const handleRunReport = (reportId: string) => {
    runReportMutation.mutate(reportId);
  };

  const handleExportReport = (reportId: string, format: string) => {
    toast({
      title: "Export Started",
      description: `Exporting report in ${format.toUpperCase()} format...`,
    });
    // Implement export logic
  };

  return (
    <div className="flex h-screen bg-carbon-gray-10">
      <Sidebar />
      <div className="flex-1 overflow-auto">
        <div className="p-6 space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-carbon-gray-80">Reports & Analytics</h1>
              <p className="text-carbon-gray-60">Create, manage, and schedule comprehensive business reports</p>
            </div>
            <div className="flex items-center space-x-3">
              <Button variant="outline" onClick={() => setViewMode(viewMode === "grid" ? "list" : "grid")}>
                {viewMode === "grid" ? <Grid className="w-4 h-4" /> : <Layers className="w-4 h-4" />}
              </Button>
              <Button variant="outline" onClick={() => queryClient.invalidateQueries({ queryKey: ["/api/reports"] })}>
                <Activity className="w-4 h-4 mr-2" />
                Refresh
              </Button>
            </div>
          </div>

          {/* Overview Stats */}
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <FileText className="w-5 h-5 text-blue-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Total Reports</p>
                    <p className="text-xl font-bold">{reportStats.total}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Active</p>
                    <p className="text-xl font-bold">{reportStats.active}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Clock className="w-5 h-5 text-orange-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Scheduled</p>
                    <p className="text-xl font-bold">{reportStats.scheduled}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Share className="w-5 h-5 text-purple-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Public</p>
                    <p className="text-xl font-bold">{reportStats.public}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Eye className="w-5 h-5 text-indigo-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Total Views</p>
                    <p className="text-xl font-bold">{reportStats.totalViews.toLocaleString()}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
            <div className="flex items-center justify-between">
              <TabsList>
                <TabsTrigger value="reports">My Reports</TabsTrigger>
                <TabsTrigger value="templates">Templates</TabsTrigger>
                <TabsTrigger value="dashboards">Dashboards</TabsTrigger>
                <TabsTrigger value="builder">Report Builder</TabsTrigger>
                <TabsTrigger value="scheduled">Scheduled</TabsTrigger>
              </TabsList>
              <div className="flex space-x-2">
                {activeTab === "reports" && (
                  <Dialog open={isReportDialogOpen} onOpenChange={setIsReportDialogOpen}>
                    <DialogTrigger asChild>
                      <Button>
                        <Plus className="w-4 h-4 mr-2" />
                        New Report
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl">
                      <DialogHeader>
                        <DialogTitle>Create New Report</DialogTitle>
                      </DialogHeader>
                      <Form {...reportForm}>
                        <form onSubmit={reportForm.handleSubmit(onReportSubmit)} className="space-y-4">
                          <div className="grid grid-cols-2 gap-4">
                            <FormField
                              control={reportForm.control}
                              name="name"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Report Name</FormLabel>
                                  <FormControl>
                                    <Input {...field} />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={reportForm.control}
                              name="category"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Category</FormLabel>
                                  <FormControl>
                                    <Select onValueChange={field.onChange} value={field.value}>
                                      <SelectTrigger>
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="production">Production</SelectItem>
                                        <SelectItem value="inventory">Inventory</SelectItem>
                                        <SelectItem value="quality">Quality</SelectItem>
                                        <SelectItem value="energy">Energy</SelectItem>
                                        <SelectItem value="financial">Financial</SelectItem>
                                        <SelectItem value="maintenance">Maintenance</SelectItem>
                                        <SelectItem value="supply_chain">Supply Chain</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                          </div>
                          <FormField
                            control={reportForm.control}
                            name="description"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Description</FormLabel>
                                <FormControl>
                                  <Textarea {...field} />
                                </FormControl>
                              </FormItem>
                            )}
                          />
                          <div className="grid grid-cols-3 gap-4">
                            <FormField
                              control={reportForm.control}
                              name="type"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Report Type</FormLabel>
                                  <FormControl>
                                    <Select onValueChange={field.onChange} value={field.value}>
                                      <SelectTrigger>
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="chart">Chart</SelectItem>
                                        <SelectItem value="table">Table</SelectItem>
                                        <SelectItem value="dashboard">Dashboard</SelectItem>
                                        <SelectItem value="kpi">KPI</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={reportForm.control}
                              name="dataSource"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Data Source</FormLabel>
                                  <FormControl>
                                    <Select onValueChange={field.onChange} value={field.value}>
                                      <SelectTrigger>
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="production_orders">Production Orders</SelectItem>
                                        <SelectItem value="inventory_items">Inventory Items</SelectItem>
                                        <SelectItem value="quality_control_logs">Quality Control</SelectItem>
                                        <SelectItem value="energy_data">Energy Data</SelectItem>
                                        <SelectItem value="financial_data">Financial Data</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={reportForm.control}
                              name="visualization"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Visualization</FormLabel>
                                  <FormControl>
                                    <Select onValueChange={field.onChange} value={field.value}>
                                      <SelectTrigger>
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="bar_chart">Bar Chart</SelectItem>
                                        <SelectItem value="line_chart">Line Chart</SelectItem>
                                        <SelectItem value="pie_chart">Pie Chart</SelectItem>
                                        <SelectItem value="area_chart">Area Chart</SelectItem>
                                        <SelectItem value="data_table">Data Table</SelectItem>
                                        <SelectItem value="kpi_cards">KPI Cards</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                          </div>
                          <div className="flex justify-end space-x-2">
                            <Button type="button" variant="outline" onClick={() => setIsReportDialogOpen(false)}>
                              Cancel
                            </Button>
                            <Button type="submit" disabled={createReportMutation.isPending}>
                              {createReportMutation.isPending ? "Creating..." : "Create Report"}
                            </Button>
                          </div>
                        </form>
                      </Form>
                    </DialogContent>
                  </Dialog>
                )}
                {activeTab === "dashboards" && (
                  <Button onClick={() => setIsDashboardDialogOpen(true)}>
                    <Plus className="w-4 h-4 mr-2" />
                    New Dashboard
                  </Button>
                )}
              </div>
            </div>

            <TabsContent value="reports" className="space-y-4">
              {/* Filters */}
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      placeholder="Search reports..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10 w-64"
                    />
                  </div>
                  <Select value={filterCategory} onValueChange={setFilterCategory}>
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Categories</SelectItem>
                      <SelectItem value="production">Production</SelectItem>
                      <SelectItem value="inventory">Inventory</SelectItem>
                      <SelectItem value="quality">Quality</SelectItem>
                      <SelectItem value="energy">Energy</SelectItem>
                      <SelectItem value="financial">Financial</SelectItem>
                      <SelectItem value="maintenance">Maintenance</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Reports Grid/List */}
              <div className={viewMode === "grid" ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" : "space-y-4"}>
                {filteredReports.map((report) => (
                  <Card key={report.id} className="border-carbon-gray-20 hover:shadow-lg transition-shadow">
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          {getCategoryIcon(report.category)}
                          <div>
                            <CardTitle className="text-lg">{report.name}</CardTitle>
                            <p className="text-sm text-carbon-gray-60 capitalize">{report.category}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          {getTypeIcon(report.type)}
                          <Badge className={getStatusColor(report.status)}>
                            {report.status}
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <p className="text-sm text-gray-600">{report.description}</p>
                      
                      <div className="grid grid-cols-3 gap-2 text-xs text-gray-500">
                        <div>
                          <span className="font-medium">Views:</span> {report.viewCount}
                        </div>
                        <div>
                          <span className="font-medium">Exports:</span> {report.exportCount}
                        </div>
                        <div>
                          <span className="font-medium">Type:</span> {report.type}
                        </div>
                      </div>

                      {report.schedule?.enabled && (
                        <div className="flex items-center space-x-2 text-xs text-blue-600">
                          <Clock className="w-3 h-3" />
                          <span>Scheduled {report.schedule.frequency} at {report.schedule.time}</span>
                        </div>
                      )}

                      {report.lastRun && (
                        <p className="text-xs text-gray-500">
                          Last run: {report.lastRun}
                        </p>
                      )}

                      <div className="flex items-center justify-between pt-2 border-t">
                        <div className="flex space-x-1">
                          <Button size="sm" variant="outline" onClick={() => handleRunReport(report.id)}>
                            <Play className="w-3 h-3" />
                          </Button>
                          <Button size="sm" variant="outline">
                            <Eye className="w-3 h-3" />
                          </Button>
                          <Button size="sm" variant="outline">
                            <Edit className="w-3 h-3" />
                          </Button>
                        </div>
                        <div className="flex space-x-1">
                          <Button size="sm" variant="outline" onClick={() => handleExportReport(report.id, "pdf")}>
                            <Download className="w-3 h-3" />
                          </Button>
                          <Button size="sm" variant="outline">
                            <Share className="w-3 h-3" />
                          </Button>
                          <Button size="sm" variant="outline">
                            <MoreHorizontal className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="templates" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {sampleTemplates.map((template) => (
                  <Card key={template.id} className="border-carbon-gray-20 hover:shadow-lg transition-shadow cursor-pointer">
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          {getCategoryIcon(template.category)}
                          <div>
                            <CardTitle className="text-lg">{template.name}</CardTitle>
                            <p className="text-sm text-carbon-gray-60 capitalize">{template.category}</p>
                          </div>
                        </div>
                        {template.isPopular && (
                          <Badge className="bg-yellow-100 text-yellow-800">
                            Popular
                          </Badge>
                        )}
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <p className="text-sm text-gray-600">{template.description}</p>
                      
                      <div className="flex items-center justify-between text-xs">
                        <Badge className={getComplexityColor(template.complexity)}>
                          {template.complexity}
                        </Badge>
                        <span className="text-gray-500">{template.estimatedTime}</span>
                      </div>

                      <div className="flex flex-wrap gap-1">
                        {template.tags.slice(0, 3).map((tag, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                        {template.tags.length > 3 && (
                          <Badge variant="outline" className="text-xs">
                            +{template.tags.length - 3}
                          </Badge>
                        )}
                      </div>

                      <div className="flex space-x-2 pt-2 border-t">
                        <Button size="sm" className="flex-1">
                          <Plus className="w-3 h-3 mr-2" />
                          Use Template
                        </Button>
                        <Button size="sm" variant="outline">
                          <Eye className="w-3 h-3" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="dashboards" className="space-y-4">
              <div className="text-center py-12">
                <Layers className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No Dashboards Yet</h3>
                <p className="text-gray-600 mb-4">Create your first dashboard to combine multiple reports in one view</p>
                <Button onClick={() => setIsDashboardDialogOpen(true)}>
                  <Plus className="w-4 h-4 mr-2" />
                  Create Dashboard
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="builder" className="space-y-4">
              <div className="text-center py-12">
                <Settings className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">Report Builder</h3>
                <p className="text-gray-600 mb-4">Drag-and-drop interface for creating custom reports</p>
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Launch Builder
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="scheduled" className="space-y-4">
              <div className="space-y-4">
                {sampleReports.filter(r => r.schedule?.enabled).map((report) => (
                  <Card key={report.id} className="border-carbon-gray-20">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            {getCategoryIcon(report.category)}
                            <h4 className="font-medium">{report.name}</h4>
                            <Badge className={getStatusColor(report.status)}>
                              {report.status}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-600 mb-2">{report.description}</p>
                          <div className="flex items-center space-x-4 text-sm text-gray-500">
                            <div className="flex items-center space-x-1">
                              <Clock className="w-3 h-3" />
                              <span>{report.schedule?.frequency} at {report.schedule?.time}</span>
                            </div>
                            <div className="flex items-center space-x-1">
                              <Mail className="w-3 h-3" />
                              <span>{report.schedule?.recipients?.length} recipients</span>
                            </div>
                            <span>Last run: {report.lastRun}</span>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Switch 
                            checked={report.schedule?.enabled}
                            onCheckedChange={() => {/* Handle toggle */}}
                          />
                          <Button variant="outline" size="sm">
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button variant="outline" size="sm" onClick={() => handleRunReport(report.id)}>
                            <Play className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}