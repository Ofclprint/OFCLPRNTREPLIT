import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  Area,
  AreaChart,
  PieChart,
  Pie,
  Cell
} from "recharts";
import {
  Calendar as CalendarIcon,
  Clock,
  Users,
  Zap,
  Target,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Play,
  Pause,
  RotateCcw,
  Settings,
  Plus,
  Edit,
  Eye,
  Trash2,
  Filter,
  Search,
  Download,
  Brain,
  Activity,
  BarChart3,
  TrendingUp,
  Factory,
  Wrench
} from "lucide-react";
import { format, addDays, startOfWeek, endOfWeek, eachDayOfInterval, isSameDay, parseISO } from "date-fns";

interface Resource {
  id: string;
  name: string;
  type: "machine" | "worker" | "workstation" | "tool";
  status: "available" | "busy" | "maintenance" | "offline";
  capacity: number;
  currentLoad: number;
  efficiency: number;
  skills?: string[];
  shiftPattern: string;
  hourlyRate?: number;
  location: string;
  utilizationRate: number;
}

interface ScheduledJob {
  id: string;
  jobNumber: string;
  productName: string;
  priority: "low" | "medium" | "high" | "urgent";
  status: "scheduled" | "in_progress" | "completed" | "delayed" | "cancelled";
  resourceId: string;
  resourceName: string;
  startTime: Date;
  endTime: Date;
  estimatedDuration: number;
  actualDuration?: number;
  dependencies: string[];
  completionPercent: number;
  assignedWorkers: string[];
  setupTime: number;
  teardownTime: number;
  skillsRequired: string[];
}

interface SchedulingMetrics {
  totalJobs: number;
  scheduledJobs: number;
  completedJobs: number;
  delayedJobs: number;
  averageUtilization: number;
  onTimeDelivery: number;
  resourceEfficiency: number;
  scheduleOptimization: number;
  bottleneckResources: number;
}

interface TimeSlot {
  start: Date;
  end: Date;
  resourceId: string;
  jobId?: string;
  status: "available" | "scheduled" | "maintenance" | "break";
}

export default function SmartScheduling() {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [selectedResource, setSelectedResource] = useState("all");
  const [viewMode, setViewMode] = useState<"day" | "week" | "month">("week");
  const [autoScheduling, setAutoScheduling] = useState(true);
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [showJobDialog, setShowJobDialog] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const sampleResources: Resource[] = [
    {
      id: "R001",
      name: "CNC Machine Alpha",
      type: "machine",
      status: "busy",
      capacity: 100,
      currentLoad: 85,
      efficiency: 94.2,
      shiftPattern: "24x7",
      location: "Production Floor A",
      utilizationRate: 87.5
    },
    {
      id: "R002",
      name: "Assembly Station 1",
      type: "workstation",
      status: "available",
      capacity: 50,
      currentLoad: 30,
      efficiency: 89.8,
      shiftPattern: "8x5",
      location: "Assembly Line",
      utilizationRate: 72.3
    },
    {
      id: "R003",
      name: "John Smith",
      type: "worker",
      status: "busy",
      capacity: 8,
      currentLoad: 7,
      efficiency: 96.5,
      skills: ["Machining", "Quality Control", "Setup"],
      shiftPattern: "8x5",
      hourlyRate: 28.50,
      location: "Production Floor A",
      utilizationRate: 91.2
    },
    {
      id: "R004",
      name: "Hydraulic Press",
      type: "machine",
      status: "maintenance",
      capacity: 80,
      currentLoad: 0,
      efficiency: 92.1,
      shiftPattern: "16x6",
      location: "Production Floor B",
      utilizationRate: 78.9
    }
  ];

  const sampleJobs: ScheduledJob[] = [
    {
      id: "J001",
      jobNumber: "JOB-2025-001",
      productName: "Widget Pro Assembly",
      priority: "high",
      status: "in_progress",
      resourceId: "R001",
      resourceName: "CNC Machine Alpha",
      startTime: new Date(2025, 5, 17, 8, 0),
      endTime: new Date(2025, 5, 17, 12, 0),
      estimatedDuration: 4,
      actualDuration: 3.5,
      dependencies: [],
      completionPercent: 75,
      assignedWorkers: ["John Smith", "Sarah Johnson"],
      setupTime: 0.5,
      teardownTime: 0.5,
      skillsRequired: ["Machining", "Quality Control"]
    },
    {
      id: "J002",
      jobNumber: "JOB-2025-002",
      productName: "Component X Manufacturing",
      priority: "medium",
      status: "scheduled",
      resourceId: "R002",
      resourceName: "Assembly Station 1",
      startTime: new Date(2025, 5, 17, 14, 0),
      endTime: new Date(2025, 5, 17, 18, 0),
      estimatedDuration: 4,
      dependencies: ["J001"],
      completionPercent: 0,
      assignedWorkers: ["Mike Davis"],
      setupTime: 1,
      teardownTime: 0.5,
      skillsRequired: ["Assembly", "Testing"]
    },
    {
      id: "J003",
      jobNumber: "JOB-2025-003",
      productName: "Quality Inspection Batch",
      priority: "urgent",
      status: "delayed",
      resourceId: "R003",
      resourceName: "John Smith",
      startTime: new Date(2025, 5, 17, 10, 0),
      endTime: new Date(2025, 5, 17, 16, 0),
      estimatedDuration: 6,
      dependencies: [],
      completionPercent: 25,
      assignedWorkers: ["John Smith"],
      setupTime: 0,
      teardownTime: 0,
      skillsRequired: ["Quality Control", "Documentation"]
    }
  ];

  const schedulingMetrics: SchedulingMetrics = {
    totalJobs: 125,
    scheduledJobs: 98,
    completedJobs: 87,
    delayedJobs: 8,
    averageUtilization: 84.7,
    onTimeDelivery: 92.4,
    resourceEfficiency: 89.6,
    scheduleOptimization: 91.8,
    bottleneckResources: 3
  };

  const utilizationData = [
    { hour: "06:00", utilization: 45, efficiency: 92 },
    { hour: "07:00", utilization: 78, efficiency: 94 },
    { hour: "08:00", utilization: 92, efficiency: 96 },
    { hour: "09:00", utilization: 95, efficiency: 94 },
    { hour: "10:00", utilization: 89, efficiency: 93 },
    { hour: "11:00", utilization: 87, efficiency: 95 },
    { hour: "12:00", utilization: 65, efficiency: 88 },
    { hour: "13:00", utilization: 82, efficiency: 91 },
    { hour: "14:00", utilization: 91, efficiency: 94 },
    { hour: "15:00", utilization: 88, efficiency: 92 },
    { hour: "16:00", utilization: 85, efficiency: 90 },
    { hour: "17:00", utilization: 72, efficiency: 87 }
  ];

  const weeklySchedule = [
    { day: "Mon", scheduled: 24, completed: 22, efficiency: 91.7 },
    { day: "Tue", scheduled: 26, completed: 25, efficiency: 96.2 },
    { day: "Wed", scheduled: 23, completed: 21, efficiency: 91.3 },
    { day: "Thu", scheduled: 25, completed: 24, efficiency: 96.0 },
    { day: "Fri", scheduled: 22, completed: 20, efficiency: 90.9 },
    { day: "Sat", scheduled: 18, completed: 17, efficiency: 94.4 },
    { day: "Sun", scheduled: 12, completed: 11, efficiency: 91.7 }
  ];

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

  const filteredJobs = sampleJobs.filter(job => {
    const resourceMatch = selectedResource === "all" || job.resourceId === selectedResource;
    return resourceMatch;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "scheduled": return "bg-blue-100 text-blue-800";
      case "in_progress": return "bg-green-100 text-green-800";
      case "completed": return "bg-emerald-100 text-emerald-800";
      case "delayed": return "bg-red-100 text-red-800";
      case "cancelled": return "bg-gray-100 text-gray-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "low": return "bg-gray-100 text-gray-800";
      case "medium": return "bg-blue-100 text-blue-800";
      case "high": return "bg-orange-100 text-orange-800";
      case "urgent": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getResourceStatusColor = (status: string) => {
    switch (status) {
      case "available": return "text-green-600";
      case "busy": return "text-blue-600";
      case "maintenance": return "text-orange-600";
      case "offline": return "text-red-600";
      default: return "text-gray-600";
    }
  };

  const runOptimization = async () => {
    setIsOptimizing(true);
    // Simulate AI optimization
    await new Promise(resolve => setTimeout(resolve, 4000));
    setIsOptimizing(false);
    toast({
      title: "Schedule Optimized",
      description: "AI optimization improved resource utilization by 12%",
    });
  };

  const createJob = (jobData: Partial<ScheduledJob>) => {
    toast({
      title: "Job Scheduled",
      description: "New job has been added to the schedule",
    });
    setShowJobDialog(false);
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-3xl font-bold mb-2">Smart Scheduling & Resource Allocation</h1>
          <p className="text-gray-600">
            AI-powered production scheduling with real-time resource optimization
          </p>
        </div>
        <div className="flex gap-2">
          <div className="flex items-center space-x-2">
            <Switch
              checked={autoScheduling}
              onCheckedChange={setAutoScheduling}
            />
            <Label>Auto Scheduling</Label>
          </div>
          <Button 
            onClick={runOptimization} 
            disabled={isOptimizing}
            variant="outline"
          >
            {isOptimizing ? (
              <RotateCcw className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Brain className="w-4 h-4 mr-2" />
            )}
            {isOptimizing ? "Optimizing..." : "AI Optimize"}
          </Button>
          <Button onClick={() => setShowJobDialog(true)}>
            <Plus className="w-4 h-4 mr-2" />
            Schedule Job
          </Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Resource Utilization</p>
                <p className="text-2xl font-bold text-blue-600">{schedulingMetrics.averageUtilization}%</p>
                <p className="text-xs text-green-600">+5.2% vs last week</p>
              </div>
              <BarChart3 className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">On-Time Delivery</p>
                <p className="text-2xl font-bold text-green-600">{schedulingMetrics.onTimeDelivery}%</p>
                <p className="text-xs text-gray-500">Target: 95%</p>
              </div>
              <Target className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Delayed Jobs</p>
                <p className="text-2xl font-bold text-orange-600">{schedulingMetrics.delayedJobs}</p>
                <p className="text-xs text-gray-500">{schedulingMetrics.totalJobs} total jobs</p>
              </div>
              <AlertTriangle className="w-8 h-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Schedule Efficiency</p>
                <p className="text-2xl font-bold text-purple-600">{schedulingMetrics.scheduleOptimization}%</p>
                <p className="text-xs text-green-600">AI optimized</p>
              </div>
              <Zap className="w-8 h-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="schedule" className="space-y-4">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="schedule">Schedule</TabsTrigger>
          <TabsTrigger value="resources">Resources</TabsTrigger>
          <TabsTrigger value="jobs">Jobs</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="optimization">Optimization</TabsTrigger>
        </TabsList>

        <TabsContent value="schedule" className="space-y-4">
          {/* View Controls */}
          <div className="flex items-center justify-between">
            <div className="flex gap-4 items-center">
              <Select value={viewMode} onValueChange={(value: "day" | "week" | "month") => setViewMode(value)}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="day">Day View</SelectItem>
                  <SelectItem value="week">Week View</SelectItem>
                  <SelectItem value="month">Month View</SelectItem>
                </SelectContent>
              </Select>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {format(selectedDate, "PPP")}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={selectedDate}
                    onSelect={(date) => date && setSelectedDate(date)}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm">
                <Download className="w-4 h-4 mr-2" />
                Export
              </Button>
            </div>
          </div>

          {/* Schedule Grid */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <CalendarIcon className="w-5 h-5 mr-2" />
                Production Schedule - {viewMode} View
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4">
                {/* Timeline Header */}
                <div className="grid grid-cols-13 gap-2 text-sm font-medium text-gray-600 border-b pb-2">
                  <div>Resource</div>
                  {Array.from({ length: 12 }, (_, i) => (
                    <div key={i} className="text-center">
                      {String(6 + i).padStart(2, '0')}:00
                    </div>
                  ))}
                </div>

                {/* Resource Rows */}
                {sampleResources.map((resource) => (
                  <div key={resource.id} className="grid grid-cols-13 gap-2 items-center py-2 border-b">
                    <div className="font-medium">
                      <div className="flex items-center gap-2">
                        {resource.type === "machine" && <Factory className="w-4 h-4" />}
                        {resource.type === "worker" && <Users className="w-4 h-4" />}
                        {resource.type === "workstation" && <Wrench className="w-4 h-4" />}
                        <span className="text-sm">{resource.name}</span>
                      </div>
                      <div className={`text-xs ${getResourceStatusColor(resource.status)}`}>
                        {resource.status}
                      </div>
                    </div>
                    
                    {/* Time Slots */}
                    {Array.from({ length: 12 }, (_, i) => {
                      const hour = 6 + i;
                      const job = sampleJobs.find(j => 
                        j.resourceId === resource.id && 
                        j.startTime.getHours() <= hour && 
                        j.endTime.getHours() > hour
                      );
                      
                      return (
                        <div key={i} className="h-12 relative">
                          {job ? (
                            <div className={`h-full rounded text-xs p-1 ${getStatusColor(job.status)} border`}>
                              <div className="font-medium truncate">{job.productName}</div>
                              <div className="text-xs opacity-75">{job.completionPercent}%</div>
                            </div>
                          ) : resource.status === "available" ? (
                            <div className="h-full bg-green-50 border border-green-200 rounded opacity-50"></div>
                          ) : resource.status === "maintenance" ? (
                            <div className="h-full bg-orange-50 border border-orange-200 rounded opacity-50"></div>
                          ) : (
                            <div className="h-full bg-gray-50 border border-gray-200 rounded opacity-30"></div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="resources" className="space-y-4">
          <div className="grid gap-4">
            {sampleResources.map((resource) => (
              <Card key={resource.id}>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        {resource.type === "machine" && <Factory className="w-5 h-5" />}
                        {resource.type === "worker" && <Users className="w-5 h-5" />}
                        {resource.type === "workstation" && <Wrench className="w-5 h-5" />}
                        <h3 className="font-semibold text-lg">{resource.name}</h3>
                        <Badge variant="outline">{resource.type}</Badge>
                        <Badge className={getResourceStatusColor(resource.status)}>
                          {resource.status}
                        </Badge>
                      </div>
                      
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm mb-4">
                        <div>
                          <p className="text-gray-500">Capacity</p>
                          <p className="font-medium">{resource.capacity} units/day</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Current Load</p>
                          <p className="font-medium">{resource.currentLoad} units</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Efficiency</p>
                          <p className="font-medium">{resource.efficiency}%</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Utilization</p>
                          <p className="font-medium">{resource.utilizationRate}%</p>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm mb-4">
                        <div>
                          <p className="text-gray-500">Shift Pattern</p>
                          <p className="font-medium">{resource.shiftPattern}</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Location</p>
                          <p className="font-medium">{resource.location}</p>
                        </div>
                        {resource.hourlyRate && (
                          <div>
                            <p className="text-gray-500">Hourly Rate</p>
                            <p className="font-medium">${resource.hourlyRate}</p>
                          </div>
                        )}
                      </div>

                      {resource.skills && (
                        <div className="mb-4">
                          <p className="text-gray-500 text-sm mb-1">Skills:</p>
                          <div className="flex flex-wrap gap-1">
                            {resource.skills.map((skill, index) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {skill}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}

                      <div className="mb-2">
                        <div className="flex justify-between text-sm mb-1">
                          <span>Current Utilization</span>
                          <span>{resource.utilizationRate}%</span>
                        </div>
                        <Progress value={resource.utilizationRate} className="h-2" />
                      </div>
                    </div>
                    
                    <div className="flex gap-2 ml-4">
                      <Button size="sm" variant="outline">
                        <Eye className="w-4 h-4" />
                      </Button>
                      <Button size="sm" variant="outline">
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button size="sm" variant="outline">
                        <Settings className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="jobs" className="space-y-4">
          {/* Filters */}
          <div className="flex flex-wrap gap-4 items-center">
            <Select value={selectedResource} onValueChange={setSelectedResource}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Select resource" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Resources</SelectItem>
                {sampleResources.map((resource) => (
                  <SelectItem key={resource.id} value={resource.id}>
                    {resource.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Jobs List */}
          <div className="space-y-4">
            {filteredJobs.map((job) => (
              <Card key={job.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <Clock className="w-5 h-5" />
                        <h3 className="font-semibold text-lg">{job.productName}</h3>
                        <Badge variant="outline">{job.jobNumber}</Badge>
                        <Badge className={getStatusColor(job.status)}>
                          {job.status.replace('_', ' ')}
                        </Badge>
                        <Badge className={getPriorityColor(job.priority)}>
                          {job.priority}
                        </Badge>
                      </div>
                      
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm mb-4">
                        <div>
                          <p className="text-gray-500">Resource</p>
                          <p className="font-medium">{job.resourceName}</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Start Time</p>
                          <p className="font-medium">{format(job.startTime, "MMM dd, HH:mm")}</p>
                        </div>
                        <div>
                          <p className="text-gray-500">End Time</p>
                          <p className="font-medium">{format(job.endTime, "MMM dd, HH:mm")}</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Duration</p>
                          <p className="font-medium">
                            {job.actualDuration || job.estimatedDuration}h
                            {job.actualDuration && job.actualDuration !== job.estimatedDuration && 
                              <span className="text-gray-400"> (est. {job.estimatedDuration}h)</span>
                            }
                          </p>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm mb-4">
                        <div>
                          <p className="text-gray-500">Assigned Workers</p>
                          <p className="font-medium">{job.assignedWorkers.join(", ")}</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Setup Time</p>
                          <p className="font-medium">{job.setupTime}h</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Dependencies</p>
                          <p className="font-medium">
                            {job.dependencies.length > 0 ? job.dependencies.join(", ") : "None"}
                          </p>
                        </div>
                      </div>

                      {job.skillsRequired.length > 0 && (
                        <div className="mb-4">
                          <p className="text-gray-500 text-sm mb-1">Skills Required:</p>
                          <div className="flex flex-wrap gap-1">
                            {job.skillsRequired.map((skill, index) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {skill}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}

                      <div className="mb-2">
                        <div className="flex justify-between text-sm mb-1">
                          <span>Progress</span>
                          <span>{job.completionPercent}%</span>
                        </div>
                        <Progress value={job.completionPercent} className="h-2" />
                      </div>
                    </div>
                    
                    <div className="flex gap-2 ml-4">
                      <Button size="sm" variant="outline">
                        <Eye className="w-4 h-4" />
                      </Button>
                      <Button size="sm" variant="outline">
                        <Edit className="w-4 h-4" />
                      </Button>
                      {job.status === "scheduled" && (
                        <Button size="sm" className="bg-green-600 hover:bg-green-700">
                          <Play className="w-4 h-4" />
                        </Button>
                      )}
                      {job.status === "in_progress" && (
                        <Button size="sm" variant="outline">
                          <Pause className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Hourly Utilization */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BarChart3 className="w-5 h-5 mr-2" />
                  Hourly Resource Utilization
                </CardTitle>
                <CardDescription>Real-time utilization and efficiency tracking</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <AreaChart data={utilizationData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="hour" />
                    <YAxis />
                    <Tooltip />
                    <Area type="monotone" dataKey="utilization" stroke="#8884d8" fill="#8884d8" fillOpacity={0.3} />
                    <Line type="monotone" dataKey="efficiency" stroke="#82ca9d" strokeWidth={2} />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Weekly Performance */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <TrendingUp className="w-5 h-5 mr-2" />
                  Weekly Schedule Performance
                </CardTitle>
                <CardDescription>Jobs scheduled vs completed by day</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <BarChart data={weeklySchedule}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="day" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="scheduled" fill="#8884d8" name="Scheduled" />
                    <Bar dataKey="completed" fill="#82ca9d" name="Completed" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Performance Metrics */}
          <Card>
            <CardHeader>
              <CardTitle>Schedule Performance Metrics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <h4 className="font-semibold text-blue-600">Resource Efficiency</h4>
                  <p className="text-2xl font-bold">{schedulingMetrics.resourceEfficiency}%</p>
                  <p className="text-sm text-gray-600">Average across all resources</p>
                  <Progress value={schedulingMetrics.resourceEfficiency} className="h-2" />
                </div>
                
                <div className="space-y-2">
                  <h4 className="font-semibold text-green-600">On-Time Delivery</h4>
                  <p className="text-2xl font-bold">{schedulingMetrics.onTimeDelivery}%</p>
                  <p className="text-sm text-gray-600">Jobs completed on schedule</p>
                  <Progress value={schedulingMetrics.onTimeDelivery} className="h-2" />
                </div>
                
                <div className="space-y-2">
                  <h4 className="font-semibold text-purple-600">Schedule Optimization</h4>
                  <p className="text-2xl font-bold">{schedulingMetrics.scheduleOptimization}%</p>
                  <p className="text-sm text-gray-600">AI optimization score</p>
                  <Progress value={schedulingMetrics.scheduleOptimization} className="h-2" />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="optimization" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>AI Optimization Settings</CardTitle>
              <CardDescription>Configure automatic scheduling parameters</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Automatic Scheduling</Label>
                    <p className="text-sm text-gray-600">Enable AI-powered automatic job scheduling</p>
                  </div>
                  <Switch checked={autoScheduling} onCheckedChange={setAutoScheduling} />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Optimization Frequency</Label>
                    <Select defaultValue="hourly">
                      <SelectTrigger className="mt-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="realtime">Real-time</SelectItem>
                        <SelectItem value="hourly">Hourly</SelectItem>
                        <SelectItem value="daily">Daily</SelectItem>
                        <SelectItem value="manual">Manual</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Priority Weight</Label>
                    <Select defaultValue="balanced">
                      <SelectTrigger className="mt-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="efficiency">Efficiency First</SelectItem>
                        <SelectItem value="balanced">Balanced</SelectItem>
                        <SelectItem value="deadline">Deadline First</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Resource Utilization Target (%)</Label>
                    <Input type="number" defaultValue="85" className="mt-1" />
                  </div>
                  <div>
                    <Label>Setup Time Buffer (minutes)</Label>
                    <Input type="number" defaultValue="15" className="mt-1" />
                  </div>
                </div>
                
                <div className="flex gap-4">
                  <Button onClick={runOptimization} disabled={isOptimizing}>
                    {isOptimizing ? (
                      <RotateCcw className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Brain className="w-4 h-4 mr-2" />
                    )}
                    {isOptimizing ? "Optimizing..." : "Run Optimization"}
                  </Button>
                  <Button variant="outline">
                    Reset to Default
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Schedule Job Dialog */}
      <Dialog open={showJobDialog} onOpenChange={setShowJobDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Schedule New Job</DialogTitle>
            <DialogDescription>
              Add a new job to the production schedule
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="jobNumber">Job Number</Label>
                <Input placeholder="JOB-2025-004" />
              </div>
              <div>
                <Label htmlFor="productName">Product Name</Label>
                <Input placeholder="Widget Assembly" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="resource">Resource</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select resource" />
                  </SelectTrigger>
                  <SelectContent>
                    {sampleResources.filter(r => r.status === "available").map((resource) => (
                      <SelectItem key={resource.id} value={resource.id}>
                        {resource.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="priority">Priority</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select priority" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="urgent">Urgent</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="estimatedDuration">Estimated Duration (hours)</Label>
                <Input type="number" placeholder="4" />
              </div>
              <div>
                <Label htmlFor="setupTime">Setup Time (hours)</Label>
                <Input type="number" placeholder="0.5" />
              </div>
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setShowJobDialog(false)}>
              Cancel
            </Button>
            <Button onClick={() => createJob({})}>
              Schedule Job
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}