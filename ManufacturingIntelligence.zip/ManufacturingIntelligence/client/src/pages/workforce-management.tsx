import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Calendar } from "@/components/ui/calendar";
import { Progress } from "@/components/ui/progress";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import Sidebar from "@/components/layout/sidebar";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  Users, 
  Clock, 
  Calendar as CalendarIcon,
  UserCheck,
  UserX,
  Award,
  TrendingUp,
  TrendingDown,
  Plus,
  Edit,
  Eye,
  BarChart3,
  Target,
  AlertTriangle,
  CheckCircle,
  MapPin,
  Phone,
  Mail,
  Briefcase,
  DollarSign
} from "lucide-react";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from "recharts";

const employeeSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  email: z.string().email("Valid email is required"),
  phone: z.string().min(1, "Phone is required"),
  department: z.string().min(1, "Department is required"),
  position: z.string().min(1, "Position is required"),
  hireDate: z.string().min(1, "Hire date is required"),
  salary: z.number().min(0, "Salary must be positive"),
  skills: z.array(z.string()).optional(),
});

const shiftSchema = z.object({
  employeeId: z.string().min(1, "Employee is required"),
  date: z.string().min(1, "Date is required"),
  startTime: z.string().min(1, "Start time is required"),
  endTime: z.string().min(1, "End time is required"),
  department: z.string().min(1, "Department is required"),
  notes: z.string().optional(),
});

interface Employee {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  department: string;
  position: string;
  hireDate: string;
  salary: number;
  status: "active" | "inactive" | "on_leave";
  performance: number;
  attendance: number;
  skills: string[];
  hoursWorked: number;
  overtimeHours: number;
  lastLogin: string;
}

interface Shift {
  id: string;
  employeeId: string;
  employeeName: string;
  date: string;
  startTime: string;
  endTime: string;
  department: string;
  status: "scheduled" | "in_progress" | "completed" | "no_show";
  hoursWorked?: number;
  notes?: string;
}

interface PerformanceRecord {
  id: string;
  employeeId: string;
  employeeName: string;
  period: string;
  productivityScore: number;
  qualityScore: number;
  attendanceScore: number;
  overallScore: number;
  goals: Array<{
    description: string;
    target: number;
    achieved: number;
    status: "achieved" | "in_progress" | "missed";
  }>;
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

export default function WorkforceManagement() {
  const [activeTab, setActiveTab] = useState("employees");
  const [isEmployeeDialogOpen, setIsEmployeeDialogOpen] = useState(false);
  const [isShiftDialogOpen, setIsShiftDialogOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [selectedDepartment, setSelectedDepartment] = useState("all");
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const employeeForm = useForm<z.infer<typeof employeeSchema>>({
    resolver: zodResolver(employeeSchema),
  });

  const shiftForm = useForm<z.infer<typeof shiftSchema>>({
    resolver: zodResolver(shiftSchema),
  });

  // Fetch employees
  const { data: employees, isLoading: loadingEmployees } = useQuery({
    queryKey: ["/api/employees"],
    staleTime: 5 * 60 * 1000,
  });

  // Sample employee data
  const sampleEmployees: Employee[] = [
    {
      id: "E001",
      firstName: "John",
      lastName: "Smith",
      email: "john.smith@company.com",
      phone: "+1-555-0123",
      department: "Production",
      position: "Machine Operator",
      hireDate: "2023-03-15",
      salary: 45000,
      status: "active",
      performance: 88,
      attendance: 95,
      skills: ["CNC Operation", "Quality Control", "Safety Protocols"],
      hoursWorked: 168,
      overtimeHours: 12,
      lastLogin: "2024-12-16 08:30"
    },
    {
      id: "E002",
      firstName: "Sarah",
      lastName: "Johnson",
      email: "sarah.johnson@company.com",
      phone: "+1-555-0456",
      department: "Quality Control",
      position: "QC Inspector",
      hireDate: "2022-08-20",
      salary: 52000,
      status: "active",
      performance: 92,
      attendance: 98,
      skills: ["Statistical Analysis", "ISO Standards", "Documentation"],
      hoursWorked: 160,
      overtimeHours: 4,
      lastLogin: "2024-12-16 07:45"
    },
    {
      id: "E003",
      firstName: "Mike",
      lastName: "Wilson",
      email: "mike.wilson@company.com",
      phone: "+1-555-0789",
      department: "Maintenance",
      position: "Maintenance Technician",
      hireDate: "2021-11-10",
      salary: 48000,
      status: "active",
      performance: 85,
      attendance: 90,
      skills: ["Electrical", "Mechanical", "Troubleshooting"],
      hoursWorked: 170,
      overtimeHours: 18,
      lastLogin: "2024-12-15 16:20"
    },
    {
      id: "E004",
      firstName: "Lisa",
      lastName: "Brown",
      email: "lisa.brown@company.com",
      phone: "+1-555-0321",
      department: "Production",
      position: "Production Supervisor",
      hireDate: "2020-05-03",
      salary: 65000,
      status: "on_leave",
      performance: 94,
      attendance: 96,
      skills: ["Leadership", "Process Optimization", "Team Management"],
      hoursWorked: 0,
      overtimeHours: 0,
      lastLogin: "2024-12-01 17:30"
    }
  ];

  const sampleShifts: Shift[] = [
    {
      id: "S001",
      employeeId: "E001",
      employeeName: "John Smith",
      date: "2024-12-16",
      startTime: "08:00",
      endTime: "16:00",
      department: "Production",
      status: "in_progress",
      notes: "Regular shift on Line A"
    },
    {
      id: "S002",
      employeeId: "E002",
      employeeName: "Sarah Johnson",
      date: "2024-12-16",
      startTime: "07:00",
      endTime: "15:00",
      department: "Quality Control",
      status: "completed",
      hoursWorked: 8
    },
    {
      id: "S003",
      employeeId: "E003",
      employeeName: "Mike Wilson",
      date: "2024-12-16",
      startTime: "16:00",
      endTime: "00:00",
      department: "Maintenance",
      status: "scheduled"
    }
  ];

  const samplePerformance: PerformanceRecord[] = [
    {
      id: "P001",
      employeeId: "E001",
      employeeName: "John Smith",
      period: "2024-Q4",
      productivityScore: 88,
      qualityScore: 92,
      attendanceScore: 95,
      overallScore: 91,
      goals: [
        { description: "Reduce defect rate", target: 2, achieved: 1.5, status: "achieved" },
        { description: "Complete safety training", target: 100, achieved: 100, status: "achieved" },
        { description: "Improve efficiency", target: 90, achieved: 88, status: "in_progress" }
      ]
    }
  ];

  // Performance trend data
  const performanceTrends = [
    { month: 'Jan', productivity: 85, quality: 88, attendance: 92 },
    { month: 'Feb', productivity: 87, quality: 90, attendance: 94 },
    { month: 'Mar', productivity: 89, quality: 89, attendance: 96 },
    { month: 'Apr', productivity: 88, quality: 92, attendance: 95 },
    { month: 'May', productivity: 90, quality: 94, attendance: 93 },
    { month: 'Jun', productivity: 92, quality: 91, attendance: 97 }
  ];

  // Department distribution
  const departmentData = [
    { name: 'Production', value: 45, employees: 18 },
    { name: 'Quality Control', value: 20, employees: 8 },
    { name: 'Maintenance', value: 15, employees: 6 },
    { name: 'Administration', value: 12, employees: 5 },
    { name: 'Logistics', value: 8, employees: 3 }
  ];

  // Create employee mutation
  const createEmployeeMutation = useMutation({
    mutationFn: async (data: z.infer<typeof employeeSchema>) => {
      return apiRequest("/api/employees", "POST", data);
    },
    onSuccess: () => {
      toast({
        title: "Employee Added",
        description: "New employee has been added successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/employees"] });
      setIsEmployeeDialogOpen(false);
      employeeForm.reset();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to add employee",
        variant: "destructive",
      });
    },
  });

  // Create shift mutation
  const createShiftMutation = useMutation({
    mutationFn: async (data: z.infer<typeof shiftSchema>) => {
      return apiRequest("/api/shifts", "POST", data);
    },
    onSuccess: () => {
      toast({
        title: "Shift Scheduled",
        description: "New shift has been scheduled successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/shifts"] });
      setIsShiftDialogOpen(false);
      shiftForm.reset();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to schedule shift",
        variant: "destructive",
      });
    },
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
      case "completed":
      case "achieved":
        return "bg-green-100 text-green-800";
      case "scheduled":
      case "in_progress":
        return "bg-blue-100 text-blue-800";
      case "on_leave":
        return "bg-yellow-100 text-yellow-800";
      case "inactive":
      case "no_show":
      case "missed":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "active":
      case "completed":
      case "achieved":
        return <CheckCircle className="w-4 h-4" />;
      case "scheduled":
      case "in_progress":
        return <Clock className="w-4 h-4" />;
      case "on_leave":
        return <CalendarIcon className="w-4 h-4" />;
      case "inactive":
      case "no_show":
      case "missed":
        return <AlertTriangle className="w-4 h-4" />;
      default:
        return <Users className="w-4 h-4" />;
    }
  };

  const filteredEmployees = selectedDepartment === "all" 
    ? sampleEmployees 
    : sampleEmployees.filter(emp => emp.department === selectedDepartment);

  const overallStats = {
    totalEmployees: sampleEmployees.length,
    activeEmployees: sampleEmployees.filter(emp => emp.status === "active").length,
    avgPerformance: Math.round(sampleEmployees.reduce((acc, emp) => acc + emp.performance, 0) / sampleEmployees.length),
    avgAttendance: Math.round(sampleEmployees.reduce((acc, emp) => acc + emp.attendance, 0) / sampleEmployees.length),
    totalHours: sampleEmployees.reduce((acc, emp) => acc + emp.hoursWorked, 0),
    totalOvertime: sampleEmployees.reduce((acc, emp) => acc + emp.overtimeHours, 0)
  };

  const onEmployeeSubmit = (data: z.infer<typeof employeeSchema>) => {
    createEmployeeMutation.mutate(data);
  };

  const onShiftSubmit = (data: z.infer<typeof shiftSchema>) => {
    createShiftMutation.mutate(data);
  };

  return (
    <div className="flex h-screen bg-carbon-gray-10">
      <Sidebar />
      <div className="flex-1 overflow-auto">
        <div className="p-6 space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-carbon-gray-80">Workforce Management</h1>
              <p className="text-carbon-gray-60">Employee scheduling, performance, and analytics</p>
            </div>
            <div className="flex items-center space-x-3">
              <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
                <SelectTrigger className="w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Departments</SelectItem>
                  <SelectItem value="Production">Production</SelectItem>
                  <SelectItem value="Quality Control">Quality Control</SelectItem>
                  <SelectItem value="Maintenance">Maintenance</SelectItem>
                  <SelectItem value="Administration">Administration</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Overview Stats */}
          <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Users className="w-5 h-5 text-blue-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Total Employees</p>
                    <p className="text-xl font-bold">{overallStats.totalEmployees}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <UserCheck className="w-5 h-5 text-green-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Active</p>
                    <p className="text-xl font-bold">{overallStats.activeEmployees}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Target className="w-5 h-5 text-purple-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Avg Performance</p>
                    <p className="text-xl font-bold">{overallStats.avgPerformance}%</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <CalendarIcon className="w-5 h-5 text-orange-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Avg Attendance</p>
                    <p className="text-xl font-bold">{overallStats.avgAttendance}%</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Clock className="w-5 h-5 text-yellow-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Total Hours</p>
                    <p className="text-xl font-bold">{overallStats.totalHours}h</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <TrendingUp className="w-5 h-5 text-red-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Overtime</p>
                    <p className="text-xl font-bold">{overallStats.totalOvertime}h</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
            <div className="flex items-center justify-between">
              <TabsList>
                <TabsTrigger value="employees">Employees</TabsTrigger>
                <TabsTrigger value="scheduling">Scheduling</TabsTrigger>
                <TabsTrigger value="performance">Performance</TabsTrigger>
                <TabsTrigger value="analytics">Analytics</TabsTrigger>
              </TabsList>
              <div className="flex space-x-2">
                {activeTab === "employees" && (
                  <Dialog open={isEmployeeDialogOpen} onOpenChange={setIsEmployeeDialogOpen}>
                    <DialogTrigger asChild>
                      <Button>
                        <Plus className="w-4 h-4 mr-2" />
                        Add Employee
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl">
                      <DialogHeader>
                        <DialogTitle>Add New Employee</DialogTitle>
                      </DialogHeader>
                      <Form {...employeeForm}>
                        <form onSubmit={employeeForm.handleSubmit(onEmployeeSubmit)} className="space-y-4">
                          <div className="grid grid-cols-2 gap-4">
                            <FormField
                              control={employeeForm.control}
                              name="firstName"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>First Name</FormLabel>
                                  <FormControl>
                                    <Input {...field} />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={employeeForm.control}
                              name="lastName"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Last Name</FormLabel>
                                  <FormControl>
                                    <Input {...field} />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={employeeForm.control}
                              name="email"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Email</FormLabel>
                                  <FormControl>
                                    <Input type="email" {...field} />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={employeeForm.control}
                              name="phone"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Phone</FormLabel>
                                  <FormControl>
                                    <Input {...field} />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={employeeForm.control}
                              name="department"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Department</FormLabel>
                                  <FormControl>
                                    <Select onValueChange={field.onChange} value={field.value}>
                                      <SelectTrigger>
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="Production">Production</SelectItem>
                                        <SelectItem value="Quality Control">Quality Control</SelectItem>
                                        <SelectItem value="Maintenance">Maintenance</SelectItem>
                                        <SelectItem value="Administration">Administration</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={employeeForm.control}
                              name="position"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Position</FormLabel>
                                  <FormControl>
                                    <Input {...field} />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={employeeForm.control}
                              name="hireDate"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Hire Date</FormLabel>
                                  <FormControl>
                                    <Input type="date" {...field} />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={employeeForm.control}
                              name="salary"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Annual Salary</FormLabel>
                                  <FormControl>
                                    <Input 
                                      type="number" 
                                      {...field}
                                      onChange={e => field.onChange(parseInt(e.target.value))}
                                    />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                          </div>
                          <div className="flex justify-end space-x-2">
                            <Button type="button" variant="outline" onClick={() => setIsEmployeeDialogOpen(false)}>
                              Cancel
                            </Button>
                            <Button type="submit" disabled={createEmployeeMutation.isPending}>
                              {createEmployeeMutation.isPending ? "Adding..." : "Add Employee"}
                            </Button>
                          </div>
                        </form>
                      </Form>
                    </DialogContent>
                  </Dialog>
                )}
                {activeTab === "scheduling" && (
                  <Button onClick={() => setIsShiftDialogOpen(true)}>
                    <Plus className="w-4 h-4 mr-2" />
                    Schedule Shift
                  </Button>
                )}
              </div>
            </div>

            <TabsContent value="employees" className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                {filteredEmployees.map((employee) => (
                  <Card key={employee.id} className="border-carbon-gray-20">
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-lg">{employee.firstName} {employee.lastName}</CardTitle>
                        <Badge className={getStatusColor(employee.status)}>
                          {getStatusIcon(employee.status)}
                          <span className="ml-1 capitalize">{employee.status.replace('_', ' ')}</span>
                        </Badge>
                      </div>
                      <p className="text-sm text-carbon-gray-60">{employee.position}</p>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="space-y-2">
                        <div className="flex items-center space-x-2 text-sm">
                          <Briefcase className="w-4 h-4 text-gray-500" />
                          <span>{employee.department}</span>
                        </div>
                        <div className="flex items-center space-x-2 text-sm">
                          <Mail className="w-4 h-4 text-gray-500" />
                          <span className="truncate">{employee.email}</span>
                        </div>
                        <div className="flex items-center space-x-2 text-sm">
                          <Phone className="w-4 h-4 text-gray-500" />
                          <span>{employee.phone}</span>
                        </div>
                        <div className="flex items-center space-x-2 text-sm">
                          <DollarSign className="w-4 h-4 text-gray-500" />
                          <span>${employee.salary.toLocaleString()}</span>
                        </div>
                      </div>

                      {/* Performance Metrics */}
                      <div className="space-y-2">
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span>Performance</span>
                            <span className="font-medium">{employee.performance}%</span>
                          </div>
                          <Progress value={employee.performance} className="h-2" />
                        </div>
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span>Attendance</span>
                            <span className="font-medium">{employee.attendance}%</span>
                          </div>
                          <Progress value={employee.attendance} className="h-2" />
                        </div>
                      </div>

                      {/* Work Hours */}
                      <div className="grid grid-cols-2 gap-2 pt-2 border-t text-center">
                        <div>
                          <p className="text-xs text-gray-600">This Month</p>
                          <p className="font-semibold">{employee.hoursWorked}h</p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-600">Overtime</p>
                          <p className="font-semibold">{employee.overtimeHours}h</p>
                        </div>
                      </div>

                      {/* Skills */}
                      <div className="space-y-2">
                        <p className="text-sm font-medium">Skills:</p>
                        <div className="flex flex-wrap gap-1">
                          {employee.skills.slice(0, 3).map((skill, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {skill}
                            </Badge>
                          ))}
                          {employee.skills.length > 3 && (
                            <Badge variant="outline" className="text-xs">
                              +{employee.skills.length - 3} more
                            </Badge>
                          )}
                        </div>
                      </div>

                      <div className="flex space-x-2 pt-2">
                        <Button variant="outline" size="sm" className="flex-1">
                          <Eye className="w-4 h-4 mr-1" />
                          View
                        </Button>
                        <Button variant="outline" size="sm" className="flex-1">
                          <Edit className="w-4 h-4 mr-1" />
                          Edit
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="scheduling" className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <Card className="lg:col-span-1 border-carbon-gray-20">
                  <CardHeader>
                    <CardTitle>Schedule Calendar</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Calendar
                      mode="single"
                      selected={selectedDate}
                      onSelect={(date) => date && setSelectedDate(date)}
                      className="rounded-md border"
                    />
                  </CardContent>
                </Card>

                <div className="lg:col-span-2 space-y-4">
                  <Card className="border-carbon-gray-20">
                    <CardHeader>
                      <CardTitle>Today's Schedule</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {sampleShifts.map((shift) => (
                          <div key={shift.id} className="flex items-center justify-between p-3 border rounded-lg">
                            <div className="flex-1">
                              <div className="flex items-center space-x-2">
                                <h4 className="font-medium">{shift.employeeName}</h4>
                                <Badge className={getStatusColor(shift.status)}>
                                  {getStatusIcon(shift.status)}
                                  <span className="ml-1 capitalize">{shift.status.replace('_', ' ')}</span>
                                </Badge>
                              </div>
                              <p className="text-sm text-gray-600">{shift.department}</p>
                              <p className="text-sm text-gray-600">{shift.startTime} - {shift.endTime}</p>
                              {shift.notes && (
                                <p className="text-xs text-gray-500 italic">{shift.notes}</p>
                              )}
                            </div>
                            <div className="text-right">
                              {shift.hoursWorked && (
                                <p className="font-medium">{shift.hoursWorked}h worked</p>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="performance" className="space-y-4">
              <div className="space-y-4">
                {samplePerformance.map((record) => (
                  <Card key={record.id} className="border-carbon-gray-20">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div>
                          <CardTitle className="text-lg">{record.employeeName}</CardTitle>
                          <p className="text-sm text-carbon-gray-60">Performance Review - {record.period}</p>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold">{record.overallScore}%</div>
                          <p className="text-sm text-gray-600">Overall Score</p>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      {/* Score Breakdown */}
                      <div className="grid grid-cols-3 gap-4">
                        <div>
                          <p className="text-sm text-gray-600 mb-1">Productivity</p>
                          <div className="flex items-center space-x-2">
                            <Progress value={record.productivityScore} className="flex-1 h-2" />
                            <span className="text-sm font-medium">{record.productivityScore}%</span>
                          </div>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600 mb-1">Quality</p>
                          <div className="flex items-center space-x-2">
                            <Progress value={record.qualityScore} className="flex-1 h-2" />
                            <span className="text-sm font-medium">{record.qualityScore}%</span>
                          </div>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600 mb-1">Attendance</p>
                          <div className="flex items-center space-x-2">
                            <Progress value={record.attendanceScore} className="flex-1 h-2" />
                            <span className="text-sm font-medium">{record.attendanceScore}%</span>
                          </div>
                        </div>
                      </div>

                      {/* Goals */}
                      <div>
                        <h4 className="font-medium mb-3">Performance Goals</h4>
                        <div className="space-y-2">
                          {record.goals.map((goal, index) => (
                            <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                              <div className="flex-1">
                                <p className="font-medium">{goal.description}</p>
                                <p className="text-sm text-gray-600">
                                  Target: {goal.target} | Achieved: {goal.achieved}
                                </p>
                              </div>
                              <Badge className={getStatusColor(goal.status)}>
                                {getStatusIcon(goal.status)}
                                <span className="ml-1 capitalize">{goal.status.replace('_', ' ')}</span>
                              </Badge>
                            </div>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="analytics" className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="border-carbon-gray-20">
                  <CardHeader>
                    <CardTitle>Performance Trends</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <LineChart data={performanceTrends}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip />
                        <Line type="monotone" dataKey="productivity" stroke="#0088FE" name="Productivity" />
                        <Line type="monotone" dataKey="quality" stroke="#00C49F" name="Quality" />
                        <Line type="monotone" dataKey="attendance" stroke="#FFBB28" name="Attendance" />
                      </LineChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card className="border-carbon-gray-20">
                  <CardHeader>
                    <CardTitle>Department Distribution</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <PieChart>
                        <Pie
                          data={departmentData}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={({ name, value }) => `${name} ${value}%`}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                        >
                          {departmentData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}