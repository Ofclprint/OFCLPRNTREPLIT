import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useUserPreferences } from "@/hooks/useUserPreferences";
import { useToast } from "@/hooks/use-toast";
import Sidebar from "@/components/layout/sidebar";
import MobileNav from "@/components/layout/mobile-nav";
import DragDropConfigurator from "@/components/preferences/drag-drop-configurator";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Palette, 
  Moon, 
  Sun, 
  Monitor, 
  Bell, 
  Mail, 
  Smartphone,
  Globe,
  Loader2
} from "lucide-react";

export default function Preferences() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const {
    preferences,
    isLoading: preferencesLoading,
    isSaving,
    updateDashboardLayout,
    updateTheme,
    updateNotificationSettings,
    resetPreferences
  } = useUserPreferences();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  if (isLoading || preferencesLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-blue-600" />
          <p className="text-gray-600">Loading preferences...</p>
        </div>
      </div>
    );
  }

  const handleSavePreferences = (newLayout: any) => {
    updateDashboardLayout(newLayout);
  };

  const handleResetPreferences = () => {
    resetPreferences();
  };

  const handleThemeChange = (newTheme: string) => {
    updateTheme(newTheme);
  };

  const handleNotificationToggle = (type: keyof typeof preferences.notifications) => {
    updateNotificationSettings({
      ...preferences.notifications,
      [type]: !preferences.notifications[type]
    });
  };

  return (
    <div className="min-h-screen flex bg-carbon-gray-10">
      {/* Desktop Sidebar */}
      <div className="hidden lg:block">
        <Sidebar />
      </div>
      
      {/* Mobile Navigation */}
      <div className="lg:hidden">
        <MobileNav />
      </div>
      
      <div className="flex-1 flex flex-col overflow-hidden lg:ml-0">
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          <div className="max-w-7xl mx-auto space-y-6 sm:space-y-8">
            {/* Header */}
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold text-carbon-gray-90 flex items-center space-x-3">
                  <Palette className="w-6 h-6 sm:w-8 sm:h-8 text-blue-600" />
                  <span>User Preferences</span>
                </h1>
                <p className="text-carbon-gray-60 mt-2 text-sm sm:text-base">
                  Customize your Manufacturing ERP experience with drag-and-drop interface configuration
                </p>
              </div>
              
              {isSaving && (
                <div className="flex items-center space-x-2 text-blue-600">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span className="text-sm">Saving...</span>
                </div>
              )}
            </div>

            {/* Quick Settings */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Theme Settings */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Sun className="w-5 h-5 text-yellow-600" />
                    <span>Theme</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Select 
                    value={preferences.theme} 
                    onValueChange={handleThemeChange}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="light">
                        <div className="flex items-center space-x-2">
                          <Sun className="w-4 h-4" />
                          <span>Light</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="dark">
                        <div className="flex items-center space-x-2">
                          <Moon className="w-4 h-4" />
                          <span>Dark</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="auto">
                        <div className="flex items-center space-x-2">
                          <Monitor className="w-4 h-4" />
                          <span>Auto</span>
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-sm text-gray-600">
                    Choose your preferred color scheme
                  </p>
                </CardContent>
              </Card>

              {/* Language Settings */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Globe className="w-5 h-5 text-green-600" />
                    <span>Language</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Select value={preferences.language} disabled>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="en">English</SelectItem>
                      <SelectItem value="es">Español</SelectItem>
                      <SelectItem value="fr">Français</SelectItem>
                    </SelectContent>
                  </Select>
                  <Badge variant="outline" className="text-xs">
                    Coming Soon
                  </Badge>
                </CardContent>
              </Card>

              {/* Notification Settings */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Bell className="w-5 h-5 text-blue-600" />
                    <span>Notifications</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Mail className="w-4 h-4 text-gray-600" />
                        <span className="text-sm">Email</span>
                      </div>
                      <Switch
                        checked={preferences.notifications.email}
                        onCheckedChange={() => handleNotificationToggle('email')}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Smartphone className="w-4 h-4 text-gray-600" />
                        <span className="text-sm">Push</span>
                      </div>
                      <Switch
                        checked={preferences.notifications.push}
                        onCheckedChange={() => handleNotificationToggle('push')}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Monitor className="w-4 h-4 text-gray-600" />
                        <span className="text-sm">Desktop</span>
                      </div>
                      <Switch
                        checked={preferences.notifications.desktop}
                        onCheckedChange={() => handleNotificationToggle('desktop')}
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Separator />

            {/* Drag and Drop Configurator */}
            <DragDropConfigurator
              onSave={handleSavePreferences}
              onReset={handleResetPreferences}
            />

            {/* Status Information */}
            <Card className="bg-gray-50">
              <CardHeader>
                <CardTitle className="text-sm font-medium text-gray-700">
                  Preference Status
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                  <div>
                    <label className="text-gray-600">Last Updated</label>
                    <p className="font-medium">
                      {preferences.updatedAt 
                        ? new Date(preferences.updatedAt).toLocaleDateString()
                        : "Never"
                      }
                    </p>
                  </div>
                  <div>
                    <label className="text-gray-600">Sync Status</label>
                    <p className="font-medium flex items-center space-x-1">
                      <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                      <span>Synced</span>
                    </p>
                  </div>
                  <div>
                    <label className="text-gray-600">Storage</label>
                    <p className="font-medium">Cloud + Local</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
      
      <MobileNav />
    </div>
  );
}