import MVPSidebar from "@/components/layout/mvp-sidebar";
import { ReactNode } from "react";

interface MVPLayoutProps {
  children: ReactNode;
}

export default function MVPLayout({ children }: MVPLayoutProps) {
  return (
    <div className="flex h-screen bg-gray-50 dark:bg-gray-900">
      <MVPSidebar />
      <main className="flex-1 overflow-auto">
        {children}
      </main>
    </div>
  );
}