import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { useToast } from "@/hooks/use-toast";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  Area,
  AreaChart
} from "recharts";
import {
  DollarSign,
  TrendingUp,
  TrendingDown,
  Calculator,
  Factory,
  Package,
  Users,
  Clock,
  Target,
  AlertCircle,
  Download,
  CalendarIcon,
  Filter,
  Search,
  Plus,
  Edit,
  Eye,
  BarChart3,
  PieChart as PieChartIcon
} from "lucide-react";
import { format, subDays, startOfMonth, endOfMonth } from "date-fns";

interface CostCenter {
  id: string;
  name: string;
  type: "production" | "overhead" | "administration" | "sales";
  manager: string;
  budget: number;
  actualCost: number;
  variance: number;
  variancePercent: number;
  department: string;
}

interface ProductCost {
  id: string;
  productName: string;
  sku: string;
  materialCost: number;
  laborCost: number;
  overheadCost: number;
  totalCost: number;
  sellingPrice: number;
  margin: number;
  marginPercent: number;
  volume: number;
  revenue: number;
}

interface CostBreakdown {
  category: string;
  amount: number;
  percentage: number;
  change: number;
  trend: "up" | "down" | "stable";
}

interface CostAnalytics {
  totalCosts: number;
  materialCosts: number;
  laborCosts: number;
  overheadCosts: number;
  costPerUnit: number;
  grossMargin: number;
  costVariance: number;
  efficiency: number;
}

export default function CostAccounting() {
  const [selectedPeriod, setSelectedPeriod] = useState("current_month");
  const [selectedCostCenter, setSelectedCostCenter] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const sampleCostCenters: CostCenter[] = [
    {
      id: "CC001",
      name: "Production Floor A",
      type: "production",
      manager: "John Smith",
      budget: 125000,
      actualCost: 118500,
      variance: -6500,
      variancePercent: -5.2,
      department: "Manufacturing"
    },
    {
      id: "CC002",
      name: "Quality Control",
      type: "production",
      manager: "Sarah Johnson",
      budget: 45000,
      actualCost: 47200,
      variance: 2200,
      variancePercent: 4.9,
      department: "Quality"
    },
    {
      id: "CC003",
      name: "Maintenance",
      type: "overhead",
      manager: "Mike Davis",
      budget: 35000,
      actualCost: 32800,
      variance: -2200,
      variancePercent: -6.3,
      department: "Facilities"
    },
    {
      id: "CC004",
      name: "Administration",
      type: "administration",
      manager: "Lisa Brown",
      budget: 28000,
      actualCost: 29500,
      variance: 1500,
      variancePercent: 5.4,
      department: "Admin"
    }
  ];

  const sampleProductCosts: ProductCost[] = [
    {
      id: "P001",
      productName: "Widget Pro",
      sku: "WP-001",
      materialCost: 45.50,
      laborCost: 28.75,
      overheadCost: 15.25,
      totalCost: 89.50,
      sellingPrice: 145.00,
      margin: 55.50,
      marginPercent: 38.3,
      volume: 2500,
      revenue: 362500
    },
    {
      id: "P002",
      productName: "Component X12",
      sku: "CX-012",
      materialCost: 32.00,
      laborCost: 18.50,
      overheadCost: 12.75,
      totalCost: 63.25,
      sellingPrice: 95.00,
      margin: 31.75,
      marginPercent: 33.4,
      volume: 1800,
      revenue: 171000
    },
    {
      id: "P003",
      productName: "Assembly Unit",
      sku: "AU-003",
      materialCost: 78.25,
      laborCost: 45.00,
      overheadCost: 22.50,
      totalCost: 145.75,
      sellingPrice: 220.00,
      margin: 74.25,
      marginPercent: 33.8,
      volume: 950,
      revenue: 209000
    }
  ];

  const costBreakdown: CostBreakdown[] = [
    {
      category: "Raw Materials",
      amount: 285000,
      percentage: 45.2,
      change: -3.2,
      trend: "down"
    },
    {
      category: "Direct Labor",
      amount: 195000,
      percentage: 30.9,
      change: 2.1,
      trend: "up"
    },
    {
      category: "Manufacturing Overhead",
      amount: 98000,
      percentage: 15.5,
      change: 1.8,
      trend: "up"
    },
    {
      category: "Administrative",
      amount: 52000,
      percentage: 8.4,
      change: -0.5,
      trend: "down"
    }
  ];

  const analytics: CostAnalytics = {
    totalCosts: 630000,
    materialCosts: 285000,
    laborCosts: 195000,
    overheadCosts: 150000,
    costPerUnit: 94.75,
    grossMargin: 35.8,
    costVariance: -2.4,
    efficiency: 92.3
  };

  const monthlyTrends = [
    { month: "Jan", totalCost: 580000, materialCost: 265000, laborCost: 180000, overhead: 135000 },
    { month: "Feb", totalCost: 595000, materialCost: 270000, laborCost: 185000, overhead: 140000 },
    { month: "Mar", totalCost: 610000, materialCost: 275000, laborCost: 190000, overhead: 145000 },
    { month: "Apr", totalCost: 625000, materialCost: 280000, laborCost: 192000, overhead: 153000 },
    { month: "May", totalCost: 630000, materialCost: 285000, laborCost: 195000, overhead: 150000 },
    { month: "Jun", totalCost: 618000, materialCost: 278000, laborCost: 193000, overhead: 147000 }
  ];

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

  const filteredCostCenters = sampleCostCenters.filter(center => {
    const matchesSearch = searchQuery === "" || 
      center.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      center.manager.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = selectedCostCenter === "all" || center.type === selectedCostCenter;
    
    return matchesSearch && matchesType;
  });

  const getVarianceColor = (variance: number) => {
    if (variance < -5) return "text-green-600 bg-green-50";
    if (variance > 5) return "text-red-600 bg-red-50";
    return "text-yellow-600 bg-yellow-50";
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case "up": return <TrendingUp className="w-4 h-4 text-red-600" />;
      case "down": return <TrendingDown className="w-4 h-4 text-green-600" />;
      default: return null;
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-3xl font-bold mb-2">Cost Accounting & Analysis</h1>
          <p className="text-gray-600">
            Comprehensive cost tracking, analysis, and profitability management
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Export Report
          </Button>
          <Button>
            <Plus className="w-4 h-4 mr-2" />
            Add Cost Entry
          </Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Costs</p>
                <p className="text-2xl font-bold">${analytics.totalCosts.toLocaleString()}</p>
                <p className="text-xs text-gray-500">
                  {analytics.costVariance > 0 ? '+' : ''}{analytics.costVariance}% vs budget
                </p>
              </div>
              <DollarSign className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Cost per Unit</p>
                <p className="text-2xl font-bold">${analytics.costPerUnit}</p>
                <p className="text-xs text-green-600">-2.1% vs last month</p>
              </div>
              <Calculator className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Gross Margin</p>
                <p className="text-2xl font-bold">{analytics.grossMargin}%</p>
                <p className="text-xs text-green-600">+1.3% vs target</p>
              </div>
              <Target className="w-8 h-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Cost Efficiency</p>
                <p className="text-2xl font-bold">{analytics.efficiency}%</p>
                <p className="text-xs text-yellow-600">Standard target: 95%</p>
              </div>
              <BarChart3 className="w-8 h-8 text-yellow-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="cost-centers">Cost Centers</TabsTrigger>
          <TabsTrigger value="products">Product Costs</TabsTrigger>
          <TabsTrigger value="analysis">Analysis</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Cost Breakdown */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <PieChartIcon className="w-5 h-5 mr-2" />
                  Cost Breakdown
                </CardTitle>
                <CardDescription>Distribution of manufacturing costs</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={costBreakdown}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ category, percentage }) => `${category}: ${percentage}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="amount"
                    >
                      {costBreakdown.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value: number) => [`$${value.toLocaleString()}`, 'Amount']} />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Monthly Trends */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BarChart3 className="w-5 h-5 mr-2" />
                  Cost Trends
                </CardTitle>
                <CardDescription>Monthly cost breakdown over time</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={monthlyTrends}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip formatter={(value: number) => [`$${value.toLocaleString()}`, '']} />
                    <Area type="monotone" dataKey="materialCost" stackId="1" stroke="#8884d8" fill="#8884d8" />
                    <Area type="monotone" dataKey="laborCost" stackId="1" stroke="#82ca9d" fill="#82ca9d" />
                    <Area type="monotone" dataKey="overhead" stackId="1" stroke="#ffc658" fill="#ffc658" />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Cost Categories */}
          <Card>
            <CardHeader>
              <CardTitle>Cost Categories</CardTitle>
              <CardDescription>Detailed breakdown by category with variance analysis</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {costBreakdown.map((category) => (
                  <div key={category.category} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-3">
                        <h4 className="font-semibold">{category.category}</h4>
                        {getTrendIcon(category.trend)}
                        <Badge variant="outline">
                          {category.trend === "up" ? "+" : ""}{category.change}%
                        </Badge>
                      </div>
                      <div className="text-right">
                        <p className="font-bold">${category.amount.toLocaleString()}</p>
                        <p className="text-sm text-gray-600">{category.percentage}% of total</p>
                      </div>
                    </div>
                    <Progress value={category.percentage} className="h-2" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="cost-centers" className="space-y-4">
          {/* Filters */}
          <div className="flex flex-wrap gap-4 items-center">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search cost centers..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 w-64"
              />
            </div>
            <Select value={selectedCostCenter} onValueChange={setSelectedCostCenter}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Cost center type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="production">Production</SelectItem>
                <SelectItem value="overhead">Overhead</SelectItem>
                <SelectItem value="administration">Administration</SelectItem>
                <SelectItem value="sales">Sales</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Cost Centers List */}
          <div className="space-y-4">
            {filteredCostCenters.map((center) => (
              <Card key={center.id}>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <Factory className="w-5 h-5" />
                        <h3 className="font-semibold text-lg">{center.name}</h3>
                        <Badge variant="outline">{center.type}</Badge>
                        <Badge className={getVarianceColor(center.variancePercent)}>
                          {center.variancePercent > 0 ? "+" : ""}{center.variancePercent.toFixed(1)}%
                        </Badge>
                      </div>
                      
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <p className="text-gray-500">Manager</p>
                          <p className="font-medium">{center.manager}</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Budget</p>
                          <p className="font-medium">${center.budget.toLocaleString()}</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Actual Cost</p>
                          <p className="font-medium">${center.actualCost.toLocaleString()}</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Variance</p>
                          <p className={`font-medium ${center.variance < 0 ? 'text-green-600' : 'text-red-600'}`}>
                            ${Math.abs(center.variance).toLocaleString()}
                            {center.variance < 0 ? ' under' : ' over'}
                          </p>
                        </div>
                      </div>

                      <div className="mt-4">
                        <div className="flex justify-between text-sm mb-1">
                          <span>Budget Utilization</span>
                          <span>{((center.actualCost / center.budget) * 100).toFixed(1)}%</span>
                        </div>
                        <Progress value={(center.actualCost / center.budget) * 100} className="h-2" />
                      </div>
                    </div>
                    
                    <div className="flex gap-2 ml-4">
                      <Button size="sm" variant="outline">
                        <Eye className="w-4 h-4" />
                      </Button>
                      <Button size="sm" variant="outline">
                        <Edit className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="products" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Product Cost Analysis</CardTitle>
              <CardDescription>Cost breakdown and profitability by product</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-2">Product</th>
                      <th className="text-right p-2">Material</th>
                      <th className="text-right p-2">Labor</th>
                      <th className="text-right p-2">Overhead</th>
                      <th className="text-right p-2">Total Cost</th>
                      <th className="text-right p-2">Selling Price</th>
                      <th className="text-right p-2">Margin</th>
                      <th className="text-right p-2">Volume</th>
                      <th className="text-right p-2">Revenue</th>
                    </tr>
                  </thead>
                  <tbody>
                    {sampleProductCosts.map((product) => (
                      <tr key={product.id} className="border-b hover:bg-gray-50">
                        <td className="p-2">
                          <div>
                            <p className="font-medium">{product.productName}</p>
                            <p className="text-sm text-gray-600">{product.sku}</p>
                          </div>
                        </td>
                        <td className="text-right p-2">${product.materialCost.toFixed(2)}</td>
                        <td className="text-right p-2">${product.laborCost.toFixed(2)}</td>
                        <td className="text-right p-2">${product.overheadCost.toFixed(2)}</td>
                        <td className="text-right p-2 font-medium">${product.totalCost.toFixed(2)}</td>
                        <td className="text-right p-2">${product.sellingPrice.toFixed(2)}</td>
                        <td className="text-right p-2">
                          <div>
                            <p className="font-medium text-green-600">${product.margin.toFixed(2)}</p>
                            <p className="text-xs text-gray-600">{product.marginPercent.toFixed(1)}%</p>
                          </div>
                        </td>
                        <td className="text-right p-2">{product.volume.toLocaleString()}</td>
                        <td className="text-right p-2 font-medium">${product.revenue.toLocaleString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analysis" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Variance Analysis</CardTitle>
                <CardDescription>Budget vs actual performance</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>Material Costs</span>
                    <div className="text-right">
                      <span className="font-medium">${analytics.materialCosts.toLocaleString()}</span>
                      <p className="text-sm text-green-600">-3.2% vs budget</p>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Labor Costs</span>
                    <div className="text-right">
                      <span className="font-medium">${analytics.laborCosts.toLocaleString()}</span>
                      <p className="text-sm text-red-600">+2.1% vs budget</p>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Overhead Costs</span>
                    <div className="text-right">
                      <span className="font-medium">${analytics.overheadCosts.toLocaleString()}</span>
                      <p className="text-sm text-yellow-600">+1.8% vs budget</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Cost Efficiency Metrics</CardTitle>
                <CardDescription>Performance indicators</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm">Overall Efficiency</span>
                      <span className="text-sm font-semibold">{analytics.efficiency}%</span>
                    </div>
                    <Progress value={analytics.efficiency} className="h-2" />
                  </div>
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm">Material Efficiency</span>
                      <span className="text-sm font-semibold">94.8%</span>
                    </div>
                    <Progress value={94.8} className="h-2" />
                  </div>
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm">Labor Efficiency</span>
                      <span className="text-sm font-semibold">89.2%</span>
                    </div>
                    <Progress value={89.2} className="h-2" />
                  </div>
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm">Overhead Control</span>
                      <span className="text-sm font-semibold">91.5%</span>
                    </div>
                    <Progress value={91.5} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="reports" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <Card className="hover:shadow-md transition-shadow cursor-pointer">
              <CardContent className="p-4">
                <div className="flex items-center gap-3 mb-2">
                  <BarChart3 className="w-6 h-6 text-blue-600" />
                  <h3 className="font-semibold">Cost Center Report</h3>
                </div>
                <p className="text-sm text-gray-600 mb-3">
                  Detailed analysis of cost center performance and variances
                </p>
                <Button size="sm" variant="outline" className="w-full">
                  <Download className="w-4 h-4 mr-2" />
                  Generate
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-md transition-shadow cursor-pointer">
              <CardContent className="p-4">
                <div className="flex items-center gap-3 mb-2">
                  <PieChartIcon className="w-6 h-6 text-green-600" />
                  <h3 className="font-semibold">Product Profitability</h3>
                </div>
                <p className="text-sm text-gray-600 mb-3">
                  Product-level cost analysis and margin calculations
                </p>
                <Button size="sm" variant="outline" className="w-full">
                  <Download className="w-4 h-4 mr-2" />
                  Generate
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-md transition-shadow cursor-pointer">
              <CardContent className="p-4">
                <div className="flex items-center gap-3 mb-2">
                  <Calculator className="w-6 h-6 text-purple-600" />
                  <h3 className="font-semibold">Variance Analysis</h3>
                </div>
                <p className="text-sm text-gray-600 mb-3">
                  Budget vs actual analysis with variance explanations
                </p>
                <Button size="sm" variant="outline" className="w-full">
                  <Download className="w-4 h-4 mr-2" />
                  Generate
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-md transition-shadow cursor-pointer">
              <CardContent className="p-4">
                <div className="flex items-center gap-3 mb-2">
                  <TrendingUp className="w-6 h-6 text-orange-600" />
                  <h3 className="font-semibold">Trend Analysis</h3>
                </div>
                <p className="text-sm text-gray-600 mb-3">
                  Historical cost trends and forecasting analysis
                </p>
                <Button size="sm" variant="outline" className="w-full">
                  <Download className="w-4 h-4 mr-2" />
                  Generate
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-md transition-shadow cursor-pointer">
              <CardContent className="p-4">
                <div className="flex items-center gap-3 mb-2">
                  <Target className="w-6 h-6 text-red-600" />
                  <h3 className="font-semibold">Cost Optimization</h3>
                </div>
                <p className="text-sm text-gray-600 mb-3">
                  Recommendations for cost reduction and efficiency improvements
                </p>
                <Button size="sm" variant="outline" className="w-full">
                  <Download className="w-4 h-4 mr-2" />
                  Generate
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-md transition-shadow cursor-pointer">
              <CardContent className="p-4">
                <div className="flex items-center gap-3 mb-2">
                  <DollarSign className="w-6 h-6 text-indigo-600" />
                  <h3 className="font-semibold">Executive Summary</h3>
                </div>
                <p className="text-sm text-gray-600 mb-3">
                  High-level cost overview and key performance indicators
                </p>
                <Button size="sm" variant="outline" className="w-full">
                  <Download className="w-4 h-4 mr-2" />
                  Generate
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}