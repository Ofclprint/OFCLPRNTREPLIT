import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import Sidebar from "@/components/layout/sidebar";
import { 
  BarChart3, 
  TrendingUp, 
  TrendingDown, 
  Target, 
  AlertTriangle,
  Calendar,
  Download,
  RefreshCw,
  Zap,
  Activity,
  DollarSign,
  Package
} from "lucide-react";
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from "recharts";

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

export default function AdvancedAnalytics() {
  const [timeRange, setTimeRange] = useState("30d");
  const [selectedMetric, setSelectedMetric] = useState("all");

  // Fetch analytics data
  const { data: analyticsData, isLoading, refetch } = useQuery({
    queryKey: ["/api/analytics/advanced", timeRange, selectedMetric],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // Sample data for demonstration
  const productionTrends = [
    { month: 'Jan', production: 4000, efficiency: 85, quality: 92 },
    { month: 'Feb', production: 3000, efficiency: 88, quality: 94 },
    { month: 'Mar', production: 2000, efficiency: 82, quality: 90 },
    { month: 'Apr', production: 2780, efficiency: 90, quality: 96 },
    { month: 'May', production: 1890, efficiency: 86, quality: 93 },
    { month: 'Jun', production: 2390, efficiency: 92, quality: 95 }
  ];

  const inventoryDistribution = [
    { name: 'Raw Materials', value: 35, count: 150 },
    { name: 'Work in Progress', value: 25, count: 80 },
    { name: 'Finished Goods', value: 30, count: 120 },
    { name: 'Maintenance Parts', value: 10, count: 45 }
  ];

  const qualityMetrics = [
    { week: 'W1', defectRate: 2.1, reworkRate: 1.5, customerComplaints: 3 },
    { week: 'W2', defectRate: 1.8, reworkRate: 1.2, customerComplaints: 2 },
    { week: 'W3', defectRate: 2.5, reworkRate: 1.8, customerComplaints: 4 },
    { week: 'W4', defectRate: 1.6, reworkRate: 1.0, customerComplaints: 1 }
  ];

  const costAnalysis = [
    { category: 'Materials', current: 45000, budget: 42000, variance: 7.1 },
    { category: 'Labor', current: 28000, budget: 30000, variance: -6.7 },
    { category: 'Overhead', current: 15000, budget: 14500, variance: 3.4 },
    { category: 'Equipment', current: 8000, budget: 9000, variance: -11.1 }
  ];

  const kpiCards = [
    {
      title: "Overall Equipment Effectiveness",
      value: "87.3%",
      change: "+2.1%",
      trend: "up",
      icon: Target,
      color: "text-green-600"
    },
    {
      title: "Production Efficiency",
      value: "92.1%",
      change: "+1.8%", 
      trend: "up",
      icon: TrendingUp,
      color: "text-blue-600"
    },
    {
      title: "Quality Score",
      value: "94.7%",
      change: "-0.3%",
      trend: "down",
      icon: Activity,
      color: "text-purple-600"
    },
    {
      title: "Cost Variance",
      value: "$12.5K",
      change: "+5.2%",
      trend: "down",
      icon: DollarSign,
      color: "text-orange-600"
    }
  ];

  return (
    <div className="flex h-screen bg-carbon-gray-10">
      <Sidebar />
      <div className="flex-1 overflow-auto">
        <div className="p-6 space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-carbon-gray-80">Advanced Analytics</h1>
              <p className="text-carbon-gray-60">Deep insights into manufacturing performance</p>
            </div>
            <div className="flex items-center space-x-3">
              <Select value={timeRange} onValueChange={setTimeRange}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7d">Last 7 days</SelectItem>
                  <SelectItem value="30d">Last 30 days</SelectItem>
                  <SelectItem value="90d">Last 90 days</SelectItem>
                  <SelectItem value="1y">Last year</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" onClick={() => refetch()}>
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh
              </Button>
              <Button>
                <Download className="w-4 h-4 mr-2" />
                Export
              </Button>
            </div>
          </div>

          {/* KPI Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {kpiCards.map((kpi, index) => (
              <Card key={index} className="border-carbon-gray-20">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-carbon-gray-60">{kpi.title}</p>
                      <div className="flex items-center space-x-2 mt-2">
                        <span className="text-2xl font-bold text-carbon-gray-80">{kpi.value}</span>
                        <Badge 
                          variant={kpi.trend === "up" ? "default" : "destructive"}
                          className="text-xs"
                        >
                          {kpi.trend === "up" ? <TrendingUp className="w-3 h-3 mr-1" /> : <TrendingDown className="w-3 h-3 mr-1" />}
                          {kpi.change}
                        </Badge>
                      </div>
                    </div>
                    <div className={`p-3 rounded-lg bg-gray-50 ${kpi.color}`}>
                      <kpi.icon className="w-6 h-6" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Analytics Tabs */}
          <Tabs defaultValue="production" className="space-y-4">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="production">Production</TabsTrigger>
              <TabsTrigger value="inventory">Inventory</TabsTrigger>
              <TabsTrigger value="quality">Quality</TabsTrigger>
              <TabsTrigger value="costs">Costs</TabsTrigger>
            </TabsList>

            <TabsContent value="production" className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="border-carbon-gray-20">
                  <CardHeader>
                    <CardTitle>Production Trends</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <LineChart data={productionTrends}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Line type="monotone" dataKey="production" stroke="#0088FE" name="Production" />
                        <Line type="monotone" dataKey="efficiency" stroke="#00C49F" name="Efficiency %" />
                      </LineChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card className="border-carbon-gray-20">
                  <CardHeader>
                    <CardTitle>Efficiency vs Quality</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <AreaChart data={productionTrends}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Area type="monotone" dataKey="efficiency" stackId="1" stroke="#8884d8" fill="#8884d8" name="Efficiency %" />
                        <Area type="monotone" dataKey="quality" stackId="2" stroke="#82ca9d" fill="#82ca9d" name="Quality %" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="inventory" className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="border-carbon-gray-20">
                  <CardHeader>
                    <CardTitle>Inventory Distribution</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <PieChart>
                        <Pie
                          data={inventoryDistribution}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                        >
                          {inventoryDistribution.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card className="border-carbon-gray-20">
                  <CardHeader>
                    <CardTitle>Inventory Levels</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {inventoryDistribution.map((item, index) => (
                        <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center space-x-3">
                            <div 
                              className="w-4 h-4 rounded-full" 
                              style={{ backgroundColor: COLORS[index % COLORS.length] }}
                            />
                            <span className="font-medium">{item.name}</span>
                          </div>
                          <div className="text-right">
                            <div className="font-bold">{item.count} items</div>
                            <div className="text-sm text-gray-600">{item.value}% of total</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="quality" className="space-y-4">
              <Card className="border-carbon-gray-20">
                <CardHeader>
                  <CardTitle>Quality Metrics Trends</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={400}>
                    <BarChart data={qualityMetrics}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="week" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="defectRate" fill="#FF8042" name="Defect Rate %" />
                      <Bar dataKey="reworkRate" fill="#FFBB28" name="Rework Rate %" />
                      <Bar dataKey="customerComplaints" fill="#FF6B6B" name="Customer Complaints" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="costs" className="space-y-4">
              <Card className="border-carbon-gray-20">
                <CardHeader>
                  <CardTitle>Cost Analysis</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {costAnalysis.map((cost, index) => (
                      <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                        <div>
                          <h4 className="font-medium">{cost.category}</h4>
                          <p className="text-sm text-gray-600">Current vs Budget</p>
                        </div>
                        <div className="text-right">
                          <div className="flex items-center space-x-4">
                            <div>
                              <div className="font-bold">${cost.current.toLocaleString()}</div>
                              <div className="text-sm text-gray-600">Budget: ${cost.budget.toLocaleString()}</div>
                            </div>
                            <Badge variant={cost.variance > 0 ? "destructive" : "default"}>
                              {cost.variance > 0 ? "+" : ""}{cost.variance.toFixed(1)}%
                            </Badge>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          {/* Alerts and Recommendations */}
          <Card className="border-carbon-gray-20">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <AlertTriangle className="w-5 h-5 text-orange-500" />
                <span>Alerts & Recommendations</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-start space-x-3 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <AlertTriangle className="w-5 h-5 text-yellow-600 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-yellow-800">Material Cost Variance</h4>
                    <p className="text-sm text-yellow-700">Material costs are 7.1% over budget this month. Consider reviewing supplier contracts.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                  <Zap className="w-5 h-5 text-blue-600 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-blue-800">Efficiency Opportunity</h4>
                    <p className="text-sm text-blue-700">Production Line 2 shows 15% improvement potential based on historical data.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3 p-3 bg-green-50 border border-green-200 rounded-lg">
                  <TrendingUp className="w-5 h-5 text-green-600 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-green-800">Quality Improvement</h4>
                    <p className="text-sm text-green-700">Overall quality scores have improved 2.3% this quarter. Excellent progress!</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}