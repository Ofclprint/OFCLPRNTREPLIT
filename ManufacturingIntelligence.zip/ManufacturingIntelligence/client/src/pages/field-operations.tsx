import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import Sidebar from "@/components/layout/sidebar";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  Smartphone, 
  MapPin,
  Wifi,
  WifiOff,
  RefreshCw as Sync,
  Download,
  Upload,
  Clock,
  CheckCircle,
  AlertCircle,
  Info,
  User,
  Camera,
  FileText,
  QrCode,
  Navigation,
  Battery,
  Signal,
  Globe,
  Database,
  CloudOff,
  Cloud as CloudSync,
  RefreshCw,
  Plus,
  Edit,
  Trash2,
  Eye,
  Settings,
  Activity,
  Target,
  Package,
  Wrench,
  Shield,
  Zap,
  Truck,
  Calendar,
  Timer,
  Star,
  Award,
  TrendingUp,
  BarChart3,
  Filter,
  Search,
  MoreHorizontal,
  Mail
} from "lucide-react";

const fieldTaskSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().min(1, "Description is required"),
  type: z.enum(["inspection", "maintenance", "delivery", "audit", "training", "installation"]),
  priority: z.enum(["low", "medium", "high", "urgent"]),
  assignedTo: z.string().min(1, "Assignee is required"),
  location: z.string().min(1, "Location is required"),
  dueDate: z.string().min(1, "Due date is required"),
  estimatedDuration: z.number().min(1, "Duration must be at least 1 minute"),
  requiredSkills: z.array(z.string()).optional(),
  equipmentNeeded: z.array(z.string()).optional(),
  instructions: z.string().optional(),
  coordinates: z.object({
    lat: z.number(),
    lng: z.number(),
  }).optional(),
});

const inspectionFormSchema = z.object({
  taskId: z.string().min(1, "Task ID is required"),
  checklistItems: z.array(z.object({
    id: z.string(),
    description: z.string(),
    status: z.enum(["pass", "fail", "na"]),
    notes: z.string().optional(),
    photos: z.array(z.string()).optional(),
  })),
  overallStatus: z.enum(["pass", "fail", "partial"]),
  notes: z.string().optional(),
  recommendations: z.string().optional(),
  followUpRequired: z.boolean().default(false),
  gpsLocation: z.object({
    lat: z.number(),
    lng: z.number(),
    accuracy: z.number(),
  }).optional(),
  timestamp: z.string(),
});

interface FieldTask {
  id: string;
  title: string;
  description: string;
  type: "inspection" | "maintenance" | "delivery" | "audit" | "training" | "installation";
  priority: "low" | "medium" | "high" | "urgent";
  status: "pending" | "assigned" | "in_progress" | "completed" | "cancelled";
  assignedTo: string;
  assignedBy: string;
  location: string;
  coordinates?: {
    lat: number;
    lng: number;
  };
  dueDate: string;
  estimatedDuration: number; // minutes
  actualDuration?: number;
  requiredSkills: string[];
  equipmentNeeded: string[];
  instructions?: string;
  createdAt: string;
  updatedAt: string;
  completedAt?: string;
  syncStatus: "synced" | "pending" | "offline" | "conflict";
}

interface FieldWorker {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: string;
  department: string;
  skills: string[];
  certifications: string[];
  currentLocation?: {
    lat: number;
    lng: number;
    accuracy: number;
    timestamp: string;
  };
  isOnline: boolean;
  lastSeen: string;
  activeTaskCount: number;
  completedTasksToday: number;
  averageRating: number;
  deviceInfo: {
    model: string;
    os: string;
    appVersion: string;
    lastSync: string;
  };
}

interface OfflineData {
  tasks: FieldTask[];
  inspections: any[];
  photos: string[];
  lastSync: string;
  pendingUploads: number;
  storageUsed: number; // MB
  maxStorage: number; // MB
}

export default function FieldOperations() {
  const [activeTab, setActiveTab] = useState("tasks");
  const [isTaskDialogOpen, setIsTaskDialogOpen] = useState(false);
  const [isOffline, setIsOffline] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [selectedTask, setSelectedTask] = useState<FieldTask | null>(null);
  const [viewMode, setViewMode] = useState<"map" | "list">("list");
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [filterType, setFilterType] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState("");

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const taskForm = useForm<z.infer<typeof fieldTaskSchema>>({
    resolver: zodResolver(fieldTaskSchema),
    defaultValues: {
      type: "inspection",
      priority: "medium",
      estimatedDuration: 60,
      requiredSkills: [],
      equipmentNeeded: [],
    },
  });

  // Monitor online/offline status
  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Check initial status
    setIsOffline(!navigator.onLine);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Sample field tasks data
  const sampleTasks: FieldTask[] = [
    {
      id: "task_001",
      title: "Production Line A - Safety Inspection",
      description: "Weekly safety inspection of production line A equipment and procedures",
      type: "inspection",
      priority: "high",
      status: "assigned",
      assignedTo: "John Inspector",
      assignedBy: "Sarah Manager",
      location: "Building A - Production Floor",
      coordinates: { lat: 40.7128, lng: -74.0060 },
      dueDate: "2024-12-17 16:00:00",
      estimatedDuration: 90,
      requiredSkills: ["safety_inspection", "equipment_knowledge"],
      equipmentNeeded: ["tablet", "camera", "measuring_tape", "safety_checklist"],
      instructions: "Complete full safety checklist including emergency exits, equipment guards, and PPE compliance",
      createdAt: "2024-12-16 09:00:00",
      updatedAt: "2024-12-16 09:00:00",
      syncStatus: "synced"
    },
    {
      id: "task_002",
      title: "CNC Machine #3 - Preventive Maintenance",
      description: "Monthly preventive maintenance on CNC Machine #3",
      type: "maintenance",
      priority: "medium",
      status: "in_progress",
      assignedTo: "Mike Technician",
      assignedBy: "Tom Maintenance",
      location: "Building B - Machine Shop",
      coordinates: { lat: 40.7130, lng: -74.0062 },
      dueDate: "2024-12-17 14:00:00",
      estimatedDuration: 120,
      actualDuration: 85,
      requiredSkills: ["cnc_maintenance", "hydraulics", "electrical"],
      equipmentNeeded: ["toolkit", "lubricants", "replacement_filters", "multimeter"],
      instructions: "Follow maintenance checklist PM-003. Replace filters, check fluid levels, calibrate positioning",
      createdAt: "2024-12-16 08:30:00",
      updatedAt: "2024-12-17 10:15:00",
      syncStatus: "pending"
    },
    {
      id: "task_003",
      title: "Raw Materials Delivery - Warehouse C",
      description: "Receive and inspect incoming raw materials shipment",
      type: "delivery",
      priority: "urgent",
      status: "pending",
      assignedTo: "Lisa Warehouse",
      assignedBy: "Bob Logistics",
      location: "Warehouse C - Loading Dock",
      coordinates: { lat: 40.7125, lng: -74.0065 },
      dueDate: "2024-12-17 11:00:00",
      estimatedDuration: 45,
      requiredSkills: ["inventory_management", "forklift_operation"],
      equipmentNeeded: ["scanner", "forklift", "inspection_forms", "scale"],
      instructions: "Verify quantities against delivery note, check quality, update inventory system",
      createdAt: "2024-12-17 08:00:00",
      updatedAt: "2024-12-17 08:00:00",
      syncStatus: "offline"
    },
    {
      id: "task_004",
      title: "ISO 9001 Compliance Audit - Quality Lab",
      description: "Internal audit of quality lab procedures for ISO compliance",
      type: "audit",
      priority: "high",
      status: "completed",
      assignedTo: "Alice Quality",
      assignedBy: "Mike Quality Director",
      location: "Building A - Quality Lab",
      coordinates: { lat: 40.7132, lng: -74.0058 },
      dueDate: "2024-12-16 15:00:00",
      estimatedDuration: 180,
      actualDuration: 165,
      requiredSkills: ["iso_auditing", "quality_procedures"],
      equipmentNeeded: ["audit_checklist", "camera", "measuring_instruments"],
      instructions: "Review all quality procedures, document compliance, identify improvement areas",
      createdAt: "2024-12-15 10:00:00",
      updatedAt: "2024-12-16 15:30:00",
      completedAt: "2024-12-16 15:30:00",
      syncStatus: "synced"
    },
    {
      id: "task_005",
      title: "New Employee Safety Training",
      description: "Conduct safety orientation for new production employees",
      type: "training",
      priority: "medium",
      status: "assigned",
      assignedTo: "Diana Trainer",
      assignedBy: "John Safety Manager",
      location: "Training Room 2",
      coordinates: { lat: 40.7129, lng: -74.0061 },
      dueDate: "2024-12-18 09:00:00",
      estimatedDuration: 240,
      requiredSkills: ["safety_training", "presentation"],
      equipmentNeeded: ["projector", "training_materials", "certificates"],
      instructions: "Cover all safety basics, PPE requirements, emergency procedures, and company policies",
      createdAt: "2024-12-16 14:00:00",
      updatedAt: "2024-12-16 14:00:00",
      syncStatus: "synced"
    }
  ];

  const sampleWorkers: FieldWorker[] = [
    {
      id: "worker_001",
      name: "John Inspector",
      email: "john.inspector@company.com",
      phone: "+1-555-0101",
      role: "Safety Inspector",
      department: "Safety",
      skills: ["safety_inspection", "equipment_knowledge", "compliance_auditing"],
      certifications: ["OSHA 30", "Safety Inspector Level 2"],
      currentLocation: {
        lat: 40.7128,
        lng: -74.0060,
        accuracy: 5,
        timestamp: "2024-12-17 10:30:00"
      },
      isOnline: true,
      lastSeen: "2024-12-17 10:30:00",
      activeTaskCount: 2,
      completedTasksToday: 1,
      averageRating: 4.8,
      deviceInfo: {
        model: "iPad Pro 12.9",
        os: "iOS 17.2",
        appVersion: "2.1.4",
        lastSync: "2024-12-17 10:25:00"
      }
    },
    {
      id: "worker_002",
      name: "Mike Technician",
      email: "mike.tech@company.com",
      phone: "+1-555-0102",
      role: "Maintenance Technician",
      department: "Maintenance",
      skills: ["cnc_maintenance", "hydraulics", "electrical", "mechanical"],
      certifications: ["Electrical Safety", "Hydraulics Level 3", "CNC Operation"],
      currentLocation: {
        lat: 40.7130,
        lng: -74.0062,
        accuracy: 3,
        timestamp: "2024-12-17 10:15:00"
      },
      isOnline: false,
      lastSeen: "2024-12-17 09:45:00",
      activeTaskCount: 1,
      completedTasksToday: 2,
      averageRating: 4.9,
      deviceInfo: {
        model: "Samsung Galaxy Tab S9",
        os: "Android 14",
        appVersion: "2.1.4",
        lastSync: "2024-12-17 09:40:00"
      }
    },
    {
      id: "worker_003",
      name: "Lisa Warehouse",
      email: "lisa.warehouse@company.com",
      phone: "+1-555-0103",
      role: "Warehouse Coordinator",
      department: "Logistics",
      skills: ["inventory_management", "forklift_operation", "quality_inspection"],
      certifications: ["Forklift Operator", "Warehouse Management"],
      isOnline: true,
      lastSeen: "2024-12-17 10:35:00",
      activeTaskCount: 1,
      completedTasksToday: 0,
      averageRating: 4.7,
      deviceInfo: {
        model: "iPhone 15 Pro",
        os: "iOS 17.2",
        appVersion: "2.1.4",
        lastSync: "2024-12-17 10:30:00"
      }
    }
  ];

  const offlineData: OfflineData = {
    tasks: sampleTasks.filter(t => t.syncStatus !== "synced"),
    inspections: [],
    photos: [],
    lastSync: "2024-12-17 09:30:00",
    pendingUploads: 5,
    storageUsed: 125.6,
    maxStorage: 512
  };

  // Create task mutation
  const createTaskMutation = useMutation({
    mutationFn: async (data: z.infer<typeof fieldTaskSchema>) => {
      return apiRequest("/api/field-tasks", "POST", data);
    },
    onSuccess: () => {
      toast({
        title: "Task Created",
        description: "Field task has been created and assigned successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/field-tasks"] });
      setIsTaskDialogOpen(false);
      taskForm.reset();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create task",
        variant: "destructive",
      });
    },
  });

  // Sync data mutation
  const syncDataMutation = useMutation({
    mutationFn: async () => {
      setIsSyncing(true);
      return apiRequest("/api/field-operations/sync", "POST");
    },
    onSuccess: () => {
      toast({
        title: "Sync Complete",
        description: "All offline data has been synchronized successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/field-tasks"] });
      setIsSyncing(false);
    },
    onError: (error) => {
      toast({
        title: "Sync Failed",
        description: error.message || "Failed to synchronize data",
        variant: "destructive",
      });
      setIsSyncing(false);
    },
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-gray-100 text-gray-800";
      case "assigned":
        return "bg-blue-100 text-blue-800";
      case "in_progress":
        return "bg-yellow-100 text-yellow-800";
      case "completed":
        return "bg-green-100 text-green-800";
      case "cancelled":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "low":
        return "bg-green-100 text-green-800";
      case "medium":
        return "bg-yellow-100 text-yellow-800";
      case "high":
        return "bg-orange-100 text-orange-800";
      case "urgent":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "inspection":
        return <Shield className="w-5 h-5 text-blue-600" />;
      case "maintenance":
        return <Wrench className="w-5 h-5 text-orange-600" />;
      case "delivery":
        return <Truck className="w-5 h-5 text-green-600" />;
      case "audit":
        return <FileText className="w-5 h-5 text-purple-600" />;
      case "training":
        return <Award className="w-5 h-5 text-indigo-600" />;
      case "installation":
        return <Settings className="w-5 h-5 text-gray-600" />;
      default:
        return <Target className="w-5 h-5 text-gray-600" />;
    }
  };

  const getSyncStatusIcon = (status: string) => {
    switch (status) {
      case "synced":
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case "pending":
        return <Clock className="w-4 h-4 text-yellow-600" />;
      case "offline":
        return <CloudOff className="w-4 h-4 text-red-600" />;
      case "conflict":
        return <AlertCircle className="w-4 h-4 text-orange-600" />;
      default:
        return <Info className="w-4 h-4 text-gray-600" />;
    }
  };

  const formatDuration = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    if (hours === 0) return `${mins}m`;
    return `${hours}h ${mins}m`;
  };

  const filteredTasks = sampleTasks.filter(task => {
    const matchesStatus = filterStatus === "all" || task.status === filterStatus;
    const matchesType = filterType === "all" || task.type === filterType;
    const matchesSearch = searchTerm === "" || 
      task.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      task.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      task.assignedTo.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesStatus && matchesType && matchesSearch;
  });

  const taskStats = {
    total: sampleTasks.length,
    pending: sampleTasks.filter(t => t.status === "pending").length,
    assigned: sampleTasks.filter(t => t.status === "assigned").length,
    inProgress: sampleTasks.filter(t => t.status === "in_progress").length,
    completed: sampleTasks.filter(t => t.status === "completed").length,
    overdue: sampleTasks.filter(t => new Date(t.dueDate) < new Date() && t.status !== "completed").length
  };

  const onTaskSubmit = (data: z.infer<typeof fieldTaskSchema>) => {
    createTaskMutation.mutate(data);
  };

  const handleSyncData = () => {
    syncDataMutation.mutate();
  };

  const handleStartTask = (taskId: string) => {
    toast({
      title: "Task Started",
      description: "Field task has been marked as in progress",
    });
    // Implement start task logic
  };

  const handleCompleteTask = (taskId: string) => {
    toast({
      title: "Task Completed",
      description: "Field task has been marked as completed",
    });
    // Implement complete task logic
  };

  return (
    <div className="flex h-screen bg-carbon-gray-10">
      <Sidebar />
      <div className="flex-1 overflow-auto">
        <div className="p-6 space-y-6">
          {/* Header with Connection Status */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-carbon-gray-80">Field Operations</h1>
              <p className="text-carbon-gray-60">Manage field tasks, mobile workers, and offline operations</p>
            </div>
            <div className="flex items-center space-x-3">
              {/* Connection Status */}
              <div className={`flex items-center space-x-2 px-3 py-2 rounded-lg ${
                isOffline ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'
              }`}>
                {isOffline ? <WifiOff className="w-4 h-4" /> : <Wifi className="w-4 h-4" />}
                <span className="text-sm font-medium">
                  {isOffline ? 'Offline' : 'Online'}
                </span>
              </div>
              
              {/* Sync Button */}
              <Button 
                variant="outline" 
                onClick={handleSyncData}
                disabled={isSyncing || isOffline}
              >
                {isSyncing ? (
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Sync className="w-4 h-4 mr-2" />
                )}
                {isSyncing ? 'Syncing...' : 'Sync Data'}
              </Button>

              <Button variant="outline" onClick={() => setViewMode(viewMode === "list" ? "map" : "list")}>
                {viewMode === "list" ? <MapPin className="w-4 h-4" /> : <Database className="w-4 h-4" />}
              </Button>
            </div>
          </div>

          {/* Offline Status Banner */}
          {isOffline && (
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
              <div className="flex items-center space-x-3">
                <CloudOff className="w-5 h-5 text-yellow-600" />
                <div>
                  <h3 className="font-medium text-yellow-800">Operating in Offline Mode</h3>
                  <p className="text-sm text-yellow-700">
                    {offlineData.pendingUploads} items pending sync. 
                    Data will be synchronized when connection is restored.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Overview Stats */}
          <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Target className="w-5 h-5 text-blue-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Total Tasks</p>
                    <p className="text-xl font-bold">{taskStats.total}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Clock className="w-5 h-5 text-gray-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Pending</p>
                    <p className="text-xl font-bold">{taskStats.pending}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Activity className="w-5 h-5 text-yellow-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">In Progress</p>
                    <p className="text-xl font-bold">{taskStats.inProgress}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Completed</p>
                    <p className="text-xl font-bold">{taskStats.completed}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <AlertCircle className="w-5 h-5 text-red-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Overdue</p>
                    <p className="text-xl font-bold">{taskStats.overdue}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <CloudSync className="w-5 h-5 text-purple-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Pending Sync</p>
                    <p className="text-xl font-bold">{offlineData.pendingUploads}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
            <div className="flex items-center justify-between">
              <TabsList>
                <TabsTrigger value="tasks">Field Tasks</TabsTrigger>
                <TabsTrigger value="workers">Mobile Workers</TabsTrigger>
                <TabsTrigger value="offline">Offline Data</TabsTrigger>
                <TabsTrigger value="forms">Mobile Forms</TabsTrigger>
                <TabsTrigger value="analytics">Field Analytics</TabsTrigger>
              </TabsList>
              <div className="flex space-x-2">
                {activeTab === "tasks" && (
                  <Dialog open={isTaskDialogOpen} onOpenChange={setIsTaskDialogOpen}>
                    <DialogTrigger asChild>
                      <Button>
                        <Plus className="w-4 h-4 mr-2" />
                        New Task
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl">
                      <DialogHeader>
                        <DialogTitle>Create Field Task</DialogTitle>
                      </DialogHeader>
                      <Form {...taskForm}>
                        <form onSubmit={taskForm.handleSubmit(onTaskSubmit)} className="space-y-4">
                          <div className="grid grid-cols-2 gap-4">
                            <FormField
                              control={taskForm.control}
                              name="title"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Task Title</FormLabel>
                                  <FormControl>
                                    <Input {...field} />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={taskForm.control}
                              name="type"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Task Type</FormLabel>
                                  <FormControl>
                                    <Select onValueChange={field.onChange} value={field.value}>
                                      <SelectTrigger>
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="inspection">Inspection</SelectItem>
                                        <SelectItem value="maintenance">Maintenance</SelectItem>
                                        <SelectItem value="delivery">Delivery</SelectItem>
                                        <SelectItem value="audit">Audit</SelectItem>
                                        <SelectItem value="training">Training</SelectItem>
                                        <SelectItem value="installation">Installation</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                          </div>
                          <FormField
                            control={taskForm.control}
                            name="description"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Description</FormLabel>
                                <FormControl>
                                  <Textarea {...field} />
                                </FormControl>
                              </FormItem>
                            )}
                          />
                          <div className="grid grid-cols-3 gap-4">
                            <FormField
                              control={taskForm.control}
                              name="priority"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Priority</FormLabel>
                                  <FormControl>
                                    <Select onValueChange={field.onChange} value={field.value}>
                                      <SelectTrigger>
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="low">Low</SelectItem>
                                        <SelectItem value="medium">Medium</SelectItem>
                                        <SelectItem value="high">High</SelectItem>
                                        <SelectItem value="urgent">Urgent</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={taskForm.control}
                              name="assignedTo"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Assigned To</FormLabel>
                                  <FormControl>
                                    <Select onValueChange={field.onChange} value={field.value}>
                                      <SelectTrigger>
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        {sampleWorkers.map((worker) => (
                                          <SelectItem key={worker.id} value={worker.name}>
                                            {worker.name}
                                          </SelectItem>
                                        ))}
                                      </SelectContent>
                                    </Select>
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={taskForm.control}
                              name="estimatedDuration"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Duration (minutes)</FormLabel>
                                  <FormControl>
                                    <Input 
                                      type="number" 
                                      min="1" 
                                      {...field}
                                      onChange={e => field.onChange(parseInt(e.target.value))}
                                    />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                            <FormField
                              control={taskForm.control}
                              name="location"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Location</FormLabel>
                                  <FormControl>
                                    <Input {...field} />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={taskForm.control}
                              name="dueDate"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Due Date</FormLabel>
                                  <FormControl>
                                    <Input type="datetime-local" {...field} />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                          </div>
                          <FormField
                            control={taskForm.control}
                            name="instructions"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Instructions (Optional)</FormLabel>
                                <FormControl>
                                  <Textarea {...field} />
                                </FormControl>
                              </FormItem>
                            )}
                          />
                          <div className="flex justify-end space-x-2">
                            <Button type="button" variant="outline" onClick={() => setIsTaskDialogOpen(false)}>
                              Cancel
                            </Button>
                            <Button type="submit" disabled={createTaskMutation.isPending}>
                              {createTaskMutation.isPending ? "Creating..." : "Create Task"}
                            </Button>
                          </div>
                        </form>
                      </Form>
                    </DialogContent>
                  </Dialog>
                )}
              </div>
            </div>

            <TabsContent value="tasks" className="space-y-4">
              {/* Filters and Search */}
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      placeholder="Search tasks..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10 w-64"
                    />
                  </div>
                  <Select value={filterStatus} onValueChange={setFilterStatus}>
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="assigned">Assigned</SelectItem>
                      <SelectItem value="in_progress">In Progress</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={filterType} onValueChange={setFilterType}>
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="inspection">Inspection</SelectItem>
                      <SelectItem value="maintenance">Maintenance</SelectItem>
                      <SelectItem value="delivery">Delivery</SelectItem>
                      <SelectItem value="audit">Audit</SelectItem>
                      <SelectItem value="training">Training</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Tasks List */}
              <div className="space-y-4">
                {filteredTasks.map((task) => (
                  <Card key={task.id} className="border-carbon-gray-20">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-3">
                            {getTypeIcon(task.type)}
                            <h3 className="text-lg font-semibold">{task.title}</h3>
                            <Badge className={getStatusColor(task.status)}>
                              {task.status.replace('_', ' ')}
                            </Badge>
                            <Badge className={getPriorityColor(task.priority)}>
                              {task.priority}
                            </Badge>
                            <div className="flex items-center space-x-1">
                              {getSyncStatusIcon(task.syncStatus)}
                              <span className="text-xs text-gray-500">{task.syncStatus}</span>
                            </div>
                          </div>
                          
                          <p className="text-gray-600 mb-4">{task.description}</p>
                          
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                            <div>
                              <span className="font-medium text-gray-700">Assigned to:</span>
                              <p className="text-gray-600">{task.assignedTo}</p>
                            </div>
                            <div>
                              <span className="font-medium text-gray-700">Location:</span>
                              <p className="text-gray-600">{task.location}</p>
                            </div>
                            <div>
                              <span className="font-medium text-gray-700">Due:</span>
                              <p className="text-gray-600">{task.dueDate}</p>
                            </div>
                            <div>
                              <span className="font-medium text-gray-700">Duration:</span>
                              <p className="text-gray-600">
                                {task.actualDuration ? 
                                  `${formatDuration(task.actualDuration)} (est. ${formatDuration(task.estimatedDuration)})` :
                                  `${formatDuration(task.estimatedDuration)} (estimated)`
                                }
                              </p>
                            </div>
                          </div>

                          {task.requiredSkills.length > 0 && (
                            <div className="mt-4">
                              <span className="text-sm font-medium text-gray-700">Required Skills:</span>
                              <div className="flex flex-wrap gap-2 mt-2">
                                {task.requiredSkills.map((skill, index) => (
                                  <Badge key={index} variant="outline" className="text-xs">
                                    {skill.replace('_', ' ')}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          )}

                          {task.equipmentNeeded.length > 0 && (
                            <div className="mt-4">
                              <span className="text-sm font-medium text-gray-700">Equipment Needed:</span>
                              <div className="flex flex-wrap gap-2 mt-2">
                                {task.equipmentNeeded.map((equipment, index) => (
                                  <Badge key={index} variant="outline" className="text-xs">
                                    {equipment.replace('_', ' ')}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>

                        <div className="flex flex-col space-y-2 ml-6">
                          {task.status === "assigned" && (
                            <Button size="sm" onClick={() => handleStartTask(task.id)}>
                              <Activity className="w-3 h-3 mr-2" />
                              Start
                            </Button>
                          )}
                          {task.status === "in_progress" && (
                            <Button size="sm" onClick={() => handleCompleteTask(task.id)}>
                              <CheckCircle className="w-3 h-3 mr-2" />
                              Complete
                            </Button>
                          )}
                          <Button size="sm" variant="outline">
                            <Eye className="w-3 h-3 mr-2" />
                            View
                          </Button>
                          <Button size="sm" variant="outline">
                            <Edit className="w-3 h-3 mr-2" />
                            Edit
                          </Button>
                          {task.coordinates && (
                            <Button size="sm" variant="outline">
                              <Navigation className="w-3 h-3 mr-2" />
                              Navigate
                            </Button>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="workers" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {sampleWorkers.map((worker) => (
                  <Card key={worker.id} className="border-carbon-gray-20">
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <User className="w-8 h-8 text-blue-600" />
                          <div>
                            <CardTitle className="text-lg">{worker.name}</CardTitle>
                            <p className="text-sm text-carbon-gray-60">{worker.role}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <div className={`w-3 h-3 rounded-full ${worker.isOnline ? 'bg-green-500' : 'bg-red-500'}`} />
                          <span className="text-xs text-gray-500">
                            {worker.isOnline ? 'Online' : 'Offline'}
                          </span>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="font-medium">Active Tasks:</span>
                          <p className="text-blue-600">{worker.activeTaskCount}</p>
                        </div>
                        <div>
                          <span className="font-medium">Completed Today:</span>
                          <p className="text-green-600">{worker.completedTasksToday}</p>
                        </div>
                        <div>
                          <span className="font-medium">Rating:</span>
                          <div className="flex items-center space-x-1">
                            <Star className="w-3 h-3 text-yellow-500 fill-current" />
                            <span>{worker.averageRating}</span>
                          </div>
                        </div>
                        <div>
                          <span className="font-medium">Department:</span>
                          <p className="text-gray-600">{worker.department}</p>
                        </div>
                      </div>

                      <div>
                        <span className="text-sm font-medium">Skills:</span>
                        <div className="flex flex-wrap gap-1 mt-2">
                          {worker.skills.slice(0, 3).map((skill, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {skill.replace('_', ' ')}
                            </Badge>
                          ))}
                          {worker.skills.length > 3 && (
                            <Badge variant="outline" className="text-xs">
                              +{worker.skills.length - 3}
                            </Badge>
                          )}
                        </div>
                      </div>

                      <div>
                        <span className="text-sm font-medium">Device:</span>
                        <p className="text-xs text-gray-600">
                          {worker.deviceInfo.model} ({worker.deviceInfo.os})
                        </p>
                        <p className="text-xs text-gray-500">
                          Last sync: {worker.deviceInfo.lastSync}
                        </p>
                      </div>

                      {worker.currentLocation && (
                        <div>
                          <span className="text-sm font-medium">Location:</span>
                          <p className="text-xs text-gray-600">
                            {worker.currentLocation.lat.toFixed(4)}, {worker.currentLocation.lng.toFixed(4)}
                          </p>
                          <p className="text-xs text-gray-500">
                            Accuracy: {worker.currentLocation.accuracy}m
                          </p>
                        </div>
                      )}

                      <div className="flex space-x-2 pt-2 border-t">
                        <Button size="sm" variant="outline" className="flex-1">
                          <Mail className="w-3 h-3 mr-2" />
                          Contact
                        </Button>
                        <Button size="sm" variant="outline">
                          <MapPin className="w-3 h-3" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <MoreHorizontal className="w-3 h-3" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="offline" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="border-carbon-gray-20">
                  <CardHeader>
                    <CardTitle>Offline Storage</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <span>Storage Used</span>
                        <span className="font-medium">
                          {offlineData.storageUsed}MB / {offlineData.maxStorage}MB
                        </span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-blue-600 h-2 rounded-full" 
                          style={{ width: `${(offlineData.storageUsed / offlineData.maxStorage) * 100}%` }}
                        ></div>
                      </div>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="text-gray-600">Offline Tasks:</span>
                          <p className="font-medium">{offlineData.tasks.length}</p>
                        </div>
                        <div>
                          <span className="text-gray-600">Pending Photos:</span>
                          <p className="font-medium">{offlineData.photos.length}</p>
                        </div>
                        <div>
                          <span className="text-gray-600">Last Sync:</span>
                          <p className="font-medium">{offlineData.lastSync}</p>
                        </div>
                        <div>
                          <span className="text-gray-600">Pending Uploads:</span>
                          <p className="font-medium">{offlineData.pendingUploads}</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-carbon-gray-20">
                  <CardHeader>
                    <CardTitle>Sync Status</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {offlineData.tasks.map((task) => (
                        <div key={task.id} className="flex items-center justify-between p-3 border rounded">
                          <div className="flex items-center space-x-3">
                            {getSyncStatusIcon(task.syncStatus)}
                            <div>
                              <p className="font-medium text-sm">{task.title}</p>
                              <p className="text-xs text-gray-500">
                                {task.type} • {task.assignedTo}
                              </p>
                            </div>
                          </div>
                          <Button size="sm" variant="outline" disabled={isOffline}>
                            <Upload className="w-3 h-3" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="forms" className="space-y-4">
              <div className="text-center py-12">
                <Smartphone className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">Mobile Forms</h3>
                <p className="text-gray-600 mb-4">Create and manage mobile inspection and data collection forms</p>
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Create Form
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="analytics" className="space-y-4">
              <div className="text-center py-12">
                <BarChart3 className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">Field Analytics</h3>
                <p className="text-gray-600 mb-4">Performance metrics and insights for field operations</p>
                <Button>
                  <TrendingUp className="w-4 h-4 mr-2" />
                  View Analytics
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}