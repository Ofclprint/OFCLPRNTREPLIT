import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import Sidebar from "@/components/layout/sidebar";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  FileText, 
  Folder,
  Upload,
  Download,
  Share,
  Edit,
  Trash2,
  Plus,
  Search,
  Filter,
  Eye,
  Lock,
  Unlock,
  Star,
  StarOff,
  Clock,
  User,
  Tag,
  Archive,
  CheckCircle,
  AlertCircle,
  FileImage,
  FileVideo,
  FileAudio,
  Database,
  Settings,
  BookOpen,
  GraduationCap,
  Shield,
  Award,
  Target,
  TrendingUp,
  Activity,
  Calendar,
  MessageSquare,
  Bell,
  History,
  GitBranch,
  MoreHorizontal
} from "lucide-react";

const documentSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().min(1, "Description is required"),
  category: z.string().min(1, "Category is required"),
  type: z.enum(["sop", "manual", "policy", "training", "specification", "certificate", "report", "other"]),
  tags: z.array(z.string()).optional(),
  accessLevel: z.enum(["public", "internal", "restricted", "confidential"]),
  department: z.string().min(1, "Department is required"),
  version: z.string().default("1.0"),
  expiryDate: z.string().optional(),
  approvalRequired: z.boolean().default(false),
  file: z.any().optional(),
});

const folderSchema = z.object({
  name: z.string().min(1, "Folder name is required"),
  description: z.string().optional(),
  parentId: z.string().optional(),
  accessLevel: z.enum(["public", "internal", "restricted", "confidential"]),
  department: z.string().min(1, "Department is required"),
});

interface Document {
  id: string;
  title: string;
  description: string;
  category: string;
  type: "sop" | "manual" | "policy" | "training" | "specification" | "certificate" | "report" | "other";
  tags: string[];
  accessLevel: "public" | "internal" | "restricted" | "confidential";
  department: string;
  version: string;
  fileUrl: string;
  fileName: string;
  fileSize: number;
  fileType: string;
  checksum: string;
  status: "draft" | "review" | "approved" | "expired" | "archived";
  expiryDate?: string;
  approvalRequired: boolean;
  approvedBy?: string;
  approvedAt?: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  lastAccessedAt?: string;
  accessCount: number;
  downloadCount: number;
  isFavorite: boolean;
  isLocked: boolean;
  lockedBy?: string;
  folderId?: string;
  revisions: number;
}

interface Folder {
  id: string;
  name: string;
  description?: string;
  parentId?: string;
  accessLevel: "public" | "internal" | "restricted" | "confidential";
  department: string;
  documentCount: number;
  subfolderCount: number;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

interface KnowledgeArticle {
  id: string;
  title: string;
  content: string;
  summary: string;
  category: string;
  tags: string[];
  author: string;
  status: "draft" | "published" | "archived";
  views: number;
  likes: number;
  isPublic: boolean;
  relatedDocuments: string[];
  lastUpdated: string;
  createdAt: string;
}

interface Training {
  id: string;
  title: string;
  description: string;
  category: string;
  type: "course" | "certification" | "assessment" | "workshop";
  duration: number; // minutes
  difficulty: "beginner" | "intermediate" | "advanced";
  prerequisiteIds: string[];
  relatedDocumentIds: string[];
  status: "active" | "inactive" | "under_review";
  completionRate: number;
  averageRating: number;
  enrolledCount: number;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export default function Documents() {
  const [activeTab, setActiveTab] = useState("documents");
  const [isDocumentDialogOpen, setIsDocumentDialogOpen] = useState(false);
  const [isFolderDialogOpen, setIsFolderDialogOpen] = useState(false);
  const [selectedDocument, setSelectedDocument] = useState<Document | null>(null);
  const [currentFolderId, setCurrentFolderId] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [searchTerm, setSearchTerm] = useState("");
  const [filterCategory, setFilterCategory] = useState<string>("all");
  const [filterType, setFilterType] = useState<string>("all");
  const [sortBy, setSortBy] = useState<string>("updated");

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const documentForm = useForm<z.infer<typeof documentSchema>>({
    resolver: zodResolver(documentSchema),
    defaultValues: {
      type: "manual",
      accessLevel: "internal",
      version: "1.0",
      approvalRequired: false,
      tags: [],
    },
  });

  const folderForm = useForm<z.infer<typeof folderSchema>>({
    resolver: zodResolver(folderSchema),
    defaultValues: {
      accessLevel: "internal",
    },
  });

  // Sample documents data
  const sampleDocuments: Document[] = [
    {
      id: "doc_001",
      title: "Production Line Safety Procedures",
      description: "Comprehensive safety guidelines for production line operations",
      category: "safety",
      type: "sop",
      tags: ["safety", "production", "procedures", "compliance"],
      accessLevel: "internal",
      department: "production",
      version: "2.1",
      fileUrl: "/documents/safety-procedures-v2.1.pdf",
      fileName: "safety-procedures-v2.1.pdf",
      fileSize: 2456789,
      fileType: "application/pdf",
      checksum: "sha256:abc123def456",
      status: "approved",
      expiryDate: "2025-06-01",
      approvalRequired: true,
      approvedBy: "John Safety Manager",
      approvedAt: "2024-12-15 10:00:00",
      createdBy: "Sarah Production",
      createdAt: "2024-12-01 09:00:00",
      updatedAt: "2024-12-15 10:00:00",
      lastAccessedAt: "2024-12-17 04:30:00",
      accessCount: 89,
      downloadCount: 23,
      isFavorite: true,
      isLocked: false,
      revisions: 5
    },
    {
      id: "doc_002",
      title: "Quality Control Manual",
      description: "Standard operating procedures for quality control inspections",
      category: "quality",
      type: "manual",
      tags: ["quality", "inspection", "standards", "iso"],
      accessLevel: "internal",
      department: "quality",
      version: "1.8",
      fileUrl: "/documents/quality-control-manual-v1.8.pdf",
      fileName: "quality-control-manual-v1.8.pdf",
      fileSize: 5432100,
      fileType: "application/pdf",
      checksum: "sha256:def456ghi789",
      status: "approved",
      approvalRequired: true,
      approvedBy: "Mike Quality Director",
      approvedAt: "2024-12-10 14:30:00",
      createdBy: "Lisa Quality",
      createdAt: "2024-11-15 11:00:00",
      updatedAt: "2024-12-10 14:30:00",
      lastAccessedAt: "2024-12-17 03:15:00",
      accessCount: 156,
      downloadCount: 67,
      isFavorite: false,
      isLocked: true,
      lockedBy: "Mike Quality Director",
      revisions: 8
    },
    {
      id: "doc_003",
      title: "Equipment Maintenance Schedule",
      description: "Preventive maintenance schedules for all production equipment",
      category: "maintenance",
      type: "specification",
      tags: ["maintenance", "equipment", "schedule", "preventive"],
      accessLevel: "internal",
      department: "maintenance",
      version: "3.0",
      fileUrl: "/documents/maintenance-schedule-v3.0.xlsx",
      fileName: "maintenance-schedule-v3.0.xlsx",
      fileSize: 892345,
      fileType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      checksum: "sha256:ghi789jkl012",
      status: "approved",
      approvalRequired: false,
      createdBy: "Tom Maintenance",
      createdAt: "2024-12-01 08:00:00",
      updatedAt: "2024-12-16 16:45:00",
      lastAccessedAt: "2024-12-17 02:00:00",
      accessCount: 45,
      downloadCount: 12,
      isFavorite: false,
      isLocked: false,
      revisions: 3
    },
    {
      id: "doc_004",
      title: "ISO 9001 Compliance Checklist",
      description: "Checklist for ISO 9001 quality management system compliance",
      category: "compliance",
      type: "policy",
      tags: ["iso", "compliance", "quality", "audit"],
      accessLevel: "restricted",
      department: "quality",
      version: "1.2",
      fileUrl: "/documents/iso-9001-checklist-v1.2.pdf",
      fileName: "iso-9001-checklist-v1.2.pdf",
      fileSize: 1234567,
      fileType: "application/pdf",
      checksum: "sha256:jkl012mno345",
      status: "review",
      expiryDate: "2025-12-01",
      approvalRequired: true,
      createdBy: "Alice Compliance",
      createdAt: "2024-11-20 13:30:00",
      updatedAt: "2024-12-12 10:15:00",
      accessCount: 34,
      downloadCount: 8,
      isFavorite: true,
      isLocked: false,
      revisions: 2
    },
    {
      id: "doc_005",
      title: "New Employee Training Guide",
      description: "Comprehensive training guide for new manufacturing employees",
      category: "training",
      type: "training",
      tags: ["training", "onboarding", "employees", "orientation"],
      accessLevel: "public",
      department: "hr",
      version: "2.3",
      fileUrl: "/documents/employee-training-guide-v2.3.pdf",
      fileName: "employee-training-guide-v2.3.pdf",
      fileSize: 3456789,
      fileType: "application/pdf",
      checksum: "sha256:mno345pqr678",
      status: "approved",
      approvalRequired: true,
      approvedBy: "Diana HR Director",
      approvedAt: "2024-12-05 09:30:00",
      createdBy: "Bob HR",
      createdAt: "2024-10-15 10:00:00",
      updatedAt: "2024-12-05 09:30:00",
      lastAccessedAt: "2024-12-17 01:45:00",
      accessCount: 234,
      downloadCount: 89,
      isFavorite: false,
      isLocked: false,
      revisions: 7
    },
    {
      id: "doc_006",
      title: "Environmental Impact Assessment",
      description: "Annual environmental impact assessment and sustainability report",
      category: "environmental",
      type: "report",
      tags: ["environment", "sustainability", "impact", "annual"],
      accessLevel: "public",
      department: "environmental",
      version: "2024.1",
      fileUrl: "/documents/environmental-impact-2024.pdf",
      fileName: "environmental-impact-2024.pdf",
      fileSize: 6789012,
      fileType: "application/pdf",
      checksum: "sha256:pqr678stu901",
      status: "approved",
      expiryDate: "2025-12-31",
      approvalRequired: true,
      approvedBy: "Green Environmental Manager",
      approvedAt: "2024-12-01 11:00:00",
      createdBy: "Emma Environmental",
      createdAt: "2024-11-01 14:00:00",
      updatedAt: "2024-12-01 11:00:00",
      accessCount: 67,
      downloadCount: 15,
      isFavorite: false,
      isLocked: false,
      revisions: 1
    }
  ];

  const sampleFolders: Folder[] = [
    {
      id: "folder_001",
      name: "Safety Procedures",
      description: "All safety-related documents and procedures",
      accessLevel: "internal",
      department: "safety",
      documentCount: 15,
      subfolderCount: 3,
      createdBy: "John Safety Manager",
      createdAt: "2024-10-01 09:00:00",
      updatedAt: "2024-12-15 10:00:00"
    },
    {
      id: "folder_002",
      name: "Quality Manuals",
      description: "Quality control and assurance documentation",
      accessLevel: "internal",
      department: "quality",
      documentCount: 23,
      subfolderCount: 5,
      createdBy: "Mike Quality Director",
      createdAt: "2024-09-15 11:00:00",
      updatedAt: "2024-12-10 14:30:00"
    },
    {
      id: "folder_003",
      name: "Training Materials",
      description: "Employee training and development resources",
      accessLevel: "public",
      department: "hr",
      documentCount: 34,
      subfolderCount: 8,
      createdBy: "Diana HR Director",
      createdAt: "2024-08-01 08:00:00",
      updatedAt: "2024-12-05 09:30:00"
    }
  ];

  const sampleKnowledgeArticles: KnowledgeArticle[] = [
    {
      id: "kb_001",
      title: "Troubleshooting Common Production Line Issues",
      content: "Comprehensive guide to identifying and resolving common production line problems...",
      summary: "Step-by-step troubleshooting guide for production line operators",
      category: "troubleshooting",
      tags: ["production", "troubleshooting", "maintenance", "operators"],
      author: "Sarah Production Expert",
      status: "published",
      views: 456,
      likes: 23,
      isPublic: true,
      relatedDocuments: ["doc_001", "doc_003"],
      lastUpdated: "2024-12-15 14:30:00",
      createdAt: "2024-11-20 10:00:00"
    },
    {
      id: "kb_002",
      title: "Best Practices for Quality Inspections",
      content: "Guidelines and best practices for conducting thorough quality inspections...",
      summary: "Quality inspection best practices and common pitfalls to avoid",
      category: "quality",
      tags: ["quality", "inspection", "best-practices", "standards"],
      author: "Mike Quality Director",
      status: "published",
      views: 234,
      likes: 18,
      isPublic: true,
      relatedDocuments: ["doc_002", "doc_004"],
      lastUpdated: "2024-12-12 16:45:00",
      createdAt: "2024-11-10 13:15:00"
    }
  ];

  const sampleTrainings: Training[] = [
    {
      id: "train_001",
      title: "Manufacturing Safety Fundamentals",
      description: "Essential safety training for all manufacturing personnel",
      category: "safety",
      type: "certification",
      duration: 120,
      difficulty: "beginner",
      prerequisiteIds: [],
      relatedDocumentIds: ["doc_001", "doc_005"],
      status: "active",
      completionRate: 87.5,
      averageRating: 4.6,
      enrolledCount: 156,
      createdBy: "John Safety Manager",
      createdAt: "2024-10-01 09:00:00",
      updatedAt: "2024-12-01 11:00:00"
    },
    {
      id: "train_002",
      title: "Advanced Quality Control Techniques",
      description: "Advanced training for quality control inspectors",
      category: "quality",
      type: "course",
      duration: 240,
      difficulty: "advanced",
      prerequisiteIds: ["train_001"],
      relatedDocumentIds: ["doc_002", "doc_004"],
      status: "active",
      completionRate: 72.3,
      averageRating: 4.8,
      enrolledCount: 89,
      createdBy: "Mike Quality Director",
      createdAt: "2024-11-01 10:00:00",
      updatedAt: "2024-12-10 14:30:00"
    }
  ];

  // Create document mutation
  const createDocumentMutation = useMutation({
    mutationFn: async (data: z.infer<typeof documentSchema>) => {
      return apiRequest("/api/documents", "POST", data);
    },
    onSuccess: () => {
      toast({
        title: "Document Created",
        description: "Document has been uploaded successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/documents"] });
      setIsDocumentDialogOpen(false);
      documentForm.reset();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create document",
        variant: "destructive",
      });
    },
  });

  // Create folder mutation
  const createFolderMutation = useMutation({
    mutationFn: async (data: z.infer<typeof folderSchema>) => {
      return apiRequest("/api/documents/folders", "POST", data);
    },
    onSuccess: () => {
      toast({
        title: "Folder Created",
        description: "Folder has been created successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/documents/folders"] });
      setIsFolderDialogOpen(false);
      folderForm.reset();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create folder",
        variant: "destructive",
      });
    },
  });

  const getFileIcon = (fileType: string) => {
    if (fileType.includes("pdf")) return <FileText className="w-5 h-5 text-red-600" />;
    if (fileType.includes("image")) return <FileImage className="w-5 h-5 text-blue-600" />;
    if (fileType.includes("video")) return <FileVideo className="w-5 h-5 text-purple-600" />;
    if (fileType.includes("audio")) return <FileAudio className="w-5 h-5 text-green-600" />;
    if (fileType.includes("spreadsheet") || fileType.includes("excel")) return <Database className="w-5 h-5 text-green-600" />;
    return <FileText className="w-5 h-5 text-gray-600" />;
  };

  const getAccessLevelColor = (level: string) => {
    switch (level) {
      case "public":
        return "bg-green-100 text-green-800";
      case "internal":
        return "bg-blue-100 text-blue-800";
      case "restricted":
        return "bg-yellow-100 text-yellow-800";
      case "confidential":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "approved":
        return "bg-green-100 text-green-800";
      case "review":
        return "bg-yellow-100 text-yellow-800";
      case "draft":
        return "bg-gray-100 text-gray-800";
      case "expired":
        return "bg-red-100 text-red-800";
      case "archived":
        return "bg-purple-100 text-purple-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "sop":
        return <Settings className="w-4 h-4" />;
      case "manual":
        return <BookOpen className="w-4 h-4" />;
      case "policy":
        return <Shield className="w-4 h-4" />;
      case "training":
        return <GraduationCap className="w-4 h-4" />;
      case "specification":
        return <Target className="w-4 h-4" />;
      case "certificate":
        return <Award className="w-4 h-4" />;
      case "report":
        return <TrendingUp className="w-4 h-4" />;
      default:
        return <FileText className="w-4 h-4" />;
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "beginner":
        return "bg-green-100 text-green-800";
      case "intermediate":
        return "bg-yellow-100 text-yellow-800";
      case "advanced":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const formatFileSize = (bytes: number) => {
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    if (bytes === 0) return '0 Bytes';
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return Math.round(bytes / Math.pow(1024, i) * 100) / 100 + ' ' + sizes[i];
  };

  const formatDuration = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    if (hours === 0) return `${mins}m`;
    return `${hours}h ${mins}m`;
  };

  const filteredDocuments = sampleDocuments.filter(doc => {
    const matchesSearch = searchTerm === "" || 
      doc.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      doc.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      doc.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesCategory = filterCategory === "all" || doc.category === filterCategory;
    const matchesType = filterType === "all" || doc.type === filterType;
    const matchesFolder = !currentFolderId || doc.folderId === currentFolderId;
    return matchesSearch && matchesCategory && matchesType && matchesFolder;
  });

  const documentStats = {
    total: sampleDocuments.length,
    approved: sampleDocuments.filter(d => d.status === "approved").length,
    pending: sampleDocuments.filter(d => d.status === "review" || d.status === "draft").length,
    expired: sampleDocuments.filter(d => d.status === "expired").length,
    totalSize: sampleDocuments.reduce((sum, d) => sum + d.fileSize, 0)
  };

  const onDocumentSubmit = (data: z.infer<typeof documentSchema>) => {
    createDocumentMutation.mutate(data);
  };

  const onFolderSubmit = (data: z.infer<typeof folderSchema>) => {
    createFolderMutation.mutate(data);
  };

  const handleDownload = (document: Document) => {
    toast({
      title: "Download Started",
      description: `Downloading ${document.fileName}...`,
    });
    // Implement download logic
  };

  const handleToggleFavorite = (documentId: string) => {
    toast({
      title: "Favorite Updated",
      description: "Document favorite status has been updated",
    });
    // Implement favorite toggle logic
  };

  return (
    <div className="flex h-screen bg-carbon-gray-10">
      <Sidebar />
      <div className="flex-1 overflow-auto">
        <div className="p-6 space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-carbon-gray-80">Document Management</h1>
              <p className="text-carbon-gray-60">Manage documents, knowledge base, and training materials</p>
            </div>
            <div className="flex items-center space-x-3">
              <Button variant="outline" onClick={() => setViewMode(viewMode === "grid" ? "list" : "grid")}>
                {viewMode === "grid" ? <Database className="w-4 h-4" /> : <Folder className="w-4 h-4" />}
              </Button>
              <Button variant="outline" onClick={() => queryClient.invalidateQueries({ queryKey: ["/api/documents"] })}>
                <Activity className="w-4 h-4 mr-2" />
                Refresh
              </Button>
            </div>
          </div>

          {/* Overview Stats */}
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <FileText className="w-5 h-5 text-blue-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Total Documents</p>
                    <p className="text-xl font-bold">{documentStats.total}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Approved</p>
                    <p className="text-xl font-bold">{documentStats.approved}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Clock className="w-5 h-5 text-yellow-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Pending</p>
                    <p className="text-xl font-bold">{documentStats.pending}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <AlertCircle className="w-5 h-5 text-red-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Expired</p>
                    <p className="text-xl font-bold">{documentStats.expired}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Database className="w-5 h-5 text-purple-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Total Size</p>
                    <p className="text-xl font-bold">{formatFileSize(documentStats.totalSize)}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
            <div className="flex items-center justify-between">
              <TabsList>
                <TabsTrigger value="documents">Documents</TabsTrigger>
                <TabsTrigger value="folders">Folders</TabsTrigger>
                <TabsTrigger value="knowledge">Knowledge Base</TabsTrigger>
                <TabsTrigger value="training">Training</TabsTrigger>
                <TabsTrigger value="audit">Audit Trail</TabsTrigger>
              </TabsList>
              <div className="flex space-x-2">
                {activeTab === "documents" && (
                  <Dialog open={isDocumentDialogOpen} onOpenChange={setIsDocumentDialogOpen}>
                    <DialogTrigger asChild>
                      <Button>
                        <Upload className="w-4 h-4 mr-2" />
                        Upload Document
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl">
                      <DialogHeader>
                        <DialogTitle>Upload New Document</DialogTitle>
                      </DialogHeader>
                      <Form {...documentForm}>
                        <form onSubmit={documentForm.handleSubmit(onDocumentSubmit)} className="space-y-4">
                          <div className="grid grid-cols-2 gap-4">
                            <FormField
                              control={documentForm.control}
                              name="title"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Document Title</FormLabel>
                                  <FormControl>
                                    <Input {...field} />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={documentForm.control}
                              name="category"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Category</FormLabel>
                                  <FormControl>
                                    <Select onValueChange={field.onChange} value={field.value}>
                                      <SelectTrigger>
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="safety">Safety</SelectItem>
                                        <SelectItem value="quality">Quality</SelectItem>
                                        <SelectItem value="maintenance">Maintenance</SelectItem>
                                        <SelectItem value="training">Training</SelectItem>
                                        <SelectItem value="compliance">Compliance</SelectItem>
                                        <SelectItem value="environmental">Environmental</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                          </div>
                          <FormField
                            control={documentForm.control}
                            name="description"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Description</FormLabel>
                                <FormControl>
                                  <Textarea {...field} />
                                </FormControl>
                              </FormItem>
                            )}
                          />
                          <div className="grid grid-cols-3 gap-4">
                            <FormField
                              control={documentForm.control}
                              name="type"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Document Type</FormLabel>
                                  <FormControl>
                                    <Select onValueChange={field.onChange} value={field.value}>
                                      <SelectTrigger>
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="sop">SOP</SelectItem>
                                        <SelectItem value="manual">Manual</SelectItem>
                                        <SelectItem value="policy">Policy</SelectItem>
                                        <SelectItem value="training">Training</SelectItem>
                                        <SelectItem value="specification">Specification</SelectItem>
                                        <SelectItem value="certificate">Certificate</SelectItem>
                                        <SelectItem value="report">Report</SelectItem>
                                        <SelectItem value="other">Other</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={documentForm.control}
                              name="accessLevel"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Access Level</FormLabel>
                                  <FormControl>
                                    <Select onValueChange={field.onChange} value={field.value}>
                                      <SelectTrigger>
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="public">Public</SelectItem>
                                        <SelectItem value="internal">Internal</SelectItem>
                                        <SelectItem value="restricted">Restricted</SelectItem>
                                        <SelectItem value="confidential">Confidential</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={documentForm.control}
                              name="department"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Department</FormLabel>
                                  <FormControl>
                                    <Select onValueChange={field.onChange} value={field.value}>
                                      <SelectTrigger>
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="production">Production</SelectItem>
                                        <SelectItem value="quality">Quality</SelectItem>
                                        <SelectItem value="maintenance">Maintenance</SelectItem>
                                        <SelectItem value="safety">Safety</SelectItem>
                                        <SelectItem value="hr">Human Resources</SelectItem>
                                        <SelectItem value="environmental">Environmental</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                          </div>
                          <div className="flex justify-end space-x-2">
                            <Button type="button" variant="outline" onClick={() => setIsDocumentDialogOpen(false)}>
                              Cancel
                            </Button>
                            <Button type="submit" disabled={createDocumentMutation.isPending}>
                              {createDocumentMutation.isPending ? "Uploading..." : "Upload Document"}
                            </Button>
                          </div>
                        </form>
                      </Form>
                    </DialogContent>
                  </Dialog>
                )}
                {activeTab === "folders" && (
                  <Dialog open={isFolderDialogOpen} onOpenChange={setIsFolderDialogOpen}>
                    <DialogTrigger asChild>
                      <Button>
                        <Plus className="w-4 h-4 mr-2" />
                        New Folder
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Create New Folder</DialogTitle>
                      </DialogHeader>
                      <Form {...folderForm}>
                        <form onSubmit={folderForm.handleSubmit(onFolderSubmit)} className="space-y-4">
                          <FormField
                            control={folderForm.control}
                            name="name"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Folder Name</FormLabel>
                                <FormControl>
                                  <Input {...field} />
                                </FormControl>
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={folderForm.control}
                            name="description"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Description (Optional)</FormLabel>
                                <FormControl>
                                  <Textarea {...field} />
                                </FormControl>
                              </FormItem>
                            )}
                          />
                          <div className="grid grid-cols-2 gap-4">
                            <FormField
                              control={folderForm.control}
                              name="accessLevel"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Access Level</FormLabel>
                                  <FormControl>
                                    <Select onValueChange={field.onChange} value={field.value}>
                                      <SelectTrigger>
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="public">Public</SelectItem>
                                        <SelectItem value="internal">Internal</SelectItem>
                                        <SelectItem value="restricted">Restricted</SelectItem>
                                        <SelectItem value="confidential">Confidential</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={folderForm.control}
                              name="department"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Department</FormLabel>
                                  <FormControl>
                                    <Select onValueChange={field.onChange} value={field.value}>
                                      <SelectTrigger>
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="production">Production</SelectItem>
                                        <SelectItem value="quality">Quality</SelectItem>
                                        <SelectItem value="maintenance">Maintenance</SelectItem>
                                        <SelectItem value="safety">Safety</SelectItem>
                                        <SelectItem value="hr">Human Resources</SelectItem>
                                        <SelectItem value="environmental">Environmental</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                          </div>
                          <div className="flex justify-end space-x-2">
                            <Button type="button" variant="outline" onClick={() => setIsFolderDialogOpen(false)}>
                              Cancel
                            </Button>
                            <Button type="submit" disabled={createFolderMutation.isPending}>
                              {createFolderMutation.isPending ? "Creating..." : "Create Folder"}
                            </Button>
                          </div>
                        </form>
                      </Form>
                    </DialogContent>
                  </Dialog>
                )}
              </div>
            </div>

            <TabsContent value="documents" className="space-y-4">
              {/* Filters and Search */}
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      placeholder="Search documents..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10 w-64"
                    />
                  </div>
                  <Select value={filterCategory} onValueChange={setFilterCategory}>
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Categories</SelectItem>
                      <SelectItem value="safety">Safety</SelectItem>
                      <SelectItem value="quality">Quality</SelectItem>
                      <SelectItem value="maintenance">Maintenance</SelectItem>
                      <SelectItem value="training">Training</SelectItem>
                      <SelectItem value="compliance">Compliance</SelectItem>
                      <SelectItem value="environmental">Environmental</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={filterType} onValueChange={setFilterType}>
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="sop">SOP</SelectItem>
                      <SelectItem value="manual">Manual</SelectItem>
                      <SelectItem value="policy">Policy</SelectItem>
                      <SelectItem value="training">Training</SelectItem>
                      <SelectItem value="specification">Specification</SelectItem>
                      <SelectItem value="certificate">Certificate</SelectItem>
                      <SelectItem value="report">Report</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="updated">Last Updated</SelectItem>
                    <SelectItem value="created">Date Created</SelectItem>
                    <SelectItem value="name">Name A-Z</SelectItem>
                    <SelectItem value="size">File Size</SelectItem>
                    <SelectItem value="views">Most Viewed</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Documents Grid/List */}
              <div className={viewMode === "grid" ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" : "space-y-4"}>
                {filteredDocuments.map((document) => (
                  <Card key={document.id} className="border-carbon-gray-20 hover:shadow-lg transition-shadow">
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          {getFileIcon(document.fileType)}
                          <div className="flex-1 min-w-0">
                            <CardTitle className="text-lg truncate">{document.title}</CardTitle>
                            <p className="text-sm text-carbon-gray-60">v{document.version}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          {getTypeIcon(document.type)}
                          {document.isLocked && <Lock className="w-4 h-4 text-yellow-600" />}
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleToggleFavorite(document.id)}
                          >
                            {document.isFavorite ? (
                              <Star className="w-4 h-4 text-yellow-500 fill-current" />
                            ) : (
                              <StarOff className="w-4 h-4 text-gray-400" />
                            )}
                          </Button>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <p className="text-sm text-gray-600 line-clamp-2">{document.description}</p>
                      
                      <div className="flex flex-wrap gap-2">
                        <Badge className={getAccessLevelColor(document.accessLevel)}>
                          {document.accessLevel}
                        </Badge>
                        <Badge className={getStatusColor(document.status)}>
                          {document.status}
                        </Badge>
                        {document.tags.slice(0, 2).map((tag, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>

                      <div className="grid grid-cols-2 gap-2 text-xs text-gray-500">
                        <div>
                          <span className="font-medium">Size:</span> {formatFileSize(document.fileSize)}
                        </div>
                        <div>
                          <span className="font-medium">Views:</span> {document.accessCount}
                        </div>
                        <div>
                          <span className="font-medium">Downloads:</span> {document.downloadCount}
                        </div>
                        <div>
                          <span className="font-medium">Revisions:</span> {document.revisions}
                        </div>
                      </div>

                      {document.expiryDate && (
                        <div className="flex items-center space-x-2 text-xs text-yellow-600">
                          <Clock className="w-3 h-3" />
                          <span>Expires: {document.expiryDate}</span>
                        </div>
                      )}

                      <div className="text-xs text-gray-500">
                        <p>Created by {document.createdBy}</p>
                        <p>Updated: {document.updatedAt}</p>
                      </div>

                      <div className="flex items-center justify-between pt-2 border-t">
                        <div className="flex space-x-1">
                          <Button size="sm" variant="outline">
                            <Eye className="w-3 h-3" />
                          </Button>
                          <Button size="sm" variant="outline" onClick={() => handleDownload(document)}>
                            <Download className="w-3 h-3" />
                          </Button>
                          <Button size="sm" variant="outline">
                            <Edit className="w-3 h-3" />
                          </Button>
                        </div>
                        <div className="flex space-x-1">
                          <Button size="sm" variant="outline">
                            <Share className="w-3 h-3" />
                          </Button>
                          <Button size="sm" variant="outline">
                            <History className="w-3 h-3" />
                          </Button>
                          <Button size="sm" variant="outline">
                            <MoreHorizontal className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="folders" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {sampleFolders.map((folder) => (
                  <Card key={folder.id} className="border-carbon-gray-20 hover:shadow-lg transition-shadow cursor-pointer">
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <Folder className="w-8 h-8 text-blue-600" />
                          <div>
                            <CardTitle className="text-lg">{folder.name}</CardTitle>
                            <p className="text-sm text-carbon-gray-60 capitalize">{folder.department}</p>
                          </div>
                        </div>
                        <Badge className={getAccessLevelColor(folder.accessLevel)}>
                          {folder.accessLevel}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {folder.description && (
                        <p className="text-sm text-gray-600">{folder.description}</p>
                      )}
                      
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div className="flex items-center space-x-2">
                          <FileText className="w-4 h-4 text-blue-600" />
                          <span>{folder.documentCount} documents</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Folder className="w-4 h-4 text-yellow-600" />
                          <span>{folder.subfolderCount} folders</span>
                        </div>
                      </div>

                      <div className="text-xs text-gray-500">
                        <p>Created by {folder.createdBy}</p>
                        <p>Updated: {folder.updatedAt}</p>
                      </div>

                      <div className="flex space-x-2 pt-2 border-t">
                        <Button size="sm" variant="outline" className="flex-1">
                          <Eye className="w-3 h-3 mr-2" />
                          Open
                        </Button>
                        <Button size="sm" variant="outline">
                          <Edit className="w-3 h-3" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <MoreHorizontal className="w-3 h-3" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="knowledge" className="space-y-4">
              <div className="space-y-6">
                {sampleKnowledgeArticles.map((article) => (
                  <Card key={article.id} className="border-carbon-gray-20">
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <CardTitle className="text-xl">{article.title}</CardTitle>
                          <p className="text-sm text-carbon-gray-60 mt-1">{article.summary}</p>
                        </div>
                        <Badge className={article.status === "published" ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"}>
                          {article.status}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex flex-wrap gap-2">
                        <Badge variant="outline" className="text-xs capitalize">
                          {article.category}
                        </Badge>
                        {article.tags.slice(0, 3).map((tag, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>

                      <div className="flex items-center justify-between text-sm text-gray-500">
                        <div className="flex items-center space-x-4">
                          <div className="flex items-center space-x-1">
                            <User className="w-3 h-3" />
                            <span>{article.author}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Eye className="w-3 h-3" />
                            <span>{article.views} views</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Star className="w-3 h-3" />
                            <span>{article.likes} likes</span>
                          </div>
                        </div>
                        <span>Updated: {article.lastUpdated}</span>
                      </div>

                      <div className="flex space-x-2 pt-2 border-t">
                        <Button size="sm" variant="outline">
                          <Eye className="w-3 h-3 mr-2" />
                          Read
                        </Button>
                        <Button size="sm" variant="outline">
                          <Edit className="w-3 h-3 mr-2" />
                          Edit
                        </Button>
                        <Button size="sm" variant="outline">
                          <Share className="w-3 h-3 mr-2" />
                          Share
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="training" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {sampleTrainings.map((training) => (
                  <Card key={training.id} className="border-carbon-gray-20">
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <GraduationCap className="w-6 h-6 text-blue-600" />
                          <div>
                            <CardTitle className="text-lg">{training.title}</CardTitle>
                            <p className="text-sm text-carbon-gray-60 capitalize">{training.category}</p>
                          </div>
                        </div>
                        <Badge className={getDifficultyColor(training.difficulty)}>
                          {training.difficulty}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <p className="text-sm text-gray-600">{training.description}</p>
                      
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="font-medium">Duration:</span> {formatDuration(training.duration)}
                        </div>
                        <div>
                          <span className="font-medium">Type:</span> {training.type}
                        </div>
                        <div>
                          <span className="font-medium">Enrolled:</span> {training.enrolledCount}
                        </div>
                        <div className="flex items-center space-x-1">
                          <span className="font-medium">Rating:</span>
                          <div className="flex items-center">
                            <Star className="w-3 h-3 text-yellow-500 fill-current" />
                            <span>{training.averageRating}</span>
                          </div>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Completion Rate</span>
                          <span>{training.completionRate}%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-blue-600 h-2 rounded-full" 
                            style={{ width: `${training.completionRate}%` }}
                          ></div>
                        </div>
                      </div>

                      <div className="text-xs text-gray-500">
                        <p>Created by {training.createdBy}</p>
                        <p>Updated: {training.updatedAt}</p>
                      </div>

                      <div className="flex space-x-2 pt-2 border-t">
                        <Button size="sm" className="flex-1">
                          <Activity className="w-3 h-3 mr-2" />
                          Start Training
                        </Button>
                        <Button size="sm" variant="outline">
                          <Eye className="w-3 h-3" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <MoreHorizontal className="w-3 h-3" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="audit" className="space-y-4">
              <div className="text-center py-12">
                <History className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">Audit Trail</h3>
                <p className="text-gray-600 mb-4">Comprehensive audit logs for all document activities</p>
                <Button>
                  <Activity className="w-4 h-4 mr-2" />
                  View Audit Logs
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}