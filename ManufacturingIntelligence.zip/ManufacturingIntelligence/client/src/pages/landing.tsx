import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Factory, BarChart3, Package, CheckCircle, QrCode, Users } from "lucide-react";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  const handleDemoLogin = async () => {
    try {
      const response = await fetch('/api/demo-login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: 'demo@example.com' })
      });
      if (response.ok) {
        window.location.reload();
      }
    } catch (error) {
      console.error('Demo login failed:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-carbon-gray-10 to-white">
      {/* Header */}
      <header className="border-b border-carbon-gray-20 bg-white/80 backdrop-blur-sm">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Factory className="w-8 h-8 text-carbon-blue" />
              <div>
                <h1 className="text-xl font-bold text-carbon-gray-80">ManufacturePro</h1>
                <p className="text-sm text-carbon-gray-50">ERP System</p>
              </div>
            </div>
            <Button onClick={handleLogin} className="carbon-blue">
              Sign In
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20">
        <div className="container mx-auto px-6 text-center">
          <h1 className="text-5xl font-bold text-carbon-gray-80 mb-6">
            AI-Powered Manufacturing ERP
          </h1>
          <p className="text-xl text-carbon-gray-50 mb-8 max-w-3xl mx-auto">
            Streamline your manufacturing operations with real-time inventory tracking, 
            production order management, quality control, and AI-powered forecasting.
          </p>
          <div className="flex items-center space-x-4">
            <Button 
              onClick={handleDemoLogin}
              size="lg"
              className="bg-blue-600 hover:bg-blue-700 text-white text-lg px-8 py-4"
            >
              Try Demo
            </Button>
            <Button 
              onClick={handleLogin}
              size="lg"
              variant="outline"
              className="text-lg px-8 py-4"
            >
              Sign In with Replit
            </Button>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-16">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center text-carbon-gray-80 mb-12">
            Complete Manufacturing Solution
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Real-time Inventory */}
            <Card className="border-carbon-gray-20 hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-carbon-blue bg-opacity-10 rounded-lg flex items-center justify-center mb-4">
                  <Package className="w-6 h-6 text-carbon-blue" />
                </div>
                <h3 className="text-xl font-semibold text-carbon-gray-80 mb-3">
                  Real-time Inventory
                </h3>
                <p className="text-carbon-gray-50">
                  Track stock levels in real-time with automated low-stock alerts 
                  and barcode scanning capabilities.
                </p>
              </CardContent>
            </Card>

            {/* Production Management */}
            <Card className="border-carbon-gray-20 hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-carbon-green bg-opacity-10 rounded-lg flex items-center justify-center mb-4">
                  <BarChart3 className="w-6 h-6 text-carbon-green" />
                </div>
                <h3 className="text-xl font-semibold text-carbon-gray-80 mb-3">
                  Production Management
                </h3>
                <p className="text-carbon-gray-50">
                  Manage production orders with role-based workflows, progress tracking, 
                  and status management.
                </p>
              </CardContent>
            </Card>

            {/* Quality Control */}
            <Card className="border-carbon-gray-20 hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-carbon-yellow bg-opacity-10 rounded-lg flex items-center justify-center mb-4">
                  <CheckCircle className="w-6 h-6 text-carbon-yellow" />
                </div>
                <h3 className="text-xl font-semibold text-carbon-gray-80 mb-3">
                  Quality Control
                </h3>
                <p className="text-carbon-gray-50">
                  Log quality control checks with pass/fail tracking, 
                  notes, and defect documentation.
                </p>
              </CardContent>
            </Card>

            {/* Barcode Scanning */}
            <Card className="border-carbon-gray-20 hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-carbon-red bg-opacity-10 rounded-lg flex items-center justify-center mb-4">
                  <QrCode className="w-6 h-6 text-carbon-red" />
                </div>
                <h3 className="text-xl font-semibold text-carbon-gray-80 mb-3">
                  Barcode Scanning
                </h3>
                <p className="text-carbon-gray-50">
                  Quick item lookup and inventory management with 
                  barcode scanning and manual entry support.
                </p>
              </CardContent>
            </Card>

            {/* Role-based Access */}
            <Card className="border-carbon-gray-20 hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-purple-500 bg-opacity-10 rounded-lg flex items-center justify-center mb-4">
                  <Users className="w-6 h-6 text-purple-500" />
                </div>
                <h3 className="text-xl font-semibold text-carbon-gray-80 mb-3">
                  Role-based Access
                </h3>
                <p className="text-carbon-gray-50">
                  Secure access control with Admin, Manager, and Employee roles 
                  with appropriate permissions.
                </p>
              </CardContent>
            </Card>

            {/* AI Insights */}
            <Card className="border-carbon-gray-20 hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 bg-opacity-10 rounded-lg flex items-center justify-center mb-4">
                  <div className="w-6 h-6 bg-gradient-to-br from-purple-500 to-pink-500 rounded"></div>
                </div>
                <h3 className="text-xl font-semibold text-carbon-gray-80 mb-3">
                  AI-Powered Insights
                </h3>
                <p className="text-carbon-gray-50">
                  Get demand forecasting, cost optimization suggestions, 
                  and quality predictions powered by AI.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-carbon-gray-80">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-3xl font-bold text-white mb-6">
            Ready to Transform Your Manufacturing?
          </h2>
          <p className="text-xl text-carbon-gray-20 mb-8 max-w-2xl mx-auto">
            Join hundreds of manufacturers who trust ManufacturePro to streamline 
            their operations and increase efficiency.
          </p>
          <div className="flex gap-4 justify-center">
            <Button 
              onClick={handleLogin}
              size="lg"
              className="carbon-blue text-lg px-8 py-4"
            >
              Start Your Free Trial
            </Button>
            <Button 
              onClick={handleDemoLogin}
              size="lg"
              variant="outline"
              className="text-lg px-8 py-4 border-white text-white hover:bg-white hover:text-carbon-gray-80"
            >
              Try Demo
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-carbon-gray-20 py-8">
        <div className="container mx-auto px-6 text-center">
          <p className="text-carbon-gray-50">
            © 2024 ManufacturePro ERP. Built for modern manufacturing teams.
          </p>
        </div>
      </footer>
    </div>
  );
}
