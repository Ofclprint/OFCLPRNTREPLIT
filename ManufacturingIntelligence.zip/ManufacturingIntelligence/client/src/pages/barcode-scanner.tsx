import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import Sidebar from "@/components/layout/sidebar";
import MobileNav from "@/components/layout/mobile-nav";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { QrCode, Search, Camera, Package, AlertCircle, Plus, Minus, RotateCcw, X, Check, CameraOff, ExternalLink, BarChart3, ClipboardList, Settings } from "lucide-react";

const inventoryMovementSchema = z.object({
  itemId: z.number().min(1, "Item is required"),
  type: z.enum(["in", "out", "adjustment"]),
  quantity: z.number().min(1, "Quantity must be positive"),
  reason: z.string().optional(),
});

type InventoryItem = {
  id: number;
  name: string;
  sku: string;
  currentStock: number;
  minStock: number;
  maxStock: number;
  unitPrice: string;
  unit: string;
  location?: string;
  barcode?: string;
};

export default function BarcodeScanner() {
  const [manualBarcode, setManualBarcode] = useState("");
  const [scannedItem, setScannedItem] = useState<InventoryItem | null>(null);
  const [isStockDialogOpen, setIsStockDialogOpen] = useState(false);
  const [scanHistory, setScanHistory] = useState<string[]>([]);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [pendingBarcode, setPendingBarcode] = useState<string>("");
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  const { toast } = useToast();
  const { isAuthenticated, isLoading, user } = useAuth();
  const queryClient = useQueryClient();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const form = useForm<z.infer<typeof inventoryMovementSchema>>({
    resolver: zodResolver(inventoryMovementSchema),
    defaultValues: {
      itemId: 0,
      type: "adjustment",
      quantity: 1,
      reason: "",
    },
  });

  const { data: inventory = [] } = useQuery({
    queryKey: ["/api/inventory"],
    enabled: isAuthenticated,
  });

  // Camera functions
  const startCamera = async () => {
    try {
      // Check if camera is available
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setCameraError("Camera not supported on this device");
        return;
      }

      console.log("Requesting camera access...");
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
          facingMode: 'environment', // Use back camera on mobile
          width: { ideal: 1280 },
          height: { ideal: 720 }
        }
      });
      
      console.log("Camera stream obtained:", stream);
      setCameraStream(stream);
      setIsCameraActive(true);
      setCameraError(null);
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        console.log("Video element source set");
        
        // Ensure video plays
        videoRef.current.onloadedmetadata = () => {
          console.log("Video metadata loaded, playing...");
          videoRef.current?.play().catch(e => console.error("Play error:", e));
        };
      }
    } catch (error) {
      let errorMessage = "Camera access denied or not available";
      if (error instanceof Error) {
        if (error.name === 'NotAllowedError') {
          errorMessage = "Camera permission denied. Please allow camera access and try again.";
        } else if (error.name === 'NotFoundError') {
          errorMessage = "No camera found on this device.";
        } else if (error.name === 'NotSupportedError') {
          errorMessage = "Camera not supported on this browser.";
        }
      }
      setCameraError(errorMessage);
      console.error("Camera error:", error);
    }
  };

  const stopCamera = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach(track => track.stop());
      setCameraStream(null);
    }
    setIsCameraActive(false);
    setCapturedImage(null);
    setPendingBarcode("");
  };

  const captureImage = () => {
    if (!videoRef.current || !canvasRef.current) return;
    
    const video = videoRef.current;
    const canvas = canvasRef.current;
    const context = canvas.getContext('2d');
    
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    
    if (context) {
      context.drawImage(video, 0, 0);
      const imageData = canvas.toDataURL('image/jpeg');
      setCapturedImage(imageData);
      
      // Prompt user to enter barcode from captured image
      setIsScanning(false);
    }
  };

  const submitBarcode = (barcode: string) => {
    if (barcode.trim()) {
      lookupMutation.mutate(barcode.trim());
      setPendingBarcode("");
      setCapturedImage(null);
      setManualBarcode("");
    }
  };

  const retakePhoto = () => {
    setCapturedImage(null);
    setPendingBarcode("");
    setIsScanning(false);
  };

  // Cleanup camera on unmount
  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  const lookupMutation = useMutation({
    mutationFn: async (barcode: string) => {
      const response = await apiRequest("GET", `/api/inventory/barcode/${encodeURIComponent(barcode)}`);
      return response.json();
    },
    onSuccess: (data: InventoryItem) => {
      setScannedItem(data);
      setScanHistory(prev => [data.barcode || data.sku, ...prev.slice(0, 9)]);
      form.setValue("itemId", data.id);
      toast({
        title: "Item Found",
        description: `Found: ${data.name} (${data.sku})`,
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Item Not Found",
        description: "No item found with this barcode",
        variant: "destructive",
      });
      setScannedItem(null);
    },
  });

  const stockMovementMutation = useMutation({
    mutationFn: async (data: z.infer<typeof inventoryMovementSchema>) => {
      await apiRequest("POST", "/api/inventory/movements", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/inventory"] });
      setIsStockDialogOpen(false);
      form.reset();
      toast({
        title: "Success",
        description: "Stock movement recorded successfully",
      });
      // Refresh the scanned item data
      if (scannedItem?.barcode) {
        lookupMutation.mutate(scannedItem.barcode);
      }
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to record stock movement",
        variant: "destructive",
      });
    },
  });

  if (isLoading || !isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-carbon-gray-10">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-carbon-blue border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-carbon-gray-50">Loading...</p>
        </div>
      </div>
    );
  }

  const canModifyStock = user && ['admin', 'manager'].includes(user.role);

  const handleManualLookup = () => {
    if (manualBarcode.trim()) {
      lookupMutation.mutate(manualBarcode.trim());
    }
  };

  const handleScanFromHistory = (barcode: string) => {
    lookupMutation.mutate(barcode);
  };

  const onSubmit = (data: z.infer<typeof inventoryMovementSchema>) => {
    stockMovementMutation.mutate(data);
  };

  const getStockStatus = (item: InventoryItem) => {
    if (item.currentStock <= item.minStock) {
      return { status: "critical", color: "bg-red-100 text-red-800" };
    } else if (item.currentStock <= item.minStock * 1.5) {
      return { status: "low", color: "bg-yellow-100 text-yellow-800" };
    }
    return { status: "normal", color: "bg-green-100 text-green-800" };
  };

  const quickStockActions = [
    { type: "in" as const, label: "Stock In", icon: Plus, color: "carbon-green" },
    { type: "out" as const, label: "Stock Out", icon: Minus, color: "carbon-red" },
    { type: "adjustment" as const, label: "Adjust", icon: RotateCcw, color: "carbon-blue" },
  ];

  return (
    <div className="min-h-screen flex bg-carbon-gray-10">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-white border-b border-carbon-gray-20 px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-semibold text-carbon-gray-80">Barcode Scanner</h1>
              <p className="text-carbon-gray-50 text-sm mt-1">Scan or lookup inventory items by barcode</p>
            </div>
          </div>
        </header>

        {/* Scanner Content */}
        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-4xl mx-auto space-y-6">
            {/* Scanner Interface */}
            <Card className="border-carbon-gray-20">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <QrCode className="w-5 h-5 text-carbon-blue" />
                  <span>Barcode Scanner</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Camera Scanner */}
                {!isCameraActive ? (
                  <div className="bg-carbon-gray-80 rounded-lg p-8 text-center">
                    <Camera className="w-16 h-16 text-white mx-auto mb-4" />
                    <p className="text-white mb-4">Camera Barcode Scanner</p>
                    <Button 
                      onClick={startCamera}
                      className="bg-carbon-blue hover:bg-carbon-blue-dark text-white mb-4"
                    >
                      <Camera className="w-4 h-4 mr-2" />
                      Start Camera
                    </Button>
                    {cameraError && (
                      <div className="bg-red-900 bg-opacity-50 rounded-lg p-4 mt-4">
                        <div className="flex items-center space-x-2 mb-3">
                          <AlertCircle className="w-5 h-5 text-red-300" />
                          <p className="text-red-300 font-medium">Camera Permission Required</p>
                        </div>
                        <p className="text-red-200 text-sm mb-4">{cameraError}</p>
                        
                        <div className="space-y-3 text-xs text-gray-300">
                          <div>
                            <p className="font-medium mb-1">To enable camera access:</p>
                            <ol className="list-decimal list-inside space-y-1">
                              <li>Tap the address bar at the top</li>
                              <li>Look for the camera icon 🎥 or lock icon 🔒</li>
                              <li>Tap it and select "Allow" for camera</li>
                              <li>Refresh this page and try again</li>
                            </ol>
                          </div>
                          
                          <div className="pt-2 border-t border-red-700">
                            <p className="font-medium">Alternative: Use manual entry below</p>
                          </div>
                        </div>
                        
                        <Button 
                          onClick={() => window.location.reload()}
                          variant="outline"
                          size="sm"
                          className="mt-3 border-red-300 text-red-300 hover:bg-red-800"
                        >
                          <RotateCcw className="w-4 h-4 mr-2" />
                          Refresh Page
                        </Button>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="space-y-4">
                    {/* Camera View */}
                    <div className="relative bg-black rounded-lg overflow-hidden">
                      {capturedImage ? (
                        <div className="relative">
                          <img 
                            src={capturedImage} 
                            alt="Captured barcode" 
                            className="w-full h-64 object-cover"
                          />
                          <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
                            <div className="bg-white p-4 rounded-lg space-y-3">
                              <p className="text-center font-medium">Enter barcode from image:</p>
                              <Input
                                type="text"
                                placeholder="Enter barcode..."
                                value={pendingBarcode}
                                onChange={(e) => setPendingBarcode(e.target.value)}
                                onKeyPress={(e) => e.key === 'Enter' && submitBarcode(pendingBarcode)}
                                className="w-64"
                                autoFocus
                              />
                              <div className="flex space-x-2">
                                <Button 
                                  onClick={() => submitBarcode(pendingBarcode)}
                                  disabled={!pendingBarcode.trim()}
                                  className="flex-1"
                                >
                                  <Check className="w-4 h-4 mr-2" />
                                  Submit
                                </Button>
                                <Button 
                                  onClick={retakePhoto}
                                  variant="outline"
                                  className="flex-1"
                                >
                                  <RotateCcw className="w-4 h-4 mr-2" />
                                  Retake
                                </Button>
                              </div>
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div className="relative bg-gray-900 rounded-lg overflow-hidden min-h-[320px]">
                          <video
                            ref={videoRef}
                            autoPlay
                            playsInline
                            muted
                            className="w-full h-80 object-cover bg-gray-900"
                            style={{ minHeight: '320px' }}
                            onLoadedMetadata={() => {
                              console.log('Video loaded');
                            }}
                            onError={(e) => {
                              console.error('Video error:', e);
                            }}
                          />
                          
                          {/* Camera overlay with targeting box - only show if video is playing */}
                          <div className="absolute inset-0 pointer-events-none z-10">
                            {/* Targeting box centered */}
                            <div className="absolute inset-0 flex items-center justify-center">
                              <div className="relative">
                                {/* Main targeting area */}
                                <div className="w-80 h-48 border-4 border-green-400 border-dashed rounded-xl flex flex-col items-center justify-center bg-black bg-opacity-30 backdrop-blur-sm">
                                  <QrCode className="w-20 h-20 text-green-400 mb-4" />
                                  <p className="text-white text-xl font-bold mb-2 tracking-wide">SCAN BARCODE</p>
                                  <p className="text-green-300 text-sm text-center">Position barcode within this frame</p>
                                </div>
                                
                                {/* Corner indicators */}
                                <div className="absolute -top-3 -left-3 w-8 h-8 border-l-4 border-t-4 border-green-400"></div>
                                <div className="absolute -top-3 -right-3 w-8 h-8 border-r-4 border-t-4 border-green-400"></div>
                                <div className="absolute -bottom-3 -left-3 w-8 h-8 border-l-4 border-b-4 border-green-400"></div>
                                <div className="absolute -bottom-3 -right-3 w-8 h-8 border-r-4 border-b-4 border-green-400"></div>
                              </div>
                            </div>
                          </div>
                          
                          {/* Loading indicator if video not ready */}
                          {!videoRef.current?.videoWidth && (
                            <div className="absolute inset-0 flex items-center justify-center bg-gray-900">
                              <div className="text-center text-white">
                                <div className="w-8 h-8 border-4 border-green-400 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                                <p>Starting camera...</p>
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                      <canvas ref={canvasRef} className="hidden" />
                    </div>
                    
                    {/* Camera Controls - Always visible when camera is active */}
                    <div className="space-y-3">
                      {!capturedImage && (
                        <div className="flex space-x-3">
                          <Button 
                            onClick={captureImage}
                            size="lg"
                            className="flex-1 bg-green-600 hover:bg-green-700 text-white font-semibold py-3"
                          >
                            <Camera className="w-5 h-5 mr-2" />
                            Take Picture
                          </Button>
                          <Button 
                            onClick={stopCamera}
                            variant="outline"
                            size="lg"
                            className="flex-1 border-red-300 text-red-600 hover:bg-red-50 py-3"
                          >
                            <X className="w-5 h-5 mr-2" />
                            Stop Camera
                          </Button>
                        </div>
                      )}
                      
                      {/* Camera status indicator */}
                      <div className="text-center">
                        <div className="inline-flex items-center space-x-2 bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm">
                          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                          <span>Camera Active</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
                
                {/* Manual Barcode Entry */}
                <div className="space-y-2">
                  <label className="text-sm font-medium text-carbon-gray-80">Manual Barcode Entry</label>
                  <div className="flex space-x-2">
                    <Input
                      type="text"
                      placeholder="Enter barcode or SKU..."
                      value={manualBarcode}
                      onChange={(e) => setManualBarcode(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleManualLookup()}
                      className="flex-1"
                    />
                    <Button 
                      onClick={handleManualLookup}
                      disabled={!manualBarcode.trim() || lookupMutation.isPending}
                      className="carbon-blue"
                    >
                      <Search className="w-4 h-4 mr-2" />
                      Lookup
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions & Management Links */}
            <Card className="border-carbon-gray-20">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Settings className="w-5 h-5 text-carbon-blue" />
                  <span>Inventory Management</span>
                </CardTitle>
                <p className="text-sm text-carbon-gray-60">Access related inventory tools and dashboards</p>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  <Button
                    onClick={() => window.location.href = '/inventory'}
                    variant="outline"
                    className="h-20 flex flex-col items-center justify-center space-y-2 border-2 hover:border-carbon-blue hover:bg-carbon-blue hover:text-white transition-all"
                  >
                    <Package className="w-6 h-6" />
                    <div className="text-center">
                      <div className="text-sm font-medium">View All Inventory</div>
                      <div className="text-xs opacity-70">Browse & manage items</div>
                    </div>
                  </Button>
                  
                  <Button
                    onClick={() => window.location.href = '/'}
                    variant="outline"
                    className="h-20 flex flex-col items-center justify-center space-y-2 border-2 hover:border-carbon-blue hover:bg-carbon-blue hover:text-white transition-all"
                  >
                    <BarChart3 className="w-6 h-6" />
                    <div className="text-center">
                      <div className="text-sm font-medium">Dashboard</div>
                      <div className="text-xs opacity-70">Analytics & insights</div>
                    </div>
                  </Button>
                  
                  <Button
                    onClick={() => window.location.href = '/production-orders'}
                    variant="outline"
                    className="h-20 flex flex-col items-center justify-center space-y-2 border-2 hover:border-carbon-blue hover:bg-carbon-blue hover:text-white transition-all"
                  >
                    <ClipboardList className="w-6 h-6" />
                    <div className="text-center">
                      <div className="text-sm font-medium">Production Orders</div>
                      <div className="text-xs opacity-70">Manage workflows</div>
                    </div>
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Scan History */}
            {scanHistory.length > 0 && (
              <Card className="border-carbon-gray-20">
                <CardHeader>
                  <CardTitle>Recent Scans</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {scanHistory.map((barcode, index) => (
                      <Button
                        key={index}
                        variant="outline"
                        size="sm"
                        onClick={() => handleScanFromHistory(barcode)}
                        className="text-xs"
                      >
                        {barcode}
                      </Button>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Scanned Item Details */}
            {scannedItem && (
              <Card className="border-carbon-gray-20">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <span>Item Details</span>
                      <Button
                        onClick={() => window.location.href = `/inventory?item=${scannedItem.id}`}
                        variant="ghost"
                        size="sm"
                        className="text-carbon-blue hover:text-carbon-blue-dark hover:bg-blue-50"
                      >
                        <ExternalLink className="w-4 h-4 mr-1" />
                        View in Library
                      </Button>
                    </div>
                    <Badge className={getStockStatus(scannedItem).color}>
                      {scannedItem.currentStock} {scannedItem.unit}
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-3">
                      <div>
                        <label className="text-sm text-carbon-gray-50">Item Name</label>
                        <p className="font-medium text-carbon-gray-80">{scannedItem.name}</p>
                      </div>
                      <div>
                        <label className="text-sm text-carbon-gray-50">SKU</label>
                        <p className="font-medium text-carbon-gray-80">{scannedItem.sku}</p>
                      </div>
                      <div>
                        <label className="text-sm text-carbon-gray-50">Current Stock</label>
                        <p className="font-medium text-carbon-gray-80">
                          {scannedItem.currentStock} {scannedItem.unit}
                        </p>
                      </div>
                    </div>
                    
                    <div className="space-y-3">
                      <div>
                        <label className="text-sm text-carbon-gray-50">Unit Price</label>
                        <p className="font-medium text-carbon-gray-80">
                          ${parseFloat(scannedItem.unitPrice).toFixed(2)}
                        </p>
                      </div>
                      <div>
                        <label className="text-sm text-carbon-gray-50">Stock Range</label>
                        <p className="font-medium text-carbon-gray-80">
                          {scannedItem.minStock} - {scannedItem.maxStock}
                        </p>
                      </div>
                      {scannedItem.location && (
                        <div>
                          <label className="text-sm text-carbon-gray-50">Location</label>
                          <p className="font-medium text-carbon-gray-80">{scannedItem.location}</p>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Stock Level Warning */}
                  {scannedItem.currentStock <= scannedItem.minStock && (
                    <div className="flex items-center space-x-2 p-3 bg-red-50 border border-red-200 rounded-lg">
                      <AlertCircle className="w-5 h-5 text-red-500" />
                      <span className="text-red-700 font-medium">
                        Low Stock Alert: Current stock is at or below minimum level
                      </span>
                    </div>
                  )}

                  {/* Inventory Management Actions */}
                  <div className="space-y-3 pt-2 border-t border-carbon-gray-20">
                    <h4 className="text-sm font-medium text-carbon-gray-70">Inventory Actions</h4>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      <Button
                        onClick={() => window.location.href = `/inventory?edit=${scannedItem.id}`}
                        variant="outline"
                        size="sm"
                        className="flex items-center justify-center space-x-1 hover:border-carbon-blue hover:text-carbon-blue"
                      >
                        <Settings className="w-4 h-4" />
                        <span>Edit Item</span>
                      </Button>
                      <Button
                        onClick={() => window.location.href = `/inventory?history=${scannedItem.id}`}
                        variant="outline"
                        size="sm"
                        className="flex items-center justify-center space-x-1 hover:border-carbon-blue hover:text-carbon-blue"
                      >
                        <BarChart3 className="w-4 h-4" />
                        <span>View History</span>
                      </Button>
                      <Button
                        onClick={() => window.location.href = `/production-orders?item=${scannedItem.id}`}
                        variant="outline"
                        size="sm"
                        className="flex items-center justify-center space-x-1 hover:border-carbon-blue hover:text-carbon-blue"
                      >
                        <ClipboardList className="w-4 h-4" />
                        <span>Create Order</span>
                      </Button>
                    </div>
                  </div>

                  {/* Quick Stock Actions */}
                  {canModifyStock && (
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-carbon-gray-80">Quick Actions</label>
                      <div className="flex space-x-2">
                        {quickStockActions.map((action) => (
                          <Button
                            key={action.type}
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              form.setValue("type", action.type);
                              form.setValue("itemId", scannedItem.id);
                              setIsStockDialogOpen(true);
                            }}
                            className="flex items-center space-x-1"
                          >
                            <action.icon className="w-4 h-4" />
                            <span>{action.label}</span>
                          </Button>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Stock Movement Dialog */}
            <Dialog open={isStockDialogOpen} onOpenChange={setIsStockDialogOpen}>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Record Stock Movement</DialogTitle>
                </DialogHeader>
                
                {scannedItem && (
                  <div className="mb-4 p-3 bg-carbon-gray-10 rounded-lg">
                    <p className="font-medium text-carbon-gray-80">{scannedItem.name}</p>
                    <p className="text-sm text-carbon-gray-50">
                      Current Stock: {scannedItem.currentStock} {scannedItem.unit}
                    </p>
                  </div>
                )}
                
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="type"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Movement Type</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select type" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="in">Stock In</SelectItem>
                                <SelectItem value="out">Stock Out</SelectItem>
                                <SelectItem value="adjustment">Adjustment</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="quantity"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Quantity</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                {...field} 
                                onChange={(e) => field.onChange(parseInt(e.target.value) || 1)}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={form.control}
                      name="reason"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Reason (Optional)</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder="Enter reason for stock movement" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="flex justify-end space-x-2">
                      <Button 
                        type="button" 
                        variant="outline"
                        onClick={() => setIsStockDialogOpen(false)}
                      >
                        Cancel
                      </Button>
                      <Button 
                        type="submit" 
                        className="carbon-blue"
                        disabled={stockMovementMutation.isPending}
                      >
                        Record Movement
                      </Button>
                    </div>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>
        </main>
      </div>
      
      <MobileNav />
    </div>
  );
}
