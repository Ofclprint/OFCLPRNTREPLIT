import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import {
  Package,
  ClipboardList,
  CheckCircle,
  AlertTriangle,
  TrendingUp,
  TrendingDown,
  Activity,
  Users,
  Calendar,
  QrCode
} from "lucide-react";

export default function MVPDashboard() {
  const { data: kpis } = useQuery({
    queryKey: ["/api/dashboard/kpis"],
  });

  const { data: inventoryItems = [] } = useQuery({
    queryKey: ["/api/inventory"],
  });

  const { data: productionOrders = [] } = useQuery({
    queryKey: ["/api/production-orders"],
  });

  const { data: lowStockItems = [] } = useQuery({
    queryKey: ["/api/inventory/low-stock"],
  });

  const { data: recentActivity = [] } = useQuery({
    queryKey: ["/api/activity-logs/recent"],
  });

  // Calculate basic metrics
  const totalItems = Array.isArray(inventoryItems) ? inventoryItems.length : 0;
  const activeOrders = Array.isArray(productionOrders) ? productionOrders.filter((order: any) => 
    order.status === "in_progress" || order.status === "pending"
  ).length : 0;
  const completedToday = Array.isArray(productionOrders) ? productionOrders.filter((order: any) => 
    order.status === "completed" && 
    new Date(order.updatedAt || '').toDateString() === new Date().toDateString()
  ).length : 0;

  const quickActions = [
    {
      title: "Add Inventory Item",
      description: "Register new stock",
      href: "/inventory",
      icon: Package,
      color: "bg-blue-500",
    },
    {
      title: "Create Production Order",
      description: "Start new production",
      href: "/production-orders",
      icon: ClipboardList,
      color: "bg-green-500",
    },
    {
      title: "Scan Barcode",
      description: "Quick inventory check",
      href: "/barcode-scanner",
      icon: QrCode,
      color: "bg-purple-500",
    },
    {
      title: "Quality Check",
      description: "Log inspection",
      href: "/quality-control",
      icon: CheckCircle,
      color: "bg-orange-500",
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="p-6">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            Manufacturing Dashboard
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-2">
            Monitor your production operations and inventory
          </p>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Inventory</CardTitle>
              <Package className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalItems}</div>
              <p className="text-xs text-muted-foreground">
                {Array.isArray(lowStockItems) && (lowStockItems as any[]).length > 0 && (
                  <span className="text-red-500">
                    {(lowStockItems as any[]).length} low stock items
                  </span>
                )}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Orders</CardTitle>
              <ClipboardList className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{activeOrders}</div>
              <p className="text-xs text-muted-foreground">
                Production in progress
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Completed Today</CardTitle>
              <CheckCircle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{completedToday}</div>
              <p className="text-xs text-muted-foreground">
                Orders finished
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Efficiency</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{(kpis as any)?.efficiency || 85}%</div>
              <p className="text-xs text-muted-foreground">
                Production efficiency
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="mb-8">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
            Quick Actions
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {quickActions.map((action) => (
              <Link key={action.href} href={action.href}>
                <Card className="hover:shadow-md transition-shadow cursor-pointer">
                  <CardContent className="p-6">
                    <div className={`w-12 h-12 ${action.color} rounded-lg flex items-center justify-center mb-4`}>
                      <action.icon className="h-6 w-6 text-white" />
                    </div>
                    <h3 className="font-semibold text-gray-900 dark:text-white mb-2">
                      {action.title}
                    </h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      {action.description}
                    </p>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>

        {/* Alerts & Recent Activity */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Low Stock Alerts */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-red-500" />
                Stock Alerts
              </CardTitle>
            </CardHeader>
            <CardContent>
              {!Array.isArray(lowStockItems) || lowStockItems.length === 0 ? (
                <p className="text-gray-600 dark:text-gray-400">No low stock items</p>
              ) : (
                <div className="space-y-3">
                  {(lowStockItems as any[]).slice(0, 5).map((item: any) => (
                    <div key={item.id} className="flex items-center justify-between p-3 bg-red-50 dark:bg-red-900/20 rounded-lg">
                      <div>
                        <p className="font-medium text-gray-900 dark:text-white">
                          {item.name}
                        </p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          Stock: {item.currentStock} / Min: {item.minStock}
                        </p>
                      </div>
                      <Badge variant="destructive">Low Stock</Badge>
                    </div>
                  ))}
                  {(lowStockItems as any[]).length > 5 && (
                    <Link href="/inventory">
                      <Button variant="outline" size="sm" className="w-full">
                        View All ({(lowStockItems as any[]).length})
                      </Button>
                    </Link>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Recent Activity */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5 text-blue-500" />
                Recent Activity
              </CardTitle>
            </CardHeader>
            <CardContent>
              {!Array.isArray(recentActivity) || recentActivity.length === 0 ? (
                <p className="text-gray-600 dark:text-gray-400">No recent activity</p>
              ) : (
                <div className="space-y-3">
                  {(recentActivity as any[]).slice(0, 5).map((activity: any) => (
                    <div key={activity.id} className="flex items-start gap-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                      <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                      <div className="flex-1">
                        <p className="text-sm font-medium text-gray-900 dark:text-white">
                          {activity.action}
                        </p>
                        <p className="text-xs text-gray-600 dark:text-gray-400">
                          {new Date(activity.createdAt).toLocaleString()}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}