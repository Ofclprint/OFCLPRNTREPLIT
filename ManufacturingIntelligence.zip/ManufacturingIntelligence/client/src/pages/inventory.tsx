import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import Sidebar from "@/components/layout/sidebar";
import MobileNav from "@/components/layout/mobile-nav";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Search, Plus, Package, AlertTriangle, Edit } from "lucide-react";

const inventoryItemSchema = z.object({
  name: z.string().min(1, "Name is required"),
  description: z.string().optional(),
  sku: z.string().min(1, "SKU is required"),
  currentStock: z.number().min(0, "Stock must be non-negative"),
  minStock: z.number().min(0, "Min stock must be non-negative"),
  maxStock: z.number().min(1, "Max stock must be positive"),
  unitPrice: z.string().min(1, "Unit price is required"),
  unit: z.string().default("pieces"),
  location: z.string().optional(),
  barcode: z.string().optional(),
});

type InventoryItem = {
  id: number;
  name: string;
  description?: string;
  sku: string;
  currentStock: number;
  minStock: number;
  maxStock: number;
  unitPrice: string;
  unit: string;
  location?: string;
  barcode?: string;
  createdAt: string;
  updatedAt: string;
};

export default function Inventory() {
  const [searchTerm, setSearchTerm] = useState("");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<InventoryItem | null>(null);
  
  const { toast } = useToast();
  const { isAuthenticated, isLoading, user } = useAuth();
  const queryClient = useQueryClient();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const form = useForm<z.infer<typeof inventoryItemSchema>>({
    resolver: zodResolver(inventoryItemSchema),
    defaultValues: {
      name: "",
      description: "",
      sku: "",
      currentStock: 0,
      minStock: 0,
      maxStock: 1000,
      unitPrice: "0.00",
      unit: "pieces",
      location: "",
      barcode: "",
    },
  });

  const { data: inventory = [], isLoading: isLoadingInventory } = useQuery({
    queryKey: ["/api/inventory"],
    enabled: isAuthenticated,
  });

  const createMutation = useMutation({
    mutationFn: async (data: z.infer<typeof inventoryItemSchema>) => {
      await apiRequest("POST", "/api/inventory", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/inventory"] });
      setIsCreateDialogOpen(false);
      form.reset();
      toast({
        title: "Success",
        description: "Inventory item created successfully",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create inventory item",
        variant: "destructive",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<z.infer<typeof inventoryItemSchema>> }) => {
      await apiRequest("PUT", `/api/inventory/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/inventory"] });
      setEditingItem(null);
      form.reset();
      toast({
        title: "Success",
        description: "Inventory item updated successfully",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update inventory item",
        variant: "destructive",
      });
    },
  });

  if (isLoading || !isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-carbon-gray-10">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-carbon-blue border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-carbon-gray-50">Loading...</p>
        </div>
      </div>
    );
  }

  const canModify = user && user.role && ['admin', 'manager'].includes(user.role);

  const filteredInventory = (inventory as InventoryItem[]).filter((item: InventoryItem) =>
    item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.sku.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const onSubmit = (data: z.infer<typeof inventoryItemSchema>) => {
    if (editingItem) {
      updateMutation.mutate({ id: editingItem.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleEdit = (item: InventoryItem) => {
    setEditingItem(item);
    form.reset({
      name: item.name,
      description: item.description || "",
      sku: item.sku,
      currentStock: item.currentStock,
      minStock: item.minStock,
      maxStock: item.maxStock,
      unitPrice: item.unitPrice,
      unit: item.unit,
      location: item.location || "",
      barcode: item.barcode || "",
    });
  };

  const getStockStatus = (item: InventoryItem) => {
    if (item.currentStock <= item.minStock) {
      return { status: "critical", color: "bg-red-100 text-red-800" };
    } else if (item.currentStock <= item.minStock * 1.5) {
      return { status: "low", color: "bg-yellow-100 text-yellow-800" };
    }
    return { status: "normal", color: "bg-green-100 text-green-800" };
  };

  return (
    <div className="min-h-screen flex bg-carbon-gray-10">
      {/* Desktop Sidebar */}
      <div className="hidden lg:block">
        <Sidebar />
      </div>
      
      {/* Mobile Navigation */}
      <div className="lg:hidden">
        <MobileNav />
      </div>
      
      <div className="flex-1 flex flex-col overflow-hidden lg:ml-0">
        {/* Responsive Header */}
        <header className="bg-white border-b border-carbon-gray-20 px-4 sm:px-6 py-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="text-xl sm:text-2xl font-semibold text-carbon-gray-80">Inventory Management</h1>
              <p className="text-carbon-gray-50 text-sm mt-1">Track and manage your inventory items</p>
            </div>
            
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 sm:gap-4">
              {/* Search - Full width on mobile */}
              <div className="relative flex-1 sm:flex-none sm:w-64">
                <Input
                  type="text"
                  placeholder="Search inventory..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 w-full"
                />
                <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-carbon-gray-50" />
              </div>
              
              {/* Add Item Button */}
              <Dialog open={isCreateDialogOpen || !!editingItem} onOpenChange={(open) => {
                if (!open) {
                  setIsCreateDialogOpen(false);
                  setEditingItem(null);
                  form.reset();
                }
              }}>
                <DialogTrigger asChild>
                  <Button 
                    onClick={() => setIsCreateDialogOpen(true)} 
                    className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-4 py-2 sm:px-6 sm:py-3 shadow-md hover:shadow-lg transition-all duration-200 w-full sm:w-auto"
                    size="lg"
                  >
                    <Plus className="w-4 h-4 sm:w-5 sm:h-5 mr-2" />
                    <span className="hidden sm:inline">Add Inventory Item</span>
                    <span className="sm:hidden">Add Item</span>
                  </Button>
                </DialogTrigger>
                  <DialogContent className="max-w-2xl mx-4 sm:mx-auto max-h-[90vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>
                        {editingItem ? "Edit Inventory Item" : "Add New Inventory Item"}
                      </DialogTitle>
                    </DialogHeader>
                    
                    <Form {...form}>
                      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="name"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Item Name</FormLabel>
                                <FormControl>
                                  <Input {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="sku"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>SKU</FormLabel>
                                <FormControl>
                                  <Input {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <FormField
                          control={form.control}
                          name="description"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Description</FormLabel>
                              <FormControl>
                                <Input {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="grid grid-cols-3 gap-4">
                          <FormField
                            control={form.control}
                            name="currentStock"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Current Stock</FormLabel>
                                <FormControl>
                                  <Input 
                                    type="number" 
                                    {...field} 
                                    onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="minStock"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Min Stock</FormLabel>
                                <FormControl>
                                  <Input 
                                    type="number" 
                                    {...field} 
                                    onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="maxStock"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Max Stock</FormLabel>
                                <FormControl>
                                  <Input 
                                    type="number" 
                                    {...field} 
                                    onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="unitPrice"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Unit Price</FormLabel>
                                <FormControl>
                                  <Input {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="unit"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Unit</FormLabel>
                                <FormControl>
                                  <Input {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="location"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Location</FormLabel>
                                <FormControl>
                                  <Input {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="barcode"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Barcode</FormLabel>
                                <FormControl>
                                  <Input {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <div className="flex justify-end space-x-2">
                          <Button 
                            type="button" 
                            variant="outline"
                            onClick={() => {
                              setIsCreateDialogOpen(false);
                              setEditingItem(null);
                              form.reset();
                            }}
                          >
                            Cancel
                          </Button>
                          <Button 
                            type="submit" 
                            className="carbon-blue"
                            disabled={createMutation.isPending || updateMutation.isPending}
                          >
                            {editingItem ? "Update" : "Create"}
                          </Button>
                        </div>
                      </form>
                    </Form>
                  </DialogContent>
                </Dialog>
            </div>
          </div>
        </header>

        {/* Inventory Grid */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6">
          {isLoadingInventory ? (
            <div className="flex items-center justify-center h-64">
              <div className="text-center">
                <div className="w-8 h-8 border-4 border-carbon-blue border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                <p className="text-carbon-gray-50">Loading inventory...</p>
              </div>
            </div>
          ) : filteredInventory.length === 0 ? (
            <div className="text-center py-12">
              <Package className="w-16 h-16 text-carbon-gray-50 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-carbon-gray-80 mb-2">
                {searchTerm ? "No items found" : "No inventory items"}
              </h3>
              <p className="text-carbon-gray-50 mb-4">
                {searchTerm 
                  ? "Try adjusting your search terms" 
                  : "Start by adding your first inventory item"
                }
              </p>
              {canModify && !searchTerm && (
                <Button onClick={() => setIsCreateDialogOpen(true)} className="carbon-blue">
                  <Plus className="w-4 h-4 mr-2" />
                  Add First Item
                </Button>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6">
              {filteredInventory.map((item: InventoryItem) => {
                const stockStatus = getStockStatus(item);
                return (
                  <Card key={item.id} className="border-carbon-gray-20 hover:shadow-lg transition-shadow">
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <CardTitle className="text-lg font-semibold text-carbon-gray-80 mb-1">
                            {item.name}
                          </CardTitle>
                          <p className="text-sm text-carbon-gray-50">{item.sku}</p>
                        </div>
                        {canModify && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEdit(item)}
                            className="p-1 h-8 w-8"
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    </CardHeader>
                    
                    <CardContent>
                      <div className="space-y-3">
                        {/* Stock Status */}
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-carbon-gray-50">Stock:</span>
                          <div className="flex items-center space-x-2">
                            <Badge className={stockStatus.color}>
                              {item.currentStock} {item.unit}
                            </Badge>
                            {stockStatus.status !== "normal" && (
                              <AlertTriangle className="w-4 h-4 text-red-500" />
                            )}
                          </div>
                        </div>
                        
                        {/* Stock Range */}
                        <div className="text-xs text-carbon-gray-50">
                          Min: {item.minStock} / Max: {item.maxStock}
                        </div>
                        
                        {/* Price */}
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-carbon-gray-50">Price:</span>
                          <span className="font-medium text-carbon-gray-80">
                            ${parseFloat(item.unitPrice).toFixed(2)}
                          </span>
                        </div>
                        
                        {/* Location */}
                        {item.location && (
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-carbon-gray-50">Location:</span>
                            <span className="text-sm text-carbon-gray-80">{item.location}</span>
                          </div>
                        )}
                        
                        {/* Description */}
                        {item.description && (
                          <p className="text-xs text-carbon-gray-50 mt-2 line-clamp-2">
                            {item.description}
                          </p>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </main>
      </div>
      
      <MobileNav />
    </div>
  );
}
