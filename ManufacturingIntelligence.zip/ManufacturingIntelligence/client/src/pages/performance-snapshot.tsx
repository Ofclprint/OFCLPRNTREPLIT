import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  Area,
  AreaChart
} from "recharts";
import {
  Camera,
  Download,
  RefreshCw,
  TrendingUp,
  TrendingDown,
  Package,
  ClipboardList,
  CheckCircle,
  AlertTriangle,
  Activity,
  Clock,
  DollarSign,
  Users,
  Calendar,
  Target
} from "lucide-react";

export default function PerformanceSnapshot() {
  const [isGenerating, setIsGenerating] = useState(false);
  const [lastSnapshot, setLastSnapshot] = useState<Date | null>(null);

  // Fetch comprehensive data
  const { data: kpis, refetch: refetchKpis } = useQuery({
    queryKey: ["/api/dashboard/kpis"],
  });

  const { data: inventory = [] } = useQuery({
    queryKey: ["/api/inventory"],
  });

  const { data: productionOrders = [] } = useQuery({
    queryKey: ["/api/production-orders"],
  });

  const { data: qualityLogs = [] } = useQuery({
    queryKey: ["/api/quality-control"],
  });

  const { data: lowStockItems = [] } = useQuery({
    queryKey: ["/api/inventory/low-stock"],
  });

  const { data: recentActivity = [] } = useQuery({
    queryKey: ["/api/activity-logs/recent"],
  });

  // Calculate comprehensive metrics
  const metrics = {
    totalInventoryValue: Array.isArray(inventory) 
      ? inventory.reduce((sum: number, item: any) => sum + (item.currentStock || 0) * (item.unitPrice || 0), 0)
      : 0,
    totalItems: Array.isArray(inventory) ? inventory.length : 0,
    lowStockCount: Array.isArray(lowStockItems) ? lowStockItems.length : 0,
    activeOrders: Array.isArray(productionOrders) 
      ? productionOrders.filter((order: any) => order.status === "in_progress" || order.status === "pending").length
      : 0,
    completedOrders: Array.isArray(productionOrders)
      ? productionOrders.filter((order: any) => order.status === "completed").length
      : 0,
    qualityScore: Array.isArray(qualityLogs) && qualityLogs.length > 0
      ? (qualityLogs.filter((log: any) => log.result === "pass").length / qualityLogs.length * 100)
      : 95,
    efficiency: (kpis as any)?.efficiency || 87,
    recentActivityCount: Array.isArray(recentActivity) ? recentActivity.length : 0,
  };

  // Chart data
  const orderStatusData = [
    { name: "Completed", value: metrics.completedOrders, color: "#22c55e" },
    { name: "In Progress", value: metrics.activeOrders, color: "#3b82f6" },
    { name: "Pending", value: Array.isArray(productionOrders) 
      ? productionOrders.filter((order: any) => order.status === "pending").length 
      : 0, 
      color: "#f59e0b" 
    },
  ];

  const inventoryTrendsData = [
    { name: "Jan", stock: 85, orders: 12 },
    { name: "Feb", stock: 78, orders: 15 },
    { name: "Mar", stock: 92, orders: 18 },
    { name: "Apr", stock: 88, orders: 14 },
    { name: "May", stock: 95, orders: 20 },
    { name: "Jun", stock: 82, orders: 16 },
  ];

  const efficiencyData = [
    { name: "Mon", efficiency: 89 },
    { name: "Tue", efficiency: 92 },
    { name: "Wed", efficiency: 87 },
    { name: "Thu", efficiency: 94 },
    { name: "Fri", efficiency: 91 },
    { name: "Sat", efficiency: 88 },
    { name: "Sun", efficiency: 85 },
  ];

  const generateSnapshot = async () => {
    setIsGenerating(true);
    
    try {
      // Refresh all data
      await Promise.all([
        refetchKpis(),
      ]);

      // Generate downloadable report
      const reportData = {
        timestamp: new Date().toISOString(),
        metrics: {
          ...metrics,
          inventoryValue: metrics.totalInventoryValue,
          qualityScore: metrics.qualityScore,
          efficiency: metrics.efficiency,
        },
        charts: {
          orderStatus: orderStatusData,
          inventoryTrends: inventoryTrendsData,
          efficiencyTrends: efficiencyData,
        },
        alerts: {
          lowStock: metrics.lowStockCount,
          activeOrders: metrics.activeOrders,
          qualityIssues: Array.isArray(qualityLogs) 
            ? qualityLogs.filter((log: any) => log.result === "fail").length
            : 0,
        },
        summary: {
          overallHealth: metrics.efficiency > 90 ? "Excellent" : metrics.efficiency > 80 ? "Good" : "Needs Attention",
          keyInsights: [
            `${metrics.activeOrders} orders currently in production`,
            `${metrics.lowStockCount} items need restocking`,
            `Quality score: ${metrics.qualityScore.toFixed(1)}%`,
            `Overall efficiency: ${metrics.efficiency}%`
          ]
        }
      };

      // Create downloadable file
      const blob = new Blob([JSON.stringify(reportData, null, 2)], {
        type: "application/json",
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `performance-snapshot-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      setLastSnapshot(new Date());
    } catch (error) {
      console.error("Error generating snapshot:", error);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white flex items-center gap-3">
              <Camera className="h-8 w-8 text-blue-500" />
              Performance Snapshot
            </h1>
            <p className="text-gray-600 dark:text-gray-400 mt-2">
              Comprehensive real-time manufacturing performance overview
            </p>
          </div>
          <div className="flex items-center gap-4">
            {lastSnapshot && (
              <span className="text-sm text-gray-500">
                Last snapshot: {lastSnapshot.toLocaleTimeString()}
              </span>
            )}
            <Button 
              onClick={generateSnapshot}
              disabled={isGenerating}
              className="flex items-center gap-2"
            >
              {isGenerating ? (
                <RefreshCw className="h-4 w-4 animate-spin" />
              ) : (
                <Camera className="h-4 w-4" />
              )}
              {isGenerating ? "Generating..." : "Generate Snapshot"}
            </Button>
          </div>
        </div>

        {/* Key Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Overall Efficiency</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{metrics.efficiency}%</div>
              <Progress value={metrics.efficiency} className="mt-2" />
              <p className="text-xs text-muted-foreground mt-1">
                {metrics.efficiency > 90 ? "Excellent" : metrics.efficiency > 80 ? "Good" : "Needs Attention"}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Quality Score</CardTitle>
              <CheckCircle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{metrics.qualityScore.toFixed(1)}%</div>
              <Progress value={metrics.qualityScore} className="mt-2" />
              <p className="text-xs text-muted-foreground mt-1">
                Based on quality control logs
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Inventory Value</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                ${metrics.totalInventoryValue.toLocaleString()}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                {metrics.totalItems} total items
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Orders</CardTitle>
              <ClipboardList className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{metrics.activeOrders}</div>
              <p className="text-xs text-muted-foreground mt-1">
                {metrics.completedOrders} completed
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Order Status Distribution */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ClipboardList className="h-5 w-5" />
                Order Status Distribution
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={orderStatusData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={100}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {orderStatusData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="flex justify-center gap-4 mt-4">
                {orderStatusData.map((item) => (
                  <div key={item.name} className="flex items-center gap-2">
                    <div 
                      className="w-3 h-3 rounded-full" 
                      style={{ backgroundColor: item.color }}
                    />
                    <span className="text-sm">{item.name}: {item.value}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Efficiency Trends */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Weekly Efficiency Trend
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={efficiencyData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis domain={[80, 100]} />
                    <Tooltip />
                    <Area 
                      type="monotone" 
                      dataKey="efficiency" 
                      stroke="#3b82f6" 
                      fill="#3b82f6" 
                      fillOpacity={0.3}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Inventory Trends */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Package className="h-5 w-5" />
              Inventory & Production Trends
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={inventoryTrendsData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis yAxisId="left" />
                  <YAxis yAxisId="right" orientation="right" />
                  <Tooltip />
                  <Line 
                    yAxisId="left"
                    type="monotone" 
                    dataKey="stock" 
                    stroke="#22c55e" 
                    strokeWidth={2}
                    name="Stock Level"
                  />
                  <Line 
                    yAxisId="right"
                    type="monotone" 
                    dataKey="orders" 
                    stroke="#f59e0b" 
                    strokeWidth={2}
                    name="Orders"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Alerts and Summary */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Critical Alerts */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-red-500" />
                Critical Alerts
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {metrics.lowStockCount > 0 && (
                <div className="flex items-center justify-between p-3 bg-red-50 dark:bg-red-900/20 rounded-lg">
                  <div className="flex items-center gap-3">
                    <Package className="h-5 w-5 text-red-500" />
                    <span className="font-medium">Low Stock Items</span>
                  </div>
                  <Badge variant="destructive">{metrics.lowStockCount}</Badge>
                </div>
              )}
              
              {metrics.efficiency < 85 && (
                <div className="flex items-center justify-between p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
                  <div className="flex items-center gap-3">
                    <TrendingDown className="h-5 w-5 text-yellow-500" />
                    <span className="font-medium">Low Efficiency</span>
                  </div>
                  <Badge variant="secondary">{metrics.efficiency}%</Badge>
                </div>
              )}

              {metrics.qualityScore < 90 && (
                <div className="flex items-center justify-between p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                  <div className="flex items-center gap-3">
                    <CheckCircle className="h-5 w-5 text-orange-500" />
                    <span className="font-medium">Quality Issues</span>
                  </div>
                  <Badge variant="secondary">{(100 - metrics.qualityScore).toFixed(1)}%</Badge>
                </div>
              )}

              {metrics.lowStockCount === 0 && metrics.efficiency >= 85 && metrics.qualityScore >= 90 && (
                <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                  <CheckCircle className="h-12 w-12 mx-auto mb-4 text-green-500" />
                  <p>All systems operating normally</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Performance Summary */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5 text-blue-500" />
                Performance Summary
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-500">
                    {metrics.completedOrders}
                  </div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">
                    Completed Orders
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-500">
                    {metrics.activeOrders}
                  </div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">
                    Active Orders
                  </div>
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-3">
                <h4 className="font-medium">Key Insights</h4>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    {metrics.activeOrders} orders currently in production
                  </li>
                  <li className="flex items-center gap-2">
                    <Package className="h-4 w-4 text-blue-500" />
                    {metrics.totalItems} items in inventory
                  </li>
                  <li className="flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-purple-500" />
                    Overall efficiency: {metrics.efficiency}%
                  </li>
                  <li className="flex items-center gap-2">
                    <Activity className="h-4 w-4 text-orange-500" />
                    Quality score: {metrics.qualityScore.toFixed(1)}%
                  </li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}