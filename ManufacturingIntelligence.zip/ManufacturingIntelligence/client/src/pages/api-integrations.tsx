import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import Sidebar from "@/components/layout/sidebar";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  Plug, 
  Settings, 
  CheckCircle, 
  AlertCircle, 
  RefreshCw,
  Plus,
  Edit,
  Trash2,
  Play,
  Pause,
  Activity,
  Globe,
  Key,
  Database,
  Webhook,
  FileText,
  Mail,
  MessageSquare,
  Smartphone,
  DollarSign,
  TrendingUp,
  Package,
  Truck,
  Users,
  BarChart3
} from "lucide-react";

const integrationSchema = z.object({
  name: z.string().min(1, "Name is required"),
  type: z.string().min(1, "Type is required"),
  description: z.string().min(1, "Description is required"),
  endpoint: z.string().url("Valid URL is required"),
  apiKey: z.string().min(1, "API key is required"),
  isActive: z.boolean().default(true),
  syncInterval: z.number().min(1, "Sync interval must be at least 1 minute"),
  webhookUrl: z.string().url().optional(),
  configuration: z.record(z.string()).optional(),
});

const webhookSchema = z.object({
  name: z.string().min(1, "Name is required"),
  url: z.string().url("Valid URL is required"),
  events: z.array(z.string()).min(1, "At least one event is required"),
  isActive: z.boolean().default(true),
  secret: z.string().optional(),
  headers: z.record(z.string()).optional(),
});

interface Integration {
  id: string;
  name: string;
  type: "erp" | "crm" | "inventory" | "payment" | "shipping" | "email" | "sms" | "analytics";
  description: string;
  status: "connected" | "disconnected" | "error" | "syncing";
  endpoint: string;
  lastSync: string;
  syncInterval: number;
  recordsSynced: number;
  isActive: boolean;
  configuration: Record<string, any>;
  healthStatus: "healthy" | "warning" | "critical";
  responseTime: number;
}

interface Webhook {
  id: string;
  name: string;
  url: string;
  events: string[];
  status: "active" | "inactive" | "error";
  lastTriggered: string;
  successRate: number;
  isActive: boolean;
  secret?: string;
  headers?: Record<string, string>;
}

interface ApiLog {
  id: string;
  timestamp: string;
  integrationName: string;
  method: string;
  endpoint: string;
  statusCode: number;
  responseTime: number;
  success: boolean;
  errorMessage?: string;
  requestId: string;
}

export default function ApiIntegrations() {
  const [activeTab, setActiveTab] = useState("integrations");
  const [isIntegrationDialogOpen, setIsIntegrationDialogOpen] = useState(false);
  const [isWebhookDialogOpen, setIsWebhookDialogOpen] = useState(false);
  const [selectedIntegration, setSelectedIntegration] = useState<Integration | null>(null);
  const [testingConnection, setTestingConnection] = useState<string | null>(null);

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const integrationForm = useForm<z.infer<typeof integrationSchema>>({
    resolver: zodResolver(integrationSchema),
    defaultValues: {
      isActive: true,
      syncInterval: 15,
    },
  });

  const webhookForm = useForm<z.infer<typeof webhookSchema>>({
    resolver: zodResolver(webhookSchema),
    defaultValues: {
      isActive: true,
      events: [],
    },
  });

  // Sample integrations data
  const sampleIntegrations: Integration[] = [
    {
      id: "int_001",
      name: "SAP ERP",
      type: "erp",
      description: "Enterprise resource planning system integration",
      status: "connected",
      endpoint: "https://api.sap.com/v2/erp",
      lastSync: "2024-12-17 03:45:00",
      syncInterval: 30,
      recordsSynced: 1547,
      isActive: true,
      configuration: { module: "finance", version: "v2" },
      healthStatus: "healthy",
      responseTime: 245
    },
    {
      id: "int_002",
      name: "Salesforce CRM",
      type: "crm",
      description: "Customer relationship management integration",
      status: "connected",
      endpoint: "https://api.salesforce.com/v1/crm",
      lastSync: "2024-12-17 03:30:00",
      syncInterval: 15,
      recordsSynced: 892,
      isActive: true,
      configuration: { sandbox: false, version: "v1" },
      healthStatus: "healthy",
      responseTime: 189
    },
    {
      id: "int_003",
      name: "Stripe Payments",
      type: "payment",
      description: "Payment processing and invoice management",
      status: "connected",
      endpoint: "https://api.stripe.com/v1",
      lastSync: "2024-12-17 03:52:00",
      syncInterval: 5,
      recordsSynced: 234,
      isActive: true,
      configuration: { currency: "USD", mode: "live" },
      healthStatus: "healthy",
      responseTime: 156
    },
    {
      id: "int_004",
      name: "FedEx Shipping",
      type: "shipping",
      description: "Shipping and tracking integration",
      status: "error",
      endpoint: "https://api.fedex.com/v2/ship",
      lastSync: "2024-12-17 02:15:00",
      syncInterval: 60,
      recordsSynced: 0,
      isActive: false,
      configuration: { service: "express", region: "US" },
      healthStatus: "critical",
      responseTime: 0
    },
    {
      id: "int_005",
      name: "Twilio SMS",
      type: "sms",
      description: "SMS notifications and alerts",
      status: "connected",
      endpoint: "https://api.twilio.com/v1/sms",
      lastSync: "2024-12-17 03:48:00",
      syncInterval: 10,
      recordsSynced: 156,
      isActive: true,
      configuration: { from: "+1234567890", region: "US" },
      healthStatus: "warning",
      responseTime: 312
    }
  ];

  const sampleWebhooks: Webhook[] = [
    {
      id: "wh_001",
      name: "Inventory Low Stock Alert",
      url: "https://hooks.slack.com/services/T00/B00/XXX",
      events: ["inventory.low_stock", "inventory.out_of_stock"],
      status: "active",
      lastTriggered: "2024-12-17 03:20:00",
      successRate: 98.5,
      isActive: true,
      secret: "wh_secret_123"
    },
    {
      id: "wh_002",
      name: "Order Completion Notification",
      url: "https://api.example.com/webhooks/orders",
      events: ["order.completed", "order.shipped"],
      status: "active",
      lastTriggered: "2024-12-17 03:15:00",
      successRate: 99.2,
      isActive: true
    },
    {
      id: "wh_003",
      name: "Quality Control Alerts",
      url: "https://notifications.company.com/quality",
      events: ["quality.failed", "quality.warning"],
      status: "error",
      lastTriggered: "2024-12-16 15:30:00",
      successRate: 85.4,
      isActive: false
    }
  ];

  const sampleApiLogs: ApiLog[] = [
    {
      id: "log_001",
      timestamp: "2024-12-17 03:52:15",
      integrationName: "Stripe Payments",
      method: "POST",
      endpoint: "/v1/invoices",
      statusCode: 200,
      responseTime: 145,
      success: true,
      requestId: "req_1234567890"
    },
    {
      id: "log_002",
      timestamp: "2024-12-17 03:51:42",
      integrationName: "SAP ERP",
      method: "GET",
      endpoint: "/v2/erp/inventory",
      statusCode: 200,
      responseTime: 267,
      success: true,
      requestId: "req_1234567891"
    },
    {
      id: "log_003",
      timestamp: "2024-12-17 03:45:23",
      integrationName: "FedEx Shipping",
      method: "POST",
      endpoint: "/v2/ship/track",
      statusCode: 401,
      responseTime: 89,
      success: false,
      errorMessage: "Unauthorized: Invalid API key",
      requestId: "req_1234567892"
    }
  ];

  // Create integration mutation
  const createIntegrationMutation = useMutation({
    mutationFn: async (data: z.infer<typeof integrationSchema>) => {
      return apiRequest("/api/integrations", "POST", data);
    },
    onSuccess: () => {
      toast({
        title: "Integration Created",
        description: "New integration has been created successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/integrations"] });
      setIsIntegrationDialogOpen(false);
      integrationForm.reset();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create integration",
        variant: "destructive",
      });
    },
  });

  // Test connection mutation
  const testConnectionMutation = useMutation({
    mutationFn: async (integrationId: string) => {
      return apiRequest(`/api/integrations/${integrationId}/test`, "POST");
    },
    onSuccess: (data, integrationId) => {
      toast({
        title: "Connection Test Successful",
        description: "Integration is working properly",
      });
      setTestingConnection(null);
    },
    onError: (error, integrationId) => {
      toast({
        title: "Connection Test Failed",
        description: error.message || "Unable to connect to the service",
        variant: "destructive",
      });
      setTestingConnection(null);
    },
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "connected":
      case "active":
        return "bg-green-100 text-green-800";
      case "disconnected":
      case "inactive":
        return "bg-gray-100 text-gray-800";
      case "error":
        return "bg-red-100 text-red-800";
      case "syncing":
        return "bg-blue-100 text-blue-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "connected":
      case "active":
        return <CheckCircle className="w-4 h-4" />;
      case "disconnected":
      case "inactive":
        return <Pause className="w-4 h-4" />;
      case "error":
        return <AlertCircle className="w-4 h-4" />;
      case "syncing":
        return <RefreshCw className="w-4 h-4 animate-spin" />;
      default:
        return <Settings className="w-4 h-4" />;
    }
  };

  const getHealthColor = (health: string) => {
    switch (health) {
      case "healthy":
        return "text-green-600";
      case "warning":
        return "text-yellow-600";
      case "critical":
        return "text-red-600";
      default:
        return "text-gray-600";
    }
  };

  const getIntegrationIcon = (type: string) => {
    switch (type) {
      case "erp":
        return <Database className="w-5 h-5" />;
      case "crm":
        return <Users className="w-5 h-5" />;
      case "payment":
        return <DollarSign className="w-5 h-5" />;
      case "shipping":
        return <Truck className="w-5 h-5" />;
      case "email":
        return <Mail className="w-5 h-5" />;
      case "sms":
        return <Smartphone className="w-5 h-5" />;
      case "analytics":
        return <BarChart3 className="w-5 h-5" />;
      case "inventory":
        return <Package className="w-5 h-5" />;
      default:
        return <Globe className="w-5 h-5" />;
    }
  };

  const handleTestConnection = (integrationId: string) => {
    setTestingConnection(integrationId);
    testConnectionMutation.mutate(integrationId);
  };

  const onIntegrationSubmit = (data: z.infer<typeof integrationSchema>) => {
    createIntegrationMutation.mutate(data);
  };

  const onWebhookSubmit = (data: z.infer<typeof webhookSchema>) => {
    // Handle webhook creation
    console.log("Creating webhook:", data);
  };

  const integrationStats = {
    total: sampleIntegrations.length,
    connected: sampleIntegrations.filter(i => i.status === "connected").length,
    errors: sampleIntegrations.filter(i => i.status === "error").length,
    totalRecords: sampleIntegrations.reduce((sum, i) => sum + i.recordsSynced, 0),
    avgResponseTime: Math.round(sampleIntegrations.reduce((sum, i) => sum + i.responseTime, 0) / sampleIntegrations.length)
  };

  return (
    <div className="flex h-screen bg-carbon-gray-10">
      <Sidebar />
      <div className="flex-1 overflow-auto">
        <div className="p-6 space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-carbon-gray-80">API Integrations</h1>
              <p className="text-carbon-gray-60">Manage external services and data synchronization</p>
            </div>
            <div className="flex items-center space-x-3">
              <Button variant="outline" onClick={() => queryClient.invalidateQueries({ queryKey: ["/api/integrations"] })}>
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh All
              </Button>
            </div>
          </div>

          {/* Overview Stats */}
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Plug className="w-5 h-5 text-blue-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Total Integrations</p>
                    <p className="text-xl font-bold">{integrationStats.total}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Connected</p>
                    <p className="text-xl font-bold">{integrationStats.connected}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <AlertCircle className="w-5 h-5 text-red-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Errors</p>
                    <p className="text-xl font-bold">{integrationStats.errors}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Database className="w-5 h-5 text-purple-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Records Synced</p>
                    <p className="text-xl font-bold">{integrationStats.totalRecords.toLocaleString()}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-carbon-gray-20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Activity className="w-5 h-5 text-orange-600" />
                  <div>
                    <p className="text-sm text-carbon-gray-60">Avg Response</p>
                    <p className="text-xl font-bold">{integrationStats.avgResponseTime}ms</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
            <div className="flex items-center justify-between">
              <TabsList>
                <TabsTrigger value="integrations">Integrations</TabsTrigger>
                <TabsTrigger value="webhooks">Webhooks</TabsTrigger>
                <TabsTrigger value="logs">API Logs</TabsTrigger>
                <TabsTrigger value="marketplace">Marketplace</TabsTrigger>
              </TabsList>
              <div className="flex space-x-2">
                {activeTab === "integrations" && (
                  <Dialog open={isIntegrationDialogOpen} onOpenChange={setIsIntegrationDialogOpen}>
                    <DialogTrigger asChild>
                      <Button>
                        <Plus className="w-4 h-4 mr-2" />
                        New Integration
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl">
                      <DialogHeader>
                        <DialogTitle>Add New Integration</DialogTitle>
                      </DialogHeader>
                      <Form {...integrationForm}>
                        <form onSubmit={integrationForm.handleSubmit(onIntegrationSubmit)} className="space-y-4">
                          <div className="grid grid-cols-2 gap-4">
                            <FormField
                              control={integrationForm.control}
                              name="name"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Integration Name</FormLabel>
                                  <FormControl>
                                    <Input {...field} />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={integrationForm.control}
                              name="type"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Type</FormLabel>
                                  <FormControl>
                                    <Select onValueChange={field.onChange} value={field.value}>
                                      <SelectTrigger>
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="erp">ERP System</SelectItem>
                                        <SelectItem value="crm">CRM</SelectItem>
                                        <SelectItem value="payment">Payment Gateway</SelectItem>
                                        <SelectItem value="shipping">Shipping Provider</SelectItem>
                                        <SelectItem value="email">Email Service</SelectItem>
                                        <SelectItem value="sms">SMS Provider</SelectItem>
                                        <SelectItem value="analytics">Analytics</SelectItem>
                                        <SelectItem value="inventory">Inventory System</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                          </div>
                          <FormField
                            control={integrationForm.control}
                            name="description"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Description</FormLabel>
                                <FormControl>
                                  <Textarea {...field} />
                                </FormControl>
                              </FormItem>
                            )}
                          />
                          <div className="grid grid-cols-2 gap-4">
                            <FormField
                              control={integrationForm.control}
                              name="endpoint"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>API Endpoint</FormLabel>
                                  <FormControl>
                                    <Input type="url" {...field} />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={integrationForm.control}
                              name="syncInterval"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Sync Interval (minutes)</FormLabel>
                                  <FormControl>
                                    <Input 
                                      type="number" 
                                      min="1" 
                                      {...field}
                                      onChange={e => field.onChange(parseInt(e.target.value))}
                                    />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                          </div>
                          <FormField
                            control={integrationForm.control}
                            name="apiKey"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>API Key</FormLabel>
                                <FormControl>
                                  <Input type="password" {...field} />
                                </FormControl>
                              </FormItem>
                            )}
                          />
                          <div className="flex justify-end space-x-2">
                            <Button type="button" variant="outline" onClick={() => setIsIntegrationDialogOpen(false)}>
                              Cancel
                            </Button>
                            <Button type="submit" disabled={createIntegrationMutation.isPending}>
                              {createIntegrationMutation.isPending ? "Creating..." : "Create Integration"}
                            </Button>
                          </div>
                        </form>
                      </Form>
                    </DialogContent>
                  </Dialog>
                )}
                {activeTab === "webhooks" && (
                  <Button onClick={() => setIsWebhookDialogOpen(true)}>
                    <Plus className="w-4 h-4 mr-2" />
                    New Webhook
                  </Button>
                )}
              </div>
            </div>

            <TabsContent value="integrations" className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {sampleIntegrations.map((integration) => (
                  <Card key={integration.id} className="border-carbon-gray-20">
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          {getIntegrationIcon(integration.type)}
                          <div>
                            <CardTitle className="text-lg">{integration.name}</CardTitle>
                            <p className="text-sm text-carbon-gray-60">{integration.description}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <div className={`w-2 h-2 rounded-full ${getHealthColor(integration.healthStatus)}`} />
                          <Badge className={getStatusColor(integration.status)}>
                            {getStatusIcon(integration.status)}
                            <span className="ml-1 capitalize">{integration.status}</span>
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <p className="text-gray-600">Last Sync</p>
                          <p className="font-medium">{integration.lastSync}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Sync Interval</p>
                          <p className="font-medium">{integration.syncInterval} min</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Records Synced</p>
                          <p className="font-medium">{integration.recordsSynced.toLocaleString()}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Response Time</p>
                          <p className="font-medium">{integration.responseTime}ms</p>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between pt-2 border-t">
                        <div className="flex items-center space-x-2">
                          <Switch 
                            checked={integration.isActive}
                            onCheckedChange={() => {/* Handle toggle */}}
                          />
                          <span className="text-sm">Active</span>
                        </div>
                        <div className="flex space-x-2">
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => handleTestConnection(integration.id)}
                            disabled={testingConnection === integration.id}
                          >
                            {testingConnection === integration.id ? (
                              <RefreshCw className="w-4 h-4 animate-spin" />
                            ) : (
                              <Activity className="w-4 h-4" />
                            )}
                          </Button>
                          <Button variant="outline" size="sm">
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button variant="outline" size="sm">
                            <Settings className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="webhooks" className="space-y-4">
              <div className="space-y-4">
                {sampleWebhooks.map((webhook) => (
                  <Card key={webhook.id} className="border-carbon-gray-20">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <Webhook className="w-5 h-5 text-blue-600" />
                            <h4 className="font-medium">{webhook.name}</h4>
                            <Badge className={getStatusColor(webhook.status)}>
                              {getStatusIcon(webhook.status)}
                              <span className="ml-1 capitalize">{webhook.status}</span>
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-600 mb-2">{webhook.url}</p>
                          <div className="flex flex-wrap gap-1 mb-2">
                            {webhook.events.map((event, index) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {event}
                              </Badge>
                            ))}
                          </div>
                          <div className="flex items-center space-x-4 text-sm text-gray-600">
                            <span>Last triggered: {webhook.lastTriggered}</span>
                            <span>Success rate: {webhook.successRate}%</span>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Switch 
                            checked={webhook.isActive}
                            onCheckedChange={() => {/* Handle toggle */}}
                          />
                          <Button variant="outline" size="sm">
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button variant="outline" size="sm">
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="logs" className="space-y-4">
              <Card className="border-carbon-gray-20">
                <CardHeader>
                  <CardTitle>API Request Logs</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {sampleApiLogs.map((log) => (
                      <div key={log.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-1">
                            <span className="font-medium text-sm">{log.integrationName}</span>
                            <Badge variant="outline" className="text-xs">
                              {log.method}
                            </Badge>
                            <Badge className={log.success ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}>
                              {log.statusCode}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-600">{log.endpoint}</p>
                          {log.errorMessage && (
                            <p className="text-sm text-red-600 mt-1">{log.errorMessage}</p>
                          )}
                        </div>
                        <div className="text-right text-sm">
                          <p className="font-medium">{log.responseTime}ms</p>
                          <p className="text-gray-600">{log.timestamp}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="marketplace" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[
                  { name: "QuickBooks", type: "accounting", description: "Financial management and accounting", icon: DollarSign },
                  { name: "Shopify", type: "ecommerce", description: "E-commerce platform integration", icon: Package },
                  { name: "HubSpot", type: "crm", description: "Customer relationship management", icon: Users },
                  { name: "Mailchimp", type: "email", description: "Email marketing automation", icon: Mail },
                  { name: "Google Analytics", type: "analytics", description: "Web analytics and reporting", icon: TrendingUp },
                  { name: "UPS", type: "shipping", description: "Shipping and logistics", icon: Truck }
                ].map((item, index) => (
                  <Card key={index} className="border-carbon-gray-20 hover:shadow-lg transition-shadow cursor-pointer">
                    <CardContent className="p-4">
                      <div className="flex items-center space-x-3 mb-3">
                        <div className="p-2 bg-blue-50 rounded">
                          <item.icon className="w-6 h-6 text-blue-600" />
                        </div>
                        <div>
                          <h4 className="font-medium">{item.name}</h4>
                          <p className="text-xs text-gray-600 capitalize">{item.type}</p>
                        </div>
                      </div>
                      <p className="text-sm text-gray-600 mb-4">{item.description}</p>
                      <Button size="sm" className="w-full">
                        <Plus className="w-4 h-4 mr-2" />
                        Connect
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}