import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useMutation, useQuery } from "@tanstack/react-query";

export interface DraggableItem {
  id: string;
  title: string;
  description: string;
  category: string;
  enabled: boolean;
  order: number;
  icon?: string;
  configurable?: boolean;
}

export interface PreferenceSection {
  id: string;
  title: string;
  description: string;
  items: DraggableItem[];
}

export interface UserPreferences {
  id?: string;
  userId?: string;
  dashboardLayout: PreferenceSection[];
  theme: string;
  language: string;
  notifications: {
    email: boolean;
    push: boolean;
    desktop: boolean;
  };
  updatedAt?: string;
}

const DEFAULT_PREFERENCES: UserPreferences = {
  dashboardLayout: [
    {
      id: "dashboard",
      title: "Dashboard Widgets",
      description: "Customize your dashboard layout and widget visibility",
      items: [
        {
          id: "kpi-cards",
          title: "KPI Cards",
          description: "Key performance indicators overview",
          category: "dashboard",
          enabled: true,
          order: 1,
          configurable: true
        },
        {
          id: "recent-activity",
          title: "Recent Activity",
          description: "Latest system activities and updates",
          category: "dashboard",
          enabled: true,
          order: 2,
          configurable: true
        },
        {
          id: "production-chart",
          title: "Production Analytics",
          description: "Real-time production metrics and trends",
          category: "dashboard",
          enabled: true,
          order: 3,
          configurable: true
        },
        {
          id: "inventory-alerts",
          title: "Inventory Alerts",
          description: "Low stock and reorder notifications",
          category: "dashboard",
          enabled: false,
          order: 4,
          configurable: true
        }
      ]
    },
    {
      id: "navigation",
      title: "Navigation & Shortcuts",
      description: "Organize menu items and quick access features",
      items: [
        {
          id: "inventory-menu",
          title: "Inventory Management",
          description: "Access to inventory tools and reports",
          category: "navigation",
          enabled: true,
          order: 1
        },
        {
          id: "production-menu",
          title: "Production Orders",
          description: "Manufacturing workflow management",
          category: "navigation",
          enabled: true,
          order: 2
        },
        {
          id: "quality-menu",
          title: "Quality Control",
          description: "Quality assurance and compliance",
          category: "navigation",
          enabled: true,
          order: 3
        },
        {
          id: "scanner-menu",
          title: "Barcode Scanner",
          description: "Mobile scanning capabilities",
          category: "navigation",
          enabled: true,
          order: 4
        }
      ]
    },
    {
      id: "notifications",
      title: "Notification Preferences",
      description: "Control what notifications you receive and how",
      items: [
        {
          id: "low-stock-alerts",
          title: "Low Stock Alerts",
          description: "Notify when inventory falls below minimum levels",
          category: "notifications",
          enabled: true,
          order: 1
        },
        {
          id: "order-updates",
          title: "Order Status Updates",
          description: "Production order progress notifications",
          category: "notifications",
          enabled: true,
          order: 2
        },
        {
          id: "quality-issues",
          title: "Quality Issues",
          description: "Quality control failure notifications",
          category: "notifications",
          enabled: true,
          order: 3
        },
        {
          id: "system-maintenance",
          title: "System Maintenance",
          description: "Scheduled maintenance and updates",
          category: "notifications",
          enabled: false,
          order: 4
        }
      ]
    }
  ],
  theme: "light",
  language: "en",
  notifications: {
    email: true,
    push: true,
    desktop: false
  }
};

const STORAGE_KEY = "user-preferences";

export function useUserPreferences() {
  const { toast } = useToast();
  
  // Get preferences from server
  const { data: serverPreferences, isLoading } = useQuery({
    queryKey: ["/api/user/preferences"],
    retry: false,
  });

  // Get local preferences as fallback
  const getLocalPreferences = (): UserPreferences => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        return { ...DEFAULT_PREFERENCES, ...JSON.parse(stored) };
      }
    } catch (error) {
      console.warn("Failed to parse stored preferences:", error);
    }
    return DEFAULT_PREFERENCES;
  };

  const [localPreferences, setLocalPreferences] = useState<UserPreferences>(getLocalPreferences);

  // Use server preferences if available, otherwise use local
  const preferences = serverPreferences || localPreferences;

  // Save preferences mutation
  const savePreferencesMutation = useMutation({
    mutationFn: async (newPreferences: UserPreferences) => {
      return await apiRequest("/api/preferences", {
        method: "PUT",
        body: JSON.stringify(newPreferences),
        headers: {
          "Content-Type": "application/json",
        },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/preferences"] });
      toast({
        title: "Preferences Saved",
        description: "Your settings have been updated successfully",
      });
    },
    onError: (error) => {
      // Fallback to local storage if server save fails
      localStorage.setItem(STORAGE_KEY, JSON.stringify(preferences));
      setLocalPreferences(preferences);
      
      toast({
        title: "Saved Locally",
        description: "Preferences saved to your device. They'll sync when you're back online.",
      });
    },
  });

  // Update preferences function
  const updatePreferences = (newPreferences: Partial<UserPreferences>) => {
    const updated = { ...preferences, ...newPreferences };
    savePreferencesMutation.mutate(updated);
  };

  // Reset to defaults
  const resetPreferences = () => {
    savePreferencesMutation.mutate(DEFAULT_PREFERENCES);
  };

  // Update dashboard layout specifically
  const updateDashboardLayout = (layout: PreferenceSection[]) => {
    updatePreferences({ dashboardLayout: layout });
  };

  // Update theme
  const updateTheme = (theme: string) => {
    updatePreferences({ theme });
    // Apply theme to document
    document.documentElement.className = theme === "dark" ? "dark" : "";
  };

  // Update notification settings
  const updateNotificationSettings = (notifications: UserPreferences["notifications"]) => {
    updatePreferences({ notifications });
  };

  // Get widget enabled status
  const isWidgetEnabled = (widgetId: string): boolean => {
    for (const section of preferences.dashboardLayout) {
      const item = section.items.find(item => item.id === widgetId);
      if (item) return item.enabled;
    }
    return false;
  };

  // Get widget order
  const getWidgetOrder = (widgetId: string): number => {
    for (const section of preferences.dashboardLayout) {
      const item = section.items.find(item => item.id === widgetId);
      if (item) return item.order;
    }
    return 999;
  };

  // Get enabled widgets for a section
  const getEnabledWidgets = (sectionId: string): DraggableItem[] => {
    const section = preferences.dashboardLayout.find(s => s.id === sectionId);
    if (!section) return [];
    
    return section.items
      .filter(item => item.enabled)
      .sort((a, b) => a.order - b.order);
  };

  return {
    preferences,
    isLoading,
    isSaving: savePreferencesMutation.isPending,
    updatePreferences,
    updateDashboardLayout,
    updateTheme,
    updateNotificationSettings,
    resetPreferences,
    isWidgetEnabled,
    getWidgetOrder,
    getEnabledWidgets,
  };
}