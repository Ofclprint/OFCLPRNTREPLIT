import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { 
  insertInventoryItemSchema,
  insertProductionOrderSchema,
  insertQualityControlLogSchema,
  insertInventoryMovementSchema,
  insertActivityLogSchema,
  insertAiForecastSchema,
  insertUserPreferencesSchema,
} from "@shared/schema";
import { z } from "zod";

// AI Service for Gemini integration
async function generateAIInsights(type: string, data: any) {
  const apiKey = process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY || "demo_key";
  
  try {
    // Mock AI insights for demo (replace with actual Gemini API call)
    const insights = {
      demand: {
        prediction: "Expected 15% increase in hydraulic pump orders next month based on historical patterns.",
        confidence: 0.85,
        type: "demand"
      },
      cost_optimization: {
        prediction: "Switching to Supplier B for steel could save $12K annually.",
        confidence: 0.78,
        type: "cost_optimization"
      },
      quality_prediction: {
        prediction: "Current batch quality scores 2% above average. Continue current process.",
        confidence: 0.92,
        type: "quality_prediction"
      }
    };
    
    return insights[type as keyof typeof insights] || insights.demand;
  } catch (error) {
    console.error("AI service error:", error);
    return null;
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware - setup sessions first
  await setupAuth(app);

  // Demo login endpoint for development
  app.post('/api/demo-login', async (req, res) => {
    try {
      const { email = 'demo@example.com' } = req.body;
      
      // Create or get demo user
      let user = await storage.getUser('demo-user-123');
      if (!user) {
        user = await storage.upsertUser({
          id: 'demo-user-123',
          email: email,
          firstName: 'Demo',
          lastName: 'User',
          profileImageUrl: 'https://via.placeholder.com/150',
          role: 'admin'
        });
      }
      
      // Set session
      (req.session as any).user = {
        claims: {
          sub: user.id,
          email: user.email,
          first_name: user.firstName,
          last_name: user.lastName,
          profile_image_url: user.profileImageUrl
        },
        expires_at: Math.floor(Date.now() / 1000) + 3600 // 1 hour
      };
      
      res.json({ success: true, user });
    } catch (error) {
      console.error('Demo login error:', error);
      res.status(500).json({ error: 'Login failed' });
    }
  });



  // Auth routes
  app.get('/api/auth/user', async (req: any, res) => {
    try {
      // Check if user is logged in via session
      if (req.session && req.session.user) {
        const userId = req.session.user.claims.sub;
        const user = await storage.getUser(userId);
        if (user) {
          res.json(user);
          return;
        }
      }
      
      // Fall back to standard auth middleware
      if (req.user && req.user.claims) {
        const userId = req.user.claims.sub;
        const user = await storage.getUser(userId);
        if (user) {
          res.json(user);
          return;
        }
      }
      
      res.status(401).json({ message: "Unauthorized" });
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(401).json({ message: "Unauthorized" });
    }
  });

  // User profile update
  app.patch('/api/auth/profile', async (req: any, res) => {
    try {
      // Check authentication
      if (!req.session || !req.session.user) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const userId = req.session.user.claims.sub;
      const updateData = req.body;

      // Update user in storage
      const updatedUser = await storage.upsertUser({
        id: userId,
        ...updateData
      });

      // Update session data
      req.session.user.claims = {
        ...req.session.user.claims,
        email: updatedUser.email,
        first_name: updatedUser.firstName,
        last_name: updatedUser.lastName,
        profile_image_url: updatedUser.profileImageUrl
      };

      res.json(updatedUser);
    } catch (error) {
      console.error("Error updating profile:", error);
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  // User preferences
  app.get('/api/user-preferences', async (req: any, res) => {
    try {
      if (!req.session || !req.session.user) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const userId = req.session.user.claims.sub;
      const preferences = await storage.getUserPreferences(userId);
      
      res.json(preferences || {
        theme: 'system',
        notifications: true,
        autoRefresh: true,
        compactView: false,
        showLowStockAlerts: true,
        defaultPageSize: '25',
        dateFormat: 'MM/dd/yyyy',
        timeFormat: '12h'
      });
    } catch (error) {
      console.error("Error fetching preferences:", error);
      res.status(500).json({ message: "Failed to fetch preferences" });
    }
  });

  app.post('/api/user-preferences', async (req: any, res) => {
    try {
      if (!req.session || !req.session.user) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const userId = req.session.user.claims.sub;
      const preferencesData = req.body;

      // Check if preferences exist
      const existingPreferences = await storage.getUserPreferences(userId);
      
      let preferences;
      if (existingPreferences) {
        preferences = await storage.updateUserPreferences(userId, preferencesData);
      } else {
        preferences = await storage.createUserPreferences({
          userId: userId,
          ...preferencesData
        });
      }

      res.json(preferences);
    } catch (error) {
      console.error("Error updating preferences:", error);
      res.status(500).json({ message: "Failed to update preferences" });
    }
  });

  // Data export
  app.get('/api/export/data', async (req: any, res) => {
    try {
      if (!req.session || !req.session.user) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      // Get all data for export
      const [
        inventory,
        productionOrders,
        qualityLogs,
        activityLogs
      ] = await Promise.all([
        storage.getAllInventoryItems(),
        storage.getAllProductionOrders(),
        storage.getAllQualityControlLogs(),
        storage.getAllActivityLogs()
      ]);

      const exportData = {
        exportDate: new Date().toISOString(),
        version: '1.0',
        data: {
          inventory,
          productionOrders,
          qualityLogs,
          activityLogs
        }
      };

      res.json(exportData);
    } catch (error) {
      console.error("Error exporting data:", error);
      res.status(500).json({ message: "Failed to export data" });
    }
  });

  // Dashboard routes
  app.get('/api/dashboard/kpis', async (req, res) => {
    try {
      const kpis = await storage.getDashboardKPIs();
      res.json(kpis);
    } catch (error) {
      console.error("Error fetching KPIs:", error);
      res.status(500).json({ message: "Failed to fetch KPIs" });
    }
  });

  app.get('/api/dashboard/recent-activity', async (req, res) => {
    try {
      const activities = await storage.getRecentActivityLogs(10);
      res.json(activities);
    } catch (error) {
      console.error("Error fetching activities:", error);
      res.status(500).json({ message: "Failed to fetch activities" });
    }
  });

  // Dashboard layout endpoints
  app.get('/api/dashboard/layout', isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any)?.claims?.sub;
      if (!userId) {
        return res.status(401).json({ message: "User not authenticated" });
      }
      
      const preferences = await storage.getUserPreferences(userId);
      if (preferences?.dashboardLayout) {
        res.json(preferences.dashboardLayout);
      } else {
        // Return default layout if no saved layout exists
        res.status(404).json({ message: "No saved layout found" });
      }
    } catch (error) {
      console.error("Error fetching dashboard layout:", error);
      res.status(500).json({ message: "Failed to fetch dashboard layout" });
    }
  });

  app.post('/api/dashboard/layout', isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any)?.claims?.sub;
      if (!userId) {
        return res.status(401).json({ message: "User not authenticated" });
      }

      const layout = req.body;
      
      // Check if user preferences exist
      const existingPreferences = await storage.getUserPreferences(userId);
      
      if (existingPreferences) {
        // Update existing preferences
        await storage.updateUserPreferences(userId, {
          dashboardLayout: layout
        });
      } else {
        // Create new preferences
        await storage.createUserPreferences({
          userId,
          dashboardLayout: layout,
          theme: "light",
          language: "en",
          notifications: {
            email: true,
            push: true,
            sms: false
          }
        });
      }

      res.json({ message: "Dashboard layout saved successfully" });
    } catch (error) {
      console.error("Error saving dashboard layout:", error);
      res.status(500).json({ message: "Failed to save dashboard layout" });
    }
  });

  // Inventory routes
  app.get('/api/inventory', async (req, res) => {
    try {
      const items = await storage.getAllInventoryItems();
      res.json(items);
    } catch (error) {
      console.error("Error fetching inventory:", error);
      res.status(500).json({ message: "Failed to fetch inventory" });
    }
  });

  app.get('/api/inventory/low-stock', async (req, res) => {
    try {
      const items = await storage.getLowStockItems();
      res.json(items);
    } catch (error) {
      console.error("Error fetching low stock items:", error);
      res.status(500).json({ message: "Failed to fetch low stock items" });
    }
  });

  app.get('/api/inventory/reorder-suggestions', async (req, res) => {
    try {
      const lowStockItems = await storage.getLowStockItems();
      const suggestions = lowStockItems.map(item => {
        const currentStock = item.currentStock || 0;
        const minStock = item.minStock || 0;
        const maxStock = item.maxStock || minStock * 2;
        const unitPrice = parseFloat(item.unitPrice || '0');
        
        const suggestedQuantity = Math.max(maxStock - currentStock, minStock * 2);
        const estimatedCost = unitPrice * suggestedQuantity;
        
        return {
          id: item.id,
          name: item.name,
          sku: item.sku || '',
          currentStock,
          suggestedQuantity,
          estimatedCost,
          urgency: currentStock === 0 ? 'high' : currentStock <= minStock / 2 ? 'medium' : 'low',
          daysUntilStockout: Math.max(1, Math.floor(currentStock / Math.max(1, minStock / 7))),
          averageWeeklyUsage: Math.max(1, minStock / 7)
        };
      });
      res.json(suggestions);
    } catch (error) {
      console.error("Error generating reorder suggestions:", error);
      res.status(500).json({ message: "Failed to generate reorder suggestions" });
    }
  });

  app.get('/api/inventory/:id', isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const item = await storage.getInventoryItem(id);
      if (!item) {
        return res.status(404).json({ message: "Item not found" });
      }
      res.json(item);
    } catch (error) {
      console.error("Error fetching inventory item:", error);
      res.status(500).json({ message: "Failed to fetch inventory item" });
    }
  });

  app.post('/api/inventory', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user?.claims?.sub;
      if (!userId) {
        return res.status(401).json({ message: "User not authenticated" });
      }
      
      const user = await storage.getUser(userId);
      
      // Allow all authenticated users to create inventory items
      if (!user) {
        return res.status(403).json({ message: "User not found" });
      }

      const validatedData = insertInventoryItemSchema.parse(req.body);
      const item = await storage.createInventoryItem(validatedData);
      
      // Log activity
      await storage.createActivityLog({
        userId,
        action: `Created inventory item: ${item.name}`,
        entityType: "inventory_item",
        entityId: item.id.toString(),
        details: { item }
      });

      res.json(item);
    } catch (error) {
      console.error("Error creating inventory item:", error);
      res.status(500).json({ message: "Failed to create inventory item" });
    }
  });

  app.put('/api/inventory/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user?.claims?.sub;
      if (!userId) {
        return res.status(401).json({ message: "User not authenticated" });
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(403).json({ message: "User not found" });
      }

      const id = parseInt(req.params.id);
      const validatedData = insertInventoryItemSchema.partial().parse(req.body);
      const item = await storage.updateInventoryItem(id, validatedData);
      
      // Log activity
      await storage.createActivityLog({
        userId,
        action: `Updated inventory item: ${item.name}`,
        entityType: "inventory_item",
        entityId: item.id.toString(),
        details: { changes: validatedData }
      });

      res.json(item);
    } catch (error) {
      console.error("Error updating inventory item:", error);
      res.status(500).json({ message: "Failed to update inventory item" });
    }
  });

  // Barcode lookup route
  app.get('/api/inventory/barcode/:barcode', isAuthenticated, async (req, res) => {
    try {
      const { barcode } = req.params;
      const item = await storage.getInventoryItemByBarcode(barcode);
      if (!item) {
        return res.status(404).json({ message: "Item not found" });
      }
      res.json(item);
    } catch (error) {
      console.error("Error looking up barcode:", error);
      res.status(500).json({ message: "Failed to lookup barcode" });
    }
  });

  // Production orders routes
  app.get('/api/orders', async (req, res) => {
    try {
      const orders = await storage.getAllProductionOrders();
      res.json(orders);
    } catch (error) {
      console.error("Error fetching orders:", error);
      res.status(500).json({ message: "Failed to fetch orders" });
    }
  });

  app.get('/api/orders/:id', isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const order = await storage.getProductionOrder(id);
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      res.json(order);
    } catch (error) {
      console.error("Error fetching order:", error);
      res.status(500).json({ message: "Failed to fetch order" });
    }
  });

  app.post('/api/orders', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user || !user.role || !['admin', 'manager'].includes(user.role)) {
        return res.status(403).json({ message: "Insufficient permissions" });
      }

      const validatedData = insertProductionOrderSchema.parse({
        ...req.body,
        createdBy: userId,
      });
      
      // Generate order number
      const orderCount = await storage.getAllProductionOrders();
      const orderNumber = `PO-${new Date().getFullYear()}-${String(orderCount.length + 1).padStart(3, '0')}`;
      
      const order = await storage.createProductionOrder({
        ...validatedData,
        orderNumber,
      });
      
      // Log activity
      await storage.createActivityLog({
        userId,
        action: `Created production order: ${order.orderNumber}`,
        entityType: "production_order",
        entityId: order.id.toString(),
        details: { order }
      });

      res.json(order);
    } catch (error) {
      console.error("Error creating order:", error);
      res.status(500).json({ message: "Failed to create order" });
    }
  });

  app.put('/api/orders/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(403).json({ message: "Insufficient permissions" });
      }

      const id = parseInt(req.params.id);
      const validatedData = insertProductionOrderSchema.partial().parse(req.body);
      
      // Check permissions based on role
      if (user.role === 'employee') {
        // Employees can only update progress and status of assigned orders
        const order = await storage.getProductionOrder(id);
        if (!order || order.assignedTo !== userId) {
          return res.status(403).json({ message: "Insufficient permissions" });
        }
      }

      const order = await storage.updateProductionOrder(id, validatedData);
      
      // Log activity
      await storage.createActivityLog({
        userId,
        action: `Updated production order: ${order.orderNumber}`,
        entityType: "production_order",
        entityId: order.id.toString(),
        details: { changes: validatedData }
      });

      res.json(order);
    } catch (error) {
      console.error("Error updating order:", error);
      res.status(500).json({ message: "Failed to update order" });
    }
  });

  // Quality control routes
  app.get('/api/quality-control', isAuthenticated, async (req, res) => {
    try {
      const logs = await storage.getAllQualityControlLogs();
      res.json(logs);
    } catch (error) {
      console.error("Error fetching QC logs:", error);
      res.status(500).json({ message: "Failed to fetch QC logs" });
    }
  });

  app.post('/api/quality-control', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertQualityControlLogSchema.parse({
        ...req.body,
        inspectorId: userId,
      });
      
      const log = await storage.createQualityControlLog(validatedData);
      
      // Log activity
      await storage.createActivityLog({
        userId,
        action: `Created QC log for order ${log.orderId}`,
        entityType: "quality_control_log",
        entityId: log.id.toString(),
        details: { log }
      });

      res.json(log);
    } catch (error) {
      console.error("Error creating QC log:", error);
      res.status(500).json({ message: "Failed to create QC log" });
    }
  });

  // AI insights routes
  app.get('/api/ai/insights', async (req, res) => {
    try {
      const forecasts = await storage.getValidForecasts();
      
      // Generate new insights if none exist or are old
      if (forecasts.length === 0) {
        const demandInsight = await generateAIInsights('demand', {});
        const costInsight = await generateAIInsights('cost_optimization', {});
        const qualityInsight = await generateAIInsights('quality_prediction', {});
        
        if (demandInsight) {
          await storage.createAiForecast({
            type: 'demand',
            prediction: demandInsight,
            confidence: "0.85",
            validUntil: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 hours
          });
        }
        
        if (costInsight) {
          await storage.createAiForecast({
            type: 'cost_optimization',
            prediction: costInsight,
            confidence: "0.78",
            validUntil: new Date(Date.now() + 24 * 60 * 60 * 1000),
          });
        }
        
        if (qualityInsight) {
          await storage.createAiForecast({
            type: 'quality_prediction',
            prediction: qualityInsight,
            confidence: "0.92",
            validUntil: new Date(Date.now() + 24 * 60 * 60 * 1000),
          });
        }
        
        const newForecasts = await storage.getValidForecasts();
        res.json(newForecasts);
      } else {
        res.json(forecasts);
      }
    } catch (error) {
      console.error("Error fetching AI insights:", error);
      res.status(500).json({ message: "Failed to fetch AI insights" });
    }
  });

  // Inventory movements route
  app.post('/api/inventory/movements', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertInventoryMovementSchema.parse({
        ...req.body,
        userId,
      });
      
      // Update inventory stock levels
      const item = await storage.getInventoryItem(validatedData.itemId!);
      if (!item) {
        return res.status(404).json({ message: "Item not found" });
      }
      
      let newStock = item.currentStock || 0;
      const previousStock = item.currentStock || 0;
      
      switch (validatedData.type) {
        case 'in':
          newStock += validatedData.quantity;
          break;
        case 'out':
          newStock -= validatedData.quantity;
          break;
        case 'adjustment':
          newStock = validatedData.quantity;
          break;
      }
      
      // Update stock in database
      await storage.updateInventoryItem(validatedData.itemId!, { currentStock: newStock });
      
      // Create movement record
      const movement = await storage.createInventoryMovement({
        ...validatedData,
        previousStock,
        newStock,
      });
      
      // Log activity
      await storage.createActivityLog({
        userId,
        action: `${validatedData.type.toUpperCase()} inventory movement for ${item.name}`,
        entityType: "inventory_movement",
        entityId: movement.id.toString(),
        details: { movement, item: item.name }
      });

      res.json(movement);
    } catch (error) {
      console.error("Error creating inventory movement:", error);
      res.status(500).json({ message: "Failed to create inventory movement" });
    }
  });

  // User preferences routes
  app.get('/api/preferences', async (req: any, res) => {
    try {
      // Get user ID from session or auth
      let userId = 'demo-user-123'; // Default for demo
      if (req.session && req.session.user) {
        userId = req.session.user.claims.sub;
      } else if (req.user && req.user.claims) {
        userId = req.user.claims.sub;
      }
      let preferences = await storage.getUserPreferences(userId);
      
      if (!preferences) {
        // Create default preferences if none exist
        const defaultPreferences = {
          userId,
          dashboardLayout: [
            {
              id: "overview",
              title: "Overview",
              description: "Production and inventory overview",
              items: [
                { id: "kpi-cards", title: "KPI Cards", description: "Key performance indicators", category: "overview", enabled: true, order: 1 },
                { id: "recent-activity", title: "Recent Activity", description: "Latest system activity", category: "overview", enabled: true, order: 2 }
              ]
            },
            {
              id: "production",
              title: "Production",
              description: "Production management tools",
              items: [
                { id: "production-orders", title: "Production Orders", description: "Manage production orders", category: "production", enabled: true, order: 1 },
                { id: "quality-control", title: "Quality Control", description: "Quality management", category: "production", enabled: true, order: 2 }
              ]
            },
            {
              id: "inventory",
              title: "Inventory",
              description: "Inventory management tools",
              items: [
                { id: "inventory-levels", title: "Inventory Levels", description: "Current stock levels", category: "inventory", enabled: true, order: 1 },
                { id: "low-stock-alerts", title: "Low Stock Alerts", description: "Items running low", category: "inventory", enabled: true, order: 2 }
              ]
            }
          ],
          theme: "light",
          language: "en",
          notifications: {
            email: true,
            push: true,
            desktop: false
          }
        };
        
        preferences = await storage.createUserPreferences(defaultPreferences);
      }
      
      res.json(preferences);
    } catch (error) {
      console.error("Error fetching user preferences:", error);
      res.status(500).json({ message: "Failed to fetch preferences" });
    }
  });

  app.put('/api/preferences', async (req: any, res) => {
    try {
      // Get user ID from session or auth
      let userId = 'demo-user-123'; // Default for demo
      if (req.session && req.session.user) {
        userId = req.session.user.claims.sub;
      } else if (req.user && req.user.claims) {
        userId = req.user.claims.sub;
      }
      const validatedData = insertUserPreferencesSchema.parse({
        ...req.body,
        userId
      });

      const preferences = await storage.updateUserPreferences(userId, validatedData);
      res.json(preferences);
    } catch (error) {
      console.error("Error updating user preferences:", error);
      res.status(500).json({ message: "Failed to update preferences" });
    }
  });

  // Performance Snapshot Dashboard API endpoints
  app.get("/api/performance/snapshot", async (req, res) => {
    try {
      const kpis = await storage.getDashboardKPIs();
      const recentLogs = await storage.getRecentActivityLogs(5);
      const lowStockItems = await storage.getLowStockItems();
      const activeOrders = await storage.getOrdersByStatus("in_progress");
      
      const snapshot = {
        timestamp: new Date().toISOString(),
        kpis,
        metrics: {
          oee: 82.4,
          qualityScore: 96.8,
          throughput: 1247,
          downtime: 2.3,
          costPerUnit: 24.85,
          inventoryTurnover: 6.2
        },
        alerts: recentLogs.slice(0, 3).map(log => ({
          id: log.id.toString(),
          type: log.action.includes("error") || log.action.includes("failed") ? "critical" : 
                log.action.includes("warning") || log.action.includes("low") ? "warning" : "info",
          message: log.action,
          timestamp: log.createdAt,
          module: "System"
        })),
        production: {
          activeOrders: activeOrders.length,
          efficiency: kpis.efficiency,
          qualityScore: kpis.qualityScore
        },
        inventory: {
          lowStockCount: lowStockItems.length,
          totalValue: kpis.inventoryValue
        }
      };
      
      res.json(snapshot);
    } catch (error) {
      console.error("Error generating performance snapshot:", error);
      res.status(500).json({ message: "Failed to generate snapshot" });
    }
  });

  app.get("/api/performance/hourly-trends", async (req, res) => {
    try {
      // Generate hourly performance data for the last 8 hours
      const hourlyData = [];
      const now = new Date();
      
      for (let i = 7; i >= 0; i--) {
        const hour = new Date(now.getTime() - (i * 60 * 60 * 1000));
        hourlyData.push({
          time: hour.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
          production: Math.floor(140 + Math.random() * 20),
          quality: Math.floor(95 + Math.random() * 4),
          efficiency: Math.floor(80 + Math.random() * 15)
        });
      }
      
      res.json(hourlyData);
    } catch (error) {
      console.error("Error fetching hourly trends:", error);
      res.status(500).json({ message: "Failed to fetch trends" });
    }
  });

  app.get("/api/performance/production-status", async (req, res) => {
    try {
      const orders = await storage.getAllProductionOrders();
      const activeOrders = orders.slice(0, 5).map(order => ({
        orderId: order.orderNumber,
        product: order.productName,
        status: order.status === "in_progress" ? "running" : 
                order.status === "completed" ? "completed" : 
                order.status === "pending" ? "pending" : "stopped",
        progress: order.progress || Math.floor(Math.random() * 100),
        efficiency: Math.floor(85 + Math.random() * 15),
        timeRemaining: order.status === "completed" ? "0m" : 
                      `${Math.floor(Math.random() * 5)}h ${Math.floor(Math.random() * 60)}m`
      }));
      
      res.json(activeOrders);
    } catch (error) {
      console.error("Error fetching production status:", error);
      res.status(500).json({ message: "Failed to fetch production status" });
    }
  });

  app.get("/api/performance/department-data", async (req, res) => {
    try {
      const departmentData = [
        { name: "Assembly", value: 35, efficiency: 92 },
        { name: "Machining", value: 28, efficiency: 87 },
        { name: "Quality", value: 15, efficiency: 96 },
        { name: "Packaging", value: 22, efficiency: 84 }
      ];
      
      res.json(departmentData);
    } catch (error) {
      console.error("Error fetching department data:", error);
      res.status(500).json({ message: "Failed to fetch department data" });
    }
  });

  app.post("/api/performance/export", async (req, res) => {
    try {
      // Log the export action
      await storage.createActivityLog({
        userId: "system",
        action: "export_performance_snapshot",
        entityType: "performance",
        entityId: "snapshot"
      });
      
      res.json({ message: "Export initiated", downloadUrl: "/api/performance/download" });
    } catch (error) {
      console.error("Error exporting snapshot:", error);
      res.status(500).json({ message: "Failed to export snapshot" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
