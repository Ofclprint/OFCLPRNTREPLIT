import {
  users,
  inventoryItems,
  productionOrders,
  qualityControlLogs,
  inventoryMovements,
  activityLogs,
  aiForecasts,
  userPreferences,
  type User,
  type UpsertUser,
  type InventoryItem,
  type InsertInventoryItem,
  type ProductionOrder,
  type InsertProductionOrder,
  type QualityControlLog,
  type InsertQualityControlLog,
  type InventoryMovement,
  type InsertInventoryMovement,
  type ActivityLog,
  type InsertActivityLog,
  type AiForecast,
  type InsertAiForecast,
  type UserPreferences,
  type InsertUserPreferences,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, asc, lt, and, or, sql } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Inventory operations
  getAllInventoryItems(): Promise<InventoryItem[]>;
  getInventoryItem(id: number): Promise<InventoryItem | undefined>;
  getInventoryItemBySku(sku: string): Promise<InventoryItem | undefined>;
  getInventoryItemByBarcode(barcode: string): Promise<InventoryItem | undefined>;
  createInventoryItem(item: InsertInventoryItem): Promise<InventoryItem>;
  updateInventoryItem(id: number, item: Partial<InsertInventoryItem>): Promise<InventoryItem>;
  deleteInventoryItem(id: number): Promise<void>;
  getLowStockItems(): Promise<InventoryItem[]>;
  
  // Production order operations
  getAllProductionOrders(): Promise<ProductionOrder[]>;
  getProductionOrder(id: number): Promise<ProductionOrder | undefined>;
  getProductionOrderByNumber(orderNumber: string): Promise<ProductionOrder | undefined>;
  createProductionOrder(order: InsertProductionOrder): Promise<ProductionOrder>;
  updateProductionOrder(id: number, order: Partial<InsertProductionOrder>): Promise<ProductionOrder>;
  deleteProductionOrder(id: number): Promise<void>;
  getOrdersByStatus(status: string): Promise<ProductionOrder[]>;
  
  // Quality control operations
  getAllQualityControlLogs(): Promise<QualityControlLog[]>;
  getQualityControlLog(id: number): Promise<QualityControlLog | undefined>;
  createQualityControlLog(log: InsertQualityControlLog): Promise<QualityControlLog>;
  updateQualityControlLog(id: number, log: Partial<InsertQualityControlLog>): Promise<QualityControlLog>;
  getQualityControlLogsByOrder(orderId: number): Promise<QualityControlLog[]>;
  
  // Inventory movement operations
  getAllInventoryMovements(): Promise<InventoryMovement[]>;
  getInventoryMovement(id: number): Promise<InventoryMovement | undefined>;
  createInventoryMovement(movement: InsertInventoryMovement): Promise<InventoryMovement>;
  getMovementsByItem(itemId: number): Promise<InventoryMovement[]>;
  
  // Activity log operations
  getAllActivityLogs(): Promise<ActivityLog[]>;
  createActivityLog(log: InsertActivityLog): Promise<ActivityLog>;
  getRecentActivityLogs(limit?: number): Promise<ActivityLog[]>;
  
  // AI forecast operations
  getAllAiForecasts(): Promise<AiForecast[]>;
  getAiForecast(id: number): Promise<AiForecast | undefined>;
  createAiForecast(forecast: InsertAiForecast): Promise<AiForecast>;
  getValidForecasts(): Promise<AiForecast[]>;
  
  // Dashboard operations
  getDashboardKPIs(): Promise<{
    efficiency: number;
    activeOrders: number;
    qualityScore: number;
    inventoryValue: number;
  }>;
  
  // User preferences operations
  getUserPreferences(userId: string): Promise<UserPreferences | undefined>;
  createUserPreferences(preferences: InsertUserPreferences): Promise<UserPreferences>;
  updateUserPreferences(userId: string, preferences: Partial<InsertUserPreferences>): Promise<UserPreferences>;
}

export class DatabaseStorage implements IStorage {
  // User operations (mandatory for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }
  
  // Inventory operations
  async getAllInventoryItems(): Promise<InventoryItem[]> {
    return await db.select().from(inventoryItems).orderBy(asc(inventoryItems.name));
  }

  async getInventoryItem(id: number): Promise<InventoryItem | undefined> {
    const [item] = await db.select().from(inventoryItems).where(eq(inventoryItems.id, id));
    return item;
  }

  async getInventoryItemBySku(sku: string): Promise<InventoryItem | undefined> {
    const [item] = await db.select().from(inventoryItems).where(eq(inventoryItems.sku, sku));
    return item;
  }

  async getInventoryItemByBarcode(barcode: string): Promise<InventoryItem | undefined> {
    const [item] = await db.select().from(inventoryItems).where(eq(inventoryItems.barcode, barcode));
    return item;
  }

  async createInventoryItem(item: InsertInventoryItem): Promise<InventoryItem> {
    const [newItem] = await db.insert(inventoryItems).values(item).returning();
    return newItem;
  }

  async updateInventoryItem(id: number, item: Partial<InsertInventoryItem>): Promise<InventoryItem> {
    const [updatedItem] = await db
      .update(inventoryItems)
      .set({ ...item, updatedAt: new Date() })
      .where(eq(inventoryItems.id, id))
      .returning();
    return updatedItem;
  }

  async deleteInventoryItem(id: number): Promise<void> {
    await db.delete(inventoryItems).where(eq(inventoryItems.id, id));
  }

  async getLowStockItems(): Promise<InventoryItem[]> {
    return await db
      .select()
      .from(inventoryItems)
      .where(sql`${inventoryItems.currentStock} <= ${inventoryItems.minStock}`)
      .orderBy(asc(inventoryItems.currentStock));
  }
  
  // Production order operations
  async getAllProductionOrders(): Promise<ProductionOrder[]> {
    return await db.select().from(productionOrders).orderBy(desc(productionOrders.createdAt));
  }

  async getProductionOrder(id: number): Promise<ProductionOrder | undefined> {
    const [order] = await db.select().from(productionOrders).where(eq(productionOrders.id, id));
    return order;
  }

  async getProductionOrderByNumber(orderNumber: string): Promise<ProductionOrder | undefined> {
    const [order] = await db.select().from(productionOrders).where(eq(productionOrders.orderNumber, orderNumber));
    return order;
  }

  async createProductionOrder(order: InsertProductionOrder): Promise<ProductionOrder> {
    const [newOrder] = await db.insert(productionOrders).values(order).returning();
    return newOrder;
  }

  async updateProductionOrder(id: number, order: Partial<InsertProductionOrder>): Promise<ProductionOrder> {
    const [updatedOrder] = await db
      .update(productionOrders)
      .set({ ...order, updatedAt: new Date() })
      .where(eq(productionOrders.id, id))
      .returning();
    return updatedOrder;
  }

  async deleteProductionOrder(id: number): Promise<void> {
    await db.delete(productionOrders).where(eq(productionOrders.id, id));
  }

  async getOrdersByStatus(status: string): Promise<ProductionOrder[]> {
    return await db
      .select()
      .from(productionOrders)
      .where(eq(productionOrders.status, status))
      .orderBy(desc(productionOrders.createdAt));
  }
  
  // Quality control operations
  async getAllQualityControlLogs(): Promise<QualityControlLog[]> {
    return await db.select().from(qualityControlLogs).orderBy(desc(qualityControlLogs.createdAt));
  }

  async getQualityControlLog(id: number): Promise<QualityControlLog | undefined> {
    const [log] = await db.select().from(qualityControlLogs).where(eq(qualityControlLogs.id, id));
    return log;
  }

  async createQualityControlLog(log: InsertQualityControlLog): Promise<QualityControlLog> {
    const [newLog] = await db.insert(qualityControlLogs).values(log).returning();
    return newLog;
  }

  async updateQualityControlLog(id: number, log: Partial<InsertQualityControlLog>): Promise<QualityControlLog> {
    const [updatedLog] = await db
      .update(qualityControlLogs)
      .set(log)
      .where(eq(qualityControlLogs.id, id))
      .returning();
    return updatedLog;
  }

  async getQualityControlLogsByOrder(orderId: number): Promise<QualityControlLog[]> {
    return await db
      .select()
      .from(qualityControlLogs)
      .where(eq(qualityControlLogs.orderId, orderId))
      .orderBy(desc(qualityControlLogs.createdAt));
  }
  
  // Inventory movement operations
  async getAllInventoryMovements(): Promise<InventoryMovement[]> {
    return await db.select().from(inventoryMovements).orderBy(desc(inventoryMovements.createdAt));
  }

  async getInventoryMovement(id: number): Promise<InventoryMovement | undefined> {
    const [movement] = await db.select().from(inventoryMovements).where(eq(inventoryMovements.id, id));
    return movement;
  }

  async createInventoryMovement(movement: InsertInventoryMovement): Promise<InventoryMovement> {
    const [newMovement] = await db.insert(inventoryMovements).values(movement).returning();
    return newMovement;
  }

  async getMovementsByItem(itemId: number): Promise<InventoryMovement[]> {
    return await db
      .select()
      .from(inventoryMovements)
      .where(eq(inventoryMovements.itemId, itemId))
      .orderBy(desc(inventoryMovements.createdAt));
  }
  
  // Activity log operations
  async getAllActivityLogs(): Promise<ActivityLog[]> {
    return await db.select().from(activityLogs).orderBy(desc(activityLogs.createdAt));
  }

  async createActivityLog(log: InsertActivityLog): Promise<ActivityLog> {
    const [newLog] = await db.insert(activityLogs).values(log).returning();
    return newLog;
  }

  async getRecentActivityLogs(limit: number = 10): Promise<ActivityLog[]> {
    return await db
      .select()
      .from(activityLogs)
      .orderBy(desc(activityLogs.createdAt))
      .limit(limit);
  }
  
  // AI forecast operations
  async getAllAiForecasts(): Promise<AiForecast[]> {
    return await db.select().from(aiForecasts).orderBy(desc(aiForecasts.createdAt));
  }

  async getAiForecast(id: number): Promise<AiForecast | undefined> {
    const [forecast] = await db.select().from(aiForecasts).where(eq(aiForecasts.id, id));
    return forecast;
  }

  async createAiForecast(forecast: InsertAiForecast): Promise<AiForecast> {
    const [newForecast] = await db.insert(aiForecasts).values(forecast).returning();
    return newForecast;
  }

  async getValidForecasts(): Promise<AiForecast[]> {
    return await db
      .select()
      .from(aiForecasts)
      .where(or(eq(aiForecasts.validUntil, null), sql`${aiForecasts.validUntil} > NOW()`))
      .orderBy(desc(aiForecasts.createdAt));
  }
  
  // Dashboard operations
  async getDashboardKPIs(): Promise<{
    efficiency: number;
    activeOrders: number;
    qualityScore: number;
    inventoryValue: number;
  }> {
    // Calculate production efficiency (completed orders / total orders in last 30 days)
    const [efficiencyResult] = await db
      .select({
        completed: sql<number>`COUNT(CASE WHEN status = 'completed' THEN 1 END)`,
        total: sql<number>`COUNT(*)`,
      })
      .from(productionOrders)
      .where(sql`${productionOrders.createdAt} > NOW() - INTERVAL '30 days'`);
    
    const efficiency = efficiencyResult.total > 0 
      ? (efficiencyResult.completed / efficiencyResult.total) * 100 
      : 0;

    // Count active orders
    const [activeOrdersResult] = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(productionOrders)
      .where(sql`${productionOrders.status} IN ('pending', 'in_progress', 'ready_for_qc')`);

    // Calculate quality score (pass rate in last 30 days)
    const [qualityResult] = await db
      .select({
        passed: sql<number>`COUNT(CASE WHEN status = 'pass' THEN 1 END)`,
        total: sql<number>`COUNT(*)`,
      })
      .from(qualityControlLogs)
      .where(sql`${qualityControlLogs.createdAt} > NOW() - INTERVAL '30 days'`);
    
    const qualityScore = qualityResult.total > 0 
      ? (qualityResult.passed / qualityResult.total) * 100 
      : 0;

    // Calculate inventory value
    const [inventoryResult] = await db
      .select({
        value: sql<number>`SUM(${inventoryItems.currentStock} * ${inventoryItems.unitPrice})`,
      })
      .from(inventoryItems);

    const inventoryValue = inventoryResult.value || 0;

    return {
      efficiency: Math.round(efficiency * 10) / 10,
      activeOrders: activeOrdersResult.count,
      qualityScore: Math.round(qualityScore * 10) / 10,
      inventoryValue: Math.round(inventoryValue),
    };
  }

  // User preferences operations
  async getUserPreferences(userId: string): Promise<UserPreferences | undefined> {
    const [preferences] = await db.select().from(userPreferences).where(eq(userPreferences.userId, userId));
    return preferences;
  }

  async createUserPreferences(preferences: InsertUserPreferences): Promise<UserPreferences> {
    const [newPreferences] = await db
      .insert(userPreferences)
      .values(preferences)
      .returning();
    return newPreferences;
  }

  async updateUserPreferences(userId: string, preferences: Partial<InsertUserPreferences>): Promise<UserPreferences> {
    const [updatedPreferences] = await db
      .update(userPreferences)
      .set({
        ...preferences,
        updatedAt: new Date(),
      })
      .where(eq(userPreferences.userId, userId))
      .returning();
    return updatedPreferences;
  }
}

export const storage = new DatabaseStorage();
